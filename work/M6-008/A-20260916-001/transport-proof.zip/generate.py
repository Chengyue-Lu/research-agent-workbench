import argparse
import hashlib
import json
import shutil
import subprocess
from datetime import datetime, timezone
from dataclasses import asdict
from pathlib import Path

from research_workbench.execution.baseline_closeout import verify_baseline_receipt
from research_workbench.observability.trace import AgentTraceRecorder, validate_attempt_trace
from tests import test_baseline_execution as execution
from tests.baseline_fixtures import A1, A2, ROOT, BaselineFixture


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())


def ref(root, path):
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description='Generate fresh local scripted A1/A2 proof, never a live run.')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    destination = args.output.resolve()
    destination.mkdir(parents=True, exist_ok=False)
    generated = datetime.now(timezone.utc).isoformat()
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    summary = {'generated_at': generated, 'implementation_commit': head,
               'evidence_kind': 'synthetic-local-transport', 'task_completion': False,
               'source_refs': [], 'cases': []}
    for name in ('baseline.py', 'baseline_envelope.py', 'baseline_closeout.py'):
        path = ROOT / 'src/research_workbench/execution' / name
        summary['source_refs'].append(ref(ROOT, path))
    for name, arm in (('a1', A1), ('a2', A2)):
        project = destination / 'cases' / name
        harness = execution.BaselineExecutionTests()
        harness.f = BaselineFixture(project)
        harness.f.build()
        responses = [execution.response('final')]
        if arm == A2:
            responses.insert(0, execution.response('tool-call', tool=True))
        provider = execution.ScriptedProvider(*responses)
        harness.freeze(provider, arm)
        tool = harness.load_tool() if arm == A2 else None
        result = harness.run_arm(provider, tools=(tool,) if tool is not None else ())
        if not result['replay_valid']:
            raise RuntimeError(result['replay_error'])
        harness.assert_fresh_file_replay(result, implementation=(
            project / harness.f.bindings[A2]['implementation_ref']['path'] if tool is not None else None))
        replay = verify_baseline_receipt(project, result['receipt_ref'],
            expected_envelope_ref=harness.f.envelope_ref, schema_root=ROOT / 'schemas')
        report = validate_attempt_trace(project, project / result['receipt']['trace_index_ref']['path'])
        if report.blocked:
            raise RuntimeError(report.risks)
        summary['cases'].append({'project': project.relative_to(destination).as_posix(),
            'envelope_ref': harness.f.envelope_ref, 'receipt_ref': result['receipt_ref'],
            'status': replay['status'], 'provider_calls': len(provider.requests),
            'cold_replay': 'pass', 'trace_blocked': report.blocked})
    write(destination / 'proof.json', summary)
    # Retained development outputs are an explicitly delayed/gapped export.
    recorder = AgentTraceRecorder(destination / 'development-trace', task_id='M6-008', task_revision=1,
        attempt_id='M6-008-TAKEOVER-20260916', task_snapshot={'task_id': 'M6-008', 'revision': 1,
            'source': 'docs/TASKS.md', 'task_owner': 'Huang Yi',
            'authorization': 'User authorized the current agent to take over M6-008 implementation in PR75.'},
        accountable_owner='Chengyue-Lu (authorized takeover evidence)', actor_id='m6-takeover-agent',
        runtime_identity='codex-development-export', provider='uncaptured-development-provider',
        read_allowlist=['src/research_workbench/execution/**', 'tests/test_baseline*', 'docs/TASKS.md'],
        write_scope=['work/M6-008/**'], tool_allowlist=['retained-local-check'], created_at=generated)
    recorder.record_capture_gap('events', 'Delayed export: initial reads, edits, command setup, original event times and partial tool results were not captured. Timestamps below describe export.', reason_category='capture-failure')
    recorder.record_capture_gap('messages', 'Original provider messages and commentary were not captured; no reconstruction of hidden reasoning or secrets.', reason_category='platform-unavailable')
    for index, name in enumerate(('replay-baseline-red.log', 'focused-fix.log', 'focused-coverage.log', 'edge-coverage.log'), 1):
        path = ROOT / '.rwb/m6-008' / name
        content = path.read_text(encoding='utf-8').replace(str(ROOT), '<checkout>').replace(ROOT.as_posix(), '<checkout>')
        target = destination / 'evidence' / name
        target.parent.mkdir(exist_ok=True)
        target.write_bytes(content.encode())
        payload = {'call_id': f'retained-{index}', 'name': 'retained-local-check', 'arguments': {'evidence': name}}
        recorder.record('tool-attempted', payload)
        recorder.record('tool-result', {**payload, 'status': 'succeeded', 'result_entered_context': True,
            'result': {'exported_file': ref(destination, target), 'retained_output': content,
                       'meaning': 'Successful export; the red test log records expected regression failures.'}})
    recorder.record_attempt_status('safe-paused', reason='Development export is incomplete; synthetic case results are separate.')
    recorder.seal('safe-paused')
    report = validate_attempt_trace(destination, destination / 'development-trace/INDEX.yaml')
    write(destination / 'trace-validation.json', {'blocked': report.blocked, 'risks': [asdict(r) for r in report.risks]})
    if report.blocked:
        raise RuntimeError(report.risks)
    shutil.copyfile(__file__, destination / 'generate.py')
    print(json.dumps({'output': destination.relative_to(ROOT).as_posix(), 'cases': summary['cases'],
                      'development_trace_blocked': report.blocked}, ensure_ascii=False))


if __name__ == '__main__':
    main()
