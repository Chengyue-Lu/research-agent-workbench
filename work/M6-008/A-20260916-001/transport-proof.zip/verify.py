"""Replay the committed synthetic cases without running Provider or Tool code."""

import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

from research_workbench.execution.baseline_closeout import verify_baseline_receipt
from research_workbench.observability.trace import validate_attempt_trace


directory = Path(__file__).resolve().parent
repository = directory.parents[2]
proof = json.loads((directory / 'proof.json').read_bytes())


def audit(event, arguments):
    if event == 'exec' and Path(arguments[0].co_filename).resolve().is_relative_to(directory / 'cases'):
        raise AssertionError('Cold replay imported a case Tool implementation')


sys.addaudithook(audit)
results = []
with patch('research_workbench.execution.baseline.run_baseline_session', side_effect=AssertionError('transport rerun')), \
     patch.object(subprocess, 'Popen', side_effect=AssertionError('process launch')):
    for case in proof['cases']:
        project = directory / case['project']
        receipt = verify_baseline_receipt(project, case['receipt_ref'],
            expected_envelope_ref=case['envelope_ref'], schema_root=repository / 'schemas')
        results.append({'project': case['project'], 'status': receipt['status'],
                        'task_completion': receipt['task_completion']})
report = validate_attempt_trace(directory, directory / 'development-trace/INDEX.yaml')
assert not report.blocked, report.risks
print(json.dumps({'cases': results, 'development_trace_blocked': report.blocked,
                  'development_trace_warnings': [r.code for r in report.risks]}, indent=2))
