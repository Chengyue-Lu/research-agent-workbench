"""Read archived bytes; never import or execute recorded case/checker source."""
import argparse
import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch
from research_workbench.execution.baseline_closeout import verify_baseline_receipt
from research_workbench.observability.trace import validate_attempt_trace
from tests.test_baseline_execution import ScriptedProvider

parser = argparse.ArgumentParser()
parser.add_argument('--schema-root', type=Path, required=True)
args = parser.parse_args()
directory = Path(__file__).resolve().parent
proof = json.loads((directory / 'proof.json').read_bytes())
def audit(event, values):
    if event == 'exec' and Path(values[0].co_filename).resolve().is_relative_to(directory / 'cases'):
        raise AssertionError('Cold replay imported recorded case or checker source')
sys.addaudithook(audit)
results = []
with patch('research_workbench.execution.baseline.run_baseline_session', side_effect=AssertionError('transport rerun')), \
     patch.object(ScriptedProvider, 'generate', side_effect=AssertionError('Provider rerun')), \
     patch.object(ScriptedProvider, 'capabilities', side_effect=AssertionError('Provider observation rerun')), \
     patch.object(subprocess, 'Popen', side_effect=AssertionError('process launch')):
    for case in proof['cases']:
        project = directory / case['project']
        receipt = verify_baseline_receipt(project, case['receipt_ref'],
            expected_envelope_ref=case['envelope_ref'], schema_root=args.schema_root)
        results.append({'project': case['project'], 'status': receipt['status'],
                        'task_completion': receipt['task_completion']})
report = validate_attempt_trace(directory, directory / 'development-trace/INDEX.yaml')
assert not report.blocked, report.risks
print(json.dumps({'cases': results, 'development_trace_blocked': report.blocked,
                  'development_trace_warnings': [r.code for r in report.risks]}, indent=2))
