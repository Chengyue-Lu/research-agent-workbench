def bounded_operation(value):
    return value
