import dataclasses, hashlib, json, subprocess, sys, zipfile
from pathlib import Path
repo=Path(sys.argv[1]); scratch=Path(r'D:\lcy\develop\_assessments\rwb-ci-next-20260920')
kind=sys.argv[2]; attempt=repo/('work/TEST-PERF-002/A-20260920-006' if kind=='fixture' else 'work/TEST-PERF-002/A-20260920-005')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert not attempt.exists(),'never rewrite an existing attempt'
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
base=subprocess.check_output(['git','-C',str(repo),'rev-parse','origin/develop'],text=True).strip()
checks=attempt/'checks'
if kind=='fixture':
 inputs=[scratch/'fixture-cost',scratch/'fixture-docs.log']
 report=(scratch/'fixture-cost/HANDOFF.md').read_text(encoding='utf-8')
 validation=json.loads((scratch/'fixture-cost/summary.json').read_bytes())
 assert sha((repo/'tests/test_ci_plan.py').read_bytes())==validation['source_sha256']
 request='Port independent Git fixture setup optimization, preserve behavior, and prepare a Draft PR'
 scope=['tests/test_ci_plan.py','docs/workstreams/chengyue-lu/TEST-PERF-002/**',attempt.relative_to(repo).as_posix()+'/**']
else:
 inputs=[scratch/'anchor-review',scratch/'anchor-replay',scratch/'anchor-replay-v2',scratch/'anchor-replay-check',scratch/'inventory',scratch/'early-proof']
 inputs += [p for p in scratch.iterdir() if p.is_file() and (p.name.startswith(('anchor-','replay_anchor')) or p.name in {'WORK_PLAN.md','WORKLOG.md','.coverage-anchor-final','.coverage-anchor-related'})]
 report=(scratch/'anchor-results.md').read_text(encoding='utf-8')
 validation=json.loads((scratch/'anchor-validation.json').read_bytes())
 assert sha((repo/'.github/scripts/plan_ci.py').read_bytes())==validation['source_sha256']['.github/scripts/plan_ci.py']
 request='Repair reviewed policy anchor history and inventory unfinished CI work without activating new consumer exclusions'
 scope=['.github/scripts/plan_ci.py','tests/test_ci_plan.py','docs/workstreams/chengyue-lu/TEST-PERF-002/**',attempt.relative_to(repo).as_posix()+'/**']
inputs.append(Path(__file__))
checks.mkdir(parents=True)
files={}
for item in inputs:
 if not item.exists():continue
 for path in ([item] if item.is_file() else item.rglob('*')):
  rel=path.relative_to(scratch)
  if path.is_file() and not set(rel.parts)&{'.git','__pycache__','repo','snapshot','.venv','venv','probe-repo'}:
   files[rel.as_posix()]=path
inventory=[]
with zipfile.ZipFile(checks/'raw-evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for name,path in sorted(files.items()):
  raw=path.read_bytes();archive.writestr(name,raw);inventory.append({'path':name,'bytes':len(raw),'sha256':sha(raw)})
with zipfile.ZipFile(checks/'raw-evidence.zip') as archive:
 assert archive.testzip() is None
 assert all(sha(archive.read(row['path']))==row['sha256'] for row in inventory)
summary={'implementation':head,'base':base,'scope':kind,'validation':validation,'raw_archive_sha256':sha((checks/'raw-evidence.zip').read_bytes()),'raw_members':inventory,'hosted_exact_head_pending':True,'human_review_pending':True,'merged':False}
dump(checks/'validation.json',summary)
sys.path.insert(0,str(repo/'src'))
sys.path.insert(0,str(repo))
import build_backend
build_backend.generate()
from research_workbench.observability.trace import AgentTraceRecorder,validate_attempt_trace
recorder=AgentTraceRecorder(attempt,task_id='TEST-PERF-002',task_revision=43,attempt_id=attempt.name,
 task_snapshot={'task_id':'TEST-PERF-002','revision':43,'request':request,'scope':scope,'delegation':True,'required_skills':[]},
 accountable_owner='Chengyue-Lu',actor_id='main-agent',runtime_identity='Codex desktop',provider='OpenAI',
 read_allowlist=['AGENTS.md','.github/**','tests/**','docs/workstreams/chengyue-lu/TEST-PERF-002/**','work/TEST-PERF-002/**','scoped historical CI prototypes, named source consumers and current PR evidence'],
 write_scope=scope,tool_allowlist=['git','gh','python','shell','collaboration','goal'],baseline=base)
recorder.record_capture_gap('messages','Scoped reports, instructions and raw measurements retain visible work; the complete initial tool and inter-agent stream was not captured. This is not a complete message transcript.')
recorder.record_capture_gap('external-actions','Final exact-head checks, push and PR/Issue publication occur after sealing and are retained externally.')
recorder.record_tool_call(operation_id=kind+'-ci-evidence',tool_name='shell',status='succeeded',arguments={'operation':request},result=summary,result_entered_context=True)
recorder.seal('safe-paused')
validated=validate_attempt_trace(repo,attempt)
dump(checks/'trace-validation.json',{'blocked':validated.blocked,'risks':[dataclasses.asdict(r) for r in validated.risks]})
assert not validated.blocked
(attempt/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n',encoding='utf-8')
(attempt/'RESULTS.md').write_text('# CI follow-up evidence\n\nImplementation `'+head+'`; accepted base `'+base+'`.\n\nThe raw acquisition report below describes its original pre-commit state; source hashes bind it to this implementation. Hosted CI and human acceptance are separate.\n\n'+report,encoding='utf-8')
manifest=[{'path':p.relative_to(attempt).as_posix(),'sha256':sha(p.read_bytes())} for p in sorted(attempt.rglob('*')) if p.is_file()]
dump(checks/'evidence-manifest.json',{'files':manifest})
print(json.dumps({'attempt':str(attempt),'implementation':head,'raw_members':len(inventory),'manifest_files':len(manifest),'trace_blocked':validated.blocked}))
