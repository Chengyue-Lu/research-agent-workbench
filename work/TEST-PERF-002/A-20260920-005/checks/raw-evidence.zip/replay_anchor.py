import hashlib, importlib.util, json, os, subprocess, sys, time
from pathlib import Path
root=Path(r'D:\lcy\develop\_worktrees\RWB\ci-authority-anchor')
accepted_root=Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow')
out=Path(r'D:\lcy\develop\_assessments\rwb-ci-next-20260920\anchor-replay-v2')
out.mkdir(parents=True, exist_ok=True)
repo=out/'repo'
base='171d4654f88e926f239cdf25bc8168109b81f391'
def git(*args):
 return subprocess.check_output(['git','-C',str(repo),*args],stderr=subprocess.PIPE).decode().strip()
if repo.exists(): raise SystemExit('refuse to overwrite existing replay')
subprocess.run(['git','clone','-q','--shared','--no-checkout','-c','user.name=CI replay','-c','user.email=ci@example.invalid','-c','core.autocrlf=false',str(root),str(repo)],check=True)
git('checkout','-q','--detach',base)
sys.path.insert(0,str(root/'.github/scripts'))
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=module('accepted_planner',accepted_root/'.github/scripts/plan_ci.py')
new=module('repaired_planner',root/'.github/scripts/plan_ci.py')
assert (accepted_root/'.github/scripts/plan_ci.py').read_bytes()==subprocess.check_output(['git','-C',str(root),'show',base+':.github/scripts/plan_ci.py'])
cases=[(name,'src/research_workbench/adapters/models/'+name+'.py','self.timeout_seconds = timeout_seconds','self.timeout_seconds = +timeout_seconds') for name in ('openai','anthropic','gemini')]
cases += [('claim','src/research_workbench/artifacts/claim_trace.py','return value.lower().removeprefix("sha256:")','return str.lower(value).removeprefix("sha256:")'),('projection','src/research_workbench/capability/release_projection.py','    return normalized\n','    return normalized.lower()\n')]
rows=[]
for label,path,before,after in cases:
 git('checkout','-q','--detach',base)
 target=repo/path;raw=target.read_bytes().decode();assert before in raw,(label,before)
 target.write_bytes(raw.replace(before,after,1).encode())
 git('add',path);git('commit','-qm','isolated anchor replay '+label);head=git('rev-parse','HEAD');git('tag','probe/'+label,head)
 row={'scenario':label,'path':path,'base':base,'head':head}
 for name,planner in [('accepted',old),('repaired',new)]:
  started=time.perf_counter();p=planner.make_plan(repo,base=base,head=head,target=head,repository='Chengyue-Lu/research-agent-workbench',body='- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no')
  (out/(label+'-'+name+'-plan.json')).write_bytes(planner.canonical(p))
  row[name]={'plan_id':p['plan_id'],'behavioral_scope':p['behavioral_scope'],'coverage_scope':p['coverage_scope'],'test_modules':len(p['tests']),'behavioral_selectors':len(p['tests']),'coverage_selectors':len(p['coverage_tests']),'anchor':p['selection']['reviewed_contract_anchor'],'bounded':p['selection']['reviewed_opaque_boundary'],'smokes':[p['package_smoke'],p['repository_smoke']],'reasons':[s for s in p['reasons'] if 'anchor' in s or 'contract evidence' in s],'plan_seconds':time.perf_counter()-started}
  assert not p['blocked_reasons'],p['blocked_reasons']
 rows.append(row); print(json.dumps(row),flush=True)
(out/'summary.json').write_text(json.dumps({'execution_authority':False,'fresh_execution_performed':False,'source_sha256':{'accepted':hashlib.sha256((accepted_root/'.github/scripts/plan_ci.py').read_bytes()).hexdigest(),'repaired':hashlib.sha256((root/'.github/scripts/plan_ci.py').read_bytes()).hexdigest()},'rows':rows},indent=2)+'\n')
git('bundle','create',str(out/'scenarios.bundle'),'--tags','^'+base)

