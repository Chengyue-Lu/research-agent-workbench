# Independent implementation review — authority anchor restoration

Date: 2026-09-20. Owner: Chengyue-Lu. Profile: CI selection trust reviewer. Skills: []. Worktree: `ci-authority-anchor`; branch `fix/ci-policy-authority-anchor`, base 171d4654f88e926f239cdf25bc8168109b81f391. Reviewed uncommitted plan_ci.py/test_ci_plan.py delta against DESIGN_REVIEW.md. No production edits, policy refresh, test-body changes or PR mutations by reviewer.

## Disposition

**No reproduced material implementation problem found in this bounded review.** The helper implements the recommended continuity barrier and preserves existing consumer/evidence safeguards. Suitable to continue exact-head validation and a separately reviewed Draft PR. This is not production activation or merge approval.

## Design conformance

- `plan_ci.py:54-81`: authority comparison uses canonical JSON with only validated diagnostic `consumer_contracts` removed. All authority fields, JSON types and array ordering remain. Every historical JSON uses `unique_object` and `validate_policy`; malformed JSON, duplicate keys, invalid shapes/records and unknown authority versions cannot be skipped.
- Traversal is `git log --first-parent --full-history --max-count=64` from accepted base. Every visited revision must retain the same mode/type and authority projection. A mismatch returns unavailable immediately, so an older matching digest behind a changed-authority or invalid-policy barrier cannot grant scope. Side ancestry is not scanned. A missing/unmatched history returns unavailable.
- Only an actual historical tree self-matching the accepted policy fingerprint is returned. The fingerprint is never recomputed into policy; the accepted base remains the authority source. The root's current base 171d465 independently resolves to **348d6257ddd28637c9d06abe177fc685ac4368b6** with the actual new helper.
- `plan_ci.py:564-586`: the recovered anchor feeds the existing evidence-closure drift checks for both base and head. The reviewed set still requires before==after==anchor metadata. New consumers lack an anchor entry; changed consumers fail equality. Both ordinary selection and impact-proof selection retain this bounded/reviewed input contract. Import/function-body guards, coverage thresholds and witness authority are untouched.
- The only design wording difference is allowing a consistently regular executable mode 100755 as well as 100644. Every historical mode/type must match current mode; transitions still block. This retains compatibility with the previous data reader and does not execute policy bytes or ignore a mode boundary. No material trust violation was found from that choice.

## Regression review and independent probe

The six new test methods use actual Git history for metadata drift/new consumers, authority A→B→A replay, malformed/duplicate/invalid record barriers, policy deletion/mode restoration, a misleading matching side branch with a real merge, and the 64-revision bound. Missing/unmatched history additionally has narrow failure-injection tests. Existing evidence/helper/fixture guards remain unchanged and the root is retaining their regressions.

Per task instruction, this reviewer did **not repeat the prior eight-test run**. Independently executed only the newly added limit method, which was added after that earlier run:

`PlannerTests.test_anchor_history_limit_fails_closed_without_scanning_older_authority`: **1 PASS in 21.778 s** (21.8135 s including loading). It proves a matching anchor in slot 64 remains available, while one more metadata-only revision makes the search fail closed rather than scanning older authority. Temporary Git test data stayed within the assessment's `probe-temp` directory and was cleaned by the test.

The actual immutable 171d465 lookup was also exercised read-only and recovered 348d625. Evidence: `implementation-limit-probe.log` and `implementation-probe.json`. No full suite, fresh production scenario, coverage instrumentation or external witness was run by this reviewer.

## Acceptance remaining with root

The necessary remaining evidence is the already planned production authority validation: exact final diff/head/base plan, FULL independent witness/bootstrap, applicable quality gates, and current-base good/bad real leaf replays showing unchanged/new/changed consumers and proof drift. Existing reported root tests are not attributed to this reviewer. Broader B/C timing claims require their own fresh measurements. New 2C exclusion contracts and result reuse remain out of scope.

No additional source repair is requested by this review. Recheck the source hashes if the implementation changes before acceptance.

## Reviewed SHA-256

- `.github/scripts/plan_ci.py`: `437a0bb529ca1be0f66ef08a088825f8079ba2b01d3c73c2875eddb27131775e`
- `tests/test_ci_plan.py`: `22f03c47378515c1bab3049611b35117d9e9898a5872a65e883c89ac08b0d68a`
