# Final authority-anchor recheck

Reviewer: independent CI authority reviewer/finalizer; owner Chengyue-Lu; TEST-PERF-002.

No material defect found in the final delta. `ANCHOR_HISTORY_LIMIT = 64` retains the prior production boundary. The shortened regression uses actual first-parent Git history with a patched cap of 2; it proves success with the matching anchor inside the horizon and failure after one additional diagnostic policy commit places it outside. The earlier full-cap regression also passed in the previous independent review. No production default or fail-closed barrier changed in this final delta.

Finalizer edits were spacing only in AUTHORITY_ANCHOR.md and CI_FOLLOWUP_INVENTORY.md. Fresh documentation and horizon regression: 11 PASS, 2.498 seconds. Retained focused execution logs: Python 3.11 200 PASS, 389.110 seconds; Python 3.13 20 PASS, 80.559 seconds. Parent confirmed final coverage collection after the constant/test change, with current planner SHA256 `748dde68d79cb67412ae0c1c3e054de92ffce0387f1985a7a00927018452c406`.

The explicit five implementation/documentation paths were committed as `d973c75083405e427ff8636d9a5a9de9eaf6a3d8`, parent/base `171d4654f88e926f239cdf25bc8168109b81f391`. Clean post-commit checkout, exact source hashes and five-path diff were verified.

Exact-head plan recomputation and verification PASS: plan ID `b34da20d35bf5451149d6cec1423ff2b6ecbf764560393820e24ddd648726a30`, behavioral full on Python 3.11/3.13, coverage impact on `.github/scripts/plan_ci.py`, package/repository smoke both true. The independent witness function loaded from the exact accepted-base Git blob confirms FULL. It proves the selection-authority floor only; this direct function invocation is not a hosted or CLI checkout receipt.

Offline retained raw coverage establishes all 48 changed executable lines and 18 changed outgoing branches, plus planner critical coverage 584/585 lines and 222/224 branches. A new plan-bound native execution receipt does not exist; none was created or rebound. The entire impact execution gate and remaining behavioral/smoke obligations are still outstanding at the new HEAD.

The real leaf replay retains B1398/C1372 on both old/new plans. Restoring anchor identity alone does not establish a speedup. Earlier v2 producer capture and native collection limitations remain explicit in anchor-replay-check/REPORT.md. No new consumer exclusion is approved.

Machine-readable source/artifact hashes and precise results are in `../anchor-validation.json` relative to this review folder; command records and raw logs are in the assessment root. No push, PR change, merge, formal Attempt Archive or other branch mutation was performed by this finalizer.
