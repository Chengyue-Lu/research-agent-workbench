# Minimal reviewed-authority anchor repair — independent design

Owner: Chengyue-Lu. Profile: CI selection trust reviewer. Skills: []. Date: 2026-09-20. Reviewed source HEAD: 4119f8b2d8e1e64a0afead138d13061e2d89e996. Scope: plan_ci/ci_dependencies/selection_witness, existing policy and relevant tests, prior fingerprint audit, Issue87 direction. Read-only; no source/policy modification, test execution, PR mutation or production activation.

## Recommendation

Implement a small **first-parent, continuous authority-epoch anchor resolver** in plan_ci.py, replacing only the single whole-file-history lookup at lines 537-538. Recover a historical matching anchor only while every traversed policy revision retains exactly the accepted base's authority projection. Preserve the original per-consumer and evidence drift logic. Do not refresh the consumer fingerprint or introduce new consumer exclusions.

The current base can recover **348d6257ddd28637c9d06abe177fc685ac4368b6** without admitting the PR86/89 new consumers. Independent read-only inspection found the policy sequence **171d465 → 51dc3ab → 348d625**: all three validate, are mode 100644, and have identical authority projection digest **82aa716f119e761f889c9535d03e26c4f7ec416c0dc3e189ba0b37a3f976239c**. The first two retain the old fingerprint but fail self-match; 348d625 self-matches. Results are in `historical-epoch-check.json`. No test or plan execution was performed in this design check.

## Source-bound design

1. **Trusted inputs:** use only immutable accepted `base`, its already parsed/validated policy, and leaves derived from that policy. `make_plan` validates exact SHAs at 391-393, rejects shallow history at403, and loads base policy at414-417. Candidate policy, local worktree files and optional PR metadata must not supply an anchor or authorize continuity.
2. **Authority projection:** after full `validate_policy`/`validate_consumer_contracts` validation (223-268 /189-220), remove only `consumer_contracts`. Keep **policy_id, version, surfaces, groups, impact_evidence, consumer_fingerprint**. Compare canonical JSON bytes, retaining array order and JSON types. Do not merely compare the fingerprint string or only group coverage. Do not normalize versions, omit optional group fields or drop future unknown fields. v1/v2 version changes remain an authority boundary for this minimal repair.
3. **Traversal:** use the existing replacement-disabled `git` helper (140-144). Traverse newest to oldest **first-parent policy revisions**, including merge results; `git log --first-parent --full-history --format=%H <base> -- <POLICY>` is an appropriate starting point. A small explicit limit, e.g.64 policy revisions, bounds diagnostic cost; exhausting it means no anchor. Do not use `--all`, arbitrary tags, candidate ancestry or unconstrained DAG matches. A commit that appears only on another merge parent must not be selected just because its digest matches.
4. **Each revision:** verify the exact regular data blob/mode (`100644`), parse with `unique_object` to reject duplicate keys, validate the whole policy, and compare its authority projection against accepted base before evaluating fingerprint. Derive the fingerprint with the unchanged `consumer_fingerprint` function (43-51), against that revision's Git tree and the accepted equal leaf inventory.
5. **Stop, never skip:** at the first authority-projection difference, malformed/unsupported policy, deleted/replaced policy path, mode/type problem, missing object/history or bound exhaustion, return unavailable or raise into the existing conservative fallback. Never continue behind a barrier searching for a conveniently matching old digest. On a matching self-fingerprint inside the continuous equal epoch, return that exact immutable commit.
6. **Consumers/evidence unchanged:** retain `contract_evidence` and both anchor-to-base and anchor-to-head `evidence_drift` checks (54-71,545-549), then build reviewed files only from **before == after == anchor metadata** (550-551). Keep import/function-body rejection at529-534. Preserve both dependency selections at555 and582, and record the actual recovered `reviewed_contract_anchor`. Failure leaves `bounded` empty and a clear reason; do not record an unverified latest policy commit as a usable recovered anchor.

The resolver is a Git/accepted-policy identity repair. It needs no AST inference expansion, no changes to ci_dependencies, no new policy schema, no coverage threshold change, and no consumer-record execution authority.

## Why this does not approve new consumers

For any path added after 348d625, the original reviewed-set intersection excludes it because it is absent from the anchor. For an existing path changed after 348d625, the equality check fails. `ci_dependencies.select` preserves unioned old/new edges (623-635), excludes only reviewed opaque consumers for bounded seeds (651-653), then traverses every new/changed consumer and its downstream closure (664-669). Consequently the new harness/runtime/host/trace consumers identified in the prior 11/13-record audit do not become reviewed simply because metadata pins moved.

Proof/helper/fixture changes are even stricter: `evidence_drift` takes the union of both historical/current proof closures, so a changed proof module, helper, new package initializer or fixture-directory member invalidates the affected group boundary before graph filtering. Restoring an anchor cannot suppress these checks. Unchanged consumers already accepted at 348d625 are the only existing exclusion basis being recovered.

## Semantic scan versus explicit pinned authority ref

| Option | Advantages | Material risks / needed guards | Assessment |
| --- | --- | --- | --- |
| Continuous semantic epoch on first-parent history | Repairs existing v2 records without writing policy; preserves exact legacy anchor and original new-consumer guards | Unbounded/DAG scan can resurrect revoked authority or use unrelated history; skipping invalid entries can cross a trust gap; projection omissions may silently ignore real contract edits | Smallest viable repair if all barriers and regressions below hold |
| Explicit `consumer_authority_anchor` exact SHA in accepted policy | Easier reviewer-visible provenance; avoids history search and future whole-file coupling | Requires schema/version migration and review of who may set the ref; must reject candidate/chosen-current/unrelated refs; exact SHA alone does not prove policy equivalence or approval; blindly pointing at current source admits new opaque consumers | Reasonable future representation, not necessary for this bounded restoration |

An explicit ref still needs ancestor/accepted-lineage checks, matching declared fingerprint at the anchor, authority projection agreement, and all current evidence/consumer drift guards. Merely allowing a new JSON field to name any readable commit is weaker than the guarded scan. If chosen later, its creation/update is a separately accepted base-side authority change; candidate metadata cannot make it operative within its own PR.

A scan must stop across **A → B → A** authority history when the latest restoredA revision is not self-matching: it cannot jump over B and reuse the older A anchor. A merge bringing in a matching side-branch policy is not a reviewed mainline anchor until the merged tree itself satisfies the accepted invariant. These are replay/revocation cases, not formatting exceptions.

## Required regression matrix

All history tests should build real small Git repositories; do not prove the new lookup only by mocking consumer_fingerprint or the history list.

| Case | Required result |
| --- | --- |
| Two PR86/89-shaped diagnostic pin-only policy edits after added/changed non-leaf inventory | Recover the original matching anchor; authority projection unchanged; do not refresh policy |
| Same metadata history plus an old unchanged opaque consumer and a new opaque consumer with a real failing relevant case | Old consumer remains within existing reviewed boundary; new consumer and its test remain in behavioral and impact selection |
| Existing opaque consumer changed before base, and one changed only on head | Both remain required; equality with anchor cannot be inferred from base=head alone |
| Existing proof, positive/negative evidence, transitive helper, initializer or literal fixture membership drift | Affected group loses bounded status and ordinary closure returns; reuse existing true failing proof controls |
| Each authority field changes: groups/tests/coverage_tests/change_scope/downstream/smoke flags, surfaces, impact evidence, fingerprint, version | Stop at that revision; no older anchor admitted |
| A → B → A policy replay, latest A fingerprint mismatches its new inventory | Stop at B; cannot reactivate pre-revocation anchor |
| Malformed/duplicate-key/unknown-version/invalid diagnostic record between base and older valid anchor | Unavailable/fail-safe; no skipping invalid history |
| Policy deletion/recreation, rename/type/mode change, unavailable Git object, shallow history and explicit scan limit exhaustion | No boundary granted; existing FULL/ordinary-closure fallback remains visible |
| Matching unrelated branch/tag or matching non-first-parent merge ancestor | Not recovered; only accepted first-parent history examined |
| Candidate edits fingerprint or consumer records while base remains unchanged | Same recovered base anchor or conservative behavior; candidate cannot refresh/re-authorize itself |
| Already self-matching current accepted anchor | Exact unchanged plan selection/obligations except intentionally added diagnostic reason fields, if any |
| Force-full, integration/main/release, stale-base and selection-authority implementation edits | Existing FULL/repository and fixed matrix/witness floor retained |

Extend `PlannerTests.test_reviewed_opaque_contract_is_invalidated_per_consumer` (556+) with real history, while preserving its existing direct fallback assertion. Reuse the contract/proof tests around642-712 and the later helper/membership tests instead of reimplementing their business behavior. Existing dependency tests for removed edges (367), evidence closure (609) and transitive helpers (643) remain relevant baseline coverage; no new AST analyzer behavior is needed.

## Separate Draft PR and acceptance evidence

The change is production selection authority even though it restores an older accepted boundary. The independent witness already includes plan_ci.py in AUTHORITY (`selection_witness.py:17-19`) and requires FULL for changed authority/stale base (97-102). Keep that witness floor unchanged and obtain exact-head bootstrap/quality evidence; do not use the new resolver to reduce its own required review/test proof. Candidate plan self-verification is insufficient.

Before claiming restored precision, compare exact old/new plans on the current 171d465 base for provider, claim-trace and release-projection local edits, plus mixed/changed-proof/new-consumer controls. Retain the actual failing relevant cases and unaffected controls; show B/C overlap and obligations rather than only test counts. Preserve 90/95/90, changed 100/100, negative evidence, ordered execution, fixed aggregates, and fresh integration baselines. Hosted cost reduction remains a later measured result, not implied by the resolver's recovered SHA.

Issue87's current direction distinguishes this inherited production anchor repair from PR92's diagnostic-only scope ([latest comment](https://github.com/Chengyue-Lu/research-agent-workbench/issues/87#issuecomment-5748657713)); the earlier methodology rejects generic syntax-by-syntax patches and requires evidence before exclusion authority. This design changes a stable policy-history invariant, not inference of a new consumer boundary. Keep the repair in its own Draft PR and explicitly identify the two observed metadata-history events; do not inflate them into three independent natural PR experiments. No new 2C consumer-record activation or cross-commit result reuse belongs in this repair.

## Review stop condition

The minimal design is acceptable for implementation/review preparation if the helper respects continuous history, exact authority projection and conservative barriers. Production acceptance remains conditional on the actual code diff, the regression matrix, independent witness/quality checks and human review. This report is design review, not implementation approval or a promise of measured savings.
