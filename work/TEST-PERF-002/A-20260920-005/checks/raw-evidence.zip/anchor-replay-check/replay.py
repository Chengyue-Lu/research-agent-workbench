import hashlib,importlib.util,json,os,shutil,subprocess,sys,time
from pathlib import Path
out=Path(__file__).parent; original=out.parent/'anchor-replay-v2';repo=out/'repo'
base='171d4654f88e926f239cdf25bc8168109b81f391'; anchor='348d6257ddd28637c9d06abe177fc685ac4368b6'
log=[]
def cmd(args,cwd=repo,check=True,env=None):
    p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace');log.append({'args':args,'cwd':str(cwd),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});(out/'commands.json').write_text(json.dumps(log,indent=2)+'\n')
    if check and p.returncode:raise RuntimeError(p.stderr)
    return p
def git(*args):return cmd(['git',*args]).stdout.strip()
if not repo.exists():cmd(['git','clone','--shared','--no-checkout','-q','-c','user.name=CI audit','-c','user.email=ci-audit@example.invalid','-c','core.autocrlf=false',str(original/'repo'),str(repo)],cwd=out)
git('checkout','--detach','-q',base)
source_roots={'accepted':Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow'),'repaired':Path(r'D:\lcy\develop\_worktrees\RWB\ci-authority-anchor')}
expected=json.loads((original/'summary.json').read_text())['source_sha256']; source_hashes={}
for label,src in source_roots.items():
    dest=out/'engines'/label/'.github/scripts';dest.mkdir(parents=True,exist_ok=True)
    for f in (src/'.github/scripts').glob('*.py'):
        (dest/f.name).write_bytes(f.read_bytes())
    (dest.parent/'governance-policy.json').write_bytes((src/'.github/governance-policy.json').read_bytes())
    digest=hashlib.sha256((dest/'plan_ci.py').read_bytes()).hexdigest()
    if label=='accepted':assert digest==expected[label]
    else:assert digest=='748dde68d79cb67412ae0c1c3e054de92ffce0387f1985a7a00927018452c406'
    source_hashes[label]=digest
sys.path.insert(0,str(out/'engines/repaired/.github/scripts'))
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
engines={label:module(label+'_plan',out/'engines'/label/'.github/scripts/plan_ci.py') for label in source_roots}
rows=[]
source_rows=json.loads((original/'summary.json').read_text())['rows']
for row in source_rows:
    head=row['head'];git('checkout','--detach','-q',head)
    for label in engines:
        name=row['scenario']+'-'+label; src=original/(name+'-plan.json');dest=out/(name+'-plan.json');dest.write_bytes(src.read_bytes())
        if not (out/(name+'-inventory.json')).exists():cmd([sys.executable,str(out/'native_inventory.py'),str(repo),str(dest),str(out/(name+'-inventory.json'))])
for label,path,before,after in [('claim-literal','src/research_workbench/artifacts/claim_trace.py','removeprefix("sha256:")','removeprefix("sha256:" + "")'),('projection-binop','src/research_workbench/capability/release_projection.py','len(normalized) != 64','len(normalized) != (32 + 32)')]:
    git('checkout','--detach','-q',base);target=repo/path;raw=target.read_bytes().decode();assert before in raw;target.write_bytes(raw.replace(before,after,1).encode());git('add',path);git('commit','-qm','isolated audit '+label);head=git('rev-parse','HEAD');git('tag','audit2/'+label,head)
    row={'scenario':label,'path':path,'base':base,'head':head,'semantics':'name/call-set preserving equivalent expression'}
    for engine_label,engine in engines.items():
        p=engine.make_plan(repo,base=base,head=head,target=head,repository='Chengyue-Lu/research-agent-workbench',body='- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no');name=label+'-'+engine_label;dest=out/(name+'-plan.json');dest.write_bytes(engine.canonical(p));row[engine_label]={'behavioral_scope':p['behavioral_scope'],'coverage_scope':p['coverage_scope'],'tests':len(p['tests']),'coverage_tests':len(p['coverage_tests']),'anchor':p['selection']['reviewed_contract_anchor'],'bounded':p['selection']['reviewed_opaque_boundary'],'smokes':[p['package_smoke'],p['repository_smoke']]};cmd([sys.executable,str(out/'native_inventory.py'),str(repo),str(dest),str(out/(name+'-inventory.json'))])
    rows.append(row);print(json.dumps(row),flush=True)
# Real relevant behavior control, no injected test replacements or mock changes.
git('checkout','--detach','-q',base)
env=dict(os.environ);env['PYTHONPATH']=os.pathsep.join([str(repo/'src'),str(repo/'tests'),str(repo)])
test='test_provider_adapters.OpenAIAdapterTests.test_text_request_disables_storage_and_maps_usage'
positive=cmd([sys.executable,'-m','unittest',test,'-v'],env=env,check=False);(out/'provider-positive.log').write_text(positive.stdout+positive.stderr)
path='src/research_workbench/adapters/models/openai.py';t=repo/path;raw=t.read_bytes().decode();assert 'self.timeout_seconds = timeout_seconds' in raw;t.write_bytes(raw.replace('self.timeout_seconds = timeout_seconds','raise ValueError("CI intentional timeout-assignment fault")',1).encode());git('add',path);git('commit','-qm','isolated real provider failure control');bad_head=git('rev-parse','HEAD');git('tag','audit/provider-negative',bad_head)
negative=cmd([sys.executable,'-m','unittest',test,'-v'],env=env,check=False);(out/'provider-negative.log').write_text(negative.stdout+negative.stderr)
failure_plan=engines['repaired'].make_plan(repo,base=base,head=bad_head,target=bad_head,repository='Chengyue-Lu/research-agent-workbench',body='- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no');(out/'provider-negative-plan.json').write_bytes(engines['repaired'].canonical(failure_plan))
for p in ['src/research_workbench/adapters/models/__init__.py','src/research_workbench/validation/documents.py','tests/harness_execution_fixtures.py','tests/test_evaluation_harness_execution.py','tests/test_ci_plan.py']:
    result=cmd(['git','diff','--stat',anchor,base,'--',p]);(out/(Path(p).stem+'-anchor-diff.txt')).write_text(result.stdout+cmd(['git','diff','--unified=3',anchor,base,'--',p]).stdout)
git('bundle','create',str(out/'scenarios.bundle'),'--tags','^'+base)
(out/'summary.json').write_text(json.dumps({'execution_authority':False,'engines':source_hashes,'new_scenarios':rows,'provider_control':{'test':test,'positive_target':base,'positive_exit':positive.returncode,'negative_target':bad_head,'negative_exit':negative.returncode,'selected_by_repaired_plan':any(x in test or test.startswith(x+'.') for x in failure_plan['tests'])}},indent=2)+'\n')
print('COMPLETE',flush=True)
