import importlib.util,json,sys,unittest,traceback
from pathlib import Path
repo=Path(sys.argv[1]); plan=json.loads(Path(sys.argv[2]).read_text()); out=Path(sys.argv[3])
sys.path[:0]=[str(repo/'tests'),str(repo/'src'),str(repo),str(repo/'.github/scripts')]
spec=importlib.util.spec_from_file_location('native_runner',repo/'tests/run_unittest_suite.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
result={'target':plan['binding']['target'],'plan_id':plan['plan_id'],'python':sys.version,'execution_performed':False,'method':'original unittest.TestLoader and unchanged runner._canonical_test_id/_inventory'}
for label,key in [('B','tests'),('C','coverage_tests')]:
    loader=unittest.TestLoader()
    try:
        suite=loader.loadTestsFromNames(plan[key])
        raw=list(runner._iter_tests(suite));unique={runner._canonical_test_id(t):t for t in raw}
        inventory=runner._inventory(unittest.TestSuite(unique.values()))
        result[label]={'selectors':len(plan[key]),'loaded_cases_including_duplicate_selectors':len(raw),'unique_cases':len(inventory),'ids':list(inventory),'loader_errors':loader.errors,'failed_test_placeholders':[t.id() for t in raw if isinstance(t,unittest.loader._FailedTest)]}
    except Exception as exc:
        result[label]={'error':repr(exc),'traceback':traceback.format_exc(),'loader_errors':loader.errors}
if all('ids' in result[x] for x in ('B','C')):
    b=set(result['B']['ids']);c=set(result['C']['ids'])
    result.update(intersection=len(b&c),coverage_only=len(c-b),union=len(b|c))
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:({x:y for x,y in v.items() if x not in ('ids','traceback')} if isinstance(v,dict) else v) for k,v in result.items()}))
