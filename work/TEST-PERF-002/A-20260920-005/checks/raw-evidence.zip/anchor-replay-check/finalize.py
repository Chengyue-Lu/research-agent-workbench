import json,hashlib,subprocess,shutil,collections
from pathlib import Path
out=Path(__file__).parent; repo=out/'repo'; base='171d4654f88e926f239cdf25bc8168109b81f391'; anchor='348d6257ddd28637c9d06abe177fc685ac4368b6'
def git(*a):return subprocess.run(['git','-C',str(repo),*a],capture_output=True)
def read(n):return json.loads((out/n).read_text())
p=read('openai-repaired-plan.json'); s=read('summary.json')
rows=[]
for f in sorted(out.glob('*-inventory.json')):
 i=read(f.name);rows.append({'file':f.name,'target':i['target'],'B':i['B']['unique_cases'],'C':i['C']['unique_cases'],'intersection':i['intersection'],'union':i['union'],'loader_errors':len(i['B']['loader_errors'])+len(i['C']['loader_errors'])})
(out/'inventory-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
diff=git('diff','--name-status',anchor,base).stdout.decode();(out/'anchor-base-name-status.txt').write_text(diff)
changed={line.split('\t')[-1]:line.split('\t')[0] for line in diff.splitlines()}
witness=p['selection']['affected_witnesses']; selected=p['selection']['selected']; first=collections.Counter()
for test,chain in selected.items():
 first[next((x for x in chain[1:] if x in changed),'none-in-witness')]+=1
paths=['src/research_workbench/cli.py','src/research_workbench/validation/documents.py','tests/test_evaluation_harness_execution.py','tests/harness_execution_fixtures.py','tests/test_ci_plan.py','tests/test_artifacts_promotion.py']
fanout={'base':base,'anchor':anchor,'plan_id':p['plan_id'],'scope_summary':p['selection']['scope_summary'],'opaque_consumers':len(p['selection']['opaque_consumers']),'affected_paths':len(p['selection']['affected_paths']),'smoke_reasons':p['obligation_reasons'],'witnesses':{x:witness[x] for x in paths if x in witness},'first_changed_or_new_witness_node_since_anchor_counts':dict(first),'note':'Witness paths are one graph traversal witness, not exhaustive causality or permission to exclude tests.'}
(out/'fanout.json').write_text(json.dumps(fanout,indent=2)+'\n')
hashes=[]
for path in ['tests/run_unittest_suite.py','tests/test_provider_adapters.py','.github/scripts/ci_dependencies.py',*paths]:
 for commit in [base,anchor]:
  r=git('show',commit+':'+path);hashes.append({'commit':commit,'path':path,'exit':r.returncode,'sha256':hashlib.sha256(r.stdout).hexdigest() if r.returncode==0 else None})
(out/'scoped-source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
reconstructed=out.parent/'anchor-replay-v2-producer.py.txt'
if reconstructed.exists():
 raw=reconstructed.read_bytes();assert hashlib.sha256(raw).hexdigest()=='437a0bb529ca1be0f66ef08a088825f8079ba2b01d3c73c2875eddb27131775e';(out/'v2-producer-reconstructed.py.txt').write_bytes(raw)
r=git('bundle','verify',str(out/'scenarios.bundle'));(out/'bundle-verify.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
legacy=read('inventory314/openai-repaired-inventory.json')['B']['loader_errors'][0]
report=f'''# Anchor replay independent check

Exact base `{base}`; restored contract anchor `{anchor}`. This is local replay and native inventory evidence, not a hosted timing comparison or merge authority.

## Result

All five frozen v2 old/new plan pairs, plus both new old/new equivalent-expression probes, select **B 1,398 / C 1,372 / intersection 1,372 / union 1,398 / C-only 0 actual native test identities** under Python 3.11.16. All fourteen inventories have zero loader errors. Their 95 behavioral / 114 coverage selectors are not case counts. Tests were collected using original unittest loader and unmodified runner canonical identity helpers; setupClass/test execution was not performed by collection.

Behavior remains focused + impact and both package/repository smoke true. Restoring an immutable anchor does not by itself restore useful precision on current base. No duration reduction is demonstrated here.

## Producer provenance

Frozen v2 plans were copied byte-for-byte, with repaired planner SHA256 `437a0bb529ca1be0f66ef08a088825f8079ba2b01d3c73c2875eddb27131775e`. Its saved producer copy here is **reconstructed from current source by reversing the later two-line constant extraction, then checked against the original digest**; it is not an original contemporaneous capture.

New probes use repaired planner SHA256 `{s['engines']['repaired']}` and accepted planner `{s['engines']['accepted']}`. The repaired change since v2 extracts the existing history limit into ANCHOR_HISTORY_LIMIT. Original v2 plans were not recomputed or relabeled with this producer.

## Remaining expansion

`fanout.json` retains actual graph witnesses and edge kinds. Exact anchor→base diffs show:

* `validation/documents.py` adds two schema kinds, evaluation_harness_plan and evaluation_harness_preflight. Existing provider → models/__init__ → validation/documents → CLI import paths remain broad. models/__init__ itself is unchanged.
* New `tests/harness_execution_fixtures.py` (136 lines) is an opaque-execution consumer and feeds the unchanged `tests/test_ci_plan.py`; new `tests/test_evaluation_harness_execution.py` (375 lines) is another opaque-execution consumer.
* Additional changed witnesses include execution/host.py (13 changed lines), test_agent_trace (+12), test_execution_host (+31), and new harness plan/preflight tests (242/268 lines); their exact diff is retained in remaining-new-consumers.diff.
* The graph intentionally takes each new/changed consumer's whole downstream closure (ci_dependencies.select additions + walk), which can reinclude unchanged consumers. The provider → models/__init__ → execution runner/host → artifact tests witness illustrates remaining package/import propagation.

The first changed/new node in each retained selected-test witness is distributed as `{dict(first)}`. These are traversal witnesses, not a complete causal decomposition. Review semantics of new consumer boundaries and symbol-level imports before narrowing; blanket exclusion is not supported.

Smoke reasons are independently preserved: package `provider-cli` plus affected public CLI; repository `provider-conformance` plus affected repository validation consumer. Both remain true even after provider anchor restoration.

## Additional probes and actual fault control

* Claim prefix `"sha256:"` → `"sha256:" + ""`: target `{s['new_scenarios'][0]['head']}`, no bounded contract old or repaired. Names are preserved, but strict function_body_only compares **complete Call ASTs and string constants**; the call argument AST changes and a new empty string is added. This is conservatism in the guard, not another anchor failure.
* Projection `64` → `(32 + 32)`: target `{s['new_scenarios'][1]['head']}`. Current repaired planner restores anchor348 and bounds release_projection.py; accepted planner does not retain the bound. Yet both select the same 1,398/1,372 cases and both smokes.
* Existing provider test `{s['provider_control']['test']}` passed exact base (exit 0). An isolated source commit `{s['provider_control']['negative_target']}` deliberately raises at the existing timeout assignment. The same unchanged test fails (exit 1, original traceback retained), and repaired plan still selects it. No production logic or tests in owner branches were changed. This is a real source-fault detection control, not whole-suite efficacy proof.

## Preserved limitations and reproducibility

Initial default Python 3.14 collection failed importing test_public_surface because markdown_it was absent; raw inventories with failed-test placeholders remain in inventory314 and are not accepted case counts. A producer-hash mismatch stop and missing governance-policy setup error also remain in initial logs; later complete runs copied required engine metadata and used the existing dependency-complete Python 3.11 environment.

`commands.json`, `inventory-commands.json`, scripts, raw plan/inventory JSON, scoped source hashes, exact diffs, provider logs and verified thin `scenarios.bundle` are retained. The original scenarios.bundle retains imported archive tags and their additional prerequisites; probes-exact.bundle restricts to the eight audited scenario targets and requires only exact base. All mutations/commits live only in this isolated scratch clone. No GitHub changes or full-suite runs were made.
'''
(out/'REPORT.md').write_text(report,encoding='utf-8')
manifest=[]
for f in sorted(out.rglob('*')):
 if f.is_file() and 'repo' not in f.relative_to(out).parts and '__pycache__' not in f.parts and f.name!='SHA256SUMS.txt':manifest.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(out).as_posix())
(out/'SHA256SUMS.txt').write_text('\n'.join(manifest)+'\n')
print(json.dumps({'report_sha256':hashlib.sha256((out/'REPORT.md').read_bytes()).hexdigest(),'bundle_sha256':hashlib.sha256((out/'scenarios.bundle').read_bytes()).hexdigest(),'fanout_counts':dict(first),'files_hashed':len(manifest)}))
