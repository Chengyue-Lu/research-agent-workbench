from pathlib import Path
import subprocess
out=Path(__file__).parent;repo=out/'repo'
paths=['src/research_workbench/execution/host.py','tests/test_agent_trace.py','tests/test_evaluation_harness_plan.py','tests/test_evaluation_harness_preflight.py','tests/test_execution_host.py']
r=subprocess.run(['git','-C',str(repo),'diff','348d6257ddd28637c9d06abe177fc685ac4368b6','171d4654f88e926f239cdf25bc8168109b81f391','--',*paths],capture_output=True);(out/'remaining-new-consumers.diff').write_bytes(r.stdout)
r=subprocess.run(['git','-C',str(repo),'bundle','verify',str(out/'probes-exact.bundle')],capture_output=True);(out/'probes-exact-verify.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
p=out/'finalize.py';text=p.read_text(encoding='utf-8-sig').replace('The bundle requires exact base as prerequisite.','The original scenarios.bundle retains imported archive tags and their additional prerequisites; probes-exact.bundle restricts to the eight audited scenario targets and requires only exact base.').replace('* The graph intentionally takes','* Additional changed witnesses include execution/host.py (13 changed lines), test_agent_trace (+12), test_execution_host (+31), and new harness plan/preflight tests (242/268 lines); their exact diff is retained in remaining-new-consumers.diff.\n* The graph intentionally takes');p.write_text(text,encoding='utf-8')
