# Anchor replay independent check

Exact base `171d4654f88e926f239cdf25bc8168109b81f391`; restored contract anchor `348d6257ddd28637c9d06abe177fc685ac4368b6`. This is local replay and native inventory evidence, not a hosted timing comparison or merge authority.

## Result

All five frozen v2 old/new plan pairs, plus both new old/new equivalent-expression probes, select **B 1,398 / C 1,372 / intersection 1,372 / union 1,398 / C-only 0 actual native test identities** under Python 3.11.16. All fourteen inventories have zero loader errors. Their 95 behavioral / 114 coverage selectors are not case counts. Tests were collected using original unittest loader and unmodified runner canonical identity helpers; setupClass/test execution was not performed by collection.

Behavior remains focused + impact and both package/repository smoke true. Restoring an immutable anchor does not by itself restore useful precision on current base. No duration reduction is demonstrated here.

## Producer provenance

Frozen v2 plans were copied byte-for-byte, with repaired planner SHA256 `437a0bb529ca1be0f66ef08a088825f8079ba2b01d3c73c2875eddb27131775e`. Its saved producer copy here is **reconstructed from current source by reversing the later two-line constant extraction, then checked against the original digest**; it is not an original contemporaneous capture.

New probes use repaired planner SHA256 `748dde68d79cb67412ae0c1c3e054de92ffce0387f1985a7a00927018452c406` and accepted planner `55c21010a31671199908053b7d044355be0fe4cead16ffeb799bc2d5f7057ecb`. The repaired change since v2 extracts the existing history limit into ANCHOR_HISTORY_LIMIT. Original v2 plans were not recomputed or relabeled with this producer.

## Remaining expansion

`fanout.json` retains actual graph witnesses and edge kinds. Exact anchor→base diffs show:

* `validation/documents.py` adds two schema kinds, evaluation_harness_plan and evaluation_harness_preflight. Existing provider → models/__init__ → validation/documents → CLI import paths remain broad. models/__init__ itself is unchanged.
* New `tests/harness_execution_fixtures.py` (136 lines) is an opaque-execution consumer and feeds the unchanged `tests/test_ci_plan.py`; new `tests/test_evaluation_harness_execution.py` (375 lines) is another opaque-execution consumer.
* Additional changed witnesses include execution/host.py (13 changed lines), test_agent_trace (+12), test_execution_host (+31), and new harness plan/preflight tests (242/268 lines); their exact diff is retained in remaining-new-consumers.diff.
* The graph intentionally takes each new/changed consumer's whole downstream closure (ci_dependencies.select additions + walk), which can reinclude unchanged consumers. The provider → models/__init__ → execution runner/host → artifact tests witness illustrates remaining package/import propagation.

The first changed/new node in each retained selected-test witness is distributed as `{'src/research_workbench/validation/documents.py': 74, 'tests/test_agent_trace.py': 1, 'src/research_workbench/execution/host.py': 9, 'tests/harness_execution_fixtures.py': 7, 'tests/test_evaluation_harness_execution.py': 1, 'tests/test_evaluation_harness_plan.py': 1, 'tests/test_evaluation_harness_preflight.py': 1, 'tests/test_execution_host.py': 1}`. These are traversal witnesses, not a complete causal decomposition. Review semantics of new consumer boundaries and symbol-level imports before narrowing; blanket exclusion is not supported.

Smoke reasons are independently preserved: package `provider-cli` plus affected public CLI; repository `provider-conformance` plus affected repository validation consumer. Both remain true even after provider anchor restoration.

## Additional probes and actual fault control

* Claim prefix `"sha256:"` → `"sha256:" + ""`: target `0df4839c1a5470b13942c41c77ae9c368fdef090`, no bounded contract old or repaired. Names are preserved, but strict function_body_only compares **complete Call ASTs and string constants**; the call argument AST changes and a new empty string is added. This is conservatism in the guard, not another anchor failure.
* Projection `64` → `(32 + 32)`: target `4c192599230a930d3d2d1f05e88f98d3472f2b6e`. Current repaired planner restores anchor348 and bounds release_projection.py; accepted planner does not retain the bound. Yet both select the same 1,398/1,372 cases and both smokes.
* Existing provider test `test_provider_adapters.OpenAIAdapterTests.test_text_request_disables_storage_and_maps_usage` passed exact base (exit 0). An isolated source commit `a560c261b139c077682cf94eb6d6a87a726a0e3b` deliberately raises at the existing timeout assignment. The same unchanged test fails (exit 1, original traceback retained), and repaired plan still selects it. No production logic or tests in owner branches were changed. This is a real source-fault detection control, not whole-suite efficacy proof.

## Preserved limitations and reproducibility

Initial default Python 3.14 collection failed importing test_public_surface because markdown_it was absent; raw inventories with failed-test placeholders remain in inventory314 and are not accepted case counts. A producer-hash mismatch stop and missing governance-policy setup error also remain in initial logs; later complete runs copied required engine metadata and used the existing dependency-complete Python 3.11 environment.

`commands.json`, `inventory-commands.json`, scripts, raw plan/inventory JSON, scoped source hashes, exact diffs, provider logs and verified thin `scenarios.bundle` are retained. The original scenarios.bundle retains imported archive tags and their additional prerequisites; probes-exact.bundle restricts to the eight audited scenario targets and requires only exact base. All mutations/commits live only in this isolated scratch clone. No GitHub changes or full-suite runs were made.
