import json,subprocess,sys
from pathlib import Path
out=Path(__file__).parent; original=out.parent/'anchor-replay-v2';repo=out/'repo'
commands=[]
for row in json.loads((original/'summary.json').read_text())['rows']:
    subprocess.run(['git','-C',str(repo),'checkout','-q','--detach',row['head']],check=True)
    for label in ('accepted','repaired'):
        name=row['scenario']+'-'+label;src=original/(name+'-plan.json');dest=out/(name+'-plan.json');dest.write_bytes(src.read_bytes())
        args=[sys.executable,str(out/'native_inventory.py'),str(repo),str(dest),str(out/(name+'-inventory.json'))]
        p=subprocess.run(args,capture_output=True,text=True);commands.append({'args':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});print(name,p.returncode,p.stdout[:150],flush=True)
(out/'inventory-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
