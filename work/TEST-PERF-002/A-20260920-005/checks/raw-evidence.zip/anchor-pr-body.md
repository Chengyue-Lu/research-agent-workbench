## 治理元数据

- **PR 类型**: feature
- **任务 ID**: TEST-PERF-002
- **风险等级**: R2
- **责任人**: @Chengyue-Lu
- **工作流目录**: docs/workstreams/chengyue-lu/TEST-PERF-002

## Scope and non-goals

仅更新诊断 consumer 记录也会移动整份 policy 的最近 Git 提交；旧 reviewed fingerprint 因此在错误的历史快照上校验，导致已接受的局部边界失效。本 PR 沿第一父链查找同一连续 authority epoch 中的匹配锚点。最多检查 64 个 policy 修订；遇到权威语义变化、无效 policy、删除/类型/模式变化或不可用历史即保守退回。

从 accepted develop `171d4654f88e926f239cdf25bc8168109b81f391` 独立起步，实现 `d973c75083405e427ff8636d9a5a9de9eaf6a3d8`。只将合法且 `execution_authority=false` 的 consumer 诊断记录排除在 authority 比较之外。新增/变化消费者与 proof drift 仍逐项扩大范围，不刷新任何 fingerprint。

## 契约与权威影响

- **共享契约**: yes
- **权威、权限或数据边界**: yes

属于 R2 生产 planner 修复。保留独立 base-side witness、selection authority 修改需 FULL、两个固定 aggregate、global90%、critical95/90、changed100/100、负证据以及 integration fresh baseline。本次没有新增排除契约。

## TASKS transition

none；沿用 TEST-PERF-002。

## Verification evidence

- 最终源码相关回归：Python3.11 **200 PASS / 389.110s**，Python3.13 专项 **20 PASS / 80.559s**。文档检查通过。
- 原始工作区 coverage：planner **584/585 statements、222/224 branches**；提交 diff 的 **48 个 executable lines / 18 个 outgoing branches 全覆盖**。没有原生 exact-new-head receipt；这些是源文件 hash 一致的本地范围证据，当前 HEAD hosted CI 单独执行。
- 实现提交的 exact-head plan/verify 通过；从 accepted base Git blob 加载的独立 witness 通过。计划仍要求 full behavioral 与 planner impact，两个 smoke 保留。
- 14 份真实原生 inventory 均无 loader error：当前 base 的 B=1398、C=1372、交集=1372。历史锚点恢复，但新/变化消费者仍重新展开下游，**没有案例数或缩时收益声明**。
- 现有 Provider 案例在基线通过，在独立 clone 的 timeout 赋值处故意抛错后失败，且仍在候选计划内。未修改业务分支。
- Trace 无 BLOCK，保留 capture-gap warning。原始失败/配置错误、旧 producer 的重建来源和未通过的默认 Python3.14 collection 均如实保存，不计为成功证据。

入口：`docs/workstreams/chengyue-lu/TEST-PERF-002/AUTHORITY_ANCHOR.md`；CI 待办盘点：`CI_FOLLOWUP_INVENTORY.md`（同目录）；证据：`work/TEST-PERF-002/A-20260920-005/RESULTS.md`。

## Authority basis

用户授权推进 Issue #87 的 CI 修复并盘点可启动项；本 PR 单独修复已确认的 authority-anchor 缺陷。请求 @let778750-cpu cross-owner review，不自行合并。

## Adversarial evidence

真实 Git 历史覆盖：诊断更新后新增 opaque consumer、已知 consumer 变化、authority A→B→A、重复键/畸形 policy、诊断 authority 注入、删除/模式/符号链接、第二父链伪匹配、缺失历史和扫描上限。未匹配或不连续时保守保留原范围。上限测试使用真实三提交历史及注入的 cap=2，生产上限仍为64，避免每轮全量额外构造64次提交。

## Residual risk and follow-up

当前锚点之后的 consumer 变化仍可能形成大范围闭包；95 条 selected-test witness 中，74 条的首个变化节点是 `validation/documents.py`。后续需要审查具名 reader/symbol 边界，不能把新增 schema kind 简单忽略。64 次上限耗尽会保守扩测；它不会授予更窄范围。

本 PR 与 #91/#92 的诊断接受链、#93 的 fixture 内部优化独立。2C 激活和完全相同 CI 复用仍按各自前置条件审查。

Refs #87.
