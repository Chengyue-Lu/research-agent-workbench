# Expanded CI continuation — 2026-09-20

Owner Chengyue-Lu; workstream TEST-PERF-002; Issue87. The user authorized PR91 Ready, continued PR92 readiness, additional bounded CI repairs and an inventory of unstarted work. No merge is authorized.

1. PR91 is now Ready, requested cross-owner review remains pending. PR92 current head4119 is hosted-green; retain dependency and review requirements.
2. Publish fixture-clone process reduction as its own Draft PR from accepted171d465. Preserve fixture independence and all existing test cases; do not claim hosted time savings from shared-machine timings.
3. Publish authority-anchor repair as its own Draft PR from accepted171d465. Preserve authority epoch barriers and new-consumer obligations. Actual replay shows restored anchor but no current case-count reduction.
4. Implement runner early rejection in a separate branch based on pending PR92. Preserve B-before-C and fixture semantics. Publish only after meaningful local verification; label pending dependency.
5. Update Issue87 with the 12-item backlog, current evidence and staged next steps. Inventory priorities include named-reader precision, documents.py fanout, schema/fixture setup costs, domain diagnostic acceptance, and dormant identical-CI reuse. Existing source/coverage obligations remain authoritative.

Ready-for-merge requires current accepted base, current-head checks, resolved blocking findings, prescribed human acceptance and honest provenance. CI/agent review cannot supply human acceptance. No activation of 2C reductions or identical-result skipping is implied.

The goal API retains the earlier unfinished blocked goal and cannot replace or expand it. This plan and the updated existing pr92-ready heartbeat carry the resumed, expanded work; do not falsely complete the old goal merely to replace it.

All work occurs in isolated CI branches. The primary develop checkout and business-owner branches remain outside write scope. Frozen artifacts are immutable. Trace gaps are retained explicitly.
