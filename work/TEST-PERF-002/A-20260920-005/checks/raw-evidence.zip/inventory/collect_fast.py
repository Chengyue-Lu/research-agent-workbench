import json,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent;REPO=Path('D:/lcy/develop/_worktrees/RWB/ci-consumer-shadow')
def git(*args,cwd=REPO):
    p=subprocess.run(['git',*args],cwd=cwd,capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr;return p.stdout.strip()
base=json.loads((OUT/'accepted-develop.json').read_bytes())['object']['sha']
prs=json.loads((OUT/'ci-prs.json').read_bytes())
def tree(ref):
    data={}
    for line in git('ls-tree','-r',ref).splitlines():
        meta,path=line.split('\t',1);mode,kind,oid=meta.split();data[path]=oid
    return data
accepted=tree(base);metadata=[]
for name in ('ci-execution-contexts','ci-fresh-read-cost','ci-identical-reuse','ci-input-propagation','ci-internal-cost','ci-invocation-proof','ci-local-boundaries','ci-round2-costs','ci-schema-parse-cost'):
    path=REPO.parent/name;head=git('rev-parse','HEAD',cwd=path);merge=git('merge-base',base,head);branch=git('branch','--show-current',cwd=path);candidate=tree(head)
    changed=git('diff','--name-only',merge,head).splitlines()
    comparisons=[{'path':file,'same_blob_as_accepted':file in accepted and accepted.get(file)==candidate.get(file),'exists_in_accepted':file in accepted,'accepted_blob':accepted.get(file),'branch_blob':candidate.get(file)} for file in changed]
    row={'worktree':str(path),'branch':branch,'head':head,'status':git('status','--short',cwd=path),'accepted_develop':base,'merge_base':merge,'ahead_behind':git('rev-list','--left-right','--count',base+'...'+head),'unique_subjects':git('log','--format=%H %s',base+'..'+head).splitlines(),'cherry':git('cherry',base,head).splitlines(),'changed_files':comparisons,'matching_prs':[p for p in prs if p['headRefName']==branch]};metadata.append(row)
    print(json.dumps({'branch':branch,'head':head,'status':row['status'],'ahead_behind':row['ahead_behind'],'subjects':row['unique_subjects'],'different_code':[f['path'] for f in comparisons if not f['same_blob_as_accepted'] and not f['path'].startswith(('work/','docs/'))],'new_notes':[f['path'] for f in comparisons if not f['same_blob_as_accepted'] and f['path'].startswith('docs/workstreams/')],'prs':row['matching_prs']},ensure_ascii=False),flush=True)
(OUT/'worktree-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
