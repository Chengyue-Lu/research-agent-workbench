# CI待办盘点与可启动切片

Owner: Chengyue-Lu；2026-09-20；只读盘点，`execution_authority=false`。

接受基线以线上 `develop=171d4654f88e926f239cdf25bc8168109b81f391` 为准。本地develop的11c3b57不作为已接受authority。PR91已由root转Ready（09c6cb1/base171d465未变），PR92仍Draft（4119f8b）。

## 去重与状态判定

PR85已于2026-09-17合并。其9f27c19与当前accepted develop的planner、typed-input、contract-shadow和consumer-record四个实现文件Git blob完全相同。旧分支ahead包含squash前祖先，不能据此算作未实现；不同policy/coverage文件还包含后来M5已接受变化，不能用旧文件覆盖。

九个指定CI worktree均clean，当前PR列表没有它们的独立PR。它们是叠加链，建议从新accepted-base分支取最小增量，不整链重放旧PR85。分支名中的execution-contexts仅是coverage.py诊断，并不是已经实现的RuntimeResources operation context。

下述既有通过数来自精确commit的归档说明；本轮未重跑旧实验。性能比均保留局部/全量、cold/warm、hosted/local边界。

## 建议立即推进的顺序

1. root已启动authority-anchor恢复，作为独立生产权威修复。
2. 并行准备单一diagnostic JSON/归档consumer闭包和早期impact可行性诊断。
3. 优先移植已有Git fixture小改动；fresh-read和批量Git检查再分片review。
4. 继续PR91/92接受链；单条文档2C、YAML冷路径和完全相同CI复用分别保持独立验收。

## 逐项状态与行动

### ANCHOR / P0 — 恢复既有 reviewed closure 的 authority anchor

状态：root 已启动隔离实现。

已完成：PR86/89仅更新diagnostic consumer pins却移动整文件anchor；旧fingerprint失配，5个既有leaf边界停用。最新真实控制B1412/C1386，历史PR85有B15/C15与B81/C34窄计划。

仍缺：语义authority anchor、逐consumer drift、新增opaque消费者保留、跨base兼容及独立witness回归；当前base exact-head质量与review。

依赖与authority：恢复已接受的生产最小范围，不属于2C新增排除。不能直接刷新digest把新消费者当已reviewed。

收益及不确定性：可能恢复局部源码的小范围计划；历史窄集合不是当前base收益证明。

现在可启动：继续 ci-authority-anchor / fix/ci-policy-authority-anchor；先差分现有5个边界及新增/修改消费者负例，再独立PR。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/issues/87#issuecomment-5748657713)；[ref2](https://github.com/Chengyue-Lu/research-agent-workbench/blob/4119f8b2d8e1e64a0afead138d13061e2d89e996/docs/workstreams/chengyue-lu/TEST-PERF-002/RISK_LEDGER.md)

### TYPED-INPUTS / P0 — 诊断 JSON / 固定归档的数据输入闭包

状态：已诊断，未实现生产边界。

已完成：PR92唯一unknown-surface FULL来源domain-model.json；PR90有42个归档数据/元数据触发FULL/repository。2A inventory与2B比较器已保留真实消费者、mode和未知项。

仍缺：JSON/schema/archival hash/ref/目录成员的真实consumer输入声明；add/delete/rename、脚本与runtime/catalog反例；base接受与witness。

依赖与authority：不能docs/后缀blanket skip；运行消费、full inventory、CLI/shared initializer保留跨域；与anchor修复分PR。

收益及不确定性：这是消除doc/archive全业务运行的直接候选，收益较大但没有新基线hosted证明。

现在可启动：从domain-model.json一个具名diagnostic输入开始，审计读者及不变执行输入，形成仅诊断的正反replay；再讨论已接受最小契约。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/blob/4119f8b2d8e1e64a0afead138d13061e2d89e996/docs/workstreams/chengyue-lu/TEST-PERF-002/RISK_LEDGER.md)；[ref2](https://github.com/Chengyue-Lu/research-agent-workbench/blob/4119f8b2d8e1e64a0afead138d13061e2d89e996/docs/workstreams/chengyue-lu/TEST-PERF-002/CI_REPLAN_ACCEPTANCE.md)；[ref3](https://github.com/Chengyue-Lu/research-agent-workbench/issues/87#issuecomment-5744876877)

### EARLY-PROOF / P0 — 昂贵执行前检查 impact 证明是否可成立

状态：失败根因已留证，流程尚未实现。

已完成：PR90在37m24s测试后因归档export_capture.py缺impact证据失败；真实provider负对照81行为全过仍被changed guard coverage阻断。

仍缺：廉价计划/收集/subject/acceptance映射、source pin与可测量入口诊断；哪些缺口可早阻断需明确，真正coverage仍以执行为准。

依赖与authority：预检不能静态宣称coverage成功，也不能覆盖缺失subject或negative acceptance。

收益及不确定性：减少注定失败的长跑成本，不能减少有效的必要证明；尚无节时统计。

现在可启动：设计预检报告并重放归档缺失proof与已覆盖正例；先报告不更改workflow Gate。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/issues/87#issuecomment-5748657713)；[ref2](https://github.com/Chengyue-Lu/research-agent-workbench/issues/87#issuecomment-5744876877)

### READY-2B / P0 — 完成PR91依赖和PR92诊断协议接受

状态：PR91 Ready；PR92 Draft。

已完成：PR91 head09c6cb1已转Ready，未merge。PR92 head4119f8b有文档325→252共同driver pair、真实impact/smoke81/34 pair、真实coverage/fixture/skip/argv/smoke错误反例。

仍缺：PR91接受后PR92 rebase/revalidate；最终head CI、cross-owner review和未解决comment核对；报告本身不授权merge。

依赖与authority：PR92的诊断协议Ready与2C激活条件分开；不能因缺3hosted pairs永远阻塞仅诊断PR，也不能因本地pair通过激活。

收益及不确定性：提供可审核证据链；协议合入本身没有生产缩时。

现在可启动：跟进PR91审核与PR92当前head检查；依赖接受后只做必要rebase及exact-head验证。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/pull/91)；[ref2](https://github.com/Chengyue-Lu/research-agent-workbench/pull/92)；[ref3](https://github.com/Chengyue-Lu/research-agent-workbench/blob/4119f8b2d8e1e64a0afead138d13061e2d89e996/docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_SHADOW_READINESS.md)

### DOCS-ACTIVATION / P1 — 单条workstream文档consumer的2C减测试点

状态：已有本地实际对照，未激活。

已完成：73 PlannerTests、19 pins、modified-existing docs/workstreams范围已审计；完整325与252各PASS，单local pair323.008→59.492s；Cnone、smoke不要求。

仍缺：独立不可被candidate改写的exclusion witness；input/environment闭包；schema/worker/aggregate兼容与rollback；至少3fresh同环境hosted pairs。

依赖与authority：不推广到rootREADME、JSON、archive可执行、新增/删除或别的业务consumer；C与smoke原义务保持。

收益及不确定性：本地单观察81.58%不能当hosted收益；该边界确有较大case成本潜力。

现在可启动：依赖2A/2B接受后准备独立witness设计与攻击矩阵；启动hosted前冻结driver/env/原始receipt要求。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/blob/4119f8b2d8e1e64a0afead138d13061e2d89e996/docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_SHADOW_READINESS.md)；[ref2](https://github.com/Chengyue-Lu/research-agent-workbench/issues/87#issuecomment-5748490147)

### GIT-FIXTURE / P1 — 移植已验证的Git fixture进程优化

状态：本地实现完成，未开PR。

已完成：132dffe将3次fixture git config合入clone -c；74PASS；24-clone中位7.920→5.999s，24行为case51.546→49.139s，首轮变慢也保留。

仍缺：在accepted develop新分支只移植本切片、重新确认所有现有test AST/fixture隔离与当前exact-head证据；hosted成本未知。

依赖与authority：只改测试setup，不改生产selector/阈值/执行receipt；不能整条旧分支重复引入PR85或覆盖后来policy。

收益及不确定性：局部行为4.67%、fixture24.26%历史实测；新机器/完整CI收益待复验。

现在可启动：可立即从132dffe抽取最小fixture提交至新accepted-base分支，检查74及新增当前测试的生命周期并准备Draft。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/blob/132dffe9e5c2cf47b0bf1f5531a89c7381ba3f01/docs/workstreams/chengyue-lu/TEST-PERF-002/INTERNAL_COST_20260917.md)

### FRESH-COST / P1 — 迁移单次新鲜lstat与批量exact-commit校验

状态：本地实现及完整质量证据完成，未开PR。

已完成：d94d470及后续9d39af6修正有双Python各1375项、global94.13%、55critical95/90、impact100/100、repository186/0/0与8安装PASS；原replay/planner三对降低7.37%/6.29%。

仍缺：两个功能拆分review、基于新base复验；POSIX权限/无权限symlink环境与hosted性能仍缺。旧pin刷新必须按当前anchor规则处理。

依赖与authority：每次仍新鲜lstat/commit检查；不缓存可变路径通过或HEAD成功。planner改动是selection authority，保留full bootstrap/witness。resources改动需对应ownerreview。

收益及不确定性：减系统调用和Git启动，单案例收益已观察；旧完整运行并发，不能推全CI加速比。

现在可启动：先独立移植生产bytes与必要反例；将资源路径与planner batch拆成reviewable切片，避免叠入全部旧实验。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/blob/96a26dbb94453e01e7be15e39c0c4bb5080d3072/docs/workstreams/chengyue-lu/TEST-PERF-002/FRESH_READ_COSTS.md)

### YAML-PARSE / P2 — 相同已读YAML字节的解析模板复用

状态：完整本地候选，冷路径问题待解释。

已完成：b76e847/93a5019：691输入冷/热差分一致，22回归，双Python各1397项、global94.15%、impact/critical/smoke通过；replay三对降低20.63%。

仍缺：Skill冷案例稳定回退3.37%未解释；并发策略变化/压力和真实RSS上限未实测；新base兼容及hosted成本待证。

依赖与authority：每次重新读取bytes，私有LRU返回deepcopy；不缓存完整性成功或可变bytearray；C后端16个兼容反例已拒绝，不再算待实现优化。

收益及不确定性：重复YAML热点可能获益，冷路径可能更慢；32MiB raw key上限不是RSS上限。

现在可启动：先对冷/重复负载复核guard/复制/内存成本，再决定是否拆出Draft；不要以完整旧PASS忽略冷回退。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/blob/31d237a7b5f6ea49d24e515718a359306682c99b/docs/workstreams/chengyue-lu/TEST-PERF-002/YAML_PARSE_COSTS.md)

### INPUT-DIAGNOSTICS / P2 — coverage contexts与具体调用输入包

状态：工具/隔离实验完成，未提交生产使用。

已完成：7798251 opt-in contexts六回归+三对33cases，原line/arcs/order一致；41c70fe原runner17项三/七文件capsule正负对照；testmon资源/子进程/环境漏选与生命周期差异已保留。

仍缺：更昂贵consumer样本、Linux/Pants原命令实验、完整外部输入闭包和hosted成本。轻量17cases下testmon warm比原CLI慢15.7%。

依赖与authority：observed contexts不是未观察路径不存在；setup/import空context、opaque/resource输入保守。不能改用pytest顺序替代原ordered producer。

收益及不确定性：能提高归因精度，contexts增加约2.24%producer/6.35%含export成本；没有直接缩时。

现在可启动：保存最小诊断adapter供按需使用；如有Linux runner，先在独立capsule上验证Pants adhoc原命令，选重consumer才评估缓存收益。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/blob/779825110aabe543230475b0f7b7a016d97cc54a/docs/workstreams/chengyue-lu/TEST-PERF-002/COVERAGE_CONTEXT_DIAGNOSTICS.md)；[ref2](https://github.com/Chengyue-Lu/research-agent-workbench/blob/41c70fea9af466fe2b8b3c2a7ffa4c05e1422d87/docs/workstreams/chengyue-lu/TEST-PERF-002/INVOCATION_INPUT_PROOF.md)；[ref3](https://github.com/Chengyue-Lu/research-agent-workbench/blob/916750e2dc77dc36afef22b9a807ece540b39107/docs/workstreams/chengyue-lu/TEST-PERF-002/ROUND2_COSTS.md)

### FIXTURE-BOUNDARY / P2 — baseline execution/replay共享fixture抽取

状态：本地实现和故障证明完成，未开PR。

已完成：ad1313b/473586c保留18+19身份37PASS；相同execution test-body变更选择11→10模块，唯一减少replay；故意错误仍失败。

仍缺：accepted-base重新验证、完整改动本身的充分CI和ownerreview；9个CI模块的输入扩散仍存在。

依赖与authority：helper改变仍92/95与smokes；提取本身不授权消费者排除。业务语义owner共同审查，不能删真实transport/replay故障。

收益及不确定性：证明边界更清楚，只有一模块选择减少；没有全CIwall收益。

现在可启动：从ad1313b抽最小helper切片供独立Draft，后续对9个CI consumer用2B协议审计。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/blob/473586c0d687af89136a46170a8572589ca31f09/docs/workstreams/chengyue-lu/TEST-PERF-002/BASELINE_FIXTURE_BOUNDARY.md)

### IDENTICAL-REUSE / P2 — 完全相同CI执行证据复用

状态：dormant比较器及环境采集器已有原型。

已完成：8c79a6c分支：11对抗回归；99/99 lines、50/50 branches；真实local producer一次后校验原receipt。PR85两success run同plan但缺原环境attestation，正确拒绝reuse。

仍缺：可信producer attestation、原run/job/artifact认证和有效期/撤销、完整runtime/actions/image/dependency/command闭包、独立verifier、worker/aggregatefallback；跨commit坐标合并另案。

依赖与authority：不能把candidate JSON一致性当认证；integration/explicit fresh继续执行；reused事实不能重新标为fresh PASS。

收益及不确定性：已观测重复run1599s job和是理论上限而非收益；命中率及真实bootstrap/materialization成本未知。

现在可启动：先设计并只采集新hosted producer的完整执行环境与出处，不接skip；保留原型复验接口，缺任何binding继续执行。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/blob/8c79a6c2df10b9f34cf6fcedd2cafd0df856b96f/docs/workstreams/chengyue-lu/TEST-PERF-002/IDENTICAL_EXECUTION_REUSE.md)

### FULL-HOTSPOTS / P2 — 其余必要full内部成本和业务族迁移

状态：热点已测；没有完整冗余test获准删除。

已完成：ROUND2原full1364、1314s，前4热点case42.9%；schema self-check exact-bytes cache已在accepted基础，原单test63.7%局部收益；重复work主要Git/资源/解析而非coverage JSON导出。

仍缺：operation-scoped资源上下文、必要scenario/checkpoint合并、M4/M6/M11/M14/C06–C14真实正负案例迁移；各自API/初始化/权限/账本/fresh-read等价证明。

依赖与authority：H3/H4约46.49%case成本由RWB开发(3)业务owner负责；不在CI窗口改业务实现。无完整test被证明可删；schema deepcopy更慢及C YAML不兼容均已否决。

收益及不确定性：可能削减必要full时间，但没有全局成本承诺；保留distinct faults和ordered B/C。

现在可启动：用最新receipt重排热点，给业务owner具体profile问题；CI窗口优先上述已证实进程/输入债务，而非重复引入现有cache或通用AST特例。

依据：[ref1](https://github.com/Chengyue-Lu/research-agent-workbench/blob/916750e2dc77dc36afef22b9a807ece540b39107/docs/workstreams/chengyue-lu/TEST-PERF-002/ROUND2_COSTS.md)；[ref2](https://github.com/Chengyue-Lu/research-agent-workbench/blob/4119f8b2d8e1e64a0afead138d13061e2d89e996/docs/workstreams/chengyue-lu/TEST-PERF-002/FULL_SUITE_COST.md)；[ref3](https://github.com/Chengyue-Lu/research-agent-workbench/blob/4119f8b2d8e1e64a0afead138d13061e2d89e996/docs/workstreams/chengyue-lu/TEST-PERF-002/CI_REPLAN_ACCEPTANCE.md)

## 九个worktree的精确身份

| 工作树 | HEAD | 状态 | 自原PR85 head后的提交数 |
| --- | --- | --- | ---: |
| ci-execution-contexts | `779825110aabe543230475b0f7b7a016d97cc54a` | clean | 4 |
| ci-fresh-read-cost | `96a26dbb94453e01e7be15e39c0c4bb5080d3072` | clean | 10 |
| ci-identical-reuse | `8c79a6c2df10b9f34cf6fcedd2cafd0df856b96f` | clean | 5 |
| ci-input-propagation | `590ee6d35917c1c6408ace523a858255ce9c39df` | clean | 3 |
| ci-internal-cost | `132dffe9e5c2cf47b0bf1f5531a89c7381ba3f01` | clean | 1 |
| ci-invocation-proof | `41c70fea9af466fe2b8b3c2a7ffa4c05e1422d87` | clean | 5 |
| ci-local-boundaries | `473586c0d687af89136a46170a8572589ca31f09` | clean | 2 |
| ci-round2-costs | `916750e2dc77dc36afef22b9a807ece540b39107` | clean | 6 |
| ci-schema-parse-cost | `31d237a7b5f6ea49d24e515718a359306682c99b` | clean | 13 |

完整Git subjects、diff文件名、与accepted blob比较、patch-id及PR匹配见 `worktree-metadata.json`。`issue87.json`、`accepted-develop.json`、`ci-prs.json`保留取证时点的原始read-only响应。Issue正文中PR85尚未合并等旧状态已被后续comments和live refs覆盖。

盘点未执行测试、未改生产policy、未操作业务分支、未发布评论或改变PR状态。建议行动由root选择及执行。
