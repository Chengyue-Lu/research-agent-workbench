import hashlib,json,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
REPO=Path('D:/lcy/develop/_worktrees/RWB/ci-consumer-shadow')
def command(args,cwd=REPO):
    p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')
    return {'argv':args,'cwd':str(cwd),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
def gh(name,args):
    p=command(['gh',*args]);(OUT/(name+'.json')).write_text(p['stdout'],encoding='utf-8');assert p['exit_code']==0,p
    return json.loads(p['stdout'])
def git(*args,cwd=REPO):
    p=command(['git',*args],cwd);assert p['exit_code']==0,p;return p['stdout'].strip()
issue=gh('issue87',['issue','view','87','--repo','Chengyue-Lu/research-agent-workbench','--json','number,title,state,updatedAt,url,body,comments'])
ref=gh('accepted-develop',['api','repos/Chengyue-Lu/research-agent-workbench/git/ref/heads/develop']);base=ref['object']['sha']
prs=gh('ci-prs',['pr','list','--repo','Chengyue-Lu/research-agent-workbench','--state','all','--limit','100','--json','number,title,state,isDraft,headRefName,headRefOid,baseRefName,mergedAt,url'])
metadata=[]
for name in ('ci-execution-contexts','ci-fresh-read-cost','ci-identical-reuse','ci-input-propagation','ci-internal-cost','ci-invocation-proof','ci-local-boundaries','ci-round2-costs','ci-schema-parse-cost'):
    path=REPO.parent/name;head=git('rev-parse','HEAD',cwd=path);merge=git('merge-base',base,head);branch=git('branch','--show-current',cwd=path)
    changed=git('diff','--name-only',merge,head).splitlines()
    comparisons=[]
    for file in changed:
        pbase=command(['git','rev-parse',base+':'+file]);phead=command(['git','rev-parse',head+':'+file])
        comparisons.append({'path':file,'same_blob_as_accepted':pbase['exit_code']==0 and pbase['stdout']==phead['stdout'],'exists_in_accepted':pbase['exit_code']==0,'accepted_blob':pbase['stdout'].strip() if pbase['exit_code']==0 else None,'branch_blob':phead['stdout'].strip() if phead['exit_code']==0 else None})
    metadata.append({'worktree':str(path),'branch':branch,'head':head,'status':git('status','--short',cwd=path),'accepted_develop':base,'merge_base':merge,'ahead_behind':git('rev-list','--left-right','--count',base+'...'+head),'unique_subjects':git('log','--format=%H %s',base+'..'+head).splitlines(),'cherry':git('cherry',base,head).splitlines(),'changed_files':comparisons,'matching_prs':[p for p in prs if p['headRefName']==branch]})
(OUT/'worktree-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'accepted_develop':base,'issue_updated':issue['updatedAt'],'latest_comments':[{'url':c['url'],'author':c['author']['login'],'createdAt':c['createdAt'],'body':c['body']} for c in issue['comments'][-6:]],'worktrees':[{'branch':m['branch'],'head':m['head'],'status':m['status'],'ahead_behind':m['ahead_behind'],'subjects':m['unique_subjects'],'different_files':[f['path'] for f in m['changed_files'] if not f['same_blob_as_accepted']],'prs':m['matching_prs']} for m in metadata]},ensure_ascii=False,indent=2))
