import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

root=Path(__file__).parent
repo=Path(r'D:\lcy\develop\_worktrees\RWB\ci-domain-model')
head='d9042fd1611f152573a7d2cae176cb1e1ec70065'
env=dict(os.environ)
for key in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY'):
    env.pop(key,None)
artifacts=json.loads((root/'artifacts.json').read_text(encoding='utf-8-sig'))['artifacts']
zip_verification=[]
for row in artifacts:
    path=root/(row['name']+'.zip')
    with path.open('wb') as handle:
        subprocess.run(['gh','api',f"repos/Chengyue-Lu/research-agent-workbench/actions/artifacts/{row['id']}/zip"],stdout=handle,check=True,env=env)
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    assert 'sha256:'+digest==row['digest'],row['name']
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        for name in archive.namelist():
            if not name.endswith('/'):
                assert archive.read(name)==(root/'artifacts'/row['name']/name).read_bytes(),name
    zip_verification.append({'artifact':row['name'],'id':row['id'],'sha256':digest,'api_digest_match':True,'extracted_bytes_match':True})
sources={
    'plan_ci.py':'.github/scripts/plan_ci.py',
    'ci_dependencies.py':'.github/scripts/ci_dependencies.py',
    'ci_checks.py':'.github/scripts/ci_checks.py',
    'harness_evidence.py':'src/research_workbench/evaluation/harness_evidence.py',
    'test_evaluation_harness_evidence.py':'tests/test_evaluation_harness_evidence.py',
    'test_evaluation_harness_execution.py':'tests/test_evaluation_harness_execution.py',
    'export_capture.py':'docs/workstreams/chengyue-lu/M5-SYSTEM-EVALUATION-DESIGN/attempts/M5-007-H4-001/export_capture.py',
}
source_verification=[]
for name,path in sources.items():
    raw=subprocess.check_output(['git','-C',str(repo),'show',head+':'+path])
    (root/name).write_bytes(raw)
    source_verification.append({'path':path,'commit':head,'copy':name,'git_blob':subprocess.check_output(['git','-C',str(repo),'rev-parse',head+':'+path],text=True).strip(),'sha256':hashlib.sha256(raw).hexdigest()})
(root/'verification.json').write_text(json.dumps({'zip_artifacts':zip_verification,'source_blobs':source_verification},indent=2)+'\n',encoding='utf-8')
manifest=[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(root.rglob('*')) if p.is_file() and p.name !='SHA256SUMS.json']
(root/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(zip_verification,indent=2))
