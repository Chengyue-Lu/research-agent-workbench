import fnmatch, hashlib, json, pathlib, re, subprocess
root = pathlib.Path.cwd()
out = pathlib.Path(r'D:\lcy\develop\_assessments\rwb-ci-domain-20260920\domain-inventory')
model_path = root / 'docs/workstreams/chengyue-lu/TEST-PERF-002/domain-model.json'
model = json.loads(model_path.read_text(encoding='utf-8'))
policy = json.loads((root / 'tests/ci_impact_policy.yaml').read_text(encoding='utf-8'))
assert set(model) == {'version', 'execution_authority', 'domains', 'pilots'}
assert model['version'] == 1 and model['execution_authority'] is False and model['pilots'] == []
assert len(model['domains']) == len({d['id'] for d in model['domains']}) == 8
records = {c['id'] for c in policy['consumer_contracts']}
fields = {'id','owner','source_patterns','test_patterns','input_patterns','consumer_ids','unknowns'}
for domain in model['domains']:
    assert set(domain) == fields
    assert set(domain['consumer_ids']) <= records
    for field in ['source_patterns','test_patterns','input_patterns']:
        assert all(not p.startswith('/') and '\\' not in p and ':' not in p and '..' not in p.split('/') for p in domain[field])
tracked = subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD'], text=True).splitlines()
source = [p for p in tracked if (p.startswith('src/research_workbench/') or p.startswith('.github/scripts/') or p == 'build_backend.py') and p.endswith('.py')]
tests = [p for p in tracked if p.startswith('tests/test_') and p.endswith('.py')]
helpers = [p for p in tracked if p.startswith('tests/') and p.endswith('.py') and p.count('/') == 1 and p not in tests]
def matches(path, fields):
    return [d['id'] for d in model['domains'] if any(fnmatch.fnmatchcase(path, pattern) for field in fields for pattern in d[field])]
result = {
    'base': subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(),
    'execution_authority': False,
    'source_count': len(source), 'test_module_count': len(tests), 'helper_count': len(helpers),
    'unrouted_source': [p for p in source if not matches(p, ['source_patterns'])],
    'unrouted_tests': [p for p in tests if not matches(p, ['test_patterns'])],
    'unrouted_helpers': [p for p in helpers if not matches(p, ['source_patterns','input_patterns'])],
    'overlapping_sources': {p: matches(p,['source_patterns']) for p in source if len(matches(p,['source_patterns'])) > 1},
    'overlapping_helpers': {p: matches(p,['source_patterns','input_patterns']) for p in helpers if len(matches(p,['source_patterns','input_patterns'])) > 1},
    'missing_pattern_matches': {d['id']: [p for field in ['source_patterns','test_patterns','input_patterns'] for p in d[field] if not any(fnmatch.fnmatchcase(f,p) for f in tracked)] for d in model['domains']}
}
md = root / 'docs/workstreams/chengyue-lu/TEST-PERF-002/DOMAIN_MODEL.md'
missing_links = []
for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)', md.read_text(encoding='utf-8')):
    if not target.startswith(('https://','http://','#')) and not (md.parent / target.split('#')[0]).resolve().exists():
        missing_links.append(target)
result['missing_links'] = missing_links
inputs = ['AGENTS.md','docs/README.md','docs/DEVELOPMENT.md','docs/workstreams/chengyue-lu/TEST-PERF-002/MODULE_AUDIT.md','docs/workstreams/chengyue-lu/TEST-PERF-002/CI_REPLAN_ACCEPTANCE.md','docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_CONTRACTS_V1.md','tests/ci_impact_policy.yaml','src/research_workbench/validation/schemas.py','src/research_workbench/validation/documents.py','src/research_workbench/resources.py','tests/test_documentation.py','tests/public_surface_helpers.py','tests/harness_execution_fixtures.py','tests/baseline_fixtures.py']
result['input_sha256'] = {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in inputs}
(out / 'inventory-check.json').write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'input_sha256'}, indent=2, ensure_ascii=False))
