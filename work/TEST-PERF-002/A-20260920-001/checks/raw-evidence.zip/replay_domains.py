import hashlib
import json
from pathlib import Path
import sys
import time

repo = Path(r'D:\lcy\develop\_worktrees\RWB\ci-domain-model')
scratch = Path(__file__).parent
sys.path.insert(0, str(repo / '.github/scripts'))
import ci_domain_audit as audit
import plan_ci as planner

model = json.loads((repo / audit.MODEL).read_bytes())
original = repo / 'work/TEST-PERF-002/A-20260916-009/checks/corpus-after'
output = scratch / 'replays'
output.mkdir(exist_ok=True)
matrix = []
for number in (65, 68, 84, 86, 90):
    plan_path = (original / f'pr{number}-plan.json' if number != 90 else
                 scratch / 'pr90/artifacts/ci-plan/ci-plan.json')
    plan_bytes = plan_path.read_bytes()
    plan = json.loads(plan_bytes)
    receipt = None
    if number == 90:
        receipt = json.loads((scratch/'pr90/artifacts/coverage-quality-evidence/execution-test-results.json').read_bytes())
    before = planner.canonical(plan)
    started = time.perf_counter()
    report = audit.build_report(repo, plan, model, receipt)
    wall = time.perf_counter() - started
    assert planner.canonical(plan) == before
    assert report['execution_authority'] is False and not report['activation']['eligible']
    for key, value in report['accepted_execution'].items():
        assert value == plan[key], (number, key)
    (output/f'pr{number}-domain-audit.json').write_bytes(planner.canonical(report))
    matrix.append({'pr': number, 'source_plan_sha256': hashlib.sha256(plan_bytes).hexdigest(),
                   'binding': plan['binding'], 'plan_id': plan['plan_id'], 'report_id': report['report_id'],
                   'wall_seconds': round(wall, 6), 'change_count': len(report['inputs']),
                   'domains': report['affected_routing_domains'],
                   'missing_consumer_records': report['consumer_records']['absent_from_accepted_base'],
                   'accepted_execution_unchanged': True, 'execution_authority': False,
                   'source_plan': plan_path.relative_to(repo).as_posix() if number != 90 else 'pr90/artifacts/ci-plan/ci-plan.json'})
    print(json.dumps(matrix[-1]), flush=True)
(output/'matrix.json').write_bytes(planner.canonical({'base': '171d4654f88e926f239cdf25bc8168109b81f391',
                                                    'model_sha256': planner.digest(model), 'cases': matrix,
                                                    'execution_rerun': False, 'speedup_proved': False}))
