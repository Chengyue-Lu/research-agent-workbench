import hashlib
import json
from pathlib import Path
import sys

root=Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow')
scratch=Path(__file__).parent
common='--common' in sys.argv
source=scratch/('accepted-doc/common-driver' if common else 'accepted-doc/corrected')
output=scratch/('paired-report-common' if common else 'paired-report')
output.mkdir(exist_ok=True)
sys.path.insert(0,str(root/'.github/scripts'))
import ci_shadow_pair as pair
import plan_ci as planner

def read(path):return json.loads(path.read_bytes())
def write(name,value):(output/name).write_bytes(planner.canonical(value))
plan=read(scratch/'accepted-doc/corrected/plan.json' if common else source/'plan.json')
inventory=read(source/'accepted-inventory.json')
proposal=read(scratch/'planner-consumer/proposal.json')
for consumer in proposal['consumers']:
    consumer['changed_path_patterns']=['docs/workstreams/**']
write('proposal-scoped.json',proposal)
bundles=[]
for role in ('accepted','candidate'):
    env=read(source/(role+'-environment.json'))
    context={key:value for key,value in env.items() if key not in pair.ENVIRONMENT}
    environment={key:env[key] for key in pair.ENVIRONMENT if key!='invocation_context_sha256'}
    environment['invocation_context_sha256']=planner.digest(context)
    raw_driver=read(source/(role+'-driver.json'))
    write(role+'-invocation-context.json',context)
    # Driver format is verified against the retained raw manifest before use.
    driver={'sha256':raw_driver['driver_sha256'],'invocation':raw_driver['command']}
    bundle={'version':1,'role':role,'run_id':'local-doc-9724a4e-'+role,'environment':environment,'driver':driver,
            'receipt':read(source/(role+'-receipt.json')),'coverage':None,'coverage_binding':None,'smokes':{}}
    bundles.append(bundle);write(role+'-bundle.json',bundle)
report=pair.build_report(scratch/'accepted-doc/snapshot',plan,proposal,inventory,*bundles)
write('report.json',report)
write('plan.json',plan);write('inventory.json',inventory)
assert not report['candidate_execution']['failing_ids'],report['candidate_execution']
assert len(report['behavioral_skips'])==73
assert len(report['effective_execution_skips'])==73
assert report['coverage']['candidate']['status']=='not-required'
if common:
    assert report['pair_status']=='observed-matching-pair' and not report['blockers'],report['blockers']
else:
    assert report['pair_status']=='inconclusive' and any('drivers differ' in why for why in report['blockers'])
summary={'target':plan['binding']['target'],'plan_id':plan['plan_id'],'accepted_count':len(inventory['behavioral_order']),
         'candidate_count':len(bundles[1]['receipt']['tests']),'behavioral_skips':73,'effective_execution_skips':73,
         'timing':report['timing'],'comparison_status':report['pair_status'],'blockers':report['blockers'],
         'execution_authority':False,'savings_proved':False}
write('summary.json',summary)
print(json.dumps(summary,indent=2))
