import hashlib,json,subprocess
from pathlib import Path
root=Path(r'D:\lcy\develop\_assessments\rwb-ci-paired-shadow-20260920\accepted-doc')
repo=root/'snapshot';out=root/'corrected'
proposal=json.loads((out/'proposal.json').read_bytes());plan=json.loads((out/'plan.json').read_bytes())
assert proposal['baseline']==plan['binding']['base']
rows=[]
for consumer in proposal['consumers']:
    for path,expected in consumer['pins'].items():
        for label,sha in [('base',plan['binding']['base']),('target',plan['binding']['target'])]:
            raw=subprocess.check_output(['git','show',f'{sha}:{path}'],cwd=repo)
            rows.append({'consumer':consumer['id'],'path':path,'snapshot':label,'expected':expected,'actual':hashlib.sha256(raw).hexdigest()})
        rows.append({'consumer':consumer['id'],'path':path,'snapshot':'working-file','expected':expected,'actual':hashlib.sha256((repo/path).read_bytes()).hexdigest()})
assert all(r['actual']==r['expected'] for r in rows)
report={'execution_authority':False,'baseline_matches':True,'checks':rows,'all_match':True}
(out/'proposal-pin-check.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(f'{len(rows)} base/target/worktree pin checks PASS')
