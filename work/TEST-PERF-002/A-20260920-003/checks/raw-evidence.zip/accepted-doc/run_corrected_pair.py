import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'corrected'
REPO = ROOT / 'snapshot'
PYTHON = sys.executable
TARGET = '9724a4ee36889b327b33ba1ebb066a6e02521404'
PROPOSAL = ROOT.parent / 'planner-consumer/proposal.json'
assert not OUT.exists()
OUT.mkdir()
assert REPO.resolve().is_relative_to(ROOT.resolve())
generated = (REPO/'src/research_workbench/_runtime_data').resolve()
assert generated.is_relative_to(REPO.resolve()) and not generated.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip() == TARGET
assert not subprocess.check_output(['git','status','--short'],cwd=REPO,text=True).strip()
shutil.copyfile(ROOT/'plan.json',OUT/'plan.json')
shutil.copyfile(PROPOSAL,OUT/'proposal.json')
environment = {key:value for key,value in os.environ.items() if not key.startswith('GITHUB_')}
environment.update(PYTHONPATH=os.pathsep.join([str(REPO),str(REPO/'src')]),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
setup_command = [PYTHON,'-c',"import build_backend; print(build_backend.generate())"]
done=subprocess.run(setup_command,cwd=REPO,env=environment,text=True,capture_output=True,encoding='utf-8')
(OUT/'setup.stdout.txt').write_text(done.stdout,encoding='utf-8')
(OUT/'setup.stderr.txt').write_text(done.stderr,encoding='utf-8')
assert done.returncode == 0
setup={'command':setup_command,'resolved_target':str(generated),'manifest_pin':done.stdout.strip(),
       'build_backend_sha256':hashlib.sha256((REPO/'build_backend.py').read_bytes()).hexdigest()}
(OUT/'setup.json').write_text(json.dumps(setup,indent=2)+'\n',encoding='utf-8')

COLLECT = '''import argparse,hashlib,importlib.metadata,importlib.util,json,os,platform,subprocess,sys
from pathlib import Path
root=Path.cwd();out=Path(sys.argv[1]);phase=sys.argv[2]
spec=importlib.util.spec_from_file_location('native_runner',root/'tests/run_unittest_suite.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
args=argparse.Namespace(suite='focused',plan=out/'plan.json',policy=root/'tests/coverage_policy.yaml')
plan=runner._verified_plan(args.plan);b,c=runner._execution_suites(args,plan)
bi,ci=runner._inventory(b),runner._inventory(c)
inventory={'version':1,'plan_id':plan['plan_id'],'target':plan['binding']['target'],
 'source':'fresh separate-process accepted-plan collection before '+phase,
 'scope':'plan-collection','python_version':platform.python_version(),
 'behavioral_order':list(bi),'coverage_order':list(ci),'runtime_ids':{**bi,**ci}}
(out/(phase+'-inventory.json')).write_text(json.dumps(inventory,indent=2)+'\\n',encoding='utf-8')
dependencies=sorted([(d.metadata['Name'],d.version) for d in importlib.metadata.distributions()])
canonical=lambda obj:(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\\n').encode()
safe_keys=['LANG','LC_ALL','TZ','PYTHONHASHSEED','PYTHONUTF8','PYTHONDONTWRITEBYTECODE','PYTHONPATH','GIT_CONFIG_COUNT','GIT_ATTR_NOSYSTEM']
git_config=subprocess.check_output(['git','config','--null','--list','--show-origin'])
env={'python_version':platform.python_version(),'platform':platform.platform(),'machine':platform.machine(),
 'dependencies_sha256':hashlib.sha256(canonical(dependencies)).hexdigest(),
 'runner_sha256':hashlib.sha256((root/'tests/run_unittest_suite.py').read_bytes()).hexdigest(),
 'coverage_config_sha256':hashlib.sha256(b'').hexdigest(),
 'runtime_manifest_sha256':hashlib.sha256((root/'src/research_workbench/_runtime_data/manifest.json').read_bytes()).hexdigest(),
 'runtime_pin_source_sha256':hashlib.sha256((root/'src/research_workbench/_runtime_pin.py').read_bytes()).hexdigest(),
 'git_version':subprocess.check_output(['git','--version'],text=True).strip(),
 'git_config_sha256':hashlib.sha256(git_config).hexdigest(),
 'process_environment_allowlist':{k:os.environ.get(k) for k in safe_keys},
 'path_sha256':hashlib.sha256(os.environ.get('PATH','').encode()).hexdigest(),
 'dependencies':dependencies,'executable':sys.executable}
(out/(phase+'-environment.json')).write_text(json.dumps(env,indent=2)+'\\n',encoding='utf-8')
print(json.dumps({'B':len(bi),'C':len(ci)}))
'''
CANDIDATE = '''import argparse,importlib.util,json,sys,time,unittest
from pathlib import Path
root=Path.cwd();out=Path(sys.argv[1]);started=time.perf_counter()
spec=importlib.util.spec_from_file_location('native_runner',root/'tests/run_unittest_suite.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
args=argparse.Namespace(suite='focused',plan=out/'plan.json',policy=root/'tests/coverage_policy.yaml')
plan=runner._verified_plan(args.plan);assert not plan['coverage_obligations']
accepted=runner._suite_for(args)
before=runner._inventory(accepted)
proposal=json.loads((out/'proposal.json').read_bytes())
excluded={test for consumer in proposal['consumers'] for test in consumer['tests']}
assert len(excluded)==73 and excluded <= before.keys()
def filtered(suite):
    assert type(suite) is unittest.TestSuite, 'unreviewed custom suite hierarchy'
    children=[]
    for child in suite:
        if isinstance(child,unittest.TestSuite):
            children.append(filtered(child))
        elif runner._evidence_test_id(child) not in excluded:
            children.append(child)
    return unittest.TestSuite(children)
candidate=filtered(accepted)
after=runner._inventory(candidate)
assert list(after)==[identity for identity in before if identity not in excluded]
assert len(before)==325 and len(after)==252
(out/'candidate-expected.json').write_text(json.dumps({'role':'candidate-expected','execution_authority':False,
 'plan_id':plan['plan_id'],'target':plan['binding']['target'],'behavioral_order':list(after),'coverage_order':[],
 'runtime_ids':after,'excluded_ids':sorted(excluded)},indent=2)+'\\n',encoding='utf-8')
result=unittest.TextTestRunner(verbosity=1,resultclass=runner.TimedTextResult).run(candidate)
runner._write_summary(out/'candidate-receipt.json','shadow-candidate',time.perf_counter()-started,result,20,plan)
sys.exit(not result.wasSuccessful())
'''
rows=[]
for phase in ('accepted','candidate'):
    collection=[PYTHON,'-c',COLLECT,str(OUT),phase]
    with (OUT/(phase+'-collect.stdout.txt')).open('w',encoding='utf-8') as stdout, (OUT/(phase+'-collect.stderr.txt')).open('w',encoding='utf-8') as stderr:
        done=subprocess.run(collection,cwd=REPO,env=environment,stdout=stdout,stderr=stderr)
    assert done.returncode == 0
    if phase=='accepted':
        args=[PYTHON,str(REPO/'tests/run_unittest_suite.py'),'--suite','focused','--plan',str(OUT/'plan.json'),
              '--json-output',str(OUT/'accepted-receipt.json'),'--verbosity','1','--slowest','20']
    else:
        args=[PYTHON,'-c',CANDIDATE,str(OUT)]
        assert json.loads((OUT/'accepted-environment.json').read_bytes())==json.loads((OUT/'candidate-environment.json').read_bytes())
    print('starting '+phase,flush=True)
    started=time.perf_counter()
    with (OUT/(phase+'.stdout.txt')).open('w',encoding='utf-8') as stdout, (OUT/(phase+'.stderr.txt')).open('w',encoding='utf-8') as stderr:
        done=subprocess.run(args,cwd=REPO,env=environment,stdout=stdout,stderr=stderr)
    elapsed=time.perf_counter()-started
    receipt=json.loads((OUT/(phase+'-receipt.json')).read_bytes())
    row={'phase':phase,'exit_code':done.returncode,'process_wall_seconds':elapsed,
         'native_wall_seconds':receipt['wall_seconds'],'test_count':receipt['test_count'],
         'outcomes':receipt['outcomes'],'problems':receipt['problems']}
    rows.append(row)
    (OUT/'progress.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(row),flush=True)
    if done.returncode:
        print('unexpected failure retained; stopping pair',flush=True)
        break
summary={'execution_authority':False,'target':TARGET,'runs':rows,'setup':setup,
 'candidate_note':'Recursive hierarchy-preserving exclusion of 73 audited PlannerTests IDs only; one local pair.',
 'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'input_sha256':{n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in ('plan.json','proposal.json')},
 'snapshot_status':subprocess.check_output(['git','status','--short'],cwd=REPO,text=True).strip()}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print('corrected summary ready',flush=True)
