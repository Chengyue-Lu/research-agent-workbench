import argparse,importlib.util,json,sys,time,unittest
from pathlib import Path
root=Path.cwd();out=Path(sys.argv[1]);started=time.perf_counter()
spec=importlib.util.spec_from_file_location('native_runner',root/'tests/run_unittest_suite.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
args=argparse.Namespace(suite='focused',plan=out/'plan.json',policy=root/'tests/coverage_policy.yaml')
plan=runner._verified_plan(args.plan);assert not plan['coverage_obligations']
accepted=runner._suite_for(args)
before=runner._inventory(accepted)
proposal=json.loads((out/'proposal.json').read_bytes())
excluded={test for consumer in proposal['consumers'] for test in consumer['tests']}
assert len(excluded)==73 and excluded <= before.keys()
def filtered(suite):
    assert type(suite) is unittest.TestSuite, 'unreviewed custom suite hierarchy'
    children=[]
    for child in suite:
        if isinstance(child,unittest.TestSuite):
            children.append(filtered(child))
        elif runner._evidence_test_id(child) not in excluded:
            children.append(child)
    return unittest.TestSuite(children)
candidate=filtered(accepted)
after=runner._inventory(candidate)
assert list(after)==[identity for identity in before if identity not in excluded]
assert len(before)==325 and len(after)==252
(out/'candidate-expected.json').write_text(json.dumps({'role':'candidate-expected','execution_authority':False,
 'plan_id':plan['plan_id'],'target':plan['binding']['target'],'behavioral_order':list(after),'coverage_order':[],
 'runtime_ids':after,'excluded_ids':sorted(excluded)},indent=2)+'\n',encoding='utf-8')
result=unittest.TextTestRunner(verbosity=1,resultclass=runner.TimedTextResult).run(candidate)
runner._write_summary(out/'candidate-receipt.json','shadow-candidate',time.perf_counter()-started,result,20,plan)
sys.exit(not result.wasSuccessful())
