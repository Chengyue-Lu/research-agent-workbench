import argparse,hashlib,importlib.metadata,importlib.util,json,os,platform,subprocess,sys
from pathlib import Path
root=Path.cwd();out=Path(sys.argv[1]);phase=sys.argv[2]
spec=importlib.util.spec_from_file_location('native_runner',root/'tests/run_unittest_suite.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
args=argparse.Namespace(suite='focused',plan=out/'plan.json',policy=root/'tests/coverage_policy.yaml')
plan=runner._verified_plan(args.plan);b,c=runner._execution_suites(args,plan)
bi,ci=runner._inventory(b),runner._inventory(c)
inventory={'version':1,'plan_id':plan['plan_id'],'target':plan['binding']['target'],
 'source':'fresh separate-process accepted-plan collection before '+phase,
 'scope':'plan-collection','python_version':platform.python_version(),
 'behavioral_order':list(bi),'coverage_order':list(ci),'runtime_ids':{**bi,**ci}}
(out/(phase+'-inventory.json')).write_text(json.dumps(inventory,indent=2)+'\n',encoding='utf-8')
dependencies=sorted([(d.metadata['Name'],d.version) for d in importlib.metadata.distributions()])
canonical=lambda obj:(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n').encode()
safe_keys=['LANG','LC_ALL','TZ','PYTHONHASHSEED','PYTHONUTF8','PYTHONDONTWRITEBYTECODE','PYTHONPATH','GIT_CONFIG_COUNT','GIT_ATTR_NOSYSTEM']
git_config=subprocess.check_output(['git','config','--null','--list','--show-origin'])
env={'python_version':platform.python_version(),'platform':platform.platform(),'machine':platform.machine(),
 'dependencies_sha256':hashlib.sha256(canonical(dependencies)).hexdigest(),
 'runner_sha256':hashlib.sha256((root/'tests/run_unittest_suite.py').read_bytes()).hexdigest(),
 'coverage_config_sha256':hashlib.sha256(b'').hexdigest(),
 'runtime_manifest_sha256':hashlib.sha256((root/'src/research_workbench/_runtime_data/manifest.json').read_bytes()).hexdigest(),
 'runtime_pin_source_sha256':hashlib.sha256((root/'src/research_workbench/_runtime_pin.py').read_bytes()).hexdigest(),
 'git_version':subprocess.check_output(['git','--version'],text=True).strip(),
 'git_config_sha256':hashlib.sha256(git_config).hexdigest(),
 'process_environment_allowlist':{k:os.environ.get(k) for k in safe_keys},
 'path_sha256':hashlib.sha256(os.environ.get('PATH','').encode()).hexdigest(),
 'dependencies':dependencies,'executable':sys.executable}
(out/(phase+'-environment.json')).write_text(json.dumps(env,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'B':len(bi),'C':len(ci)}))
