import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
SOURCE = Path(r'D:\lcy\develop\_assessments\rwb-ci-consumer-shadow-20260920\docs-probes\snapshot')
INPUTS = Path(r'D:\lcy\develop\_assessments\rwb-ci-consumer-shadow-20260920\replays\unrelated-doc-control')
REPO = OUT / 'snapshot'
PYTHON = sys.executable
TARGET = '9724a4ee36889b327b33ba1ebb066a6e02521404'
OUT.mkdir(parents=True, exist_ok=True)
assert not REPO.exists() and REPO.resolve().is_relative_to(OUT.resolve())

def command(args, cwd=REPO):
    result = subprocess.run(args, cwd=cwd, text=True, encoding='utf-8', errors='replace', capture_output=True)
    if result.returncode:
        raise RuntimeError((args,result.returncode,result.stdout,result.stderr))
    return result.stdout.strip()

command(['git','-c','core.autocrlf=false','clone','-q','--shared','--no-checkout',str(SOURCE),str(REPO)],OUT)
command(['git','config','core.autocrlf','false'])
command(['git','checkout','-q','--detach',TARGET])
for name in ('plan.json','proposal.json'):
    shutil.copyfile(INPUTS/name,OUT/name)
plan = json.loads((OUT/'plan.json').read_bytes())
assert plan['binding']['target'] == TARGET and plan['behavioral_scope'] == 'focused'
assert not plan['coverage_obligations'] and not plan['package_smoke'] and not plan['repository_smoke']
environment = {key:value for key,value in os.environ.items() if not key.startswith('GITHUB_')}
environment.update(PYTHONPATH=os.pathsep.join([str(REPO),str(REPO/'src')]),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
collector = '''import argparse, hashlib, importlib.metadata, importlib.util, json, os, platform, shutil, sys
from pathlib import Path
root=Path.cwd(); out=Path(sys.argv[1]); phase=sys.argv[2]
spec=importlib.util.spec_from_file_location('native_runner',root/'tests/run_unittest_suite.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
args=argparse.Namespace(suite='focused',plan=out/'plan.json',policy=root/'tests/coverage_policy.yaml')
plan=runner._verified_plan(args.plan)
b,c=runner._execution_suites(args,plan)
bi,ci=runner._inventory(b),runner._inventory(c)
inventory={'version':1,'plan_id':plan['plan_id'],'target':plan['binding']['target'],
 'source':'fresh separate-process unchanged native runner discovery before '+phase,
 'scope':'plan-collection','python_version':platform.python_version(),
 'behavioral_order':list(bi),'coverage_order':list(ci),'runtime_ids':{**bi,**ci}}
(out/(phase+'-inventory.json')).write_text(json.dumps(inventory,indent=2)+'\\n',encoding='utf-8')
env={'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
 'dependencies':sorted([{'name':d.metadata['Name'],'version':d.version} for d in importlib.metadata.distributions()],key=lambda d:d['name']),
 'git_executable':shutil.which('git'),'pythonpath':os.environ.get('PYTHONPATH'),
 'pythonhashseed':os.environ.get('PYTHONHASHSEED'),'pythonutf8':os.environ.get('PYTHONUTF8'),
 'path_sha256':hashlib.sha256(os.environ.get('PATH','').encode()).hexdigest(),
 'runner_sha256':hashlib.sha256((root/'tests/run_unittest_suite.py').read_bytes()).hexdigest(),
 'planner_sha256':hashlib.sha256((root/'.github/scripts/plan_ci.py').read_bytes()).hexdigest(),
 'policy_sha256':hashlib.sha256((root/'tests/ci_impact_policy.yaml').read_bytes()).hexdigest()}
(out/(phase+'-environment.json')).write_text(json.dumps(env,indent=2)+'\\n',encoding='utf-8')
print(json.dumps({'B':len(bi),'C':len(ci),'kernel_ids':[i for i in bi if i.startswith('tests/test_kernel.py::')]}))
'''
rows=[]
for phase in ('accepted','candidate-identical'):
    collection_args=[PYTHON,'-c',collector,str(OUT),phase]
    with (OUT/(phase+'-collect.stdout.txt')).open('w',encoding='utf-8') as stdout, (OUT/(phase+'-collect.stderr.txt')).open('w',encoding='utf-8') as stderr:
        discovery=subprocess.run(collection_args,cwd=REPO,env=environment,stdout=stdout,stderr=stderr)
    if discovery.returncode:
        raise RuntimeError('native plan discovery failed: '+phase)
    inventory=json.loads((OUT/(phase+'-inventory.json')).read_bytes())
    declared={test for item in json.loads((OUT/'proposal.json').read_bytes())['consumers'] for test in item['tests']}
    intersection=sorted(declared.intersection(inventory['behavioral_order']))
    assert intersection == [], 'candidate requires independent selection; this producer runs only identical candidate'
    print(json.dumps({'phase':phase,'discovered_B':len(inventory['behavioral_order']),'C':len(inventory['coverage_order']),
       'proposed_exclusions_in_accepted_B':intersection}),flush=True)
    args=[PYTHON,str(REPO/'tests/run_unittest_suite.py'),'--suite','focused','--plan',str(OUT/'plan.json'),
          '--json-output',str(OUT/(phase+'-receipt.json')),'--verbosity','1','--slowest','20']
    started=time.perf_counter()
    with (OUT/(phase+'.stdout.txt')).open('w',encoding='utf-8') as stdout, (OUT/(phase+'.stderr.txt')).open('w',encoding='utf-8') as stderr:
        executed=subprocess.run(args,cwd=REPO,env=environment,stdout=stdout,stderr=stderr)
    duration=time.perf_counter()-started
    payload=json.loads((OUT/(phase+'-receipt.json')).read_bytes())
    actual_modules={}
    for item in payload['tests']:
        module=item.get('canonical_id',item.get('id','')).split('::')[0]
        record=actual_modules.setdefault(module,{'test_count':0,'case_seconds':0,'outcomes':{}})
        record['test_count']+=1;record['case_seconds']+=item.get('duration_seconds',0)
        outcome=item.get('outcome');record['outcomes'][outcome]=record['outcomes'].get(outcome,0)+1
    row={'phase':phase,'command':args,'exit_code':executed.returncode,'process_wall_seconds':duration,
      'native_wall_seconds':payload['wall_seconds'],'test_count':payload['test_count'],
      'outcomes':payload['outcomes'],'problems':payload['problems'],'modules':actual_modules,
      'same_order_as_fresh_inventory':payload['execution_order']==inventory['behavioral_order'],
      'proposed_exclusions_in_accepted_B':intersection}
    rows.append(row)
    (OUT/'progress.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in row.items() if k not in ('modules','command','problems')}),flush=True)
    if phase=='accepted' and duration>=300:
        print('Accepted run >= 5 min; stopping before candidate by task budget.',flush=True)
        break
summary={'execution_authority':False,'plan_id':plan['plan_id'],'binding':plan['binding'],
  'accepted_modules':plan['tests'],'coverage_obligations':plan['coverage_obligations'],
  'package_smoke':plan['package_smoke'],'repository_smoke':plan['repository_smoke'],'runs':rows,
  'candidate_note':'The proposal names only Kernel tests already absent from accepted B; candidate is identical.',
  'selection_savings_tests':0,'snapshot_status':command(['git','status','--short']),
  'input_sha256':{name:hashlib.sha256((OUT/name).read_bytes()).hexdigest() for name in ('plan.json','proposal.json')},
  'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
  'git_version':command(['git','--version'])}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print('summary ready',flush=True)
