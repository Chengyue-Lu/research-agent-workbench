import hashlib,json
from pathlib import Path
root=Path(r'D:\lcy\develop\_assessments\rwb-ci-paired-shadow-20260920\accepted-doc')
checks=json.loads((root/'corrected/analysis.json').read_bytes())['artifact_sha256']
changes=[name for name,expected in checks.items() if hashlib.sha256((root/'corrected'/name).read_bytes()).hexdigest()!=expected]
report={'prior_corrected_json_artifacts_checked':len(checks),'changed_files':changes}
(root/'common-driver/prior-artifact-check.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
assert not changes
print(json.dumps(report))
