import hashlib,json
from pathlib import Path

out=Path(__file__).resolve().parent
load=lambda name:json.loads((out/name).read_bytes())
summary=load('summary.json')
accepted,candidate=load('accepted-receipt.json'),load('candidate-receipt.json')
expected_a,expected_b=load('accepted-expected.json'),load('candidate-expected.json')
driver_a,driver_b=load('accepted-driver.json'),load('candidate-driver.json')
environment_a,environment_b=load('accepted-environment.json'),load('candidate-environment.json')
assert accepted['successful'] and candidate['successful']
assert accepted['execution_order']==expected_a['behavioral_order']
assert candidate['execution_order']==expected_b['behavioral_order']
assert driver_a['driver_sha256']==driver_b['driver_sha256']
assert driver_a['command'][:-1]==driver_b['command'][:-1]
assert driver_a['command'][-2:] == ['--role','accepted']
assert driver_b['command'][-2:] == ['--role','candidate']
assert environment_a==environment_b
assert len(set(accepted['execution_order'])-set(candidate['execution_order']))==73
assert not set(candidate['execution_order'])-set(accepted['execution_order'])
analysis={'execution_authority':False,'target':accepted['target'],'plan_id':accepted['plan_id'],
 'accepted_count':accepted['test_count'],'candidate_count':candidate['test_count'],
 'accepted_outcomes':accepted['outcomes'],'candidate_outcomes':candidate['outcomes'],
 'actual_orders_match_preexecution':True,'driver_identical':True,'argv_diff_role_only':True,
 'environment_identical':True,'excluded_ids':sorted(set(accepted['execution_order'])-set(candidate['execution_order'])),
 'native_wall_seconds':{'accepted':accepted['wall_seconds'],'candidate':candidate['wall_seconds']},
 'observed_wall_difference_seconds':accepted['wall_seconds']-candidate['wall_seconds'],
 'driver_sha256':driver_a['driver_sha256'],'environment':environment_a,
 'single_local_pair_only':True,'hosted_replicates':0,'activation_eligible':False,
 'artifact_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.json')}}
(out/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n',encoding='utf-8')
rows={row['role']:row for row in summary['runs']}
body=f'''# Common-driver local pair

Owner Chengyue-Lu; CI execution auditor; required Skills=[]; execution_authority=false.
Target `{accepted['target']}`; plan `{accepted['plan_id']}`.

| Role | Cases | Outcomes | Native wall | Process wall |
| --- | ---: | --- | ---: | ---: |
| Accepted | {accepted['test_count']} | all PASS | {accepted['wall_seconds']:.3f} s | {rows['accepted']['process_wall_seconds']:.3f} s |
| Candidate | {candidate['test_count']} | all PASS | {candidate['wall_seconds']:.3f} s | {rows['candidate']['process_wall_seconds']:.3f} s |

Both fresh processes execute the same `driver.py`, SHA-256 `{driver_a['driver_sha256']}`.
Their full argv differ only in the explicit `--role accepted` / `--role candidate` argument.
Both verify the unchanged plan, collect accepted suite/input inventory, check the same 19 pins,
reconstruct the same TestSuite hierarchy, capture the same environment fields, and start timing
at the same point including collection. The role selects only the exclusion set (empty versus
the audited 73 PlannerTests IDs), role-specific evidence paths and native receipt label.
Original test methods, assertions, runner helpers, fixtures and suite hierarchy are preserved.

Accepted325 and candidate252 actual order each matches its preexecution expected inventory.
Candidate adds no case and removes exactly73. C=0; package/repository smoke are false in the
frozen plan. This does not measure coverage or establish whole-repository quality evidence.

Frozen environment documents match exactly, including Python/OS/machine, dependencies digest,
native runner digest, runtime manifest and pin-source hashes, Git/config digest, safe process
environment fields, and empty coverage-config digest. The native receipt files are unchanged
outputs of the accepted runner's TimedTextResult/_write_summary helpers.

This closes the previous local pair's different-driver confound. It remains **one local sequential
pair**, with ordinary shared-host/system cache and scheduling variation; no hosted repetitions
were performed and no activation or hosted speed claim follows. The earlier failed setup run
and corrected different-driver pair remain byte-preserved in their original directories.

## Evidence

- `driver.py`, `run.py`: exact common wrapper and sequential launcher.
- `*-driver.json`: source hash, full argv, exact plan/proposal hashes and checked pins.
- `*-inventory.json`: complete accepted B collected before each run.
- `*-expected.json`: role-specific inventory before execution.
- `*-receipt.json`: native outcomes, test IDs/order, timings and checkpoints.
- `*-environment.json`: identical environment bindings.
- `*.stdout.txt`, `*.stderr.txt`: raw output.
- `analysis.json`, `summary.json`: counts, equalities, observed timings and artifact hashes.

No primary/official branch, production source, test body, selector, policy, workflow, prior
probe snapshot or prior evidence file was edited. The shared isolated snapshot was read/executed
at its existing target with its already generated runtime resources.
'''
(out/'HANDOFF.md').write_text(body,encoding='utf-8')
print(json.dumps({key:value for key,value in analysis.items() if key in ('accepted_count','candidate_count','actual_orders_match_preexecution','driver_identical','argv_diff_role_only','environment_identical','native_wall_seconds')}))
