"""Run the same audited native-suite wrapper for each role; offline evidence only."""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import unittest


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def main():
    started = time.perf_counter()
    parser = argparse.ArgumentParser()
    parser.add_argument('--role', choices=('accepted', 'candidate'), required=True)
    args = parser.parse_args()
    out = Path(__file__).resolve().parent
    root = Path.cwd()
    frozen = out.parent / 'corrected'
    role = args.role
    assert root.resolve() == (out.parent / 'snapshot').resolve()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == '9724a4ee36889b327b33ba1ebb066a6e02521404'
    assert not subprocess.check_output(['git', 'status', '--short'], text=True).strip()
    spec = importlib.util.spec_from_file_location('native_runner', root / 'tests/run_unittest_suite.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    native_args = argparse.Namespace(suite='focused', plan=frozen / 'plan.json', policy=root / 'tests/coverage_policy.yaml')
    plan = runner._verified_plan(native_args.plan)
    assert not plan['coverage_obligations'] and not plan['package_smoke'] and not plan['repository_smoke']
    accepted = runner._suite_for(native_args)
    accepted_inventory = runner._inventory(accepted)
    proposal = json.loads((frozen / 'proposal.json').read_bytes())
    all_exclusions = {test for consumer in proposal['consumers'] for test in consumer['tests']}
    assert len(all_exclusions) == 73 and all_exclusions <= accepted_inventory.keys()
    assert proposal['baseline'] == plan['binding']['base']
    pin_rows = []
    for consumer in proposal['consumers']:
        for path, expected in consumer['pins'].items():
            actual = hashlib.sha256((root / path).read_bytes()).hexdigest()
            assert actual == expected
            pin_rows.append({'path': path, 'sha256': actual})
    exclusions = all_exclusions if role == 'candidate' else set()

    def filtered(suite):
        assert type(suite) is unittest.TestSuite, 'unreviewed custom suite hierarchy'
        children = []
        for child in suite:
            if isinstance(child, unittest.TestSuite):
                children.append(filtered(child))
            elif runner._evidence_test_id(child) not in exclusions:
                children.append(child)
        return unittest.TestSuite(children)

    suite = filtered(accepted)
    expected_inventory = runner._inventory(suite)
    assert len(accepted_inventory) == 325
    assert len(expected_inventory) == (252 if role == 'candidate' else 325)
    assert list(expected_inventory) == [identity for identity in accepted_inventory if identity not in exclusions]
    inventory = {'version': 1, 'plan_id': plan['plan_id'], 'target': plan['binding']['target'],
                 'source': 'fresh common-driver accepted plan collection before ' + role,
                 'scope': 'plan-collection', 'python_version': platform.python_version(),
                 'behavioral_order': list(accepted_inventory), 'coverage_order': [], 'runtime_ids': accepted_inventory}
    (out / (role + '-inventory.json')).write_bytes(canonical(inventory))
    expected = {'role': role, 'execution_authority': False, 'plan_id': plan['plan_id'],
                'target': plan['binding']['target'], 'behavioral_order': list(expected_inventory),
                'coverage_order': [], 'runtime_ids': expected_inventory, 'excluded_ids': sorted(exclusions)}
    (out / (role + '-expected.json')).write_bytes(canonical(expected))
    dependencies = sorted((dist.metadata['Name'], dist.version) for dist in importlib.metadata.distributions())
    safe_keys = ('LANG', 'LC_ALL', 'TZ', 'PYTHONHASHSEED', 'PYTHONUTF8', 'PYTHONDONTWRITEBYTECODE',
                 'PYTHONPATH', 'GIT_CONFIG_COUNT', 'GIT_ATTR_NOSYSTEM')
    environment = {'python_version': platform.python_version(), 'platform': platform.platform(), 'machine': platform.machine(),
                   'dependencies_sha256': hashlib.sha256(canonical(dependencies)).hexdigest(),
                   'runner_sha256': hashlib.sha256((root / 'tests/run_unittest_suite.py').read_bytes()).hexdigest(),
                   'coverage_config_sha256': hashlib.sha256(b'').hexdigest(),
                   'runtime_manifest_sha256': hashlib.sha256((root / 'src/research_workbench/_runtime_data/manifest.json').read_bytes()).hexdigest(),
                   'runtime_pin_source_sha256': hashlib.sha256((root / 'src/research_workbench/_runtime_pin.py').read_bytes()).hexdigest(),
                   'git_version': subprocess.check_output(['git', '--version'], text=True).strip(),
                   'git_config_sha256': hashlib.sha256(subprocess.check_output(['git', 'config', '--null', '--list', '--show-origin'])).hexdigest(),
                   'process_environment_allowlist': {key: os.environ.get(key) for key in safe_keys},
                   'path_sha256': hashlib.sha256(os.environ.get('PATH', '').encode()).hexdigest(),
                   'dependencies': dependencies, 'executable': sys.executable}
    (out / (role + '-environment.json')).write_bytes(canonical(environment))
    driver = {'driver_kind': 'common-native-suite-wrapper-v1', 'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'native_runner_sha256': environment['runner_sha256'], 'command': [sys.executable, *sys.argv],
              'cwd': str(root), 'role': role, 'execution_authority': False,
              'plan_sha256': hashlib.sha256((frozen / 'plan.json').read_bytes()).hexdigest(),
              'proposal_sha256': hashlib.sha256((frozen / 'proposal.json').read_bytes()).hexdigest(), 'checked_pins': pin_rows}
    (out / (role + '-driver.json')).write_bytes(canonical(driver))
    print(json.dumps({'role': role, 'expected_cases': len(expected_inventory)}), flush=True)
    result = unittest.TextTestRunner(verbosity=1, resultclass=runner.TimedTextResult).run(suite)
    label = 'shadow-candidate' if role == 'candidate' else 'focused'
    payload = runner._write_summary(out / (role + '-receipt.json'), label, time.perf_counter() - started, result, 20, plan)
    assert payload['execution_order'] == list(expected_inventory)
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    raise SystemExit(main())
