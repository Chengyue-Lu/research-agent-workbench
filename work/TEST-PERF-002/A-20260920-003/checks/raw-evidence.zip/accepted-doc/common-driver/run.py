import hashlib,json,os
from pathlib import Path
import subprocess,sys,time

OUT=Path(__file__).resolve().parent
REPO=OUT.parent/'snapshot'
environment={key:value for key,value in os.environ.items() if not key.startswith('GITHUB_')}
environment.update(PYTHONPATH=os.pathsep.join([str(REPO),str(REPO/'src')]),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
rows=[]
for role in ('accepted','candidate'):
    assert not (OUT/(role+'-receipt.json')).exists()
    command=[sys.executable,str(OUT/'driver.py'),'--role',role]
    started=time.perf_counter()
    print('starting common-driver '+role,flush=True)
    with (OUT/(role+'.stdout.txt')).open('w',encoding='utf-8') as stdout,(OUT/(role+'.stderr.txt')).open('w',encoding='utf-8') as stderr:
        process=subprocess.run(command,cwd=REPO,env=environment,stdout=stdout,stderr=stderr)
    elapsed=time.perf_counter()-started
    if not (OUT/(role+'-receipt.json')).exists():
        raise RuntimeError('driver did not produce receipt: '+role)
    receipt=json.loads((OUT/(role+'-receipt.json')).read_bytes())
    row={'role':role,'command':command,'exit_code':process.returncode,'process_wall_seconds':elapsed,
         'native_wall_seconds':receipt['wall_seconds'],'test_count':receipt['test_count'],
         'outcomes':receipt['outcomes'],'problems':receipt['problems']}
    rows.append(row)
    (OUT/'progress.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(row),flush=True)
    if process.returncode:
        print('failure preserved; no further run',flush=True)
        break
summary={'execution_authority':False,'runs':rows,'single_pair_only':True,
         'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
if len(rows)==2:
    envs=[json.loads((OUT/(role+'-environment.json')).read_bytes()) for role in ('accepted','candidate')]
    drivers=[json.loads((OUT/(role+'-driver.json')).read_bytes()) for role in ('accepted','candidate')]
    summary.update(environment_identical=envs[0]==envs[1],driver_identical=drivers[0]['driver_sha256']==drivers[1]['driver_sha256'])
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print('common-driver summary ready',flush=True)
