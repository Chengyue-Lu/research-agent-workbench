import hashlib,json
from pathlib import Path

root=Path(__file__).resolve().parent
out=root/'corrected'
accepted=json.loads((out/'accepted-receipt.json').read_bytes())
candidate=json.loads((out/'candidate-receipt.json').read_bytes())
full=json.loads((out/'accepted-inventory.json').read_bytes())
expected=json.loads((out/'candidate-expected.json').read_bytes())
summary=json.loads((out/'summary.json').read_bytes())
environment_a=json.loads((out/'accepted-environment.json').read_bytes())
environment_b=json.loads((out/'candidate-environment.json').read_bytes())
drivers={phase:json.loads((out/(phase+'-driver.json')).read_bytes()) for phase in ('accepted','candidate')}
def modules(receipt):
    result={}
    for item in receipt['tests']:
        name=item['canonical_id'].split('::')[0]
        record=result.setdefault(name,{'count':0,'case_seconds':0,'outcomes':{}})
        record['count']+=1;record['case_seconds']+=item.get('duration_seconds',0)
        outcome=item['outcome'];record['outcomes'][outcome]=record['outcomes'].get(outcome,0)+1
    return dict(sorted(result.items(),key=lambda pair:pair[1]['case_seconds'],reverse=True))
analysis={'execution_authority':False,'target':summary['target'],'plan_id':accepted['plan_id'],
 'accepted_order_matches_discovery':accepted['execution_order']==full['behavioral_order'],
 'candidate_order_matches_discovery':candidate['execution_order']==expected['behavioral_order'],
 'accepted_count':accepted['test_count'],'candidate_count':candidate['test_count'],
 'accepted_successful':accepted['successful'],'candidate_successful':candidate['successful'],
 'excluded_ids':sorted(set(full['behavioral_order'])-set(expected['behavioral_order'])),
 'candidate_extra_ids':sorted(set(expected['behavioral_order'])-set(full['behavioral_order'])),
 'environments_equal':environment_a==environment_b,
 'drivers_identical':drivers['accepted']['driver_sha256']==drivers['candidate']['driver_sha256'],
 'accepted_modules':modules(accepted),'candidate_modules':modules(candidate),
 'runs':summary['runs'],'timing_limit':'single local sequential observation, different drivers, no hosted or activation speed claim',
 'artifact_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.json')},
 'kernel_control_note':'Both Kernel IDs were absent from accepted B; initial Kernel proposal has zero effective skips.'}
(out/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n',encoding='utf-8')
ranked='\n'.join(f"| {name} | {row['count']} | {row['case_seconds']:.3f} |" for name,row in analysis['accepted_modules'].items())
runs={row['phase']:row for row in summary['runs']}
report=f'''# Accepted documentation execution and bounded PlannerTests candidate

Accountable owner Chengyue-Lu; CI execution auditor; required Skills=[]; execution_authority=false.
Exact target `{summary['target']}`; plan `{accepted['plan_id']}`.
Inputs: unchanged original plan, separately audited 73-ID PlannerTests proposal and snapshot runner.

## Results

- Full accepted B: {accepted['test_count']} cases across 13 modules; C=0; smoke obligations false.
- Candidate B: {candidate['test_count']} cases across 12 modules; removed exactly 73 audited PlannerTests IDs.
- Accepted outcomes: {json.dumps(accepted['outcomes'])}.
- Candidate outcomes: {json.dumps(candidate['outcomes'])}.
- Native accepted wall: {runs['accepted']['native_wall_seconds']:.3f} s; process wall: {runs['accepted']['process_wall_seconds']:.3f} s.
- Native candidate wall: {runs['candidate']['native_wall_seconds']:.3f} s; process wall: {runs['candidate']['process_wall_seconds']:.3f} s.
- Both actual orders match their fresh preexecution inventories: accepted={analysis['accepted_order_matches_discovery']}, candidate={analysis['candidate_order_matches_discovery']}.
- Frozen environment bindings equal: {analysis['environments_equal']}. Driver identities differ and remain an explicit timing confounder.

This is one local sequential observation, not a clean common-driver paired speed proof, hosted gain,
coverage validation, or activation authority. The candidate's original TestSuite nesting is retained
recursively; unchanged native result/summary helpers record it as `shadow-candidate`. Acceptance runs
the native CLI as `focused`. Both driver sources and complete argv are preserved separately.

The initial Kernel proposal would remove **zero** cases: neither Kernel case is in the accepted plan.
Its observed-subset exclusion cannot be presented as savings from actual CI. This full-plan check
therefore replaced that no-op experiment with the separately audited PlannerTests boundary, at the
parent's direction. The frozen proposal used here is the original audit proposal; the parent's later
workstream-path-scoped declaration did not alter this run or its 73-ID filter.

## Accepted case-cost attribution

Case seconds omit module/class fixture setup and plan collection; they are not total CPU or job critical path.

| Module | Cases | Summed case seconds |
| --- | ---: | ---: |
{ranked}

## Setup gap and retained failed evidence

The initial raw Git checkout lacked generated `_runtime_pin.py`/runtime assets. That first full run
observed 322 PASS + 3 ModuleNotFoundError errors in M5TraceExport; its native receipt and raw logs
remain in the parent directory. These are checkout-setup failures, not candidate regressions or
an accepted green baseline. Its 318.842 s process wall exceeded the original five-minute threshold,
so the pointless identical-candidate repeat was not launched.

The parent extended the task to correct setup and rerun. The resolved generated target was checked
to be inside this isolated snapshot and absent before calling this exact snapshot's `build_backend.generate`.
Generated runtime manifest/pin hashes were captured for both corrected runs, with dependencies,
runner, Git/config digest, safe environment fields, Python/OS/machine and an empty coverage-config
digest because C=0. The read-only venv was not installed into or modified. All 19 proposal pins
matched at base, target and working-file (57 checks). Tracked checkout status remains clean.

## Reproduction and evidence

- `run_pair.py`: original unchanged-runner experiment and failed raw-checkout receipt.
- `run_corrected_pair.py`: generated runtime setup; corrected complete accepted plus filtered candidate.
- `check_inputs.py`, `corrected/proposal-pin-check.json`: base/target/worktree pin checks.
- `capture_drivers.py`, `corrected/drivers/`: exact producer/collector/runner sources and argv.
- `corrected/accepted-inventory.json`: fresh full plan collection; candidate-side full discovery retained separately.
- `corrected/candidate-expected.json`: recursively filtered expected inventory before candidate execution.
- `corrected/accepted-receipt.json`, `candidate-receipt.json`: original native outcomes; no rewritten receipts.
- `corrected/*-environment.json`, `*-driver.json`, `setup.json`: environment, driver and generated-resource bindings.
- `corrected/analysis.json`: actual counts, order checks, costs and artifact hashes.
- Raw stdout/stderr and exact isolated Git checkout remain under this task's assessment directory.

No shared probe snapshot, primary/official branch, selector, production test method, policy or workflow was edited.
GitHub was not mutated. Three fresh same-environment hosted pairs with a common driver and independently
accepted exclusion authority remain future requirements.
'''
(root/'HANDOFF.md').write_text(report,encoding='utf-8')
print(json.dumps({key:value for key,value in analysis.items() if key in ('accepted_count','candidate_count','accepted_successful','candidate_successful','environments_equal','drivers_identical','accepted_order_matches_discovery','candidate_order_matches_discovery')}))
