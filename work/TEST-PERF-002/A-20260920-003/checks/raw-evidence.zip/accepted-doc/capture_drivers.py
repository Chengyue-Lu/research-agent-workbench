import ast,hashlib,json,sys
from pathlib import Path
root=Path(r'D:\lcy\develop\_assessments\rwb-ci-paired-shadow-20260920\accepted-doc');out=root/'corrected';repo=root/'snapshot'
producer=root/'run_corrected_pair.py';tree=ast.parse(producer.read_text(encoding='utf-8'))
values={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ('COLLECT','CANDIDATE')}
drivers=out/'drivers';drivers.mkdir(exist_ok=True)
native=(repo/'tests/run_unittest_suite.py').read_bytes();(drivers/'native-runner.py').write_bytes(native)
wrapper=values['CANDIDATE'].encode('utf-8');(drivers/'filtered-candidate.py').write_bytes(wrapper)
(drivers/'collector.py').write_text(values['COLLECT'],encoding='utf-8')
accepted=[sys.executable,str(repo/'tests/run_unittest_suite.py'),'--suite','focused','--plan',str(out/'plan.json'),'--json-output',str(out/'accepted-receipt.json'),'--verbosity','1','--slowest','20']
candidate=[sys.executable,'-c',values['CANDIDATE'],str(out)]
for name,source,args,kind in [('accepted',native,accepted,'native-cli'),('candidate',wrapper,candidate,'hierarchy-filtered-wrapper')]:
    value={'driver_kind':kind,'driver_sha256':hashlib.sha256(source).hexdigest(),'native_runner_sha256':hashlib.sha256(native).hexdigest(),'command':args,'cwd':str(repo),'producer_sha256':hashlib.sha256(producer.read_bytes()).hexdigest(),'execution_authority':False}
    (out/(name+'-driver.json')).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print('Both driver sources, digests, invocations preserved; different-driver timing confound explicit.')
