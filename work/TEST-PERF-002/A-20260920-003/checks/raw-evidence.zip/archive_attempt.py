import dataclasses
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

repo=Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow')
scratch=Path(__file__).parent
attempt=repo/'work/TEST-PERF-002/A-20260920-003'
checks=attempt/'checks';checks.mkdir(parents=True,exist_ok=True)
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
base='171d4654f88e926f239cdf25bc8168109b81f391'
def dump(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
pair=json.loads((scratch/'paired-report-common/summary.json').read_bytes())
assert pair['comparison_status']=='observed-matching-pair' and not pair['blockers']
metrics=json.loads((scratch/'checks/coverage.json').read_bytes())['files']
assert all(row['summary']['missing_lines']==row['summary']['missing_branches']==0 for row in metrics.values())
members=[]
for directory in ('checks','paired-report','paired-report-common','pr92'):
    members.extend((p,p.relative_to(scratch).as_posix()) for p in (scratch/directory).rglob('*')
                   if p.is_file() and p.name!='.coverage' and '__pycache__' not in p.parts)
for directory in ('accepted-doc','planner-consumer'):
    members.extend((p,p.relative_to(scratch).as_posix()) for p in (scratch/directory).iterdir() if p.is_file())
for directory in ('accepted-doc/corrected','accepted-doc/common-driver'):
    members.extend((p,p.relative_to(scratch).as_posix()) for p in (scratch/directory).rglob('*')
                   if p.is_file() and '__pycache__' not in p.parts)
members += [(scratch/name,name) for name in ('build_pair_evidence.py','archive_attempt.py')]
inventory=[]
with zipfile.ZipFile(checks/'raw-evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path,name in members:
        raw=path.read_bytes();archive.writestr(name,raw)
        inventory.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(checks/'raw-evidence.zip') as archive:
    assert all(hashlib.sha256(archive.read(row['path'])).hexdigest()==row['sha256'] for row in inventory)
for name,source in [('paired-summary.json','paired-report-common/summary.json'),
                    ('first-pair-summary.json','paired-report/summary.json'),
                    ('pr92-summary.json','pr92/summary.json'),('PR92_HOSTED_BASELINE.md','pr92/REPORT.md'),
                    ('planner-consumer-review.md','planner-consumer/REVIEW.md'),
                    ('paired-code-recheck.md','planner-consumer/paired-code-recheck.md'),
                    ('execution-handoff.md','accepted-doc/HANDOFF.md'),
                    ('common-driver-handoff.md','accepted-doc/common-driver/HANDOFF.md')]:
    shutil.copyfile(scratch/source,checks/name)
summary={'implementation':head,'base':base,'execution_authority':False,
 'validation':{'python311':{'focused_passed':51,'seconds':40.326},'python313':{'focused_passed':10,'seconds':8.494},
               'modules':{path:row['summary'] for path,row in metrics.items()},'exclusions_added':0,
               'independent_recheck_passed':7,'actual_pair':pair},
 'raw_archive_sha256':hashlib.sha256((checks/'raw-evidence.zip').read_bytes()).hexdigest(),
 'raw_members':inventory,
 'limitations':['One local common-driver pair, not three hosted pairs','Real doc plan has no coverage/smoke obligations',
                'Repository/impact paired checker tested with real fixture-phase counterexample; broad candidate coverage still pending',
                'Independent exclusion witness and consumer/environment authority review pending; no activation or merge']}
dump(checks/'validation.json',summary)
dump(checks/'delegation-summary.json',{'capture':'Retained reports and handoff summaries; incomplete raw message stream declared',
 'tasks':[{'agent':'domain_inventory','profile':'CI execution auditor','skills':[],'owner':'Chengyue-Lu',
           'write_scope':'assessment/accepted-doc only','budget':'initial12m; setup repair12m; common-driver10m',
           'outputs':'full accepted and filtered candidate raw receipts/inventories; environment/pins/drivers; retained setup errors',
           'stop':'one same-driver pair after setup and driver confounds explicitly repaired'},
          {'agent':'domain_plan_review','profile':'CI consumer and integrity reviewer','skills':[],'owner':'Chengyue-Lu',
           'write_scope':'assessment/planner-consumer only','budget':'10m audit;8m review;4m recheck',
           'outputs':'73-case19-pin consumer proposal; real executable mutant; driver finding and independent recheck'},
          {'agent':'pr90_cost','profile':'CI measurement auditor','skills':[],'owner':'Chengyue-Lu',
           'write_scope':'assessment/pr92 only','budget':'10m','outputs':'verified hosted artifacts, real target, all Gate and cost summaries'}],
 'main_decisions':['Kernel controls are not in actual accepted B; zero savings',
                  'Keep original setup failure; prepare exact runtime resources and rerun accepted/candidate',
                  'Bind actual drivers and retain different-driver pair as inconclusive',
                  'One identical-driver rerun closes that measured confound; do not claim hosted acceptance',
                  'Guard workstream-only proposal scope, all others retained; preserve C and quality checkers']})
sys.path.insert(0,str(repo/'src'))
from research_workbench.observability.trace import AgentTraceRecorder,validate_attempt_trace
recorder=AgentTraceRecorder(attempt,task_id='TEST-PERF-002',task_revision=41,attempt_id=attempt.name,
 task_snapshot={'task_id':'TEST-PERF-002','revision':41,'request':'Continue CI-only2B complete accepted/candidate execution and coverage observations',
                'scope':'paired comparator, scoped planner consumer, fresh local pair and hosted92 baseline','delegation':True,'required_skills':[]},
 accountable_owner='Chengyue-Lu',actor_id='main-agent',runtime_identity='Codex desktop',provider='OpenAI',
 read_allowlist=['AGENTS.md','.github/**','tests/**','docs/workstreams/chengyue-lu/TEST-PERF-002/**',
                 'work/TEST-PERF-002/**','scoped planner source consumers and hosted PR92 artifacts'],
 write_scope=['.github/scripts/ci_shadow_pair.py','.github/scripts/ci_consumer_shadow.py',
              'tests/test_ci_shadow_pair.py','tests/test_ci_consumer_shadow.py',
              'docs/workstreams/chengyue-lu/TEST-PERF-002/**','work/TEST-PERF-002/A-20260920-003/**'],
 tool_allowlist=['git','gh','python','shell','collaboration'],baseline=base)
recorder.record_capture_gap('messages','Retrospective capture retains original producers/reports/results and explicit delegation summaries. Full initial tool and inter-agent message stream was not captured.')
recorder.record_capture_gap('external-actions','Final exact-head verification, push and PR/Issue updates occur after archival seal and remain externally recorded.')
recorder.record_tool_call(operation_id='paired-ci-evidence',tool_name='shell',status='succeeded',
 arguments={'operation':'compare separate exact-target executions and retain setup/driver counterexamples'},
 result=summary,result_entered_context=True)
recorder.seal('safe-paused')
validated=validate_attempt_trace(repo,attempt)
dump(checks/'trace-validation.json',{'blocked':validated.blocked,'risks':[dataclasses.asdict(r) for r in validated.risks]})
assert not validated.blocked,validated.risks
(attempt/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n')
timing=pair['timing']
(attempt/'RESULTS.md').write_text(f'''# Complete accepted and candidate consumer observations

TEST-PERF-002 / Issue #87; owner Chengyue-Lu; risk R2; 2026-09-20.
Base `{base}`; implementation `{head}`; continuation of Draft PR #92.

## Actual local pair

The existing workstream Markdown control is target `{pair['target']}`.
Its actual accepted plan requires 325 cases in 13 modules, C empty, and neither smoke.
The former two Kernel controls are absent from that accepted B and save no execution.
The new proposal excludes only 73 PlannerTests under 19 unchanged source/config/fixture
pins and an explicit docs/workstreams change scope. Those tests generate Markdown
inside temporary Git fixtures; actual document consumers remain selected.

| Same-driver execution | Cases | Runner wall |
| --- | --- | --- |
| Complete accepted plan | 325 PASS | {timing['accepted_runner_wall_seconds']:.3f} s |
| Filtered candidate | 252 PASS | {timing['candidate_runner_wall_seconds']:.3f} s |

Observed difference: {timing['difference_seconds']:.3f} s ({timing['difference_percent']:.2f}%).
Both runs use the same driver source, environment and exact Git target, with fresh
processes and expected-order receipts. This is one local pair, not a repeated hosted
critical-path result, and does not authorize activation. The initial raw-checkout
failure (322 PASS + 3 missing-generated-resource errors) and the first different-driver
pair (325/252 PASS, 323.833/63.072 s) remain preserved with their original limitations.

## Quality and lifecycle

The paired comparator retains C and smoke requirements, separately evaluates the
existing impact/repository checkers, and binds artifacts to plan/target/run/receipt.
A real subprocess regression covers every source line/branch in both schedules but
fails after a case moves into a restarted class fixture. The failure stays blocking.
Different drivers remain a timing confound; missing/failed/skipped proof stays inconclusive.
Required coverage observations for broad real candidate plans remain future work: this
real docs pair has coverage_scope=none and cannot establish repository coverage.

- Python 3.11 related regression: 51 PASS, 40.326 s; Python 3.13 focused: 10 PASS, 8.494 s.
- ci_consumer_shadow: 205/205 statements, 84/84 branches; ci_shadow_pair: 118/118 statements,
  38/38 branches. Zero new exclusions. Independent review/recheck: 7 PASS.
- A real planner-source mutant fails an existing PlannerTests case. Such executable
  edits retain accepted tests through the pilot guard and old source pins.
- Hosted previous #92 head b8b21b7 passed all Gates: B1418/C1392, coverage19m51s,
  global94.3169%, all59 critical files95/90, repository186/0/0, package8probesPASS.
  Its sole FULL/repository unknown-input reason was domain-model.json. No cross-PR
  speedup is inferred from this baseline.
- Trace has no BLOCK and retains capture-gap warnings.

[Pair summary](checks/paired-summary.json), [first pair](checks/first-pair-summary.json),
[validation and raw hashes](checks/validation.json), [hosted baseline](checks/PR92_HOSTED_BASELINE.md),
[consumer audit](checks/planner-consumer-review.md), [code recheck](checks/paired-code-recheck.md),
[raw evidence ZIP](checks/raw-evidence.zip).

The ZIP preserves execution drivers, native receipts, independent inventories, environment
captures, failed setup evidence, relevant executable mutant, full hosted artifacts and
source/checker hashes. Frozen scripts inside it are historical experiment artifacts.
Independent exclusion witness, full input/environment review and at least three controlled
hosted pairs remain prerequisites for 2C. Existing quality floors and integration fresh
baselines remain unchanged; no merge or production reduction occurred.
''',encoding='utf-8')
files=[{'path':p.relative_to(attempt).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
       for p in sorted(attempt.rglob('*')) if p.is_file()]
dump(checks/'evidence-manifest.json',{'files':files})
print(json.dumps({'implementation':head,'raw_members':len(inventory),'archive_files':len(files),'trace_blocked':validated.blocked}))
