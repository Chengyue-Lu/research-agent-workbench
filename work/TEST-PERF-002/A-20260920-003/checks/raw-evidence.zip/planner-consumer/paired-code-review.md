# Independent paired-shadow code review

Profile: CI integrity reviewer; skills=[]; owner Chengyue-Lu. Reviewed ci_shadow_pair.py, the explicit suite_label extension to compare_receipt, tests/test_ci_shadow_pair.py and invoked impact/repository coverage checker entrypoints. Source read-only; no branch or GitHub changes.

## Validation observed

Independently executed the four PairedExecutionTests using Python 3.11 with bytecode writes disabled: 4 PASS in 0.012 s. These are focused component tests; they are not the main task's separate real Git/coverage/pair probes.

The inspected behavior correctly:

- validates exact plan/target/Python, distinct supplied run identity, matching declared environments, and raw coverage-to-receipt/data digest associations;
- requires changed candidates to identify shadow-candidate execution, retaining the original source receipt bytes;
- checks candidate canonical IDs/runtime aliases, complete observed order, fixture/checkpoint failures and the B-then-C-minus-B phase contract through the existing comparator;
- retains C and accepted coverage/smoke requirements;
- invokes both changed-line/branch impact checks and repository global/critical/positive-negative checks when both are required;
- binds locally used coverage checker sources to the observed target;
- keeps failed, missing, cancelled or skipped required smokes inconclusive;
- reports one-pair runner timing separately from hosted/statistical savings and remains execution_authority=false / activation=false.

The suite_label extension changes the expected diagnostic receipt label only; it does not bypass plan/target, case-order, event, alias or phase checks.

## P2: Bind the actual paired execution driver, not only its runner library

Location: ci_shadow_pair.py:20-21,31-35,105 and144-146.

The environment contract currently pins tests/run_unittest_suite.py but carries no identity for the actual experiment driver/wrapper. The canonical runner's CLI has a fixed suite-choice list and cannot emit shadow-candidate directly (tests/run_unittest_suite.py:450-451). Therefore a changed candidate uses additional driver code to collect/provide the reduced suite, invoke the runner, set up instrumentation and measure timing.

Two legitimately different driver versions can currently supply equal ENVIRONMENT values and be labeled as matching paired environments, despite changing discovery/setup/measurement behavior. This is a missing producer-code identity, distinct from the already disclosed fact that offline artifact provenance is not authentication.

Add an execution-driver digest to the bound environment or an equivalent explicit producer contract; preserve the driver source and concrete invocation in evidence. Prefer the same driver implementation with an explicit accepted/candidate role parameter so equality compares identical measurement logic. If two wrappers are intentionally different, require their relationship to be explicit and leave strict environment equivalence unproved rather than silently accepting it. Add a driver-digest-drift rejection regression. The existing target runner digest should remain independently checked.

## Boundaries that remain appropriate for this slice

- compare_pair is an internal comparison helper; the CLI's build_report recomputes the accepted proposal report from the supplied accepted receipt. That dependency should stay intact, since compare_pair itself trusts the precomputed comparison argument.
- Supplied hashes/run IDs/environment claims do not authenticate an actual run. The current activation blocker explicitly retains that limit; this review does not request online attestation in the offline prototype.
- Smoke artifacts currently have plan/target and source labels, not a complete independent run/environment attestation. Treat them as supplied observations, not proof of fresh hosted execution or permission to reuse old CI evidence.
- Equal coverage obligations and passing raw artifact checks do not alone establish performance savings. The actual candidate execution and at least three fresh controlled hosted pairs remain separate acceptance work.

## Disposition

One producer-provenance issue should be closed before final paired-comparator review closure. No P1 authority bypass or direct quality-threshold weakening was found in the reviewed slice. No activation or merge authorization is supplied.

Implementation direction acknowledged: preserve the accepted native-CLI receipt unchanged, bind each run's actual execution-driver SHA and invocation separately, and add an explicit driver-difference/timing-equivalence blocker when implementations differ. Quality observations may still be compared, but the overall pair stays inconclusive for matched-experiment purposes. This resolves the design concern without rewriting or re-signing the accepted receipt; the actual source change still requires recheck. No further material issue identified within this bounded review.
