import ast, hashlib, json, os, pathlib, subprocess, sys, time
src=pathlib.Path(r'D:/lcy/develop/_worktrees/RWB/ci-consumer-shadow')
out=pathlib.Path(r'D:/lcy/develop/_assessments/rwb-ci-paired-shadow-20260920/planner-consumer')
base=subprocess.check_output(['git','-C',str(src),'rev-parse','09c6cb1']).decode().strip()
def blob(path): return subprocess.check_output(['git','-C',str(src),'show',base+':'+path])
tree=ast.parse(blob('tests/test_ci_plan.py'))
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PlannerTests')
ids=['tests/test_ci_plan.py::PlannerTests.'+n.name for n in cls.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
pt=ast.parse(blob('.github/scripts/plan_ci.py'))
trust_node=next(n.value for n in pt.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TRUST_FILES' for t in n.targets))
trust=tuple(n.value if isinstance(n,ast.Constant) else 'tests/ci_impact_policy.yaml' for n in trust_node.elts)
paths=sorted(set(trust)|{'tests/test_ci_plan.py','tests/__init__.py','pyproject.toml','tests/fixtures/ci/pr65.json','tests/fixtures/ci/pr68-paths.json','src/research_workbench/artifacts/claim_trace.py','src/research_workbench/capability/release_projection.py','tests/test_claim_trace.py','tests/test_artifacts_promotion.py','tests/test_skill_release_projection.py','tests/test_skill_evaluation.py'})
pins={p:hashlib.sha256(blob(p)).hexdigest() for p in paths}
proposal={'version':1,'execution_authority':False,'baseline':base,'consumers':[{'id':'planner-tests-isolated-git-fixtures','owner':'Chengyue-Lu','invocation':'unittest PlannerTests: fresh class seed and per-case no-hardlinks Git clones; fixture-only subprocesses','tests':ids,'input_patterns':paths,'pins':pins,'assumptions':['Only modified existing regular workstream Markdown is under consideration; source/helper/config/fixture pin changes retain these tests.','All fixture Git roots are fresh generated temporary repositories; actual repository docs are not copied into their synthetic README/docs inputs.','Interpreter, PyYAML, Git executable/config, environment, import resolution, test discovery and prior-process state are held fixed; unclosed environment is not a trusted exclusion proof.'],'unknowns':[]}]}
(out/'proposal.json').write_text(json.dumps(proposal,indent=2)+'\n',encoding='utf-8')
(out/'inventory.json').write_text(json.dumps({'base':base,'canonical_ids':ids,'count':len(ids),'pins':pins,'authority':False},indent=2)+'\n',encoding='utf-8')
clone=out/'mutant-clone'
env=dict(os.environ)
for key in list(env):
    if key.startswith('GIT_'): env.pop(key)
env.update(PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull,GITHUB_EVENT_PATH='',GITHUB_STEP_SUMMARY='',GITHUB_OUTPUT='')
def call(args,cwd=src):
    r=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True)
    if r.returncode: raise RuntimeError(r.stderr)
    return r
call(['git','clone','--shared','--no-checkout',str(src),str(clone)])
call(['git','config','core.autocrlf','false'],clone)
call(['git','sparse-checkout','init','--no-cone'],clone)
call(['git','sparse-checkout','set','--no-cone','/.github/scripts/','/.github/governance-policy.json','/tests/','/pyproject.toml','/src/research_workbench/artifacts/claim_trace.py','/src/research_workbench/capability/release_projection.py'],clone)
call(['git','checkout','--detach',base],clone)
case='tests.test_ci_plan.PlannerTests.test_docs_fast_plan_is_explainable_and_replayable'
args=[sys.executable,'-B','-m','unittest',case,'-v']
def run(label):
    t=time.monotonic(); r=subprocess.run(args,cwd=clone,env=env,capture_output=True,text=True)
    (out/(label+'.stdout.txt')).write_text(r.stdout,encoding='utf-8'); (out/(label+'.stderr.txt')).write_text(r.stderr,encoding='utf-8')
    return {'case':case,'returncode':r.returncode,'wall_seconds':time.monotonic()-t,'stdout':label+'.stdout.txt','stderr':label+'.stderr.txt'}
before=run('baseline')
f=clone/'.github/scripts/plan_ci.py'; raw=f.read_text(encoding='utf-8')
old="behavioral = 'full' if full_reasons else 'focused' if (seeds or added_tests or modules) and behavioral_tests else 'none'"
assert raw.count(old)==1
f.write_text(raw.replace(old,"behavioral = 'full'"),encoding='utf-8',newline='')
after=run('mutant')
result={'base':base,'python':sys.version,'case_count':len(ids),'pin_count':len(pins),'baseline':before,'mutant':after,'mutation':{'path':'.github/scripts/plan_ci.py','before':old,'after':"behavioral = 'full'",'sha256':hashlib.sha256(f.read_bytes()).hexdigest()},'git_version':call(['git','--version']).stdout.strip(),'authority':False}
(out/'counterexample.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert before['returncode']==0,result
assert after['returncode']!=0,result
assert "AssertionError: 'fast' != 'full'" in (out/'mutant.stderr.txt').read_text(encoding='utf-8')
print(json.dumps(result,indent=2))

