# 三链传播 shadow：独立设计审查

Profile：CI shadow 实现设计审查；required Skills：[]；owner：Chengyue-Lu。只读指定 PLAN、H4a审计及 `ci-input-boundaries-v2` 中五个诊断/依赖模块与必要测试入口；读取时HEAD为 `6cf80610cc2d3b4ebdeb9f47a840cd0ec1870bbf`。本报告是设计评估，没有执行测试，也不验收根任务正在编写的实现。

**建议复用 `ci_contract_shadow.build_report()` 作为最小报告接缝：增加有版本的传播解释字段，不另建分类、selection policy或排除权限。现有输入分类已能描述归档数据与有限 `.gitattributes`；缺的是把“planner为何FULL”和“graph为何扩散”关联起来、保留同时存在的原因及证据局限。** 最多三项实施建议如下。

## 1. 在同一 Git-bound 报告中分开“义务原因”与“依赖边”，输入事实沿用安全对象读取

复用 `ci_contract_shadow.py:63–79` 的 `verify_observed_plan`、`103–176` 的既有报告及producer hashes；输入分类继续调用 `ci_input_facts.describe`，不要再维护另一份后缀/目录白名单。每个changed input记录：精确snapshot/mode/object type/object ID/hash、已有input role与unresolved、实际plan逐维义务理由、相关依赖见证引用。`unknown`分类与planner的 `unclassified dependency surface` 必须是两个字段：一个输入可被shadow认作evidence-data，同时实际plan仍因未受审边界要求FULL。

当前 `ci_contract_shadow.build_report` 在生成versions时直接 `read_at`；可复用 `ci_domain_audit.py:129–141` 的更完整方案：只读blob，foreign gitlink保留对象类型/ID与null hash，不读取不可用对象，不把空bytes当“内容已证明”。CLI沿用domain audit的resolve+samefile保护（`178–182`），不能覆盖plan、模型或receipt。若拆出纯函数，依赖信息应从已经验证的plan/snapshot传入，避免新增入口重复计算一套minimum或独立授予authority。

**必要反例：**同一archive目录的普通JSON、shebang伪装JSON、100755、unsupported filter属性、mode漂移、foreign gitlink缺失对象；原始plan被篡改或target父节点不符；改工作区文件但Git对象未变。预期只改变事实/未知项，不改变accepted obligations，`execution_authority=false`、activation=false恒成立。多数分类控制在 `test_ci_input_facts` 与 `test_ci_domain_audit` 已存在，应复用其fixture，新增跨报告字段的断言，不复制整套测试。

## 2. 三链允许重叠，只声称“已保留见证”或“图上的候选原因”，不声称完整独占因果

现有 `ci_dependencies.select`（`645–681`）只为每个路径保留一条先到达的BFS见证；`ci_contract_shadow.build_report` 的 `review_reason` 又按resource优先于opaque选择单一标签。因此现有70条resource/2条opaque不是所有可达路径，更不是删掉某类边能节约的测试数。最小增强是保留原accepted_kind，并添加**多值**fallback tags、direct seed与transitive edge的区别、snapshot来源，以及“one retained witness / alternate paths not enumerated”的明确完整性标记。

需要补具名输入关系时，复用 `ci_dependencies.commit_graph(repo, commit)` / `graph`（`548–595`）取得old/new reverse edges、resource/opaque集合，复用 `reference_observations` 提供read/write/name语法位置；不把写目标常量、basename相同或一次未观察到read升级成真实输入/无关证明。对同一边同时满足syntax与fallback的情形，可记录“潜在适用理由”，但不能重写正式plan已选择的见证kind。新增consumer、删输入、目录membership与old/new关系必须分别保留；无法定位动态输入则明确unknown。

**必要反例：**同一test可由archive-resource与Python-opaque两条独立路径到达；删掉任一见证仍可由另一条到达；同basename输入/输出、write_text目标、head新增reader、base已删reader、固定目录中新成员，以及whole-catalog扫描。输出须保持确定顺序、集合去重，报告多个原因而不相加；不得把“改分类后无FULL理由”表述为“实际B∪C减少”。现有 `test_ci_contract_shadow` 的old consumer、read/write、smoke source witness测试可扩展。

## 3. 本PR只完成解释；具名边界仍是提案，禁止顺带扩大已有candidate pilot

`ci_consumer_shadow.validate_proposal` / `validate_inventory` 已定义baseline、具名invocation、pins、假设/未知项、canonical IDs及原生B/C顺序；`candidate_selection`（`108–132`）明确限定modified regular Markdown，并拒绝integration或缺失snapshot。三链事实不能自动生成“已证明无关”列表，也不能为了支持archive/schema就在本诊断PR放宽这些guard。暂没有完整inventory/receipt时，报告模块/见证计数即可，case数、执行减少和耗时收益应为unknown，而不是0或估算PASS。

若需要桥接2B，只输出显式“consumer proposal所需缺口”：输入membership/helper/fixture/environment/toolchain、alternative consumer、coverage/smoke/lifecycle缺项；继续沿用既有proposal与配对协议，不引入第三种可消费的减测plan。具名边界即使所有pin匹配，也不产生排除权。保持原plan全部behavioral/coverage/smoke维度原样，并携带实际producer源码hash，不能因为模型来自candidate而把它当accepted authority。

**必要反例：**candidate同时改proposal、consumer pin和诊断分类以宣称无依赖；archive/schema输入试图绕过Markdown pilot；不完整C却提交B排除；plan本身要求schema安装或repository smoke；全量integration输入。新报告仍不可作为worker/aggregate执行输入，已有 `test_ci_contract_shadow.test_shadow_job_has_no_execution_outputs_or_aggregate_consumers` 是可复用边界检查。实际故障、覆盖及生命周期配对留在后续独立切片，当前不能声明2C或安全最小测试集成立。

## 最小交付与未证明项

建议本轮交付仅为一个既有report的增量schema/纯诊断辅助函数、少量上述交互反例、H4a及至少两个已冻结真实快照的解释输出。H4a数据足以暴露三链叠加，但本读集未含另外两个完整语料，也未提供完整invocation闭包或独立排除witness；不得推定它们已闭合。保留原正式plan和旧报告身份；生产选择、阈值、exclusions、B→C−B、必要integration均不变。先证明解释完整诚实，再单独审查可激活边界。
