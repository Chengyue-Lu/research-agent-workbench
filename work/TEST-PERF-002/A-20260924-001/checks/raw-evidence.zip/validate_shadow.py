"""Bounded current-source validation; preserve every invocation and failure."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
WT = Path(r'D:\lcy\develop\_worktrees\RWB\ci-input-boundaries-v2')
label = sys.argv[1]
out = ROOT / 'shadow-validation' / label
out.mkdir(parents=True, exist_ok=False)
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUTF8': '1',
       'PYTHONPATH': os.pathsep.join(str(WT / p) for p in ('.', 'src', 'tests', '.github/scripts'))}
python = (r'D:\lcy\develop\_assessments\rwb-ci-schema-parse-20260917\venv311\Scripts\python.exe'
          if label.startswith('311') else
          r'D:\lcy\develop\_assessments\rwb-ci-schema-parse-20260917\venv313\Scripts\python.exe')
tests = ['test_ci_contract_shadow', 'test_ci_input_facts', 'test_ci_domain_audit', 'test_ci_consumer_shadow']
config = out / 'coverage.ini'
config.write_text('[run]\nbranch = True\nsource = ci_contract_shadow\ndata_file = ' + (out / '.coverage').as_posix() + '\n', encoding='utf-8')
argv = [python, '-X', 'utf8', '-B']
if label.startswith('311'):
    argv += ['-m', 'coverage', 'run', '--rcfile=' + str(config)]
argv += ['-m', 'unittest', '-v', *tests]
started = time.monotonic()
p = subprocess.run(argv, cwd=WT, env=env, capture_output=True, encoding='utf-8')
(out / 'tests.log').write_text(p.stdout + '\n' + p.stderr, encoding='utf-8')
summary = {'time': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'argv': argv,
           'exit_code': p.returncode, 'wall_seconds': time.monotonic() - started,
           'source_sha256': {name: hashlib.sha256((WT/name).read_bytes()).hexdigest() for name in
                            ('.github/scripts/ci_contract_shadow.py', 'tests/test_ci_contract_shadow.py')}}
if label.startswith('311'):
    c = subprocess.run([python, '-m', 'coverage', 'json', '--rcfile=' + str(config), '-o', str(out/'coverage.json')],
                       cwd=WT, env=env, capture_output=True, encoding='utf-8')
    (out/'coverage.log').write_text(c.stdout+'\n'+c.stderr, encoding='utf-8')
    summary['coverage_exit_code'] = c.returncode
    if c.returncode == 0:
        summary['coverage'] = json.loads((out/'coverage.json').read_text())['totals']
(out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
print(p.stderr[-1800:])
raise SystemExit(p.returncode)
