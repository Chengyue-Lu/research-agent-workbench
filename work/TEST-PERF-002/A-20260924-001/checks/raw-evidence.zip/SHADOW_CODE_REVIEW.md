# 首版 propagation shadow 代码审查

Profile：CI shadow 实现设计审查；Skills：[]；owner：Chengyue-Lu。范围只含 `ci_contract_shadow.py`、对应测试diff、`PROPAGATION_REVIEW.md` 及必要plan/dependency API。基线HEAD `6cf80610cc2d3b4ebdeb9f47a840cd0ec1870bbf`。遵守CPU独占安排，**没有运行测试或反例**；以下是明确源码路径的静态缺陷及可执行回归设计，不冒称已复现运行结果。

## 发现

### P2：新归因将未验证的理由文本呈现为已验证义务事实

位置：`.github/scripts/ci_contract_shadow.py:116–117`（`propagation_review` 构造 `unclassified_obligations`）；已有验证入口 `63–79`；`.github/scripts/plan_ci.py:353–381`。

`verify_observed_plan` 验证可重算digest、Git facts与minimum obligations，但 `require_obligations` 完全不比较 `obligation_reasons`。因此在合法plan上仅删除或添加某输入的 `unclassified dependency surface: ...` 理由，再重算 `plan_id`，保留所有scope/selection/coverage等已验证字段，可通过现有检查，却改变新报告的 `unclassified_obligations` / `review_mechanisms`。文档称其为“exact accepted unclassified reasons”，超出了当前验证强度。这不会改变生产选择，但会产生错误的三链根因诊断，是本切片的核心正确性问题。

最小修复：利用入口已重算的minimum，对**本报告使用的unclassified理由集合逐维**核验，或直接由该minimum提供这组事实；不要要求全部理由文本字节相等，以免拒绝合法的额外metadata/显式full义务。原plan保留原身份，不把修补理由后重签的对象当原工件。

必要回归：真实Git合法plan，分别移除已有unclassified理由、伪造不存在的unclassified理由、在某一smoke维度伪造/删除该理由；每次重算plan_id，验证报告拒绝伪造或仍使用独立重算事实。合法额外full理由仍可保留。

### P2：isolated closure 与正式选择/输入事实使用不同的历史起点

位置：`.github/scripts/ci_contract_shadow.py:121–122` 的 `select(...binding['base'], ...binding['head'])`；正式planner在 `.github/scripts/plan_ci.py:464–465,587` 使用 **merge_base/head**；本报告输入versions也使用merge_base/head。

当base已前进而PR未rebase时，两对snapshot并不相同。具体反例：共同祖先M中现有test读取归档；develop分支B和PR分支H各自删除该读取，而H修改归档。正式M/H old/new union仍保留旧读取边与test；新增isolated B/H两侧都看不到旧读取，会遗漏这条需要解释的已接受传播。当前文档明确叫base/head，因此不是秘密篡改source，但把它放在同一accepted seed旁边作为本输入的传播解释，会使用不同问题的图，不能可靠解释正式结果。

最小修复：改用与accepted selection一致的 **merge_base/head**，在结果中显式携带所用graph refs；无需改变selector或增加新authority。如果确实另需base/head对照，应作为不同标签的第二项独立实验，本切片没有必要扩展。

必要回归：真实分叉Git fixture（base != merge_base），构造上述reader变化，保留真实合并target父SHA；断言isolated图与accepted old/new snapshot一致。当前新测试都沿线性base/head生成，覆盖不到该情形。

## 其余结论与小项

- `accepted_graph_seed` 由已验证selection中自根 `[path]` 判断，符合当前 `select` 对ordinary/reviewed seed保留自根的实现；policy metadata被discard后不会因文件名误算种子。
- 新schema4、producer hash、report digest、plan/merge父SHA验证及 `execution_authority=false` / activation=false继续保留。新字段未改变生产policy/selector/witness。文档明确模块、重叠集合和单BFS见证的局限，没有把模块数或单链归因冒充案例数/缩时证明。
- gitlink分支按object_type决定不读blob，字段保留ID和null content hash，方向正确。当前新gitlink测试使用本地已有 `self.base` 对象；可将其改成不存在的foreign commit ID增强“绝不读取非blob对象”的反例，但不是新增机制。
- 每seed ordinary closure会增加诊断成本；另一执行者正在计时，本审查不重复测量，也不根据循环次数推断实际开销。

## 本次读取的source hashes

- `.github/scripts/ci_contract_shadow.py`：`fc753ea7c03c33b0988d107e988d42826ea0219eadd786f6f45ba300fea672fe`
- `tests/test_ci_contract_shadow.py`：`64ff7d54325a1f9134e96e6bcbb7b9151c48484b98966c364468635b47ed004c`
- `docs/workstreams/chengyue-lu/TEST-PERF-002/PROPAGATION_REVIEW.md`：`cc17f980c218dc4d941df9052116d250ea93c61f24cf3595de03b78773a5058c`

结论：修复上述两项诊断正确性缺口后做有界复核；本报告不授予2C激活或排除权限。不建议为本轮追加更广设计或重跑full。
