"""New diagnostic observations of immutable corpus; never re-sign hosted evidence."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
WT = Path(r'D:\lcy\develop\_worktrees\RWB\ci-input-boundaries-v2')
OUT = ROOT / 'shadow-corpus'
OUT.mkdir(exist_ok=False)
sys.path.insert(0, str(WT/'.github/scripts'))
import plan_ci as planner

cases = {
    'pr90-official': Path(r'D:\lcy\develop\_assessments\rwb-ci-review-20260923\pr90-rebase-audit\official-plan.json'),
    'pr84-replay': WT/'work/TEST-PERF-002/A-20260916-009/checks/corpus-after/pr84-plan.json',
    'pr65-replay': WT/'work/TEST-PERF-002/A-20260916-009/checks/corpus-after/pr65-plan.json',
}
before = OUT/'before-producer'
before.mkdir()
(before/'ci_contract_shadow.py').write_bytes(subprocess.check_output(['git','-C',str(WT),'show',
    '6cf80610cc2d3b4ebdeb9f47a840cd0ec1870bbf:.github/scripts/ci_contract_shadow.py']))
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONUTF8':'1',
       'PYTHONPATH': os.pathsep.join(str(WT/p) for p in ('.github/scripts','src','.'))}
summary = []
for name, source in cases.items():
    original = json.loads(source.read_bytes())
    binding = original['binding']
    # All outputs are new local diagnostics; only pr90 retains its already verified formal plan.
    plan = original if name == 'pr90-official' else planner.make_plan(WT,
        base=binding['base'], head=binding['head'], target=binding['target'],
        repository=binding['repository'], body='- **Risk tier**: '+original['risk'])
    destination = OUT/name
    destination.mkdir()
    plan_path = destination/'plan.json'
    plan_path.write_bytes(planner.canonical(plan))
    record = {'case':name, 'original_plan_id':original['plan_id'], 'plan_id':plan['plan_id'],
              'binding':plan['binding'], 'original_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
              'identity':'current local diagnostic; not new hosted execution', 'runs':[]}
    for role, script in [('before',before/'ci_contract_shadow.py'),('after',WT/'.github/scripts/ci_contract_shadow.py')]:
        output=destination/(role+'-report.json')
        argv=[sys.executable,'-X','utf8','-B',str(script),'--repo',str(WT),'--plan',str(plan_path),'--output',str(output)]
        start=time.monotonic()
        result=subprocess.run(argv,env=env,cwd=WT,capture_output=True,encoding='utf-8')
        (destination/(role+'.log')).write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
        record['runs'].append({'role':role,'argv':argv,'seconds':time.monotonic()-start,'exit_code':result.returncode})
        if result.returncode:
            (destination/'failure.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
            raise SystemExit(result.stderr)
    older=json.loads((destination/'before-report.json').read_bytes())
    newer=json.loads((destination/'after-report.json').read_bytes())
    for field in ('binding','observed_plan_id','accepted_obligations','smoke_review','consumer_contract_review','activation'):
        assert older[field] == newer[field], field
    assert plan_path.read_bytes() == planner.canonical(plan)
    rows=newer['propagation_review']['inputs']
    record['input_count']=len(rows)
    record['isolated_inputs']=sum(row['isolated_ordinary_closure'] is not None for row in rows)
    record['mechanisms']={kind:sum(kind in row['review_mechanisms'] for row in rows)
                          for kind in ('unclassified-obligation','unbounded-resource','opaque-execution')}
    record['source_hashes']=newer['producer_sources']
    summary.append(record)
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in record.items() if k not in ('source_hashes','binding','runs')}),flush=True)
