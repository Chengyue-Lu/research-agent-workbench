# propagation shadow 两项P2修复复核

Profile：CI shadow 独立代码复核；Skills：[]；owner：Chengyue-Lu。本轮只读当前实现diff与两项新增回归，未运行测试；不覆盖原 `SHADOW_CODE_REVIEW.md`。

**结论：原两项P2在当前源码中均已闭合；本次有界delta复核未发现新的实质问题。** 这仅确认诊断正确性修复，不构成生产2C、排除权限或hosted收益的验收。

1. **重签理由篡改已封闭。** `verify_observed_plan` 在重算minimum并校验已有义务后，要求reason维度集合正确、值为字符串列表，再逐维比较全部 `unclassified dependency surface: ` 理由集合。删除、伪造或移到错误义务维度的理由不能仅靠重算plan_id通过。其它不属于该前缀的合法保守加严理由仍可保留，修复没有把本切片扩为所有理由文本的字节一致性要求。

   `test_resigned_unclassified_reasons_cannot_change_attribution` 使用真实Git计划，分别删除各维度理由、提交非法shape/值和伪造unclassified路径，并对每个变体重算digest；另保留合法追加full理由的控制。它检验的是归因来源验证，不只是修改原expected值。

2. **图的历史起点已对齐。** `propagation_review` 现在传入 `merge_base/head`，与正式selection及输入versions一致，并输出显式 `graph_binding`；basis文本同步更新。`test_isolated_graph_uses_merge_base_when_both_sides_remove_a_reader` 构造真实分叉及双亲merge，要求保留祖先的reader，并用旧错误 `base/head` 调用作为负对照确认它确会遗漏该模块。这覆盖了线性历史测试无法触及的原问题。

原有保护继续保留：先验证Git-bound plan和merge父身份；输出依然是无执行权的诊断报告；不更改accepted plan；普通isolated closure不传reviewed overrides；模块集合与单条见证仍明确不代表完整/独占因果或运行成本。未发现此次修复影响生产selector、policy、witness、B→C−B或coverage门槛。

## 源码绑定与验证范围

- `.github/scripts/ci_contract_shadow.py` SHA256：`d52f328826c9785f442ff1b7d30000611bea93f2ea9d04ff9ec7845fa2af3959`
- `tests/test_ci_contract_shadow.py` SHA256：`325ac3ab3391425b0e1c3b4ec7f21ac5546d37703092dc676fb46eb8d71b433f`
- `PROPAGATION_REVIEW.md` SHA256：`8040c5bc6ea55c3b261cf07695d8b587b7a982cf740e66330fa322575e147b0a`

主任务报告双Python相关35项各PASS、shadow局部151/151行及44/44分支；本复核没有重新执行或独立审计这些运行工件，不能将其写成本agent的新执行结果。当前成本配对仍由其独占执行者完成；此处不追加测试、性能推论或其它设计要求。
