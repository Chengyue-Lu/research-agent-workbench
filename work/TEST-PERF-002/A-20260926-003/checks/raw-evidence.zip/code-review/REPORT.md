# PR101 accepted-template implementation: independent source review

Date: 2026-09-26. Profile: independent source reviewer. Required Skills: []. Scope: frozen final diff for consumer shadow loader, seven real-Git regression methods, and ACCEPTED_CONSUMER_TEMPLATES.md. Read-only: no tests, source edits or remote operations. This report is the only write. Stop condition: one bounded review completed.

## Outcome

No material blocking findings in the reviewed diff. The slice implements source provenance for diagnostic consumer proposals and keeps production execution authority unchanged. This is a static source review, not an executed test result, approval by the accountable human owner, or an independent exclusion witness.

Reviewed source identities (SHA-256):

| Path | SHA-256 |
| --- | --- |
| `.github/scripts/ci_consumer_shadow.py` | `f79b699e48ddd293427647d0b10a8d78fee312c1e8f6b0e437110326bbb29d8d` |
| `tests/test_ci_consumer_shadow.py` | `e5af811c35e64b54965ba16971ad905f57b579555d75fc291cf7bb52aadddf675` |
| `docs/workstreams/chengyue-lu/TEST-PERF-002/ACCEPTED_CONSUMER_TEMPLATES.md` | `7f4f9279b452a6dd0179db8550707a592952e5c795c40f4c05e6715937678348` |

## Source / plan identity

`accepted_proposal` requires the externally supplied accepted base to equal the observed plan base and uses the existing exact-commit validator. It resolves the template from the accepted snapshot, requires `100644`/`blob`, reads raw Git bytes, and recomputes the blob identity before parsing. The template contains exactly version, execution_authority and consumers; adding the explicit base as the effective baseline is visible rather than silently replacing an existing baseline. Original consumer objects, assumptions, unknowns, test ownership and pins are preserved.

`build_accepted_report` calls the unchanged `build_report`, which still verifies the observed plan's exact Git facts, accepted minimum, inventory and receipt semantics. It adds the source provenance and explicit missing-independent-witness blocker, then recomputes the report digest. The existing `build_report` implementation itself has no semantic edits. Its source-hash field naturally changes when its module bytes change; that is expected current-source binding, not changed selection behavior or reuse of an old report identity.

The loader API alone verifies the base/template binding; full plan/head/target/inventory validation remains in the report builder. Its return should continue to be treated as data rather than an execution authorization.

## Malformed data, modes and paths

Portable path checks plus the additional JSON/exact-path constraint reject traversal, absolute or backslash paths, wildcards, malformed path components and non-JSON names. Exact snapshot lookup avoids accepting candidate-only files or following a symlink/gitlink. JSON parsing uses the existing duplicate-key hook, followed by exact shape and existing consumer validation. Authority injection, a prefilled baseline, boolean version, malformed consumers/pins and invalid unknowns are rejected.

The code reuses the repository's SHA-1 Git identity model deliberately; the blob hash comparison detects bytes that do not match the snapshot OID. It does not purport to authenticate the Git executable, repository redirection environment, checker imports or the full object database against a hostile caller. Those are explicitly still outside an independent accepted witness, consistent with the documented scope.

## CLI overwrite and compatibility

`--proposal` and `--accepted-proposal-template` are mutually exclusive. An accepted base is required only in the new template mode. Existing external-proposal callers retain their API and diagnostic output semantics. Plan, inventory, optional receipt, external proposal and the local template path are included in the existing resolved-path/hardlink overwrite guard. The template source remains its Git blob even when worktree bytes are dirty or unavailable.

The current producer is diagnostic and caller-invoked. The documentation explicitly states that choosing a commit called accepted is not proof of human review and that source hashes do not authenticate checker dependencies. No report enables production skips, overrides coverage/smoke, or claims timing savings.

## Regression coverage assessed by reading

The seven new test methods cover:

1. An accepted unresolved definition remains unchanged under local rewrites of unknowns, pins, ownership and tests; its plan delta remains Markdown-only, so the assertion isolates the actual source-binding protection.
2. External and accepted report behavior matches for selection, accepted obligations, comparison and coverage/smoke; raw Git, effective proposal and report identities remain distinct.
3. Candidate committed rewrites, deletion, symlink mode and candidate-only paths cannot replace the base definition.
4. Exact commit identity, portable path and regular mode requirements, including executable, symlink and gitlink entries.
5. Malformed and duplicate-key frozen templates plus invalid consumer fields.
6. Raw bytes must match the Git tree's blob identity.
7. CLI source exclusivity and input-overwrite guards.

The tests retain the existing conservative proposal evaluator and its overlap, unknown-input and changed-pin behavior instead of creating a second selector. No test outcomes are asserted in this source review; root dual-Python execution is separate evidence.

## Nonblocking limits

The new Git loader has no explicit byte-size budget. This matches its current local/offline caller-selected accepted-data scope and is not a production authority blocker. A future hostile-input or hosted witness boundary should set explicit object/JSON size limits and sanitize Git/Python environment before treating any receipt as trusted. This review does not request widening the current slice to that future boundary.

The linked Attempt A003 was not audited here; its final existence, hashes, truthful capture boundary and Markdown links belong to root's archive/validation step. No current-source review should be relabeled as proof for later changed source bytes.
