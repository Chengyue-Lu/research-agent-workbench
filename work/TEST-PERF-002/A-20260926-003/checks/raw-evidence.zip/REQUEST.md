# PR101 continuation: accepted declaration provenance

User request: continue. Owner Chengyue-Lu; TEST-PERF-002; R2; Skills [].
Live accepted develop 5bf2227ca9b4d2f63f452e579185e7838028de78; current Draft101
head54da8a655b509ef908f978a0abad451779d53eba and content36203011316 complete PASS.
No current review comments, approvals or source drift. Do not rerun that CI.

Profile: CI boundary engineer. This slice adds a Git-bound declaration input to
the existing consumer shadow API. It does not activate a selection rule or claim
complete invocation closure. The accepted declaration commit/path, original raw
bytes and effective current-base proposal remain distinct. A committed template
omits baseline to avoid requiring a file to contain its own Git commit ID.

Reads: project AGENTS/README/DEVELOPMENT/MEMORY, Issue87/PR101; workstream consumer
and Attempt boundary docs; ci_consumer_shadow, contracts, shadow pair, domain
audit, input facts, planner, selection witness and existing relevant tests/policy.
New writes: ci_consumer_shadow.py, test_ci_consumer_shadow.py, bounded workstream
documentation, new A-20260926-003 evidence; local assessment files, existing PR101
and Issue87 phase body and own shared memory entries. Preserve other-owner code,
main checkout, local config, all prior archive/source identities and policies.

Delegation permitted for independent bounded review and disjoint implementation:
- exclusion_design: source-only trust design review; design-review output only.
- accepted_template_impl: implement the two named Python files; no commit/push.
- independent code review follows final source; no repeated behavioral execution.

Validation: real Git adversarial tests; dual-Python focused regressions and local
module line/branch evidence with existing quality thresholds; committed-head
plan/governance/independent accepted-base floor witness/docs. One current-target
hosted run after push, authenticated official plan and native outcomes. Production
90/95/90 and changed100/100 remain; no exclusions expanded. Full local reruns are
unnecessary when native hosted execution supplies the actual plan obligations.

Stop: coherent continuation published to the existing Draft with exact evidence
and unresolved activation boundaries; no merge or Ready toggle without context.
The new declaration reader is not yet an independently accepted checker and
the selected commit's ancestry alone does not prove human approval. Existing
selection-floor witness remains unchanged. Production2C, cross-commit reuse and
release/tag/main remain separate work.

Capture: final code, tests, raw outputs and written agent findings retained.
Earlier visible tool/inter-agent messages are not a continuously complete stream;
the new Trace must preserve the capture-gap warning.
