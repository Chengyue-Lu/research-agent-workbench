from pathlib import Path
import hashlib,io,json,os,subprocess,sys,time,unittest
import coverage

ROOT=Path(__file__).resolve().parent
WT=Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
out=ROOT/'local-checks'/sys.argv[1];out.mkdir(parents=True,exist_ok=False)
files=['.github/scripts/ci_consumer_shadow.py','tests/test_ci_consumer_shadow.py','.github/scripts/ci_shadow_pair.py']
pins={p:hashlib.sha256((WT/p).read_bytes()).hexdigest() for p in files}
sys.path[:0]=[str(WT),str(WT/'src'),str(WT/'tests'),str(WT/'.github/scripts')]
os.chdir(WT)
cov=coverage.Coverage(data_file=str(out/'coverage.data'),branch=True,config_file=False,source=[str(WT/'.github/scripts')])
cov.start()
stream=io.StringIO();started=time.perf_counter()
suite=unittest.defaultTestLoader.loadTestsFromNames(['test_ci_consumer_shadow','test_ci_shadow_pair'])
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
cov.stop();cov.save();cov.json_report(outfile=str(out/'coverage.json'),include=['*/ci_consumer_shadow.py','*/ci_shadow_pair.py'])
(out/'unittest.log').write_text(stream.getvalue(),encoding='utf-8')
assert pins=={p:hashlib.sha256((WT/p).read_bytes()).hexdigest() for p in files},'source moved during checks'
summary={'status':'PASS' if result.wasSuccessful() and not result.skipped else 'FAIL','tests':result.testsRun,
 'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'seconds':time.perf_counter()-started,
 'python':sys.version,'executable':sys.executable,'source_pins':pins,'scope':'local related modules, not repository coverage/hosted execution'}
measured=json.loads((out/'coverage.json').read_bytes())
summary['modules']={p:{'summary':v['summary'],'missing_lines':v['missing_lines'],'missing_branches':v['missing_branches']} for p,v in measured['files'].items()}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2));print(stream.getvalue() if summary['status']=='FAIL' else '')
raise SystemExit(summary['status']!='PASS')
