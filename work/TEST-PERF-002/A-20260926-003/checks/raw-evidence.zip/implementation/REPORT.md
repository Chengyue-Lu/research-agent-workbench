# Accepted Git template implementation handoff

Profile: CI diagnostic implementation engineer. Required skills: [].
Write scope: `.github/scripts/ci_consumer_shadow.py`, `tests/test_ci_consumer_shadow.py` only. No commits, GitHub writes, configuration or production policy changes.

## Implemented

- `accepted_proposal(repo, plan, accepted_base, template_path)` accepts an explicit exact SHA-1 commit matching `plan.binding.base`; resolves only an immutable regular 100644 JSON Git blob and verifies its content hash against that tree entry. It rejects unsafe/wildcard paths, missing/candidate-only/deleted templates, nonregular modes, duplicate keys, unsupported shape and embedded baseline.
- Template shape is exactly version/execution_authority/consumers. Existing proposal validation applies after baseline injection; consumer pins, ownership, inputs, assumptions and unknowns remain identical to frozen definitions.
- `build_accepted_report(...)` calls the unchanged `build_report(...)`, adds accepted-template raw SHA-256/Git blob/commit/path and effective-proposal digest, retains false execution authority and blockers, and recalculates report identity. Binding-only rebinding is not semantic qualification or independent accepted-witness proof. Checker/import authentication remains external.
- CLI has mutually exclusive external `--proposal` or `--accepted-proposal-template`; `--accepted-base` is required only in the latter mode. The overwrite guard also protects the candidate worktree copy of the template.
- Candidate drift is not separately classified. Candidate contents are never a substitute for the accepted definition; existing Markdown-pilot fallback remains authoritative for committed non-Markdown changes.

## Tests and bounded validation

Seven new real-Git test methods retain every pre-existing test unchanged. They cover dirty template unknown/pin/test-owner rewriting with a docs-only Git delta, committed rewriting/deletion/symlink in the candidate, regular/executable/symlink/gitlink modes at the supplied base, missing/candidate-only/accepted-deleted paths, wrong/ref/abbreviated/blob commit identities, malformed/duplicate/authority/version/consumer definitions, independent raw/effective identities and baseline rebinding, immutable diagnostic requirements, CLI source exclusivity/overwrite protection, and actual loose-blob content corruption inside a temporary repository.

- Python 3.11 initial six new methods: 6 PASS, 11.095 s.
- Added real corrupted-blob method: 1 PASS, 1.064 s.
- After adding explicit accepted-deletion and binding-rebind assertions, only those two changed methods reran: 2 PASS, 3.694 s.
- `git diff --check` on the owned files passed before the final assertion additions; the additions are ordinary space-indented Python.
- Root owns final dual-Python module/coverage/regression validation and publication. No coverage or hosted results are asserted here.

## Defects and residual boundaries

No implementation defect was observed by these bounded runs. The data-binding feature does not establish human acceptance of an arbitrary supplied commit, prove complete consumer input closure, authenticate receipt/inventory origin, authenticate the candidate checker/import closure, provide an independent execution witness, or authorize exclusion. Existing activation blockers remain.

## Final source hashes

- ci_consumer_shadow.py SHA-256: `f79b699e48ddd293427647d0b10a8d78fee312c1e8f6b0e437110326bbb29d8d`.
- test_ci_consumer_shadow.py SHA-256: `eafdd464fd64eec19df73d675e095b4bd89e0e07d905d1e3492fb0a0af252034`.
