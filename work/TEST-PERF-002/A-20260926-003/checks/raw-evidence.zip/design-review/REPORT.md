# PR101: accepted proposal provenance before exclusion authority

Profile: independent CI trust reviewer. Required Skills: []. Scope: read-only source/design review; this report is the sole write. Budget: one bounded review. Stop condition: recommendation and a narrow acceptance matrix delivered. Date: 2026-09-26.

## Recommendation

Implement a small **accepted-Git proposal input mode in the existing consumer shadow tool**, preserving its offline status. This is a useful next prerequisite because the current `--proposal` is a caller-supplied file: a caller can remove `unknowns`, refresh pins, rewrite test ownership or input patterns, and obtain a different *proposed* skip. That is not a production vulnerability today: every report remains `execution_authority=false`, `activation.eligible=false`, and no workflow consumes it as a plan. The new mode should make the source of the proposal independently selectable and immutable before a future witness is considered.

Do not describe this slice as an independent exclusion witness or complete input closure. The current accepted `selection_witness.py` independently checks the selection-authority behavioral floor only; it does not check consumer exclusions, completeness of proposals, runtime inputs, coverage, or execution. The new checker is itself candidate code until reviewed and accepted.

This is not redundant with `ci_consumer_contracts.review`: that module already freezes a different policy-record format from the base and checks candidate revisions against original pins. Reuse its **base owns the definition** rule. Do not translate its descriptive strings into allowlists or invent a mapping from its positive/negative IDs to the richer shadow invocation protocol. Keep one consumer shadow evaluator and its current unknown/overlap/fallback behavior.

## Necessary representation decision: avoid a self-referential Git SHA

The existing proposal requires `proposal.baseline == plan.binding.base`. A file committed *inside that base* cannot also contain its own commit SHA. Simply reading this existing proposal from `base:path` therefore cannot provide a practical positive path; silently overwriting its baseline would hide requalification.

The narrowest explicit solution is a committed **proposal template**: a separately versioned shape with the existing consumer definitions but no baseline field. The external invocation supplies the exact accepted base and repository-relative path; the loader requires that base to equal the independently supplied expected base and the observed plan's base. It constructs the effective existing v1 proposal by adding that explicit base and calls the existing validation/evaluator. Preserve and report both identities:

- Raw accepted source: exact commit, path, regular mode, blob OID, raw SHA-256, template version.
- Effective proposal: explicit baseline, canonical semantic digest, and consumer definitions that are byte/semantic-equivalent to the template (no source-pin refresh, unknown removal or record rewriting).

This is an explicit template instantiation, not evidence reuse, not a claim that any historical declaration is newly reviewed, and not a rewritten old receipt. Preserve the existing external v1 proposal mode and its limitations. Use mutually exclusive CLI modes; reject ambiguous combinations. Do not require a repository-wide policy/schema revision for this diagnostic-only loader.

A legitimate alternative is an external reviewer-pinned raw artifact digest whose file contains the full baseline. That avoids a template schema but moves trust establishment outside Git and supplies less directly reusable provenance. Do not add both alternatives in this slice.

## Concrete trust and input boundaries

1. **External root:** expected base/path must be explicit trusted inputs to the new API/CLI, not adopted only from the candidate plan or a candidate wrapper. Require exact 40-hex commit identity and verify the object type. A path supplied by a candidate is merely another proposal and cannot be labeled accepted because the bytes happen to exist in a repository.
2. **Raw Git metadata:** resolve the path literally from the exact accepted tree, require one blob entry with mode `100644`, then read that blob. Reject absent/tree/symlink/gitlink/executable entries, wildcard/pathspec or escape paths, malformed JSON, duplicate keys, unsupported version/fields and oversized content. Never resolve a gitlink's foreign object or execute filters while loading the definition. Reuse existing exact-Git and duplicate-key helpers where their semantics fit.
3. **Materialization:** raw blob agreement is deliberately different from checkout bytes. This loader protects the proposal definition, not a business consumer's materialized inputs. Existing `.gitattributes` findings therefore remain unresolved for actual reader closure. A dirty candidate/worktree proposal cannot change this definition; record any different candidate bytes as proposal/drift, not authority.
4. **Candidate mutation:** removal/rewrite/new consumer records at head cannot erase an accepted unknown, reassign an existing test, refresh a source pin, or broaden the input-change pilot. Existing matching pins are checked at base/merge-base/head/target. New/unregistered tests remain selected, overlap requires agreement from every accepted consumer, and changed executable/helper inputs continue to retain their tests.
5. **Membership:** an input list without directory membership is incomplete. The current Trace checks top-level messages and recursive tool events; default RuntimeResources checks its complete manifest and physical directory closure. Do not derive exclusion permissions from four successful read observations, literal searches, or a schema-only pin list.
6. **Environment/toolchain:** Git executable/config/environment, Python/dependency/bootstrap state, invocation roots, alternative APIs and child/native I/O remain outside complete closure. Bind loader/producer sources for audit, but a digest does not establish trust in their code. At minimum use raw no-replacement object reads and demonstrate that worktree attributes do not influence proposal bytes. A future accepted execution harness must sanitize repository-redirection/config environment and bind materialization/toolchain before proving business exclusions.
7. **Future independent witness:** run accepted code from a reviewer-pinned root without importing candidate code, bind the entire checker dependency closure and independently obtain repository/base/head/target. A current candidate process that reads base data is stronger provenance but still cannot verify itself against a deliberate checker rewrite. Preserve this limitation in every new report.

## Narrow acceptance tests

Use real temporary Git repositories and exact commits, retaining the existing consumer-selection assertions. A shared fixture is reasonable; each behavior should retain a readable named test/checkpoint. No new full suite is needed just to test this adapter.

| Case | Required result |
| --- | --- |
| Committed valid template + unrelated existing Markdown delta | Explicit accepted commit/path/blob/raw/effective identities; effective proposal equals template consumers plus externally supplied base; the existing evaluator's result is unchanged |
| Accepted unknown, then candidate/local proposal removes that unknown | New mode retains accepted unknown and tests; external mode remains clearly caller-supplied; do not let generic outside-Markdown fallback be the only asserted reason |
| Candidate refreshes changed helper pin or transfers test ownership | Original accepted pin/ownership remains in force; helper drift or original overlap retains the test |
| Worktree file is dirty or replaced; candidate branch rewrites/removes template | Exact accepted blob is still used; record source status if exposed, never substitute candidate bytes |
| Wrong expected base, stale plan/base binding, branch-name ref, missing blob | Fail closed before proposing skips |
| `120000`, `160000`, `100755`, tree, traversal/pathspec, malformed/duplicate JSON, unknown version/authority field | Reject the definition; do not dereference external objects or execute candidate files |
| Candidate adds a new canonical test or an overlapping accepted consumer | The new/unresolved test stays selected; all relevant accepted owners must support any proposed skip |
| Candidate edits the new checker itself | Report stays offline and explicitly lacks independent witness authority; existing production plan/witness behavior remains intact |
| Coverage/smoke fields and activation flags | All accepted obligations byte/semantically unchanged, `execution_authority=false`, `activation.eligible=false`; no receipt/timing or speedup claim |

The first negative should assert the retained accepted unknown explicitly. A tracked JSON rewrite already falls outside the current modified-Markdown pilot; a test that only observes conservative selection there does not isolate protection from proposal self-rewriting. An uncommitted local proposal rewrite or direct source-loader assertion provides the clean control.

## Boundary still awaiting later work

This slice freezes the source of an exclusion *proposal*. It does not prove that the proposal exhausts real inputs. A real exclusion witness and 2C activation still require independent accepted checker execution, old/new consumer and membership closure, environment/materialization qualification, retained relevant-failure and irrelevant-control probes, complete B/C lifecycle, actual candidate coverage/smoke and required fresh hosted pairs. Keep default whole-Runtime/catalog dependencies selected. No change to planner authority, workflow, global90/critical95-90/changed100-100, integration freshness or cross-commit reuse belongs here.

## Reviewed inputs

- `docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_CONTRACTS_V1.md`
- `docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_SHADOW.md`
- `docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_SHADOW_READINESS.md`
- `docs/workstreams/chengyue-lu/TEST-PERF-002/CI_REPLAN_ACCEPTANCE.md`
- `docs/workstreams/chengyue-lu/TEST-PERF-002/ATTEMPT_INPUT_BOUNDARY.md`
- `.github/scripts/ci_consumer_shadow.py`, `ci_consumer_contracts.py`, `selection_witness.py`, relevant exact-Git/verification helpers in `plan_ci.py` and `ci_contract_shadow.py`
- Existing consumer-shadow and attribute-consumer test boundaries; `work/TEST-PERF-002/A-20260926-002/RESULTS.md`

No code/test/remote writes and no business executions were performed in this review.
