from pathlib import Path
from dataclasses import asdict
import hashlib,json,subprocess,sys,zipfile
R=Path(__file__).resolve().parent
W=Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
BASE='5bf2227ca9b4d2f63f452e579185e7838028de78'
IMPL=json.loads((R/'implementation.json').read_bytes())['head']
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip()==IMPL
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results={v:json.loads((R/f'local-checks/{v}-final/summary.json').read_bytes()) for v in ('311','313')}
for result in results.values():
 assert result['status']=='PASS' and result['tests']==20 and result['skips']==0
 for name,digest in result['source_pins'].items():
  assert sha(W/name)==digest==hashlib.sha256(subprocess.check_output(['git','-C',str(W),'show',IMPL+':'+name])).hexdigest()
 for module in result['modules'].values():
  assert not module['missing_lines'] and not module['missing_branches']
assert (R/'code-review/FINAL.json').is_file(),'current final source review required'
review=json.loads((R/'code-review/FINAL.json').read_bytes())
assert review['status']=='PASS'
A=W/'work/TEST-PERF-002/A-20260926-003';A.mkdir(parents=True,exist_ok=False)
C=A/'checks';C.mkdir()
paths=[R/name for name in ('REQUEST.md','implementation.json','actual-base-refusal.json','preserved-functions.json','validate_local.py','freeze.py')]
paths += [p for directory in ('design-review','code-review','implementation','local-checks') for p in (R/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
with zipfile.ZipFile(C/'raw-evidence.zip','x',zipfile.ZIP_DEFLATED) as archive:
 for p in sorted(paths):archive.write(p,p.relative_to(R).as_posix())
(C/'manifest.json').write_text(json.dumps({p.relative_to(R).as_posix():sha(p) for p in sorted(paths)},indent=2)+'\n',encoding='utf-8')
template=json.loads((W/'work/TEST-PERF-002/A-20260926-002/checks/consumer-proposal.json').read_bytes())
template.pop('baseline')
(C/'consumer-template.json').write_text(json.dumps(template,indent=2)+'\n',encoding='utf-8')
summary={'status':'PASS-local-scoped','implementation':IMPL,'base':BASE,'related_tests_per_python':20,'new_tests':7,
 'local_results':results,'review':review,'actual_base_refusal':json.loads((R/'actual-base-refusal.json').read_bytes()),
 'template_source':'A002 observation definitions unchanged, baseline intentionally omitted; candidate proposal only',
 'template_raw_sha256':sha(C/'consumer-template.json'),'execution_authority':False,'independent_witness_proved':False,
 'input_closure_proved':False,'hosted_execution_proved':False,'raw_zip_sha256':sha(C/'raw-evidence.zip')}
(C/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
(A/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
(A/'RESULTS.md').write_text(f'''# Accepted declaration provenance for consumer shadow

Owner Chengyue-Lu; TEST-PERF-002; R2; Skills []. Accepted base `{BASE}`;
implementation `{IMPL}`. This is a diagnostic proposal-source adapter, not an
independent exclusion witness or production activation.

The new mode loads an explicitly selected base's regular JSON Git blob. Its
template omits baseline; the effective proposal adds the externally supplied
plan base and records a separate digest. Candidate/local changes to unknowns,
pins and test ownership cannot replace the source definition. Existing external
proposal evaluation, all previous tests and production selection remain intact.

Seven real-Git regressions cover dirty declaration replacement while the Git delta
stays document-only, committed rewrite/deletion/mode changes, exact commit/path
validation, malformed/duplicate templates, raw object corruption and CLI source
selection/output protection. Both Python3.11 and3.13 passed20 related tests with
zero skips/errors/failures. Local consumer-shadow coverage is237/237 statements
and86/86 branches; unchanged shadow-pair is125/125 and42/42. This is local module
evidence, not repository coverage. Existing evaluator/test functions are preserved.

Independent source review passed final source hashes, including a separately
reviewed final corruption-test addition. No production validator is mocked by
these real-Git tests. Current accepted5bf does not contain PR101's candidate-only
declaration: its expected refusal is retained separately and never relabeled as
an accepted contract. [Template](checks/consumer-template.json) retains A002's
three observed consumer definitions, four test IDs and all unknowns; introducing
this file in the PR does not make it an accepted input at the old base.

[Summary](checks/summary.json), [raw](checks/raw-evidence.zip) and
[manifest](checks/manifest.json) bind commands, test outcomes, source review,
coverage, preserved functions and actual-base refusal. Tests ran on these exact
source bytes before the implementation commit. Final-head validation and hosted
execution follow under their own identities. Whole-Runtime inputs, checker/import
authentication, materialization/environment, B/C lifecycle and candidate quality
remain separate activation requirements. No speedup or skip authority is claimed.

Trace begins at this evidence freeze; earlier visible tool/inter-agent events
were not continuously captured in full. Written reviews and raw checks are
preserved with a capture-gap warning; publication remains a subsequent action.
''',encoding='utf-8',newline='\n')
sys.path.insert(0,str(W/'src'))
from research_workbench.observability.trace import AgentTraceRecorder,validate_attempt_trace
t=AgentTraceRecorder(A,task_id='TEST-PERF-002',task_revision=47,attempt_id=A.name,
 task_snapshot={'task_id':'TEST-PERF-002','revision':47,'request':'Continue PR101',
 'scope':'accepted Git declaration provenance; diagnostic only','profile':'CI boundary engineer','required_skills':[],
 'delegation':True,'budget':'one source adapter and real Git adversarial tests; scoped dual Python and actual CI',
 'stop_condition':'updated Draft with exact source and native evidence; activation remains separate'},
 accountable_owner='Chengyue-Lu',actor_id='main-agent',runtime_identity='Codex desktop',provider='OpenAI',
 read_allowlist=['AGENTS.md','README.md','PROJECT_MEMORY.md','docs/DEVELOPMENT.md','.github/scripts/**','tests/**','docs/workstreams/chengyue-lu/TEST-PERF-002/**','work/TEST-PERF-002/**'],
 write_scope=['.github/scripts/ci_consumer_shadow.py','tests/test_ci_consumer_shadow.py','docs/workstreams/chengyue-lu/TEST-PERF-002/**','work/TEST-PERF-002/A-20260926-003/**'],
 tool_allowlist=['collaboration','shell','git','gh','python'],baseline=BASE)
t.record_capture_gap('messages','Raw checks and written review findings retained; earlier visible tool/inter-agent events are not a complete continuous captured stream.')
t.record_capture_gap('external-actions','Final-head and hosted verification and publication follow this sealed local record.')
t.record_tool_call(operation_id='freeze-accepted-template-provenance',tool_name='python',status='succeeded',
 arguments={'operation':'freeze exact source, real Git regressions, local coverage and independent review'},
 result={'implementation':IMPL,'summary_sha256':sha(C/'summary.json')},result_entered_context=True)
t.seal('safe-paused')
v=validate_attempt_trace(W,A);validation={'blocked':v.blocked,'risks':[asdict(x) for x in v.risks]}
(C/'trace-validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8')
assert not v.blocked
print(json.dumps({'archive':str(A.relative_to(W)),'files':len(paths),'trace':validation}))
