"""Static equivalence of every original test except its selected preparation call."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

ASSESSMENT = Path(__file__).parent
ROOT = Path("D:/lcy/develop/_worktrees/RWB/slow-fixture-seeds-20261004")
source_path = ROOT / "tests/test_skill_execution_closeout.py"
before = (ASSESSMENT / "accepted-test_skill_execution_closeout.py").read_text(encoding="utf-8")
after = source_path.read_text(encoding="utf-8")
runner = ast.parse((ASSESSMENT / "run_pair.py").read_text(encoding="utf-8"))
selected = next(ast.literal_eval(node.value) for node in runner.body
                if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id == "METHODS")

def methods(source):
    tree = ast.parse(source)
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef)
               and node.name == "SkillExecutionCloseoutTests")
    return {node.name: node for node in cls.body if isinstance(node, ast.FunctionDef)}

original = methods(before)
candidate = methods(after)
tests = sorted(name for name in original if name.startswith("test_"))
assert len(tests) == 33
assert tests == sorted(name for name in candidate if name.startswith("test_"))
rows = []
for name, old in original.items():
    new = candidate[name]
    assertions = [ast.dump(node, include_attributes=False) for node in ast.walk(old)
                  if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                  and node.func.attr.startswith("assert")]
    new_assertions = [ast.dump(node, include_attributes=False) for node in ast.walk(new)
                      if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                      and node.func.attr.startswith("assert")]
    assert assertions == new_assertions, name
    if name in selected:
        old_first = old.body[0]
        assert ast.dump(old_first, include_attributes=False) == ast.dump(
            ast.parse("fixture = SkillCloseoutFixture(self.root)").body[0], include_attributes=False), name
        assert ast.dump(new.body[0], include_attributes=False) == ast.dump(
            ast.parse("fixture = self.completed_archive_fixture()").body[0], include_attributes=False), name
        old.body[0] = new.body[0]
    assert ast.dump(old, include_attributes=False) == ast.dump(new, include_attributes=False), name
    rows.append({"method": name, "assertion_call_count": len(assertions),
                 "assertion_ast_equal": True, "body_equal_except_preparation": True,
                 "preparation_changed": name in selected})

diff = subprocess.run(["git", "diff", "--", "tests/test_skill_execution_closeout.py"],
                      cwd=ROOT, check=True, capture_output=True).stdout
(ASSESSMENT / "candidate.diff").write_bytes(diff)
(ASSESSMENT / "candidate-test_skill_execution_closeout.py").write_bytes(source_path.read_bytes())
head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, check=True,
                      capture_output=True, text=True).stdout.strip()
report = {
    "status": "PASS", "base": head, "original_test_method_count": len(tests),
    "candidate_test_method_count": len(tests), "selected_preparation_changes": len(selected),
    "original_assertion_call_count": sum(row["assertion_call_count"] for row in rows if row["method"].startswith("test_")),
    "all_original_methods_preserved": True, "all_assertion_ast_preserved": True,
    "all_patch_subtest_attack_and_cold_bodies_preserved": True,
    "all_unselected_original_bodies_equal": True,
    "source_hashes": {
        "before": hashlib.sha256((ASSESSMENT / "accepted-test_skill_execution_closeout.py").read_bytes()).hexdigest(),
        "after": hashlib.sha256(source_path.read_bytes()).hexdigest(),
        "diff": hashlib.sha256(diff).hexdigest(),
        "pair_runner": hashlib.sha256((ASSESSMENT / "run_pair.py").read_bytes()).hexdigest(),
    },
    "test_inventory": tests, "methods": rows,
}
(ASSESSMENT / "equivalence.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: report[key] for key in ("status", "original_test_method_count", "candidate_test_method_count", "selected_preparation_changes", "original_assertion_call_count", "source_hashes")}, indent=2))
