"""One bounded isolation set against the candidate's actual fixture factory."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import time

from tests import skill_closeout_fixtures as fixtures
from tests.test_skill_execution_closeout import SkillExecutionCloseoutTests as Cases

OUTPUT = Path(__file__).parent

def hashes(root):
    return {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(root.rglob("*")) if path.is_file()}

def mutable_ids(value):
    if isinstance(value, dict):
        return {id(value)} | set().union(*(mutable_ids(item) for item in value.values()))
    if isinstance(value, list):
        return {id(value)} | set().union(*(mutable_ids(item) for item in value))
    return set()

def assert_plain(value):
    if isinstance(value, dict):
        for item in value.values():
            assert_plain(item)
    elif isinstance(value, list):
        for item in value:
            assert_plain(item)
    else:
        assert isinstance(value, (str, int, float, bool, type(None))), type(value)

counts = {"fixture_init": 0, "execute_frozen_view": 0, "provider_execute": 0}
codes = {fixtures.SkillCloseoutFixture.__init__.__code__: "fixture_init",
         fixtures.execute_frozen_view.__code__: "execute_frozen_view",
         fixtures.RecordingDriver.execute.__code__: "provider_execute"}
def observe(frame, event, arg):
    if event == "call" and frame.f_code in codes:
        counts[codes[frame.f_code]] += 1

first = Cases("test_artifact_corruption_is_rejected")
second = Cases("test_checker_pin_corruption_is_rejected")
Cases.setUpClass()
start = time.perf_counter()
sys.setprofile(observe)
try:
    first.setUp()
    a_start = time.perf_counter()
    a = first.completed_archive_fixture()
    first_factory_seconds = time.perf_counter() - a_start
    seed_root, state = Cases._completed_seed
    assert_plain(state)
    seed_hashes = hashes(seed_root)
    state_before = copy.deepcopy(state)
    assert hashes(first.root) == seed_hashes
    assert a.bundle.project_root == first.root.resolve()
    assert a.view.project_root == first.root.resolve()
    assert a.trace_dir == first.root / "closeout/trace"
    assert not hasattr(a, "driver") and not hasattr(a, "recorder")
    assert not mutable_ids(a.host) & mutable_ids(state["host"])
    assert not mutable_ids(a.validation) & mutable_ids(state["validation"])
    artifact = a.host["artifacts"][0]["path"]
    (first.root / artifact).write_bytes(b"isolated first-copy corruption\n")
    a.host["artifacts"][0]["path"] = "different-first-copy.yaml"
    a.validation["subject_refs"][0]["sha256"] = "0" * 64
    assert hashes(seed_root) == seed_hashes
    assert state == state_before
    second.setUp()
    b_start = time.perf_counter()
    b = second.completed_archive_fixture()
    second_factory_seconds = time.perf_counter() - b_start
    assert first.root != second.root != seed_root
    assert hashes(second.root) == seed_hashes
    assert b.host == state_before["host"]
    assert b.validation == state_before["validation"]
    assert not mutable_ids(a.host) & mutable_ids(b.host)
    assert not mutable_ids(a.validation) & mutable_ids(b.validation)
    assert a.bundle is not b.bundle and a.view is not b.view
    assert b.bundle.project_root == second.root.resolve()
    assert b.view.project_root == second.root.resolve()
    assert b.bundle.manifest_path == second.root.resolve() / "bundle/manifest.yaml"
    assert b.trace_dir == second.root / "closeout/trace"
    assert not hasattr(b, "driver") and not hasattr(b, "recorder")
    receipt = second.replay(b)
    assert receipt.document["status"] == "completed"
    assert counts == {"fixture_init": 1, "execute_frozen_view": 1, "provider_execute": 1}, counts
    evidence = {
        "status": "PASS", "source_sha256": hashlib.sha256((fixtures.ROOT / "tests/test_skill_execution_closeout.py").read_bytes()).hexdigest(),
        "first_factory_including_seed_seconds": first_factory_seconds,
        "second_copy_rebind_seconds": second_factory_seconds,
        "roots": {"seed": str(seed_root), "first": str(first.root), "second": str(second.root)},
        "source_hashes": seed_hashes, "files_checked": len(seed_hashes),
        "view_ref": state["view_ref"],
        "pins": {name: state[name] for name in ("host_pin", "trace_pin", "validation_pin")},
        "plain_snapshot": True, "file_isolation": True, "nested_state_isolation": True,
        "bundle_view_rebound": True, "shared_mutable_ids": 0,
        "live_driver_recorder_cached": False,
        "positive_current_api_replay": receipt.document["status"], "calls": counts,
    }
finally:
    sys.setprofile(None)
    first.doCleanups()
    second.doCleanups()
    Cases.doClassCleanups()
evidence["wall_seconds_including_cleanup"] = time.perf_counter() - start
evidence["roots_removed"] = not any(path.exists() for path in (first.root, second.root, seed_root))
assert evidence["roots_removed"]
(OUTPUT / "isolation.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: evidence[key] for key in ("status", "files_checked", "calls", "first_factory_including_seed_seconds", "second_copy_rebind_seconds", "wall_seconds_including_cleanup")}, indent=2))
