"""Matched selected unittest timings; real calls counted without substitution."""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys
import time
import unittest

import coverage


METHODS = [
    "test_missing_typed_fact_is_rejected",
    "test_missing_actual_input_read_is_rejected",
    "test_missing_fact_capture_event_is_rejected",
    "test_capture_after_provider_invocation_is_rejected",
    "test_rehashed_host_and_fact_identity_still_require_actual_input_bytes",
    "test_validation_subject_closed_set_is_enforced",
    "test_artifact_corruption_is_rejected",
    "test_checker_pin_corruption_is_rejected",
    "test_core_closeout_does_not_silently_accept_skill_contract",
    "test_receipt_recomputed_fields_cannot_be_self_reported",
    "test_receipt_versions_and_authority_fields_fail_closed",
]

parser = argparse.ArgumentParser()
parser.add_argument("output", type=Path)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=False)
process_start = time.perf_counter()
cov = coverage.Coverage(data_file=str(args.output / ".coverage"), branch=True,
                        source=["research_workbench"], config_file=False)
cov.start()
from tests import skill_closeout_fixtures as fixtures
from tests.test_skill_execution_closeout import SkillExecutionCloseoutTests

observed_codes = {
    fixtures.SkillCloseoutFixture.__init__.__code__: "fixture_init",
    fixtures.execute_frozen_view.__code__: "execute_frozen_view",
    fixtures.load_runtime_bundle.__code__: "load_runtime_bundle",
    fixtures.load_resolved_execution_view.__code__: "load_resolved_execution_view",
    fixtures.RecordingDriver.execute.__code__: "provider_execute",
    fixtures.SkillCloseoutFixture.build.__code__: "receipt_build",
}
counts = dict.fromkeys(observed_codes.values(), 0)
fixture_durations = []
fixture_starts = {}
roots = []
fixture_records = []
active_test = None
factory = getattr(SkillExecutionCloseoutTests, "completed_archive_fixture", None)
factory_code = factory.__code__ if factory is not None else None

def capture_fixture(fixture, role):
    paths = {"manifest": "bundle/manifest.yaml", "view": "view/skill.yaml",
             **{name: getattr(fixture, name).path
                for name in ("host_pin", "trace_pin", "validation_pin")}}
    fixture_records.append({
        "test": active_test.id() if active_test is not None else None,
        "role": role, "root": str(fixture.root),
        "bundle_root": str(fixture.bundle.project_root),
        "view_root": str(fixture.view.project_root),
        "manifest_path": str(fixture.bundle.manifest_path),
        "refs": paths,
        "actual_file_hashes": {name: hashlib.sha256((fixture.root / path).read_bytes()).hexdigest()
                               for name, path in paths.items()},
        "live_driver": hasattr(fixture, "driver"),
        "live_recorder": hasattr(fixture, "recorder"),
    })

def observe(frame, event, arg):
    if event == "return" and frame.f_code is factory_code:
        capture_fixture(arg, "independent_archive_copy")
    name = observed_codes.get(frame.f_code)
    if name is None:
        return
    if event == "call":
        counts[name] += 1
        if name == "fixture_init":
            fixture_starts[id(frame)] = time.perf_counter()
    elif event == "return" and name == "fixture_init":
        fixture_durations.append(time.perf_counter() - fixture_starts.pop(id(frame)))
        fixture = frame.f_locals["self"]
        role = "real_seed" if fixture.root != active_test.root else "real_case"
        capture_fixture(fixture, role)

records = []
class Result(unittest.TextTestResult):
    def startTest(self, test):
        global active_test
        active_test = test
        self.case_start = time.perf_counter()
        self.counts_start = counts.copy()
        self.outcome = "pass"
        super().startTest(test)

    def addFailure(self, test, err):
        self.outcome = "failure"
        super().addFailure(test, err)

    def addError(self, test, err):
        self.outcome = "error"
        super().addError(test, err)

    def stopTest(self, test):
        global active_test
        root = getattr(test, "root", None)
        records.append({"id": test.id(), "outcome": self.outcome,
                        "case_seconds": time.perf_counter() - self.case_start,
                        "root": str(root),
                        "calls": {key: counts[key] - self.counts_start[key] for key in counts}})
        super().stopTest(test)
        active_test = None

suite = unittest.TestSuite(SkillExecutionCloseoutTests(method) for method in METHODS)
sys.setprofile(observe)
suite_start = time.perf_counter()
with (args.output / "unittest.log").open("w", encoding="utf-8") as log:
    result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=Result).run(suite)
suite_seconds = time.perf_counter() - suite_start
sys.setprofile(None)
cov.stop()
cov.save()
cov.json_report(outfile=str(args.output / "coverage.json"))
root = fixtures.ROOT
source_hashes = {
    relative: hashlib.sha256((root / relative).read_bytes()).hexdigest()
    for relative in ("tests/test_skill_execution_closeout.py", "tests/skill_closeout_fixtures.py",
                     "tests/skill_runtime_fixtures.py", "tests/execution_fixtures.py",
                     "src/research_workbench/_runtime_pin.py")
}
summary = {
    "interpreter": sys.executable, "python": sys.version, "source_root": str(root),
    "packages": {name: importlib.metadata.version(name) for name in ("coverage", "jsonschema", "PyYAML")},
    "coverage": {"enabled": True, "branch": True, "source": ["research_workbench"],
                 "config_file": False},
    "timing_boundary": "suite wall includes class/each-case setup, body, teardown and class cleanup; coverage enabled; call observer enabled equally",
    "suite_seconds": suite_seconds,
    "observed_process_seconds": time.perf_counter() - process_start,
    "tests_run": result.testsRun, "successful": result.wasSuccessful(),
    "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
    "source_hashes": source_hashes, "calls": counts,
    "pair_runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "fixture_init_seconds": fixture_durations, "records": records,
    "fixture_records": fixture_records,
}
(args.output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: summary[key] for key in ("suite_seconds", "tests_run", "successful", "calls")}, indent=2))
raise SystemExit(not result.wasSuccessful())
