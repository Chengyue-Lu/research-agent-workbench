"""Compile existing pair receipts without running further tests."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path("D:/lcy/develop/_worktrees/RWB/slow-fixture-seeds-20261004")
OUT = Path(__file__).parent
equivalence = json.loads((OUT / "equivalence.json").read_bytes())
isolation = json.loads((OUT / "isolation.json").read_bytes())
pairs = []
for number in range(1, 4):
    before = json.loads((OUT / f"before-{number}/summary.json").read_bytes())
    after = json.loads((OUT / f"after-{number}/summary.json").read_bytes())
    runner = OUT / ("run_pair_v1.py" if number == 1 else "run_pair.py")
    runner_hash = hashlib.sha256(runner.read_bytes()).hexdigest()
    for stage in (before, after):
        assert stage["tests_run"] == 11 and stage["successful"]
        assert stage["errors"] == stage["failures"] == stage["skipped"] == 0
        assert len({row["root"] for row in stage["records"]}) == 11
    for key in ("interpreter", "python", "packages", "coverage", "timing_boundary"):
        assert before[key] == after[key], (number, key)
    assert [row["id"] for row in before["records"]] == [row["id"] for row in after["records"]]
    assert before["source_hashes"]["tests/test_skill_execution_closeout.py"] == equivalence["source_hashes"]["before"]
    assert after["source_hashes"]["tests/test_skill_execution_closeout.py"] == equivalence["source_hashes"]["after"]
    for path in before["source_hashes"]:
        if path != "tests/test_skill_execution_closeout.py":
            assert before["source_hashes"][path] == after["source_hashes"][path]
    for key in ("fixture_init", "execute_frozen_view", "provider_execute"):
        assert before["calls"][key] == 11 and after["calls"][key] == 1
    assert before["calls"]["receipt_build"] == after["calls"]["receipt_build"] == 11
    binding_report = None
    if number > 1:
        assert before["pair_runner_sha256"] == after["pair_runner_sha256"] == runner_hash
        real = before["fixture_records"]
        copies = [row for row in after["fixture_records"] if row["role"] == "independent_archive_copy"]
        seeds = [row for row in after["fixture_records"] if row["role"] == "real_seed"]
        assert len(real) == len(copies) == 11 and len(seeds) == 1
        assert {row["test"] for row in copies} == {row["id"] for row in after["records"]}
        assert len({row["root"] for row in copies}) == 11
        for row in copies:
            assert row["root"] == row["bundle_root"] == row["view_root"]
            assert row["manifest_path"] == str(Path(row["root"]) / "bundle/manifest.yaml")
            assert not row["live_driver"] and not row["live_recorder"]
            assert row["actual_file_hashes"] == seeds[0]["actual_file_hashes"]
            assert row["refs"] == seeds[0]["refs"]
            assert row["root"] != seeds[0]["root"]
        binding_report = {"copies": 11, "seed": 1, "unique_case_roots": 11,
                          "all_roots_rebound": True, "all_five_actual_hashes_equal_seed": True,
                          "no_live_driver_recorder_in_copies": True,
                          "same_manifest_view_host_hashes_as_every_real_before_case": all(
                              all(row["actual_file_hashes"][name] == seeds[0]["actual_file_hashes"][name]
                                  for name in ("manifest", "view", "host_pin")) for row in real),
                          "before_vs_seed_differing_hash_fields": sorted({
                              name for row in real for name, digest in row["actual_file_hashes"].items()
                              if digest != seeds[0]["actual_file_hashes"][name]}),
                          "difference_explanation": "Actual Recorder._now timestamps vary between independent generations; Trace hash and its validation subject pin therefore differ. No clocks or pins were rewritten for copying."}
        assert binding_report["same_manifest_view_host_hashes_as_every_real_before_case"]
        assert set(binding_report["before_vs_seed_differing_hash_fields"]) <= {"trace_pin", "validation_pin"}

    cov_before = json.loads((OUT / f"before-{number}/coverage.json").read_bytes())
    cov_after = json.loads((OUT / f"after-{number}/coverage.json").read_bytes())
    normalize = lambda report: {
        path: {field: value.get(field, []) for field in ("executed_lines", "executed_branches", "missing_lines", "missing_branches")}
        for path, value in report["files"].items()
    }
    coverage_equal = normalize(cov_before) == normalize(cov_after)
    pairs.append({
        "pair": number, "harness_version": "v1" if number == 1 else "v2-with-readonly-pin-observation",
        "runner_sha256": runner_hash, "before_seconds": before["suite_seconds"],
        "after_seconds": after["suite_seconds"],
        "avoided_seconds": before["suite_seconds"] - after["suite_seconds"],
        "within_pair_reduction_percent": 100 * (1 - after["suite_seconds"] / before["suite_seconds"]),
        "outcomes": "11 passed before and after", "before_calls": before["calls"], "after_calls": after["calls"],
        "source_hashes": {"before": before["source_hashes"], "after": after["source_hashes"]},
        "conditions": {key: before[key] for key in ("interpreter", "python", "packages", "coverage", "timing_boundary")},
        "bindings": binding_report,
        "covered_product_line_arc_sets_equal": coverage_equal,
        "coverage_before_totals": cov_before["totals"], "coverage_after_totals": cov_after["totals"],
        "raw_summary_sha256": {phase: hashlib.sha256((OUT / f"{phase}-{number}/summary.json").read_bytes()).hexdigest()
                               for phase in ("before", "after")},
    })

status = subprocess.run(["git", "status", "--short"], cwd=ROOT, check=True, capture_output=True, text=True).stdout
diff_names = subprocess.run(["git", "diff", "--name-only"], cwd=ROOT, check=True, capture_output=True, text=True).stdout.splitlines()
assert set(diff_names) == {".codex/config.toml", "tests/test_skill_execution_closeout.py"}, diff_names
assert subprocess.run(["git", "diff", "--cached", "--name-only"], cwd=ROOT, check=True,
                      capture_output=True, text=True).stdout == ""
evidence = {
    "status": "BOUNDED_IMPLEMENTATION_PASS_PENDING_INDEPENDENT_REVIEW_AND_COMPONENT_CI",
    "root": str(ROOT), "base": equivalence["base"], "branch": "perf/slow-fixture-seeds-20261004",
    "source_hashes": equivalence["source_hashes"], "original_tests": 33, "original_assertion_calls": 69,
    "modified_preparation_methods": 11, "pairs": pairs,
    "isolation": isolation, "working_tree_status": status, "tracked_diff_names": diff_names,
    "staged_files": [], "runtime_generated_once": True,
    "runtime_manifest_pin": (OUT / "runtime-generate.log").read_text(encoding="utf-8-sig").strip(),
    "cross_pair_timing_aggregate": "not computed; pair 1 v1 and pairs 2/3 v2 have different observation detail",
    "scope_limit": "single-process eleven-case family only; each fresh shard/class lifecycle creates its own real seed; no hosted/full-suite speed claim",
    "preserved_diagnostic_failure": {"path": "evidence-first-failure.log", "type": "assessment aggregation AssertionError",
                                    "reason": "Incorrect additional assumption that all five before-generated hashes must equal seed hashes; timestamps in original Recorder cause Trace/validation differences; unittest suites and independent-copy equality passed."},
    "remaining_validation": ["independent final diff/alias/cold/negative equivalence review",
                             "whole 33-case module including true cold child process and live driver/clock cases",
                             "required current-head CI on Python 3.11/3.13 and required coverage thresholds"],
}
(OUT / "evidence.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": evidence["status"], "pairs": [{key: row[key] for key in ("pair", "before_seconds", "after_seconds", "within_pair_reduction_percent", "covered_product_line_arc_sets_equal", "bindings")} for row in pairs]}, ensure_ascii=False, indent=2))
