import ast
import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
import statistics
import sys

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/lcy/develop/_worktrees/RWB/ci-full-cost-v2')
BASE='6cf80610cc2d3b4ebdeb9f47a840cd0ec1870bbf'
def read(name):return json.loads((HERE/name).read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

ranking=read('rankings.json');summary=read('summary.json');profiles={v:read('profile-'+v+'.json') for v in ('before','after')}
for source in ranking:
 path=Path(source['path']);native=json.loads(path.read_bytes())
 assert sha(path)==source['sha256'] and native['target']==BASE and native['successful'] is True
checkpoint_count=sum(len(row['checkpoints']) for row in read('pair-1-before.json')['rows'])
planner_fraction=next(row['seconds'] for row in ranking[0]['modules'] if row['module']=='test_ci_plan')/ranking[0]['wall']*100
external={variant:[row['ended']-row['started'] for row in read('commands.json') if row['command'][row['command'].index('--variant')+1]==variant] for variant in ('before','after')}
raw_old=subprocess.check_output(['git','-C',str(ROOT),'show',BASE+':tests/test_ci_plan.py']).decode()
old=ast.parse(raw_old);new=ast.parse((ROOT/'tests/test_ci_plan.py').read_text(encoding='utf-8'))
def methods(tree):
 return {node.name:ast.dump(node,include_attributes=False) for cls in tree.body if isinstance(cls,ast.ClassDef)
  for node in cls.body if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')}
a,b=methods(old),methods(new)
assert set(a)<=set(b) and all(a[name]==b[name] for name in a)
profile_summary={}
for variant,p in profiles.items():
 identity=[row for row in p['profile_functions'] if row['function']=='exact_commits' or variant=='before' and row['function']=='exact_commit']
 profile_summary[variant]={'subprocess_run_calls':sum(p['counts'].values()),'identity_git_calls':{k:v for k,v in p['counts'].items() if k.startswith('rev-parse:')},
   'identity_seconds':sum(r['cumulative'] for r in identity),'profiled_case_seconds':p['wall_seconds']}
 profile_summary[variant]['identity_percent']=profile_summary[variant]['identity_seconds']/p['wall_seconds']*100
environment={'python':sys.version,'executable':sys.executable,'git':subprocess.check_output(['git','--version'],text=True).strip(),
 'versions':{name:importlib.metadata.version(name) for name in ['coverage','PyYAML']},'base':BASE,'head':profiles['after']['head'],
 'test_count_before':len(a),'test_count_after':len(b),'retained_test_bodies_identical':True,'added_tests':sorted(set(b)-set(a)),
 'profile':profile_summary,'measurement_scope':'Local Windows fresh processes, same Python/dependencies and unchanged original case; coverage branch for pairs, cProfile plain for operation attribution only.',
 'source_sha256':profiles['after']['source_sha256']}
(HERE/'audit.json').write_text(json.dumps(environment,indent=2)+'\n',encoding='utf-8')
rows=[]
for r in ranking:
 for index,group in enumerate(r['modules'][:3],1):
  rows.append(f"| {r['name']} | {index} | `{group['module']}` | {group['seconds']:.6f} | {group['count']} |")
cost_rows=[]
for variant in ('before','after'):
 values=summary[variant]
 cost_rows.append(f"| {variant} | {', '.join(f'{v:.6f}' for v in values['values'])} | {values['median']:.6f} | {values['minimum']:.6f}–{values['maximum']:.6f} |")
before=profile_summary['before'];after=profile_summary['after']
text=f'''# Planner exact-commit batching: bounded cost slice

Owner Chengyue-Lu; TEST-PERF-002 / Issue87. Candidate implementation on accepted
baseline `{BASE}`; independent R2 review and complete integration checks remain.

## Current native cost evidence

Re-ranked the original successful [develop push run35851960207](https://github.com/Chengyue-Lu/research-agent-workbench/actions/runs/35851960207)
receipts at this exact target. These are historical observations, not a new run or a controlled coverage/plain comparison.
Coverage3.11 producer wall was1516.435344s; compatibility3.13 wall663.473623s.

| Receipt | Rank | Module | Sum of case durations, seconds | Cases |
|---|---:|---|---:|---:|
{chr(10).join(rows)}

Planner is the highest CI-owned module in both receipts. The two other coverage leaders are business harness modules and stay with their owners.
Planner case durations sum to {planner_fraction:.2f}% of coverage producer wall;
batching improves only a fraction of that module, so it cannot alone solve full-suite duration.
Original artifact10746748818 execution receipt SHA256 `{ranking[0]['sha256']}`;
artifact10746790816 compatibility receipt SHA256 `{ranking[1]['sha256']}`.

## Change and invariants

One `make_plan` validates base/head/target using one actual Git `rev-parse` process
instead of three. Validate every argument's full lowercase40-character format
before Git; preserve duplicate inputs and compare every output position. The
public singular helper delegates to the same fresh operation. Every `verify_plan`
still invokes Git again; no persistent identity cache is added. Existing
`--no-replace-objects` behavior remains. A request with multiple invalid inputs may
now report a format error before an earlier missing-object error; both fail closed.

No selection, B/C order, runner preflight, coverage policy, thresholds, fixture
isolation, test removal or business code changes. All {len(a)} original planner test
bodies are AST-identical; four new tests cover identity positions, malformed
arguments, real blob/tree/tag/missing objects with replacement refs, and removal
of a previously verified loose commit object before re-verification. Real Git is
wrapped only for call observation; its arguments/results are unchanged.

## Local measured validation

Six focused checks passed: four added regressions plus existing docs-plan replay
and independent-clone isolation checks. Three AB/BA/AB fresh process pairs ran the
original native planner leader
`PlannerTests.test_contract_pins_each_behavioral_proof_and_acceptance_module`.
Each executed the identical canonical case, subtest order, outcomes and {checkpoint_count}
subtest checkpoints, under Python3.11.16, Windows, branch coverage, the same
dependencies and fixture inputs. Existing per-case fixture construction/cleanup
remain inside the timed interval. This is one representative case, not the full module.

| Variant | Three seconds | Median seconds | Range seconds |
|---|---|---:|---|
{chr(10).join(cost_rows)}

Observed local median reduction: {summary['reduction_percent']:.2f}%.
Paired after-minus-before seconds: {', '.join(f'{v:.6f}' for v in summary['paired_deltas'])}.
The table measures test loading, fixture setup, case execution and cleanup. Process
startup, planner import and coverage start/stop sit outside that inner timer but
remain in command receipts: external process median
{statistics.median(external['before']):.6f}s→{statistics.median(external['after']):.6f}s.
This does not establish hosted CI, full-suite or aggregate critical-path savings.
Coverage records the baseline planner from its retained source file and the
candidate from its actual source path; both read identical live fixture inputs.
The before module's ROOT is explicitly bound to the same checkout. The initial
attempt omitted that binding and failed locating the governance script; that
failed log is retained and excluded from all valid pairs.
An earlier six-sample series omitted the saved baseline planner from coverage's
source scope and imported the two planners at different measurement stages. That
series is retained as invalid measurement and excluded. The final series imports
both planners symmetrically before the timed interval, includes both source
locations in branch coverage, and asserts nonempty measured planner lines/arcs.

A separate plain cProfile/operation-count run of the same case passed for each
variant; it is excluded from timing gains. Total real subprocess calls were
{before['subprocess_run_calls']}→{after['subprocess_run_calls']}.
Identity validation occupied {before['identity_seconds']:.6f}s
({before['identity_percent']:.2f}% of its profiled case) before and
{after['identity_seconds']:.6f}s ({after['identity_percent']:.2f}%) after.
This attributes the bounded saving; process reduction alone is not a speed claim.
The operation profile records 24 real `make_plan` invocations: identity subprocesses
decrease from72 single-SHA calls to24 triple-SHA calls, exactly two per invocation.

## Remaining acceptance and evidence

The source diff is limited to planner batching, its four independent regressions,
and this report. Complete module/quality checks, authority/source-pin checks and
cross-owner review remain the parent task's merge boundary. No hosted rerun,
commit, push, PR, selector activation or result reuse is performed in this slice.
Raw receipts, source hashes, paired results, command logs, profiles and the initial
failed measurement are provided with the handoff for the formal Task Archive.
The parent task must retain visible collaboration and command results. The first
failed harness version was not snapshotted before its path repair; its command and
failure log remain. Preserve that capture gap rather than claiming a complete trace.
'''
(HERE/'REPORT.md').write_text(text,encoding='utf-8')
(ROOT/'docs/workstreams/chengyue-lu/TEST-PERF-002/PLANNER_COMMIT_BATCH_COSTS.md').write_text(text,encoding='utf-8')
manifest=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='manifest.json']
manifest.extend({'path':p.relative_to(HERE).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((HERE/'invalid-coverage-scope').iterdir()) if p.is_file())
(HERE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'summary':summary,'profile':profile_summary,'old_tests':len(a),'new_tests':len(b)},indent=2))
