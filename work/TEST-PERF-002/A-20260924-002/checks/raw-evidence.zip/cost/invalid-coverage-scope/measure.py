import argparse
import cProfile
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import pstats
import statistics
import subprocess
import sys
import time
import unittest

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/lcy/develop/_worktrees/RWB/ci-full-cost-v2')
BASE='6cf80610cc2d3b4ebdeb9f47a840cd0ec1870bbf'
RECEIPTS=Path('D:/lcy/develop/_assessments/rwb-ci-review-20260923/integration/merge-92-94-95/pr95-integration/complete')
CASE='tests.test_ci_plan.PlannerTests.test_contract_pins_each_behavioral_proof_and_acceptance_module'
NEW=[
 'test_exact_commits_batch_preserves_positions_and_single_commit_api',
 'test_exact_commits_rejects_all_malformed_positions_before_git',
 'test_exact_commits_rejects_noncommits_and_missing_objects_despite_replacements',
 'test_each_verification_rechecks_commit_objects_after_cached_plan_reads',
 'test_docs_fast_plan_is_explainable_and_replayable',
 'test_fixture_clone_keeps_local_identity_line_endings_and_isolation',
]

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value): path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

class Result(unittest.TextTestResult):
 def __init__(self,*a,**kw): super().__init__(*a,**kw);self.rows=[]
 def startTest(self,test): super().startTest(test);self.rows.append({'id':test.id(),'checkpoints':[]})
 def addSuccess(self,test): super().addSuccess(test);self.rows[-1]['outcome']='passed'
 def addFailure(self,test,err): super().addFailure(test,err);self.rows[-1]['outcome']='failed'
 def addError(self,test,err): super().addError(test,err);self.rows[-1]['outcome']='error'
 def addSubTest(self,test,subtest,err):
  super().addSubTest(test,subtest,err);self.rows[-1]['checkpoints'].append({'id':subtest.id(),'passed':err is None})

def child(args):
 sys.dont_write_bytecode=True
 sys.path[:0]=[str(ROOT),str(ROOT/'src'),str(ROOT/'.github/scripts')]
 if args.variant=='before':
  spec=importlib.util.spec_from_file_location('plan_ci',HERE/'before-plan_ci.py')
  module=importlib.util.module_from_spec(spec);sys.modules['plan_ci']=module;spec.loader.exec_module(module)
  # Both implementations consume the same real fixture/authority files. Only
  # the saved planner implementation bytes differ; preserve their source hash.
  module.ROOT=ROOT
 names=['tests.test_ci_plan.PlannerTests.'+name for name in NEW] if args.action=='focused' else [CASE]
 coverage=None
 if args.action=='sample':
  import coverage as coverage_module
  coverage=coverage_module.Coverage(branch=True,data_file=None,source=[str(ROOT/'.github/scripts')],config_file=False)
  coverage.start()
 profiler=cProfile.Profile() if args.action=='profile' else None
 counts={};original_run=subprocess.run
 def counted(*a,**kw):
  command=a[0] if a else kw.get('args',[])
  key=' '.join(str(x) for x in command[:5]) if isinstance(command,list) else str(command)
  if isinstance(command,list) and 'rev-parse' in command:
   index=command.index('rev-parse');key='rev-parse: '+str(sum(str(x).endswith('^{commit}') for x in command[index+1:]))+' commit arguments'
  counts[key]=counts.get(key,0)+1
  return original_run(*a,**kw)
 if args.action=='profile': subprocess.run=counted;profiler.enable()
 started=time.perf_counter()
 result=unittest.TextTestRunner(verbosity=1,resultclass=Result).run(unittest.defaultTestLoader.loadTestsFromNames(names))
 elapsed=time.perf_counter()-started
 if profiler:
  profiler.disable();subprocess.run=original_run;profiler.dump_stats(str(HERE/(args.variant+'.prof')))
 if coverage: coverage.stop()
 import plan_ci
 import ci_dependencies
 assert Path(ci_dependencies.__file__).resolve()==ROOT/'.github/scripts/ci_dependencies.py'
 expected=HERE/'before-plan_ci.py' if args.variant=='before' else ROOT/'.github/scripts/plan_ci.py'
 assert Path(plan_ci.__file__).resolve()==expected.resolve()
 row={'action':args.action,'variant':args.variant,'base':BASE,'head':subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),
  'python':sys.version,'executable':sys.executable,'platform':sys.platform,'cwd':os.getcwd(),'case':names,'wall_seconds':elapsed,
  'successful':result.wasSuccessful(),'tests_run':result.testsRun,'rows':result.rows,'counts':counts,
  'source_sha256':{str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'.github/scripts/plan_ci.py',ROOT/'tests/test_ci_plan.py',ROOT/'.github/scripts/ci_dependencies.py')},
  'executed_planner_sha256':sha(expected),'planner_origin':str(expected),'coverage_branch':coverage is not None}
 if profiler:
  stats=pstats.Stats(profiler)
  row['profile_functions']=[{'file':key[0],'line':key[1],'function':key[2],'primitive_calls':v[0],'calls':v[1],'self':v[2],'cumulative':v[3]}
    for key,v in stats.stats.items() if key[2] in {'make_plan','exact_commit','exact_commits','git','run','communicate','_wait','wait'}]
 dump(Path(args.output),row)
 return 0 if result.wasSuccessful() else 1

def controller():
 HERE.mkdir(parents=True,exist_ok=True)
 before=subprocess.check_output(['git','-C',str(ROOT),'show',BASE+':.github/scripts/plan_ci.py'])
 (HERE/'before-plan_ci.py').write_bytes(before)
 rankings=[]
 for name,path in [('coverage-3.11',RECEIPTS/'artifact-10746748818/execution-test-results.json'),('compatibility-3.13',RECEIPTS/'artifact-10746790816/full-test-results-3.13.json')]:
  receipt=json.loads(path.read_bytes());groups={}
  for row in receipt['tests']:
   group=groups.setdefault(row['module'],{'module':row['module'],'seconds':0,'count':0});group['seconds']+=row['duration_seconds'];group['count']+=1
  rankings.append({'name':name,'path':str(path),'sha256':sha(path),'target':receipt['target'],'wall':receipt['wall_seconds'],
   'count':receipt['test_count'],'python':receipt['python_version'],'modules':sorted(groups.values(),key=lambda x:-x['seconds']),
   'ci_cases':sorted([r for r in receipt['tests'] if r['module']=='test_ci_plan'],key=lambda x:-x['duration_seconds'])})
 dump(HERE/'rankings.json',rankings)
 env=dict(os.environ);env.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None);env.pop('COVERAGE_FILE',None)
 commands=[]
 for action,variant,label in [*[('sample',variant,f'pair-{i+1}-{variant}') for i,order in enumerate((('before','after'),('after','before'),('before','after'))) for variant in order],('profile','before','profile-before'),('profile','after','profile-after')]:
  output=HERE/(label+'.json');command=[sys.executable,'-I',str(__file__),'--action',action,'--variant',variant,'--output',str(output)]
  started=time.time();result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,timeout=150)
  (HERE/(label+'.log')).write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
  commands.append({'command':command,'cwd':str(ROOT),'started':started,'ended':time.time(),'exit_code':result.returncode,'output':str(output)})
  dump(HERE/'commands.json',commands)
  if result.returncode: raise RuntimeError(label+' failed: '+result.stderr[-1800:])
 samples=[json.loads((HERE/(f'pair-{i+1}-{v}.json')).read_bytes()) for i in range(3) for v in ('before','after')]
 assert all(r['rows']==samples[0]['rows'] for r in samples)
 summary={v:{'values':[r['wall_seconds'] for r in samples if r['variant']==v]} for v in ('before','after')}
 for values in summary.values(): values.update(median=statistics.median(values['values']),minimum=min(values['values']),maximum=max(values['values']))
 summary['reduction_percent']=(1-summary['after']['median']/summary['before']['median'])*100
 summary['paired_deltas']=[samples[i+1]['wall_seconds']-samples[i]['wall_seconds'] for i in range(0,6,2)]
 summary['identical_ids_order_outcomes_checkpoints']=True
 dump(HERE/'summary.json',summary);print(json.dumps(summary))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--action',default='controller');parser.add_argument('--variant');parser.add_argument('--output');args=parser.parse_args()
 if args.action=='controller':controller()
 else:raise SystemExit(child(args))
