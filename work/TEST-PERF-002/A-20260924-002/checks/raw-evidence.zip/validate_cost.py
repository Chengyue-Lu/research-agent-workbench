"""Current planner module quality; timing here is not a performance experiment."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
WT=Path(r'D:\lcy\develop\_worktrees\RWB\ci-full-cost-v2')
label=sys.argv[1]
out=ROOT/'cost-validation'/label
out.mkdir(parents=True,exist_ok=False)
env={**os.environ,'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1',
     'PYTHONPATH':os.pathsep.join(str(WT/p) for p in ('.','src','tests','.github/scripts'))}
python=Path(r'D:\lcy\develop\_assessments\rwb-ci-schema-parse-20260917')/('venv311' if label=='311-module' else 'venv313')/'Scripts/python.exe'
argv=[str(python),'-X','utf8','-B']
config=out/'coverage.ini'
if label=='311-module':
    config.write_text('[run]\nbranch = True\nsource = plan_ci\ndata_file = '+(out/'.coverage').as_posix()+'\n',encoding='utf-8')
    argv+=['-m','coverage','run','--rcfile='+str(config)]
    names=['test_ci_plan']
else:
    focus=json.loads((ROOT/'cost/focused.json').read_text())
    names=[row['id'] for row in focus['rows']] if 'rows' in focus else focus['test_ids']
argv+=['-m','unittest','-v',*names]
start=time.monotonic()
result=subprocess.run(argv,cwd=WT,env=env,capture_output=True,encoding='utf-8')
(out/'tests.log').write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
data={'argv':argv,'exit_code':result.returncode,'seconds':time.monotonic()-start,
      'sources':{p:hashlib.sha256((WT/p).read_bytes()).hexdigest() for p in ('.github/scripts/plan_ci.py','tests/test_ci_plan.py')}}
if label=='311-module':
    c=subprocess.run([str(python),'-m','coverage','json','--rcfile='+str(config),'-o',str(out/'coverage.json')],cwd=WT,env=env,capture_output=True,encoding='utf-8')
    (out/'coverage.log').write_text(c.stdout+'\n'+c.stderr,encoding='utf-8')
    data['coverage_exit_code']=c.returncode
    if c.returncode==0: data['coverage']=json.loads((out/'coverage.json').read_text())['totals']
(out/'summary.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data,indent=2));print(result.stderr[-1000:])
raise SystemExit(result.returncode)
