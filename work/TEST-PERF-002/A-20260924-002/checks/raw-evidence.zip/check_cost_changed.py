"""Compare local measured changed lines/arcs, without creating an execution receipt."""
from pathlib import Path
import json,re,subprocess

root=Path(__file__).resolve().parent
wt=Path(r'D:\lcy\develop\_worktrees\RWB\ci-full-cost-v2')
cov=json.loads((root/'cost-validation/311-module/coverage.json').read_text())
files={k.replace('\\','/'):v for k,v in cov['files'].items()}
file=files['.github/scripts/plan_ci.py']
diff=subprocess.check_output(['git','-C',str(wt),'diff','--unified=0',
    '6cf80610cc2d3b4ebdeb9f47a840cd0ec1870bbf','--','.github/scripts/plan_ci.py'],text=True)
changed=set()
for start,count in re.findall(r'^@@ -[0-9,]+ \+(\d+)(?:,(\d+))? @@',diff,re.M):
    changed.update(range(int(start),int(start)+int(count or 1)))
executable=changed & set(file['executed_lines']+file['missing_lines'])
branches=[p for p in file['executed_branches']+file['missing_branches'] if p[0] in changed]
missing=sorted(changed & set(file['missing_lines']))
missing_branches=[p for p in file['missing_branches'] if p[0] in changed]
result={'scope':'local changed executable coverage facts; not a native execution receipt or full impact acceptance',
    'source':'.github/scripts/plan_ci.py','changed_lines':sorted(changed),
    'changed_executable_lines':sorted(executable),'changed_branch_arcs':branches,
    'missing_changed_lines':missing,'missing_changed_branches':missing_branches,
    'covered_changed_lines':len(executable),'covered_changed_branches':len(branches)}
assert executable and branches and not missing and not missing_branches
(root/'cost-validation/311-module/changed-facts.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
