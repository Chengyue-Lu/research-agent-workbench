# Independent review: planner exact-commit batching

Profile: CI Git identity optimization independent reviewer. Required Skills: []. Owner: Chengyue-Lu. Reviewed at 2026-09-24T13:27:18.880429+00:00.

**Conclusion: no substantive finding in the reviewed implementation.** The three fresh identity checks are combined into one fresh Git process without weakening the base/head/target identity boundary. This is a bounded static code/test review, not a new test run, performance replication, owner approval or hosted-Gate conclusion.

## Reviewed identity and scope

Worktree: `D:/lcy/develop/_worktrees/RWB/ci-full-cost-v2`; accepted base `6cf80610cc2d3b4ebdeb9f47a840cd0ec1870bbf`. Reviewed its two-file diff, surrounding Git wrapper, original/singular commit API, `make_plan`/`verify_plan` flow, real-Git fixtures and test cases. Read only cost REPORT/summary/audit metadata; did not read raw large profiles.

Reviewed working-tree SHA256:

- `.github/scripts/plan_ci.py`: `8dd97ff415398dddefa1f8bfab4e0f6814dae8140626489608d510999db4b851`.
- `tests/test_ci_plan.py`: `1abbaf971fff0f3eca9307adea8b7fbac404172dbcf59306a443b346c3cad5dc`.

Both hashes equal the cost audit's source identities and were checked again before this report. Later changes require checking applicability again.

## Boundary assessment

- **Input format and injection:** every element is checked as a string of exactly40 lowercase hexadecimal characters before any Git call. Abbreviations, uppercase, ref names, revision expressions, option-shaped arguments and trailing newline fail. Constructed argv then appends only the fixed `^{commit}` suffix; the unchanged subprocess API does not use a shell.
- **Position and duplicates:** input order is retained in a tuple and the Git output is compared against the complete list, without set conversion, sorting or deduplication. Missing, extra, reordered or substituted output identities cannot satisfy equality. Duplicate base/head/target identities remain separate equal positions.
- **Actual object type:** each argument uses Git's commit peeling. Tree/blob/missing objects cannot supply a matching commit. An annotated tag which peels successfully still resolves to its commit SHA rather than the supplied tag-object SHA, so full identity equality rejects it. The original singular API delegates to the same validator and returns its original string result.
- **Replacement refs:** the unchanged Git wrapper passes `--no-replace-objects` before all subcommands. Batching does not introduce a replacement-object path.
- **Freshness:** neither `exact_commits` nor the Git wrapper is cached. Every `make_plan` calls it once for the exact triple, and every successful path into `verify_plan` recomputes a plan after the existing checkout/digest checks. `read_at` may cache immutable blob reads, but it does not cache existence/type validation. The added regression creates a fresh loose base commit, verifies/reverifies, then temporarily removes the real object and expects verification to fail despite prior reads.
- **Errors:** nonzero Git status still becomes `ValueError` in the existing wrapper; batch output is not accepted after a partial failure. Identity mismatch still raises before a plan is built. The documented multi-invalid-input diagnostic-order difference is real: a malformed later input is now rejected before an earlier missing object reaches Git. Both reject the request and neither produces a weaker plan.

## Test-diff assessment

Static AST comparison independently confirms all80 original PlannerTests method bodies are unchanged and exactly four tests are added. The new tests use the real Git wrapper (wrapped only for call observation) to cover distinct/duplicate triple positions and singular API, malformed values in each position before any Git call, actual blob/tree/annotated-tag/missing objects in each position with and without replacement refs, and repeated verification after object removal. Existing event/merge-target and error tests remain intact.

No selector, witness, coverage threshold, runner lifecycle, fixture isolation or failure assertion was removed in this diff. No persistent evidence reuse was introduced.

## Limits and handoff

No tests or performance pairs were run by this reviewer because the parent task reserved the CPU for controlled timing. The reported local6.23% representative-case reduction belongs to the supplied cost experiment, which explicitly separates it from hosted/full-suite savings; this review neither reproduces nor broadens that claim. Exact-head local/hosted checks, required independent witness and cross-owner review remain the parent task's integration boundary.
