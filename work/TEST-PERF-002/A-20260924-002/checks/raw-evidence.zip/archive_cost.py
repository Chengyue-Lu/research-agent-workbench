"""Prepare a cost Attempt only after source-bound local module checks complete.

This draft is intentionally not executed during the running quality check.
"""
import ast
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import statistics
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
WT = Path('D:/lcy/develop/_worktrees/RWB/ci-full-cost-v2')
BASE = '6cf80610cc2d3b4ebdeb9f47a840cd0ec1870bbf'
ATTEMPT = WT/'work/TEST-PERF-002/A-20260924-002'
SOURCE_PATHS = ('.github/scripts/plan_ci.py', 'tests/test_ci_plan.py')
EXCLUDED = {'__pycache__', '.pytest_cache', '.venv', 'venv', 'venv311', 'venv313', 'temp', 'tmp'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(WT), *args])


def plain(path):
    status = path.lstat()
    assert not stat.S_ISLNK(status.st_mode) and not getattr(status, 'st_file_attributes', 0) & 0x400, path


def listed_files(directory):
    plain(directory)
    result = []
    for parent, directories, files in os.walk(directory, followlinks=False):
        directories[:] = sorted(name for name in directories if name not in EXCLUDED)
        for name in directories:
            plain(Path(parent)/name)
        for name in sorted(files):
            path = Path(parent)/name
            plain(path)
            assert path.resolve().is_relative_to(directory.resolve())
            result.append(path)
    assert result, directory
    return result


def successful_unittest(directory, expected, source_hashes):
    summary = read(directory/'summary.json')
    assert summary['exit_code'] == 0 and summary['sources'] == source_hashes, directory
    log = (directory/'tests.log').read_text(encoding='utf-8')
    matches = re.findall(r'^Ran (\d+) tests? in [\d.]+s$', log, re.MULTILINE)
    assert matches == [str(expected)] and log.rstrip().endswith('\nOK'), directory
    return summary


def main():
    # Fail before creating an Attempt if the still-running quality stage has no
    # complete summary or its source identities no longer match the candidate.
    head = git('rev-parse', 'HEAD').decode().strip()
    assert re.fullmatch('[0-9a-f]{40}', head) and head != BASE
    git('merge-base', '--is-ancestor', BASE, head)
    source_hashes = {path: sha((WT/path).read_bytes()) for path in SOURCE_PATHS}
    assert all(sha(git('show', f'{head}:{path}')) == signature for path, signature in source_hashes.items())
    test_tree = ast.parse((WT/'tests/test_ci_plan.py').read_text(encoding='utf-8'))
    names = [node.name for cls in test_tree.body if isinstance(cls, ast.ClassDef) and cls.name == 'PlannerTests'
             for node in cls.body if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
    assert names and len(names) == len(set(names))
    audit = read(ROOT/'cost/audit.json')
    assert audit['base'] == BASE and audit['retained_test_bodies_identical'] is True
    assert audit['test_count_after'] == len(names) and len(audit['added_tests']) == 4
    observed_sources = {path.replace('\\', '/'): signature for path, signature in audit['source_sha256'].items()}
    assert all(observed_sources[path] == signature for path, signature in source_hashes.items())

    focused = read(ROOT/'cost/focused.json')
    assert focused['successful'] is True and focused['tests_run'] == len(focused['rows']) == 6
    assert all(row['outcome'] == 'passed' and all(point['passed'] for point in row['checkpoints']) for row in focused['rows'])
    focused_sources = {path.replace('\\', '/'): signature for path, signature in focused['source_sha256'].items()}
    assert all(focused_sources[path] == signature for path, signature in source_hashes.items())
    full = successful_unittest(ROOT/'cost-validation/311-module', len(names), source_hashes)
    focus313 = successful_unittest(ROOT/'cost-validation/313-focused', len(focused['rows']), source_hashes)
    assert 'venv311' in full['argv'][0] and 'venv313' in focus313['argv'][0]
    assert full['argv'][-1] == 'test_ci_plan'
    assert focus313['argv'][-len(focused['rows']):] == [row['id'] for row in focused['rows']]
    assert full['coverage_exit_code'] == 0
    coverage = read(ROOT/'cost-validation/311-module/coverage.json')
    covered = [value for path, value in coverage['files'].items() if path.replace('\\', '/').endswith('.github/scripts/plan_ci.py')]
    assert len(covered) == 1 and coverage['meta']['branch_coverage'] is True
    module = covered[0]['summary']
    line_percent = 100 * module['covered_lines'] / module['num_statements']
    branch_percent = 100 * module['covered_branches'] / module['num_branches']
    assert line_percent >= 95 and branch_percent >= 90
    assert full['coverage'] == coverage['totals']
    changed_facts = read(ROOT/'cost-validation/311-module/changed-facts.json')
    diff = git('diff', '--unified=0', BASE, head, '--', '.github/scripts/plan_ci.py').decode()
    changed = set()
    for start, count in re.findall(r'^@@ -[0-9,]+ \+(\d+)(?:,(\d+))? @@', diff, re.MULTILINE):
        changed.update(range(int(start), int(start) + int(count or 1)))
    executable = changed & set(covered[0]['executed_lines'] + covered[0]['missing_lines'])
    arcs = [pair for pair in covered[0]['executed_branches'] + covered[0]['missing_branches'] if pair[0] in changed]
    assert executable and arcs and changed_facts['changed_lines'] == sorted(changed)
    assert changed_facts['changed_executable_lines'] == sorted(executable) and changed_facts['changed_branch_arcs'] == arcs
    assert changed_facts['missing_changed_lines'] == sorted(changed & set(covered[0]['missing_lines'])) == []
    assert changed_facts['missing_changed_branches'] == [pair for pair in covered[0]['missing_branches'] if pair[0] in changed] == []
    assert changed_facts['covered_changed_lines'] == len(executable) and changed_facts['covered_changed_branches'] == len(arcs)
    assert changed_facts['scope'] == 'local changed executable coverage facts; not a native execution receipt or full impact acceptance'

    review_path = ROOT/'COST_CODE_REVIEW.md'
    review = review_path.read_text(encoding='utf-8')
    assert 'no substantive finding' in review and all(signature in review for signature in source_hashes.values())
    pairs = {variant: [read(ROOT/f'cost/pair-{index}-{variant}.json') for index in range(1, 4)] for variant in ('before', 'after')}
    first = pairs['before'][0]
    baseline_source = sha(git('show', BASE+':.github/scripts/plan_ci.py'))
    assert sha((ROOT/'cost/before-plan_ci.py').read_bytes()) == baseline_source
    for variant, samples in pairs.items():
        for row in samples:
            assert row['successful'] is True and row['tests_run'] == 1 and row['rows'] == first['rows']
            assert row['base'] == BASE and row['head'] == BASE  # Original working-tree run identity is retained.
            assert row['coverage_branch'] is True and row['measured_planner']['lines'] > 0 and row['measured_planner']['arcs'] > 0
            assert row['python'] == first['python'] and row['executable'] == first['executable'] and row['cwd'] == first['cwd']
            assert row['source_sha256'] == first['source_sha256']
            assert row['executed_planner_sha256'] == (baseline_source if variant == 'before' else source_hashes[SOURCE_PATHS[0]])
    timing = read(ROOT/'cost/summary.json')
    for variant, samples in pairs.items():
        values = [row['wall_seconds'] for row in samples]
        assert timing[variant]['values'] == values and timing[variant]['median'] == statistics.median(values)
    assert timing['identical_ids_order_outcomes_checkpoints'] is True
    assert (ROOT/'cost/invalid-coverage-scope/INVALID.md').is_file()
    assert (ROOT/'cost/initial-pair-1-before-root-failure.log').is_file()
    assert read(ROOT/'cost/initial-pair-1-before-root-failure.json')['successful'] is False

    files = listed_files(ROOT/'cost') + listed_files(ROOT/'cost-validation')
    files += listed_files(ROOT/'cost-archive-first-failure')
    files += [review_path, ROOT/'validate_cost.py', ROOT/'check_cost_changed.py', Path(__file__).resolve()]
    assert len(files) == len(set(files))
    for path in files:
        plain(path)
    assert not ATTEMPT.exists(), 'preserve any existing Attempt'
    checks = ATTEMPT/'checks'
    checks.mkdir(parents=True)
    manifest = []
    with zipfile.ZipFile(checks/'raw-evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(files):
            raw = path.read_bytes(); name = path.relative_to(ROOT).as_posix()
            member = PurePosixPath(name)
            assert not member.is_absolute() and '..' not in member.parts
            archive.writestr(name, raw)
            manifest.append({'path': name, 'sha256': sha(raw), 'bytes': len(raw)})
    with zipfile.ZipFile(checks/'raw-evidence.zip') as archive:
        assert archive.testzip() is None and archive.namelist() == [row['path'] for row in manifest]
        assert all(sha(archive.read(row['path'])) == row['sha256'] and len(archive.read(row['path'])) == row['bytes'] for row in manifest)
    (checks/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
    summary = {'base': BASE, 'implementation': head, 'source_hashes': source_hashes,
               'local_tests': {'python311_module': len(names), 'python311_focused': focused['tests_run'], 'python313_focused': len(focused['rows'])},
               'planner_module_coverage': {'covered_lines': module['covered_lines'], 'statements': module['num_statements'],
                   'line_percent': line_percent, 'covered_branches': module['covered_branches'], 'branches': module['num_branches'], 'branch_percent': branch_percent},
               'local_changed_coverage_facts': changed_facts,
               'timing': timing, 'independent_review_sha256': sha(review_path.read_bytes()),
               'raw_archive_sha256': sha((checks/'raw-evidence.zip').read_bytes()),
               'limitations': ['Working-tree local checks retain their original run identity; source equality with implementation blobs is checked now',
                   'One representative local timing case, not hosted/full-suite speedup acceptance',
                   'Initial ROOT failure and invalid coverage-source series are retained and excluded',
                   'Initial failed harness source was not snapshotted; collaboration/tool capture is partial',
                   'No selector activation, test deletion, threshold reduction or result reuse']}
    (checks/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
    (ATTEMPT/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
    (ATTEMPT/'RESULTS.md').write_text(f'''# Planner commit batching: local proof and costs

Owner Chengyue-Lu; Audit TEST-PERF-002; R2; required Skills [].
Accepted baseline `{BASE}`; implementation `{head}`.

The [cost report](../../../docs/workstreams/chengyue-lu/TEST-PERF-002/PLANNER_COMMIT_BATCH_COSTS.md)
records one fresh Git operation replacing three exact identity checks. Ordering,
duplicates, real object type, replacement-object exclusion and re-verification
freshness remain enforced. No selection or B/C execution obligation changes.

Local Python 3.11 complete planner module: {len(names)} PASS. Its actual source
coverage is {module['covered_lines']}/{module['num_statements']} lines
({line_percent:.4f}%) and {module['covered_branches']}/{module['num_branches']} branches
({branch_percent:.4f}%). Python 3.11 and 3.13 each passed the same six focused checks.
The local diff and coverage facts cover {len(executable)}/{len(executable)} changed
executable lines and {len(arcs)}/{len(arcs)} outgoing arcs. This is not a native impact
receipt or complete impact acceptance.
These module checks do not establish repository-wide or hosted Gate completion.
Working-tree source hashes equal the implementation blobs; the original local
execution identity is retained rather than relabelled as an exact-head hosted run.

Three fair AB/BA/AB pairs preserve the original case and all its checkpoints.
The original [summary](checks/summary.json) retains raw timing values and their
bounded local claim. Native receipt rankings and profiles are evidence inputs,
not a controlled full-suite timing comparison. Independent static code review
found no substantive issue; it does not replace cross-owner acceptance.

The [raw evidence](checks/raw-evidence.zip), bound member-by-member by the
[manifest](checks/manifest.json), retains both successful and failed observations.
The initial ROOT failure and six invalid coverage-scope samples are excluded from
speedup calculations. The first failed harness version lacks an original source
snapshot; command/error records remain. This is an explicit capture gap.

Trace capture is partial: this archive records evidence freeze, not a complete live
stream of earlier tool/inter-agent transmissions. Future publication, local final-head
checks and hosted runs keep their own identities. Merge and activation remain outside
this archive's authority.
''', encoding='utf-8')
    sys.path.insert(0, str(WT/'src'))
    from research_workbench.observability.trace import AgentTraceRecorder, validate_attempt_trace
    recorder = AgentTraceRecorder(ATTEMPT, task_id='TEST-PERF-002', task_revision=45, attempt_id=ATTEMPT.name,
        task_snapshot={'task_id': 'TEST-PERF-002', 'revision': 45, 'request': 'Continue the next-stage CI improvement plan',
            'scope': 'Fresh exact-commit batching, real Git regressions, current native cost rankings and local fair pairs',
            'delegation': True, 'required_skills': [], 'profile': 'CI cost implementer, independent reviewer and evidence curator',
            'budget': 'one bounded CI-owned cost slice; local module and focused checks plus three fresh pairs',
            'stop_condition': 'archive source-bound local evidence; publication and hosted checks remain separate'},
        accountable_owner='Chengyue-Lu', actor_id='main-agent', runtime_identity='Codex desktop', provider='OpenAI',
        read_allowlist=['AGENTS.md', 'docs/DEVELOPMENT.md', '.github/scripts/**', 'tests/**',
                        'docs/workstreams/chengyue-lu/TEST-PERF-002/**', 'work/TEST-PERF-002/**', 'run35851960207 native receipts'],
        write_scope=['.github/scripts/plan_ci.py', 'tests/test_ci_plan.py',
                     'docs/workstreams/chengyue-lu/TEST-PERF-002/**', 'work/TEST-PERF-002/A-20260924-002/**'],
        tool_allowlist=['collaboration', 'shell', 'git', 'python'], baseline=BASE)
    recorder.record_capture_gap('messages', 'Trace starts at cost evidence freeze; early tool and collaboration transmissions are not a complete live recorded stream.')
    recorder.record_capture_gap('file-revisions', 'The first failed ROOT-binding harness version was not snapshotted; its original command and failure log are retained.')
    recorder.record_capture_gap('external-actions', 'Publication, later exact-head local checks and hosted runs follow this sealed archive and retain separate identities.')
    recorder.record_tool_call(operation_id='freeze-cost-evidence', tool_name='python', status='succeeded',
        arguments={'operation': 'validate actual completed local checks, source identities and retain fair/invalid original observations'},
        result={'implementation': head, 'source_hashes': source_hashes, 'raw_manifest_sha256': sha((checks/'manifest.json').read_bytes()),
                'local_test_counts': summary['local_tests']}, result_entered_context=True)
    recorder.seal('safe-paused')
    result = validate_attempt_trace(WT, ATTEMPT)
    validation = {'blocked': result.blocked, 'risks': [asdict(risk) for risk in result.risks]}
    (checks/'trace-validation.json').write_text(json.dumps(validation, indent=2, default=str)+'\n', encoding='utf-8')
    assert not result.blocked, validation
    print(json.dumps({'attempt': str(ATTEMPT.relative_to(WT)), 'summary': summary, 'trace': validation}, default=str))


if __name__ == '__main__':
    main()
