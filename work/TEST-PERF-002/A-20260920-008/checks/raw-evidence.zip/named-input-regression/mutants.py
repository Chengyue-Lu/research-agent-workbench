from pathlib import Path
import ast,hashlib,json,os,subprocess,time
repo=Path(r'D:\lcy\develop\_worktrees\RWB\ci-domain-model')
out=Path(__file__).resolve().parent
snapshot=out/'snapshot'
python=r'D:\lcy\develop\_assessments\rwb-ci-schema-parse-20260917\venv311\Scripts\python.exe'
base='09c6cb1c82680233c369014e0831874b6702d3b7'
commands=[]
def run(argv,cwd,label,env=None):
 start=time.perf_counter()
 p=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,text=True)
 log=out/(label+'.log'); log.write_text(p.stdout+p.stderr,encoding='utf-8')
 row={'argv':argv,'cwd':str(cwd),'returncode':p.returncode,'wall_seconds':time.perf_counter()-start,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 commands.append(row)
 return p
assert not snapshot.exists()
assert run(['git','clone','-q','--no-hardlinks','--single-branch','--branch','feature/ci-domain-model',str(repo),str(snapshot)],out,'clone').returncode==0
assert subprocess.check_output(['git','-C',str(snapshot),'rev-parse','HEAD']).decode().strip()==base
target='tests/test_ci_domain_audit.py'
current=(repo/target).read_bytes()
(snapshot/target).write_bytes(current)
prior=subprocess.check_output(['git','-C',str(repo),'show',base+':'+target])
def methods(raw):
 tree=ast.parse(raw)
 return {c.name+'.'+f.name:ast.dump(f) for c in tree.body if isinstance(c,ast.ClassDef) for f in c.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_')}
old,new=methods(prior),methods(current)
assert len(old)==4 and len(new)==5 and all(new[k]==v for k,v in old.items())
named='docs/workstreams/chengyue-lu/TEST-PERF-002/domain-model.json'
original=(repo/named).read_bytes()
assert (snapshot/named).read_bytes()==original
value=json.loads(original)
variants={
 'normal':original,
 'authority':json.dumps({**value,'execution_authority':True}).encode(),
 'pilots':json.dumps({**value,'pilots':[{'skip':'*'}]}).encode(),
 'duplicate-key':b'{"version":1,'+json.dumps(value).encode()[1:]}
expected={'authority':'cannot grant execution authority','pilots':'separately reviewed protocol','duplicate-key':'duplicate policy key: version'}
env={**os.environ,'PYTHONPATH':os.pathsep.join(str(snapshot/p) for p in ('','src','tests')),'PYTHONDONTWRITEBYTECODE':'1','GITHUB_EVENT_PATH':'','GITHUB_STEP_SUMMARY':''}
rows=[]
for label,raw in variants.items():
 (snapshot/named).write_bytes(raw)
 (out/(label+'-model.json')).write_bytes(raw)
 argv=[python,'-B','-m','unittest','tests.test_ci_domain_audit.DomainModelTests.test_named_repository_model_satisfies_official_validator','-v']
 p=run(argv,snapshot,label,env)
 assert p.returncode==(0 if label=='normal' else 1),(label,p.stderr)
 if label!='normal': assert expected[label] in p.stderr,p.stderr
 rows.append({'variant':label,'actual_named_path':str(snapshot/named),'model_sha256':hashlib.sha256(raw).hexdigest(),'returncode':p.returncode,'expected_error':expected.get(label),'log_sha256':commands[-1]['log_sha256']})
(snapshot/named).write_bytes(original)
assert (repo/named).read_bytes()==original
report={'execution_authority':False,'base':base,'test_source_sha256':hashlib.sha256(current).hexdigest(),'official_model_sha256':hashlib.sha256(original).hexdigest(),'old_methods_ast_unchanged':sorted(old),'rows':rows,'commands':commands,'snapshot_restored_model':True}
(out/'mutant-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'old_methods_unchanged':len(old),'rows':rows},indent=2))
