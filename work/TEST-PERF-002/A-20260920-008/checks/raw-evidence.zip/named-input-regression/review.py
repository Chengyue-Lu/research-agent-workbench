import ast,hashlib,json,subprocess
from pathlib import Path
out=Path(__file__).parent;root=Path(r'D:\lcy\develop\_worktrees\RWB\ci-domain-model');test='tests/test_ci_domain_audit.py';doc='docs/workstreams/chengyue-lu/TEST-PERF-002/DOMAIN_MODEL.md';model='docs/workstreams/chengyue-lu/TEST-PERF-002/domain-model.json';name='test_named_repository_model_satisfies_official_validator'
def git(*a):return subprocess.check_output(['git','-C',str(root),*a])
head=git('rev-parse','HEAD').decode().strip();old=ast.parse(git('show','HEAD:'+test));new=ast.parse((root/test).read_bytes());found=[]
for n in ast.walk(new):
 if isinstance(n,ast.ClassDef):
  found.extend(x for x in n.body if isinstance(x,ast.FunctionDef) and x.name==name)
  n.body=[x for x in n.body if not isinstance(x,ast.FunctionDef) or x.name!=name]
assert len(found)==1 and ast.dump(old)==ast.dump(new),'unexpected existing source changes'
assert (root/model).read_bytes()==git('show','HEAD:'+model)
files=[test,doc,model,'.github/scripts/ci_domain_audit.py','.github/scripts/plan_ci.py'];records=[]
for f in files:
 raw=(root/f).read_bytes();p=out/'sources'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 records.append({'path':f,'sha256':hashlib.sha256(raw).hexdigest(),'HEAD_sha256':hashlib.sha256(git('show','HEAD:'+f)).hexdigest()})
(out/'source-review.json').write_text(json.dumps({'head':head,'new_method':name,'existing_module_ast_unchanged_after_removing_new_method':True,'formal_model_bytes_unchanged':True,'files':records},indent=2)+'\n')
(out/'reviewed.diff').write_bytes(git('diff','--',test,doc));print(json.dumps({'head':head,'test_sha256':records[0]['sha256'],'ast_preserved':True}))
