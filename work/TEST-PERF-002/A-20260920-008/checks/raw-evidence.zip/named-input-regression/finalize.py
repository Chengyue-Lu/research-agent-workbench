from pathlib import Path
import hashlib,json,subprocess
repo=Path(r'D:\lcy\develop\_worktrees\RWB\ci-domain-model')
out=Path(__file__).resolve().parent
def git(*args): return subprocess.check_output(['git','-C',str(repo),*args]).decode().strip()
base='09c6cb1c82680233c369014e0831874b6702d3b7'
head=git('rev-parse','HEAD')
assert git('rev-parse','HEAD^')==base and not git('status','--porcelain')
paths=['tests/test_ci_domain_audit.py','docs/workstreams/chengyue-lu/TEST-PERF-002/DOMAIN_MODEL.md']
assert set(git('diff','--name-only',base,head).splitlines())==set(paths)
pins={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
checks={}
for label in ('311','313'):
 receipt=json.loads((out/(label+'-receipt.json')).read_bytes())
 process=json.loads((out/(label+'-process.json')).read_bytes())
 preflight=json.loads((out/(label+'-preflight.json')).read_bytes())
 assert process['returncode']==0 and receipt['successful'] and receipt['test_count']==15
 assert not any(receipt['events'][k] for k in ('failures','errors','skips'))
 assert all(preflight['source_sha256'][p]==v for p,v in pins.items())
 checks[label]={'python':preflight['python'],'tests':15,'successful':True,'events':receipt['events'],
   'runner_wall_seconds':receipt['wall_seconds'],'process':process,'source_sha256':preflight['source_sha256'],
   'receipt_sha256':hashlib.sha256((out/(label+'-receipt.json')).read_bytes()).hexdigest()}
mutants=json.loads((out/'mutant-results.json').read_bytes())
named='docs/workstreams/chengyue-lu/TEST-PERF-002/domain-model.json'
official=(repo/named).read_bytes()
assert hashlib.sha256(official).hexdigest()==mutants['official_model_sha256']
assert subprocess.check_output(['git','-C',str(repo),'show',base+':'+named])==official
data={'source_sha256':pins,'commit':head,'parent':base,'branch':git('branch','--show-current'),
 'execution_authority':False,'worktree_clean':True,'checks':checks,
 'official_model_sha256':mutants['official_model_sha256'],'old_methods_ast_unchanged':mutants['old_methods_ast_unchanged'],
 'mutant_results_sha256':hashlib.sha256((out/'mutant-results.json').read_bytes()).hexdigest(),
 'scope':'real named input regression only; no classification, production policy, exclusion or coverage authority change'}
(out/'validation.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
report=f'''# Named diagnostic input regression

Owner: Chengyue-Lu. Task TEST-PERF-002. Skills [].
Commit `{head}`, parent `{base}`, branch `{data['branch']}`. Working tree clean.

The prior four tests exercised synthetic models but did not validate the real named JSON. This change adds one five-line test, `DomainModelTests.test_named_repository_model_satisfies_official_validator`, reading `ROOT / audit.MODEL` bytes and using the exact duplicate-key hook and validator used by the production CLI. It does not construct another plan or report. It does not pin domain count, owner text, or a fixed model hash. Existing four methods are AST-identical. DOMAIN_MODEL.md adds five lines describing this actual-input boundary.

No production file or official model byte changed. The named model remains `{data['official_model_sha256']}`. No selector, classification, policy, threshold, smoke or exclusion permission changed, and PR92 was untouched.

## Validation

| Actual interpreter | Suite | Result | Native wall | Process wall |
| --- | --- | --- | ---: | ---: |
| {checks['311']['python']} | 5 domain + 10 documentation | 15 PASS, 0 skip/error | {checks['311']['runner_wall_seconds']} s | {checks['311']['process']['process_wall_seconds']:.6f} s |
| {checks['313']['python']} | 5 domain + 10 documentation | 15 PASS, 0 skip/error | {checks['313']['runner_wall_seconds']} s | {checks['313']['process']['process_wall_seconds']:.6f} s |

Native documentation checks include all internal Markdown links and public build/documentation boundaries. Exact source hashes and commands are in validation.json and each preflight/process record. No full suite or coverage run was needed or claimed for this local check; hosted required CI will run for the updated PR head.

`mutants.py` cloned exact parent into a disposable Git tree and copied only the final test file. It then overwrote the actual `docs/workstreams/chengyue-lu/TEST-PERF-002/domain-model.json` path, without patching ROOT/MODEL, loader, parser or validator, and ran the new method in a fresh real Python process:

- Normal exact bytes: PASS.
- `execution_authority=true`: fails with `cannot grant execution authority`.
- Nonempty pilots: fails with `separately reviewed protocol`.
- Duplicate version key: fails with `duplicate policy key: version`.

Each variant's exact JSON, subprocess argv/cwd/exit, log and hash is retained. The snapshot model was restored afterwards; the formal worktree model remained unchanged throughout. These are actual named-input faults, not synthetic model-only checks. Earlier named-input-audit retains the separate real-CLI controls and the proof that the old four methods missed a corrupted actual file.

Initial authoring evidence (`initial.log` plus its source snapshot) records an incorrect expected duplicate-key error label in a larger CLI harness. The production parser rejected that input correctly. The final minimal test uses the same parser/validator directly and the isolated controls above retain its actual exception. No failure log was overwritten.

Independent reviewer output is REVIEW.md with its separately maintained reviewer-sha256.json. The reviewer inspected the actual path, strict parse/validator calls, old-method preservation and the retained real-path controls; no source was changed by review. Root owns A-20260920-008 archival and PR91 update. This task did not push, change Ready state, create a PR or produce Trace records.

## Retain / exclude

Retain all top-level JSON/logs/scripts/review files, the four `*-model.json` control files, source snapshots and the final two source files by commit. Exclude the disposable **snapshot/** Git clone from the formal archive: its exact parent plus copied final test and all model variants/logs/commands are already preserved. Also exclude __pycache__ and .pyc. No venv was created or modified.

Final changed-source hashes:

```json
{json.dumps(pins,indent=2)}
```
'''
(out/'REPORT.md').write_text(report,encoding='utf-8')
manifest={p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*'))
 if p.is_file() and p.name!='sha256.json' and 'snapshot' not in p.relative_to(out).parts
 and '__pycache__' not in p.parts and p.suffix!='.pyc'}
(out/'sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'commit':head,'report_sha256':manifest['REPORT.md'],'validation_sha256':manifest['validation.json'],
 'files':len(manifest),'source_sha256':pins},indent=2))
