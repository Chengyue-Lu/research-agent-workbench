# Actual named-input regression review

**PASS — no actionable findings in the reviewed test/document change.**

Reviewed source base: `09c6cb1c82680233c369014e0831874b6702d3b7`, plus the exact two-file working diff in `reviewed.diff`. This conclusion binds source hashes rather than any later commit automatically.

- New method `DomainModelTests.test_named_repository_model_satisfies_official_validator` reads `(ROOT / audit.MODEL).read_bytes()`, i.e. the actual repository named input.
- JSON parsing uses the existing formal CLI duplicate-key hook `planner.unique_object`; semantic validation calls the existing `audit.validate_model`. No copied schema or parallel weaker validator is introduced.
- No domain count, owner text or model digest is hard-coded by the test. Model hash recording in evidence is provenance, not an assertion constraining future valid content.
- Removing this one new method leaves the entire test-module AST identical to HEAD, including all four prior tests. The formal model and production readers/validators are byte-identical to HEAD.
- The final method adds no subprocess, Git planning, report reconstruction or full-suite execution. Documentation accurately describes an input-contract check, without claiming classification, exclusion or release authority.

Independent evidence inspection verified the implementation owner's isolated actual-path controls. `mutants.py` copies the reviewed test bytes into a real clone and changes `snapshot/docs/workstreams/chengyue-lu/TEST-PERF-002/domain-model.json`, not the synthetic model() fixture. Running only the new method passes on original bytes and exits 1 for execution_authority=true, nonempty pilots, and duplicate version key. Each saved raw model and log matches the digest in `mutant-results.json`; the logs contain the expected official rejection. The snapshot model is restored and production model is unchanged.

The owner also provided Python 3.11/3.13 runs of five domain and ten documentation cases: 15 PASS each, process wall 5.113s/4.946s. I verified success/count and log digests; I did not rerun these suites or duplicate the single-method controls. This review establishes the actual-input regression and adversarial evidence, not hosted CI, consumer-closure completeness, coverage proof, reduction authority or merge acceptance.

Test source SHA256: `22e39bc2072486f4d24d73fc06332150fa21c31521a54be48ffacd51101669ba`.
Documentation SHA256: `5c72960545f2e6f0df9528553c71abe867864d8f15bc54ba604f3f4822a7de04`.
Mutant receipt SHA256: `ddb4820321642c94a6b435ccdb92a101e6d60ea29f806109b3217af35fc164b1`.

`source-review.json` and `reviewer-sha256.json` preserve the exact reviewed source/evidence. No code, formal model, branch, GitHub state, or earlier frozen audit was modified by this reviewer.
