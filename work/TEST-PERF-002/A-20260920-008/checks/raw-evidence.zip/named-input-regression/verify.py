from pathlib import Path
import hashlib, json, platform, sys, time, unittest
repo=Path(r'D:\lcy\develop\_worktrees\RWB\ci-domain-model')
out=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path[:0]=[str(repo),str(repo/'src'),str(repo/'tests')]
from tests import run_unittest_suite as runner
assert Path(runner.__file__).resolve()==repo/'tests/run_unittest_suite.py'
label=sys.argv[1]
pins={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in [
 'tests/test_ci_domain_audit.py','docs/workstreams/chengyue-lu/TEST-PERF-002/DOMAIN_MODEL.md',
 'docs/workstreams/chengyue-lu/TEST-PERF-002/domain-model.json','.github/scripts/ci_domain_audit.py']}
started=time.perf_counter()
loader=unittest.TestLoader()
suite=loader.loadTestsFromNames(['tests.test_ci_domain_audit','tests.test_documentation'])
assert not loader.errors, loader.errors
ids=[t.id() for t in runner._iter_tests(suite)]
(out/(label+'-preflight.json')).write_text(json.dumps({'python':platform.python_version(),'source_sha256':pins,'test_ids':ids},indent=2)+'\n')
result=unittest.TextTestRunner(verbosity=2,resultclass=runner.TimedTextResult).run(suite)
runner._write_summary(out/(label+'-receipt.json'),'named-input-and-documentation',time.perf_counter()-started,result,5)
assert pins=={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in pins}
raise SystemExit(0 if result.wasSuccessful() else 1)
