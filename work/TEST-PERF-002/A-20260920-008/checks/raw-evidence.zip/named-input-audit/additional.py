import hashlib,json,os,subprocess,sys
from pathlib import Path
out=Path(__file__).parent;repo=out/'repo';summary=json.loads((out/'summary.json').read_text());source=summary['source'];model=summary['model'];commands=[]
def run(a):
 r=subprocess.run(a,capture_output=True,cwd=repo,env=env);commands.append({'argv':list(map(str,a)),'exit':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')});return r
def git(*a):
 r=run(['git','-C',str(repo),*a]);r.check_returncode();return r.stdout.decode().strip()
temp=out/'temp';temp.mkdir(exist_ok=True);env=dict(os.environ);env.update(TEMP=str(temp),TMP=str(temp),TMPDIR=str(temp),PYTHONUTF8='1',PYTHONPATH=os.pathsep.join([str(repo/'tests'),str(repo/'src'),str(repo)]))
invalid=next(s for s in summary['scenarios'] if s['name']=='authority-escalation');git('checkout','--detach',invalid['head'])
r=run([sys.executable,'-m','unittest','test_ci_domain_audit','-v']);(out/'invalid-data-existing-reader-tests.log').write_bytes(r.stdout+r.stderr)
git('checkout','--detach','refs/tags/probe/deleted-model');deleted=git('rev-parse','HEAD')
rdeleted=run([sys.executable,'-m','unittest','test_documentation.DocumentationTests.test_internal_markdown_links_resolve','-v']);(out/'deleted-model-membership-test.log').write_bytes(rdeleted.stdout+rdeleted.stderr)
git('checkout','--detach',source)
# Copy exact concrete reader witnesses, including helper/test bytes, no owner edits.
extra=['tests/test_ci_dependencies.py','tests/test_m5_trace_export.py','tests/public_surface_helpers.py','docs/workstreams/chengyue-lu/TEST-PERF-002/DOMAIN_MODEL.md']
hashes=json.loads((out/'source-hashes.json').read_text())
for path in extra:
 raw=(repo/path).read_bytes();dest=out/'sources'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);hashes.append({'path':path,'source_commit':source,'sha256':hashlib.sha256(raw).hexdigest(),'git_entry':git('ls-tree',source,'--',path)})
(out/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
sys.path.insert(0,str(repo/'.github/scripts'));import ci_dependencies as deps
factrows={}
for path in ['.github/scripts/ci_domain_audit.py','tests/test_ci_dependencies.py','tests/test_documentation.py','tests/test_m5_trace_export.py']:
 value=deps._file_facts(path,(repo/path).read_bytes());names=('links','literals','prefixes','basenames','opaque_execution','unbounded_reader','fixed_reads','fixed_runs','fixed_directories');factrows[path]={name:sorted(v,key=repr) if isinstance(v,(set,frozenset)) else v for name,v in zip(names,value)}
(out/'direct-consumer-facts.json').write_text(json.dumps(factrows,indent=2)+'\n')
git('bundle','create',str(out/'named-input-probes-complete.bundle'),*[f"refs/tags/probe/{s['name']}" for s in summary['scenarios']],'refs/tags/probe/deleted-model','^'+source);verification=git('bundle','verify',str(out/'named-input-probes-complete.bundle'))
(out/'additional-controls.json').write_text(json.dumps({'invalid_model':invalid['head'],'invalid_model_existing_synthetic_tests_exit':r.returncode,'deleted_model':deleted,'deleted_model_real_document_membership_exit':rdeleted.returncode,'test_temp_root':str(temp),'bundle_verified':True},indent=2)+'\n');(out/'additional-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print('COMPLETE')
