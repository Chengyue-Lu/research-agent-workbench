import copy,hashlib,importlib.util,json,os,subprocess,sys,traceback
from pathlib import Path
out=Path(__file__).parent;repo=out/'repo';origin=Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow');source='4119f8b2d8e1e64a0afead138d13061e2d89e996';modelpath='docs/workstreams/chengyue-lu/TEST-PERF-002/domain-model.json';commands=[]
def run(args,**kw):
 r=subprocess.run(args,capture_output=True,**kw);commands.append({'argv':list(map(str,args)),'exit':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')});return r
def git(*a,check=True):
 r=run(['git','-C',str(repo),*a]);
 if check:r.check_returncode()
 return r.stdout.decode().strip()
if not repo.exists():run(['git','clone','--shared','--no-checkout',str(origin),str(repo)]).check_returncode()
git('config','user.name','CI input audit');git('config','user.email','ci-audit@example.invalid');git('config','core.autocrlf','false');git('checkout','--detach',source)
sys.path[:0]=[str(repo/'.github/scripts'),str(repo/'tests'),str(repo/'src'),str(repo)]
import plan_ci as planner,ci_domain_audit as audit,ci_input_facts as facts,selection_witness as witness
modelraw=(repo/modelpath).read_bytes();model=json.loads(modelraw);audit.validate_model(model)
files=[modelpath,'.github/scripts/ci_domain_audit.py','.github/scripts/ci_consumer_shadow.py','.github/scripts/ci_input_facts.py','.github/scripts/ci_contract_shadow.py','.github/scripts/ci_consumer_contracts.py','.github/scripts/plan_ci.py','.github/scripts/ci_dependencies.py','.github/scripts/selection_witness.py','.github/workflows/ci.yml','tests/ci_impact_policy.yaml','tests/coverage_policy.yaml','tests/test_ci_domain_audit.py','tests/test_ci_consumer_shadow.py','tests/test_ci_input_facts.py','tests/test_selection_witness.py','tests/test_documentation.py','runtime-resources.json','MANIFEST.in','build_backend.py']
sources=[]
for f in files:
 p=repo/f
 if p.exists():
  raw=p.read_bytes();dest=out/'sources'/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);sources.append({'path':f,'source_commit':source,'sha256':hashlib.sha256(raw).hexdigest(),'git_entry':git('ls-tree',source,'--',f)})
(out/'source-hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
scenarios=[]
for name in ['owner-text','authority-escalation','unknown-field','executable-mode','sibling-json']:
 git('checkout','--detach',source);value=copy.deepcopy(model);path=modelpath
 if name=='owner-text':value['domains'][0]['owner']+=' (diagnostic audit)'
 elif name=='authority-escalation':value['execution_authority']=True
 elif name=='unknown-field':value['unreviewed_skip']=True
 elif name=='sibling-json':path=str(Path(modelpath).with_name('sibling-input.json')).replace('\\','/')
 (repo/path).write_bytes(planner.canonical(value))
 git('add',path)
 if name=='executable-mode':git('update-index','--chmod=+x',path)
 git('commit','-qm','isolated named input probe '+name);head=git('rev-parse','HEAD');git('tag','probe/'+name)
 plan=planner.make_plan(repo,base=source,head=head,target=head,repository='Chengyue-Lu/research-agent-workbench',body='- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no')
 (out/(name+'-plan.json')).write_bytes(planner.canonical(plan))
 try:
  report=audit.build_report(repo,plan,value);reader={'status':'PASS','authority':report['execution_authority'],'activation':report['activation'],'model_sha256':report['model_sha256']};(out/(name+'-reader.json')).write_bytes(planner.canonical(report))
 except Exception as exc:reader={'status':'BLOCK','error':str(exc),'exception':type(exc).__name__}
 floor=witness.witness(repo,'Chengyue-Lu/research-agent-workbench',source,head,plan)
 record={'name':name,'path':path,'base':source,'head':head,'plan_id':plan['plan_id'],'scope':{k:plan[k] for k in ['behavioral_scope','coverage_scope','package_smoke','repository_smoke']},'reasons':plan['obligation_reasons'],'selector_count':len(plan['tests']),'reader':reader,'independent_witness':floor};scenarios.append(record)
 print(json.dumps({k:v for k,v in record.items() if k not in ['reasons','independent_witness']}),flush=True)
 if name=='owner-text':
  edges,dynamic,readers,invalid=planner.dependencies.commit_graph(repo,source)
  graph={'exact_path_static_consumers':sorted(edges.get(modelpath,set())),'opaque_execution_consumers':sorted(dynamic),'resource_consumers':sorted(readers),'errors':invalid,'selection':plan['selection'],'input_fact':facts.describe(modelpath,[('100644',modelraw),('100644',planner.canonical(value))],selection_authority=planner.SELECTION_AUTHORITY,coverage_authority=planner.COVERAGE_AUTHORITY,policy_path=planner.POLICY)}
  (out/'graph.json').write_text(json.dumps(graph,indent=2)+'\n')
git('checkout','--detach',source)
env=dict(os.environ);env['PYTHONPATH']=os.pathsep.join([str(repo/'tests'),str(repo/'src'),str(repo)]);env['PYTHONUTF8']='1'
r=run([sys.executable,'-m','unittest','test_ci_domain_audit','-v'],cwd=str(repo),env=env);(out/'existing-reader-tests.log').write_bytes(r.stdout+r.stderr)
# Read actual named-file through existing CLI with the source-pinned positive plan and selected worktree.
positive=scenarios[0];git('checkout','--detach',positive['head'])
rcli=run([sys.executable,str(repo/'.github/scripts/ci_domain_audit.py'),'--repo',str(repo),'--plan',str(out/'owner-text-plan.json'),'--output',str(out/'actual-default-reader.json')],cwd=str(repo),env=env);(out/'actual-default-reader.log').write_bytes(rcli.stdout+rcli.stderr)
git('checkout','--detach',scenarios[1]['head'])
rnegative=run([sys.executable,str(repo/'.github/scripts/ci_domain_audit.py'),'--repo',str(repo),'--plan',str(out/'authority-escalation-plan.json'),'--output',str(out/'invalid-default-reader.json')],cwd=str(repo),env=env);(out/'invalid-default-reader.log').write_bytes(rnegative.stdout+rnegative.stderr)
git('bundle','create',str(out/'named-input-probes.bundle'),*[f"refs/tags/probe/{s['name']}" for s in scenarios],'^'+source)
summary={'source':source,'model':modelpath,'scenarios':scenarios,'existing_test_exit':r.returncode,'positive_default_reader_exit':rcli.returncode,'negative_default_reader_exit':rnegative.returncode,'production_changes':False,'coverage_measured':False}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print('COMPLETE',flush=True)
