# Named diagnostic input audit: PR #92 exact 4119

Source **4119f8b2d8e1e64a0afead138d13061e2d89e996**. Named file `docs/workstreams/chengyue-lu/TEST-PERF-002/domain-model.json`. This is a design/evidence audit; no skip, exclusion or production classification was activated.

## Finding

The hosted PR92 plan (base171 → head4119, tested merge e8282d85) explicitly names this JSON as the sole behavioral FULL reason and the repository-coverage fallback alongside genuine executable impact coverage. Its actual scope is **full / impact+repository**, both smokes true. `hosted4119-plan.json` preserves the exact original plan.

Two separate mechanisms amplify it:

1. `plan_ci.non_executable` recognizes Markdown, work archives and supported test data, but no named diagnostic JSON. The file misses the runtime schema/registry/examples branch and reaches `unclassified dependency surface`, which sets FULL, repository coverage and both smokes. `ci_input_facts.describe` independently reports repository-domain **unknown**, regular non-executable bytes, no authority flags. Adding a role there alone changes diagnostic explanation, not execution planning.
2. `ci_dependencies.select` fans a non-Python/non-Markdown seed into all unresolved resource readers. The isolated owner-text mutation selects **100/101 test modules**, with **97 unbounded-resource witness paths**. These are selector/module counts, not executed cases. Merely naming the file will not close this graph expansion. Classification, coverage obligations and invocation-level consumer closure need separate proof.

## Exact readers and membership

| Surface | Observed contract | Limit |
|---|---|---|
| `ci_domain_audit.py:main` | Default repo/MODEL, or explicit --model; reads exactly that file through strict duplicate-key JSON parsing and validate_model | Explicit offline proposal. Working-tree model bytes are not automatically the model at the plan target. |
| `validate_model` | Version 1, execution_authority false, empty pilots, exact field sets, unique IDs, named owners, bounded safe routing patterns, explicit unknowns | Embedded Python validator; no business schema-catalog membership. |
| `build_report` | Retains accepted plan unchanged, snapshots exact Git refs, checks consumer IDs against base policy, emits model canonical hash and producer hashes | Always execution_authority false, activation false; missing refs are reported blockers rather than permission. |
| `ci_consumer_shadow.py` | Imports domain utilities (strings/validation helpers) | It does not read MODEL. Its separate proposal/plan/inventory/receipt CLI inputs remain separate obligations. |
| `test_ci_domain_audit.py` | 4 tests use a synthetic model() and explicit temporary model.json | The actual committed named JSON is not validated by those existing tests. |
| `test_documentation` | Reads Markdown and checks link targets exist; DOMAIN_MODEL.md links this file | Real existence/membership dependency, not JSON semantic validation. |
| Runtime/package/public source | No named reference in runtime catalog or MANIFEST; current public source selection excludes this path | Generic unresolved reader edges do not establish that a runtime invocation reads this JSON. Arbitrary future caller remains a fail-safe boundary. |

Graph exact-path consumers also include `test_ci_dependencies` and `test_m5_trace_export`. Their retained syntax facts include broad `docs` prefixes from fixture/source construction; the latter creates a separate temporary docs tree. These graph edges must not be described as demonstrated content reads of the domain JSON. `direct-consumer-facts.json` and exact witness sources preserve why they appear. Broad business reader internals were not expanded beyond these concrete witnesses.

The model has 8 routing domains and references consumer IDs ['cli-git-head-observation', 'validation-capability-root-scan', 'validation-document-instances', 'validation-schema-catalog']. Its declarations remain routing proposals, not a schema registry or selector authority. The raw blob SHA256 is `454443ea5295fe70b2ed9cf83624dc59376aa2f96c7d54b9b4df015e4d40b0c1`; model_sha256 in a report is a canonical object digest, a different identity.

## Cheap real controls

Each isolated commit is based on exact4119, not the actual develop baseline. Five generated plans all retain FULL/repository and both smokes:

| Mutation | Reader result | Planner result |
|---|---|---|
| Change owner text only | Default real CLI passes; diagnostic authority false | FULL / repository |
| execution_authority=true | Real default CLI fails with ValueError | FULL / repository |
| Unknown root key | validate_model fails | FULL / repository |
| Git mode100755 | JSON validation alone passes | FULL / repository; mode must be a separate eligibility guard |
| New sibling JSON | Explicit diagnostic model value validates | FULL / repository; sibling is not eligible by name |

Existing four domain tests pass on source4119, and **still all pass when the actual named JSON has execution_authority=true**. The real default CLI rejects that same file. This proves a missing actual-input integration check before any lower-cost classification can be considered. Deleting the named file makes the existing Markdown-link test fail on the DOMAIN_MODEL.md link. Original logs and six exact probe commits are preserved; no full suite or coverage was run.

The independent `selection_witness` reports no selection-authority semantic changes for these data-only probes. Its contract explicitly proves only the behavioral authority floor; it neither classifies this JSON nor authenticates coverage omission. It must not be cited as an independent named-input closure proof.

## Smallest auditable proposal

Start with a **single exact named-input record**, accepted from trusted base, never wildcard docs/** or all JSON. Bind the canonical path, supported 100644 blob mode at merge-base/head/target, strict schema/version, no shebang, reader entrypoint/invocation, reader/helper/validator source pins, actual-input validation tests, and membership consumers. Model content may change, so bind its per-ref raw hash in each evidence receipt instead of requiring a permanently unchanged model hash. Directory inventories, links and referenced consumer IDs are distinct membership inputs and cannot be inferred from the suffix.

First stage: add the actual-file reader integration check and a diagnostic role such as `named-diagnostic-input`; keep execution obligations unchanged until the accepted record is reviewed. Reader/schema/model-source pin drift, new reader or packaging/runtime inclusion, unsupported mode/type, rename/delete/add, ambiguous CLI path and unknown ref must fail safe or block as appropriate. Deleting a linked input must be caught by the existing membership consumer.

Second stage: separate data-content validity from executable coverage change. For a valid existing named data-only edit with unchanged reader/schema/authority, the intended minimum is focused real reader + schema + membership tests, coverage none, smokes false **only after** the invocation closure independently establishes that runtime/package/repository validators do not consume it. Keep any unproved consumers selected. A first obligation-only improvement may remove unclassified repository coverage while still retaining the broad graph; report that limited result honestly.

Implement selector/graph changes under the existing independent authority witness, so the implementation PR requires full bootstrap. Do not let candidate model data register itself, loosen schema, select its own tests, or set coverage scope. Coverage global90/critical95/90/changed100/100 rules remain unchanged for changes that actually require them.

Required adversarial controls before activation: real named valid/invalid file; duplicate JSON keys; true authority/pilots/extra keys; malformed consumer refs; reader/helper/import drift; alternate --model/working-tree-vs-Git mismatch; executable/shebang/symlink/gitlink/mode transitions; sibling/rename/delete/add; runtime/package/schema-membership addition; simultaneous production executable or coverage-authority change; metadata downgrade attempt; missing/failed reader receipt and aggregate skip rejection. Validate selected native inventories and exact target receipts; do not claim speedup without a same-target paired run.

## Acceptance and remaining limits

This audit/design and isolated tests can progress independently of PR91/92 acceptance. The named JSON, reader and tests are **absent from develop base171** (retained ls-tree observation); 4119 is a proposed source snapshot, not an accepted classification baseline. A production record would be stacked/provisional until those sources are accepted, then rebase and re-pin to the real accepted commit. Their acceptance does not automatically approve the new exclusion contract.

Known environment: Windows Python3.11.16 with existing repository test dependencies. Additional temporary fixture roots were explicitly placed under this scratch directory. This audit does not prove all possible external invocations, business semantics, hosted classification behavior, performance, or exclusion closure. Initial helper serialization failure (mixed None/string fact set) is retained; completed rerun uses repr ordering solely for evidence serialization.

All evidence is under named-input-audit. `source-hashes.json` pins scoped source blobs; `commands.json`/`additional-commands.json` retain actual commands/exits; `named-input-probes-complete.bundle` contains only six probe refs with source4119 prerequisite; `SHA256SUMS.json` covers retained report/evidence. No GitHub or owner-branch mutation occurred.
