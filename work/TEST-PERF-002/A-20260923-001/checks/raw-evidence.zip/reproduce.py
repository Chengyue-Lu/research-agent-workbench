"""Reviewer counterexample against the explicitly imported working source."""
import hashlib
import json
from pathlib import Path
import sys

from tests.test_ci_shadow_pair import example, pair

plan, inventory, policy, report, accepted, candidate = example(False)
candidate['driver']['invocation'] = accepted['driver']['invocation'][:]
result = pair.compare_pair(plan, report, inventory, policy, accepted, candidate)
output = {
    'source': str(Path(pair.__file__).resolve()),
    'source_sha256': hashlib.sha256(Path(pair.__file__).read_bytes()).hexdigest(),
    'accepted_behavioral_order': inventory['behavioral_order'],
    'candidate_behavioral_order': report['candidate']['behavioral_order'],
    'accepted_invocation': accepted['driver']['invocation'],
    'candidate_invocation': candidate['driver']['invocation'],
    'result': result,
}
Path(sys.argv[1]).write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'pair_status': result['pair_status'], 'blockers': result['blockers']}))
