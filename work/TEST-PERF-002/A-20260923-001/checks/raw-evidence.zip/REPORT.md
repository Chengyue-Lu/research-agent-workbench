# PR92 review 5287223195: bounded local fix

Owner: Chengyue-Lu. Profile: CI 2B implementer. Skills: [].

## Disposition

The reviewer counterexample was reproduced unchanged before editing: accepted B=[A,B], candidate B=[A], both driver commands `python experiment.py --role accepted`, produced `observed-matching-pair` with no blockers. The original source and complete before-result are preserved here. After the fix, the same script/input produces `inconclusive` with `changed test orders require distinct accepted/candidate --role invocations`.

The two-line guard now requires the existing correct unique accepted-to-candidate `--role` distinction whenever either behavioral order or coverage order changes. It does not add an alternate selection-input mechanism. Identical complete B/C orders may still use identical native commands. Existing protection against other argv differences, driver changes, missing/failed/skipped evidence, coverage failures, and smoke reassociation remains intact; activation remains false.

## Changed files and regression meaning

- `.github/scripts/ci_shadow_pair.py`: guard after the existing invocation-difference check.
- `tests/test_ci_shadow_pair.py`: replace the erroneous acceptance assertion with two new methods. The changed-order method proves legal roles succeed first, then tests identical accepted, candidate, absent, wrong, and duplicate roles across behavioral selection, behavioral reordering, and C-only reordering. C-only reordering retains the same actual execution union, so a union-only check cannot satisfy it. The unchanged-order method retains legal same-command controls with and without coverage. Existing smoke tests retain correct roles and their original assertions.
- `CONSUMER_SHADOW.md`: clarify the B/C order-dependent invocation contract only.

## Actual verification

| Check | Actual result |
|---|---|
| Python 3.11.16 domain + consumer + pair | 18 PASS, 16.046 s unittest time |
| Python 3.13.15 same modules | 18 PASS, 12.881 s unittest time |
| Python 3.11.16 isolated pair-only coverage run | 9 PASS, 4.627 s unittest time |
| Changed script coverage | 125/125 executable lines, 42/42 branches; no missing lines/arcs |
| Python 3.11.16 documentation | 10 PASS, 0.347 s unittest time |
| Git diff check | PASS |

Commands, cwd, timestamps, native logs, exit codes, and process wall times are in `commands-*.json`. The first 3.11 coverage invocation inherited repository `source` settings, which overrode the requested include filter and emitted a warning. Its original raw data and logs remain preserved; it is not presented as repository coverage. The authoritative local file measurement uses the separately retained `coverage-pair.rc` and `.coverage-pair-only-311`, containing exactly one script. No thresholds or repository coverage configuration were changed.

HEAD remains `99960397b0f1daa7c09f3575f8e5ef9bdb9d080c`, base `b44a03e17c3d751c12667a39f6d5b7b6fcf91a1c`. These are working-tree source-bound checks, not a new committed/hosted HEAD claim. The prior hosted run applies only to the pre-fix HEAD. Source hashes are in `validation.json`; `.codex/config.toml` retains its exact original SHA-256 `90069309d6222e3a4897277e15739fae5e57a8dcfb8192a9d480835c7896671b`. Only the three scoped tracked files were edited beyond that pre-existing dirty config.

## Parent handoff / remaining boundary

No commit, push, PR/Issue/memory/config edits, broad/full suite, repository coverage gate, or CI request was performed. Parent should review the three-file diff, retain the raw before/after evidence and command logs in the existing R2 trace, then bind any subsequent commit to current plan/governance/witness and required hosted checks. Update PR92's verification evidence and readiness record to identify this review, the narrowed fix, and new HEAD evidence when actually available. Request cross-owner re-review; this local result does not resolve the GitHub review or authorize merge/2C. Frozen historical archives must remain unchanged, with this correction linked as a new observation.
