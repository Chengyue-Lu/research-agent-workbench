"""Run only the owned protocol regressions, retaining native output and commands."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/lcy/develop/_worktrees/RWB/ci-consumer-shadow')
OUT = Path(__file__).resolve().parent
ENV = os.environ.copy()
ENV.update(PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1',
           PYTHONPATH=os.pathsep.join(str(ROOT / part) for part in ('', 'src', 'tests')))
version = sys.argv[1]
python = Path('D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917') / ('venv' + version) / 'Scripts/python.exe'
ENV['COVERAGE_FILE'] = str(OUT / '.coverage-pair-311')
modules = ['tests.test_ci_domain_audit', 'tests.test_ci_consumer_shadow', 'tests.test_ci_shadow_pair']
commands = [([str(python), '-B', '--version'], 'python')]
test_args = ['-m', 'unittest', *modules, '-v']
if version == '311':
    commands += [([str(python), '-B', '-m', 'coverage', 'run', '--branch',
                   '--include=.github/scripts/ci_shadow_pair.py', *test_args], 'protocol'),
                 ([str(python), '-B', '-m', 'coverage', 'json', '-o', str(OUT / 'coverage-pair-311.json')], 'coverage-json'),
                 ([str(python), '-B', '-m', 'coverage', 'report', '-m'], 'coverage-report')]
else:
    commands += [([str(python), '-B', *test_args], 'protocol')]
records = []
for command, label in commands:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.perf_counter()
    result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    elapsed = time.perf_counter() - clock
    log = OUT / (version + '-' + label + '.log')
    log.write_bytes(result.stdout)
    records.append({'command': command, 'cwd': str(ROOT), 'started_utc': started,
                    'wall_seconds': elapsed, 'exit_code': result.returncode,
                    'log': log.name, 'log_sha256': hashlib.sha256(result.stdout).hexdigest()})
    print(label, result.returncode, round(elapsed, 3), flush=True)
    if result.returncode:
        break
(OUT / ('commands-' + version + '.json')).write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
raise SystemExit(records[-1]['exit_code'])
