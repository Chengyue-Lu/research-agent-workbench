"""Freeze this bounded working-tree validation without claiming a new HEAD run."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('D:/lcy/develop/_worktrees/RWB/ci-consumer-shadow')
OUT = Path(__file__).resolve().parent
PATHS = ['.github/scripts/ci_shadow_pair.py', 'tests/test_ci_shadow_pair.py',
         'docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_SHADOW.md']
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])
head = git('rev-parse', 'HEAD').decode().strip()
base = git('rev-parse', 'origin/develop').decode().strip()
assert head == '99960397b0f1daa7c09f3575f8e5ef9bdb9d080c'
assert base == 'b44a03e17c3d751c12667a39f6d5b7b6fcf91a1c'
config = sha(ROOT / '.codex/config.toml')
assert config == '90069309d6222e3a4897277e15739fae5e57a8dcfb8192a9d480835c7896671b'
status = git('status', '--short')
(OUT / 'final-status.txt').write_bytes(status)
assert set(git('diff', '--name-only').decode().splitlines()) == set(PATHS + ['.codex/config.toml'])
diff = git('diff', '--', *PATHS)
(OUT / 'implementation.diff').write_bytes(diff)
check = subprocess.run(['git', '-C', str(ROOT), 'diff', '--check'], capture_output=True)
(OUT / 'diff-check.log').write_bytes(check.stdout + check.stderr)
assert check.returncode == 0
coverage = json.loads((OUT / 'coverage-pair-only-311.json').read_text(encoding='utf-8'))
assert len(coverage['files']) == 1
file, facts = next(iter(coverage['files'].items()))
assert file.replace('\\', '/') == PATHS[0]
tests = []
for log in ('311-protocol.log', '313-protocol.log', '311-pair-only-protocol.log', '311-documentation-final.log'):
    text = (OUT / log).read_text(encoding='utf-8')
    match = re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK', text)
    assert match, log
    tests.append({'log': log, 'count': int(match[1]), 'unittest_seconds': float(match[2]), 'result': 'PASS'})
before = json.loads((OUT / 'reproduced-before.json').read_text(encoding='utf-8'))
after = json.loads((OUT / 'reproduced-after.json').read_text(encoding='utf-8'))
assert before['result']['pair_status'] == 'observed-matching-pair'
assert after['result']['pair_status'] == 'inconclusive'
validation = {
    'collected_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'kind': 'working-tree scoped verification; not a committed or hosted HEAD receipt',
    'worktree': str(ROOT), 'head': head, 'base': base,
    'review_id': 5287223195,
    'paths': {path: {'sha256': sha(ROOT / path)} for path in PATHS},
    'preexisting_config_sha256_unchanged': config,
    'tests': tests,
    'source_coverage': {'path': file, 'summary': facts['summary'],
                        'missing_lines': facts['missing_lines'], 'missing_branches': facts['missing_branches'],
                        'data_sha256': sha(OUT / '.coverage-pair-only-311'),
                        'json_sha256': sha(OUT / 'coverage-pair-only-311.json'),
                        'authority': 'local script facts only; no repository or exact-head hosted gate claim'},
    'reproduction': {'before_status': before['result']['pair_status'],
                     'after_status': after['result']['pair_status'], 'after_blockers': after['result']['blockers']},
    'diff_check_exit': check.returncode,
    'not_performed': ['commit', 'push', 'PR or Issue mutation', 'full suite', 'repository coverage', '2C activation'],
}
(OUT / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n', encoding='utf-8')
report = f'''# PR92 review 5287223195: bounded local fix

Owner: Chengyue-Lu. Profile: CI 2B implementer. Skills: [].

## Disposition

The reviewer counterexample was reproduced unchanged before editing: accepted B=[A,B], candidate B=[A], both driver commands `python experiment.py --role accepted`, produced `observed-matching-pair` with no blockers. The original source and complete before-result are preserved here. After the fix, the same script/input produces `inconclusive` with `changed test orders require distinct accepted/candidate --role invocations`.

The two-line guard now requires the existing correct unique accepted-to-candidate `--role` distinction whenever either behavioral order or coverage order changes. It does not add an alternate selection-input mechanism. Identical complete B/C orders may still use identical native commands. Existing protection against other argv differences, driver changes, missing/failed/skipped evidence, coverage failures, and smoke reassociation remains intact; activation remains false.

## Changed files and regression meaning

- `.github/scripts/ci_shadow_pair.py`: guard after the existing invocation-difference check.
- `tests/test_ci_shadow_pair.py`: replace the erroneous acceptance assertion with two new methods. The changed-order method proves legal roles succeed first, then tests identical accepted, candidate, absent, wrong, and duplicate roles across behavioral selection, behavioral reordering, and C-only reordering. C-only reordering retains the same actual execution union, so a union-only check cannot satisfy it. The unchanged-order method retains legal same-command controls with and without coverage. Existing smoke tests retain correct roles and their original assertions.
- `CONSUMER_SHADOW.md`: clarify the B/C order-dependent invocation contract only.

## Actual verification

| Check | Actual result |
|---|---|
| Python 3.11.16 domain + consumer + pair | 18 PASS, 16.046 s unittest time |
| Python 3.13.15 same modules | 18 PASS, 12.881 s unittest time |
| Python 3.11.16 isolated pair-only coverage run | 9 PASS, 4.627 s unittest time |
| Changed script coverage | 125/125 executable lines, 42/42 branches; no missing lines/arcs |
| Python 3.11.16 documentation | 10 PASS, 0.347 s unittest time |
| Git diff check | PASS |

Commands, cwd, timestamps, native logs, exit codes, and process wall times are in `commands-*.json`. The first 3.11 coverage invocation inherited repository `source` settings, which overrode the requested include filter and emitted a warning. Its original raw data and logs remain preserved; it is not presented as repository coverage. The authoritative local file measurement uses the separately retained `coverage-pair.rc` and `.coverage-pair-only-311`, containing exactly one script. No thresholds or repository coverage configuration were changed.

HEAD remains `{head}`, base `{base}`. These are working-tree source-bound checks, not a new committed/hosted HEAD claim. The prior hosted run applies only to the pre-fix HEAD. Source hashes are in `validation.json`; `.codex/config.toml` retains its exact original SHA-256 `{config}`. Only the three scoped tracked files were edited beyond that pre-existing dirty config.

## Parent handoff / remaining boundary

No commit, push, PR/Issue/memory/config edits, broad/full suite, repository coverage gate, or CI request was performed. Parent should review the three-file diff, retain the raw before/after evidence and command logs in the existing R2 trace, then bind any subsequent commit to current plan/governance/witness and required hosted checks. Update PR92's verification evidence and readiness record to identify this review, the narrowed fix, and new HEAD evidence when actually available. Request cross-owner re-review; this local result does not resolve the GitHub review or authorize merge/2C. Frozen historical archives must remain unchanged, with this correction linked as a new observation.
'''
(OUT / 'REPORT.md').write_text(report, encoding='utf-8')
manifest = {path.name: sha(path) for path in sorted(OUT.iterdir()) if path.is_file() and path.name != 'manifest.json'}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'report_sha256': sha(OUT / 'REPORT.md'), 'validation_sha256': sha(OUT / 'validation.json'),
                  'manifest_sha256': sha(OUT / 'manifest.json'), 'source_sha256': validation['paths']}, indent=2))
