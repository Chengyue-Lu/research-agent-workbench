"""Use an isolated coverage configuration: the repository config declares source roots."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/lcy/develop/_worktrees/RWB/ci-consumer-shadow')
OUT = Path(__file__).resolve().parent
ENV = os.environ.copy()
ENV.update(PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1',
           PYTHONPATH=os.pathsep.join(str(ROOT / part) for part in ('', 'src', 'tests')),
           COVERAGE_FILE=str(OUT / '.coverage-pair-only-311'))
python = str(Path('D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917/venv311/Scripts/python.exe'))
rcfile = '--rcfile=' + str(OUT / 'coverage-pair.rc')
commands = [([python, '-B', '-m', 'coverage', 'run', rcfile, '-m', 'unittest', 'tests.test_ci_shadow_pair', '-v'], 'pair-only-protocol'),
            ([python, '-B', '-m', 'coverage', 'json', rcfile, '-o', str(OUT / 'coverage-pair-only-311.json')], 'pair-only-coverage-json'),
            ([python, '-B', '-m', 'coverage', 'report', rcfile, '-m'], 'pair-only-coverage-report'),
            ([python, '-B', '-m', 'unittest', 'tests.test_documentation', '-v'], 'documentation-final')]
records = []
for command, label in commands:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.perf_counter()
    result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    elapsed = time.perf_counter() - clock
    log = OUT / ('311-' + label + '.log')
    log.write_bytes(result.stdout)
    records.append({'command': command, 'cwd': str(ROOT), 'started_utc': started,
                    'wall_seconds': elapsed, 'exit_code': result.returncode,
                    'log': log.name, 'log_sha256': hashlib.sha256(result.stdout).hexdigest()})
    print(label, result.returncode, round(elapsed, 3), flush=True)
    if result.returncode:
        break
(OUT / 'commands-scoped-coverage.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
raise SystemExit(records[-1]['exit_code'])
