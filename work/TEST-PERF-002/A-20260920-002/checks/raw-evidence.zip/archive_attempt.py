import dataclasses
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

repo=Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow')
scratch=Path(__file__).parent
attempt=repo/'work/TEST-PERF-002/A-20260920-002'
checks=attempt/'checks'
checks.mkdir(parents=True,exist_ok=True)
implementation=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
base='171d4654f88e926f239cdf25bc8168109b81f391'
stack='09c6cb1c82680233c369014e0831874b6702d3b7'
def dump(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

probe_repo=scratch/'docs-probes/snapshot'
cases=json.loads((scratch/'docs-probes/summary.json').read_bytes())['cases'][1:]
refs=[]
for case in cases:
    ref='refs/shadow-probes/'+case['name'];refs.append(ref)
    subprocess.run(['git','-C',str(probe_repo),'update-ref',ref,case['head']],check=True)
subprocess.run(['git','-C',str(probe_repo),'bundle','create',str(scratch/'probe-history.bundle'),*refs,'^'+stack],check=True)
bundle_check=subprocess.run(['git','-C',str(repo),'bundle','verify',str(scratch/'probe-history.bundle')],capture_output=True,check=True)
(scratch/'bundle-check.log').write_bytes(bundle_check.stdout+bundle_check.stderr)
members=[]
for name in ('docs-input-audit.md','comparator-design-review.md','comparator-code-review.md','comparator-code-recheck.md',
             'focused-311.log','focused-313.log','coverage-unit.json','replay_consumers.py','replay.log',
             'archive_attempt.py','probe-history.bundle','bundle-check.log'):
    members.append((scratch/name,name))
for folder in ('replays','docs-probes'):
    for path in sorted((scratch/folder).rglob('*')):
        relative=path.relative_to(scratch)
        if path.is_file() and 'snapshot' not in relative.parts:
            members.append((path,relative.as_posix()))
transmissions={'capture':'partial retained visible artifacts and handoff summaries; original raw tool stream not fully captured',
 'delegations':[
  {'agent':'domain_inventory','profile':'CI consumer auditor','skills':[],'owner':'Chengyue-Lu',
   'scope':'documentation/public-surface/kernel input audit and isolated 25-case real failures; assessment files only',
   'budget':'15 minutes','output':'docs-input-audit.md plus docs-probes artifacts',
   'handoff':'Three relevant mutations and one unrelated control executed; documentation-only selection misses public navigation; only kernel pair supported as unrelated control.'},
  {'agent':'domain_plan_review','profile':'CI trust reviewer','skills':[],'owner':'Chengyue-Lu',
   'scope':'read-only design and implementation checks, report files only','budget':'design 8m; review10m; recheck5m',
   'outputs':['comparator-design-review.md','comparator-code-review.md','comparator-code-recheck.md'],
   'handoff':'Four P2 issues including follow-up unknown-C overclaim repaired and independently rechecked; no activation or merge authorization.'}],
 'main_responses':['Retain C/smoke obligations, distinguish effective skips and phase moves.',
                   'Extended docs-probe disposable write scope; no official branch changes or mocks.',
                   'Repaired receipt/checkpoint handling, exact IDs, empty diffs, and unknown coverage membership.']}
dump(checks/'delegation-summary.json',transmissions)
inventory=[]
with zipfile.ZipFile(checks/'raw-evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path,name in members:
        raw=path.read_bytes();archive.writestr(name,raw)
        inventory.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(checks/'raw-evidence.zip') as archive:
    assert all(hashlib.sha256(archive.read(row['path'])).hexdigest()==row['sha256'] for row in inventory)
for name in ('docs-input-audit.md','comparator-code-recheck.md'):
    shutil.copyfile(scratch/name,checks/name)
shutil.copyfile(scratch/'replays/summary.json',checks/'replay-summary.json')
metrics=json.loads((scratch/'coverage-unit.json').read_bytes())['totals']
assert metrics['missing_lines']==metrics['missing_branches']==0
source_paths=['.github/scripts/ci_consumer_shadow.py','tests/test_ci_consumer_shadow.py',
              'docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_SHADOW.md']
for path in source_paths:
    assert subprocess.check_output(['git','-C',str(repo),'show',implementation+':'+path]).replace(b'\r\n',b'\n') == (repo/path).read_bytes().replace(b'\r\n',b'\n')
summary={'implementation':implementation,'develop_base':base,'stacked_dependency':stack,'execution_authority':False,
 'validation':{'python311_focused':{'passed':45,'seconds':35.476},'python313_focused':{'passed':18,'seconds':9.525},
               'new_module_coverage':metrics,'exclusions_added':0,'real_probe_cases':4,'tests_each':25,
               'relevant_failures_retained':True,'historical_pr90_reexecuted':False},
 'sources':{path:hashlib.sha256((repo/path).read_bytes()).hexdigest() for path in source_paths},
 'raw_archive_sha256':hashlib.sha256((checks/'raw-evidence.zip').read_bytes()).hexdigest(),'raw_members':inventory,
 'limitations':['Subset probes are not full accepted plan execution','Only two kernel methods proposed as unrelated control',
                'Candidate coverage and smoke not run; C and smoke requirements preserved',
                'No activated reduction or hosted speedup; no business-owner branch modifications']}
dump(checks/'validation.json',summary)
sys.path.insert(0,str(repo/'src'))
from research_workbench.observability.trace import AgentTraceRecorder,validate_attempt_trace
recorder=AgentTraceRecorder(attempt,task_id='TEST-PERF-002',task_revision=40,attempt_id=attempt.name,
 task_snapshot={'task_id':'TEST-PERF-002','revision':40,'request':'Continue Issue87 CI-only 2B after 2A; business PR belongs to development3',
                'scope':'offline consumer proposal/outcome comparator with subset real failure probes','delegation':True,'required_skills':[]},
 accountable_owner='Chengyue-Lu',actor_id='main-agent',runtime_identity='Codex desktop',provider='OpenAI',
 read_allowlist=['AGENTS.md','.github/**','tests/**','docs/workstreams/chengyue-lu/TEST-PERF-002/**',
                 'work/TEST-PERF-002/**','scoped source input consumers and historical PR90 receipts'],
 write_scope=['.github/scripts/ci_consumer_shadow.py','tests/test_ci_consumer_shadow.py',
              'docs/workstreams/chengyue-lu/TEST-PERF-002/**','work/TEST-PERF-002/A-20260920-002/**'],
 tool_allowlist=['git','gh','python','shell','collaboration'],baseline=base)
recorder.record_capture_gap('messages','Retrospective capture: full original command and inter-agent transmission stream unavailable. Persisted raw reports, producers, receipts and explicit summaries; no complete conversation claim.')
recorder.record_capture_gap('external-actions','Final push, Draft publication and issue comment occur after this archive is sealed; GitHub receipts remain external exact-head records.')
recorder.record_tool_call(operation_id='consumer-shadow-evidence',tool_name='shell',status='succeeded',
 arguments={'operation':'validate bounded shadow comparator and retain immutable evidence'},result=summary,result_entered_context=True)
recorder.seal('safe-paused')
checked=validate_attempt_trace(repo,attempt)
dump(checks/'trace-validation.json',{'blocked':checked.blocked,'risks':[dataclasses.asdict(row) for row in checked.risks]})
assert not checked.blocked,checked.risks
(attempt/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n')
(attempt/'RESULTS.md').write_text(f'''# Consumer shadow 2B: first diagnostic slice

TEST-PERF-002 / Issue #87; owner Chengyue-Lu; R2; 2026-09-20.
Develop base: `{base}`. Stacked dependency: PR #91 `{stack}`.
Implementation: `{implementation}`.

The offline comparator derives explicit proposed behavioral exclusions and joins
canonical IDs with actual receipt outcomes. Coverage C, its thresholds/subjects/
coordinates/positive-negative evidence, and smoke obligations stay intact. Reports
separate B exclusions, effective execution exclusions, and changes of fixture phase.
Unknown C yields unknown effective membership and no cost claim.

## Validation

- Python 3.11: 45 focused tests PASS, 35.476 s; Python 3.13: 18 PASS, 9.525 s.
- New comparator: 197/197 statements, 78/78 branches; no new exclusions.
- Three real Markdown failures retained: bad link (one parent), missing public
  navigation (one public-surface parent while documentation passes), internal public
  navigation (six parents). One unrelated control: 25/25 PASS.
- Each native observation executes 25 unchanged documentation/public-surface/kernel
  cases with pre-execution inventory. This is an observed subset, not full CI.
- Two in-memory Kernel cases are the only proposed unrelated exclusions. Other
  unknown consumers stay selected. Historical PR #90 B=1425/C=1399 proposes no skip.
- Independent review's three initial P2 findings and one follow-up P2 were repaired
  and rechecked: receipt/checkpoint contradictions, wildcard canonical IDs, empty
  Git deltas, and unknown-coverage effective omission overclaim.
- Trace has no BLOCK. Capture-gap warnings remain explicit for incomplete original
  tool/message streaming and final publication after archival seal.

[Structured validation and raw hashes](checks/validation.json),
[probe and historical summary](checks/replay-summary.json),
[consumer audit](checks/docs-input-audit.md),
[independent recheck](checks/comparator-code-recheck.md),
[raw evidence ZIP](checks/raw-evidence.zip).
The ZIP retains native receipts/inventories, raw first-pass probe evidence, frozen
experiment producers, incremental Git bundle and local logs. Its scripts are audit
artifacts; they are not additional maintained executable coverage subjects.

## Limits and next step

This first 2B slice does not complete independent candidate coverage/smoke execution,
the full consumer/environment closure, a trusted exclusion witness, or paired hosted
speed measurements. No reduction is activated, no merge performed, and no 37-minute
coverage improvement is claimed. Continue with complete accepted-plan observations
and candidate coverage/lifecycle comparisons before requesting 2C. Business/evidence
fixes in PR #90 remain with its owner.
''',encoding='utf-8')
files=[{'path':path.relative_to(attempt).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
       for path in sorted(attempt.rglob('*')) if path.is_file()]
dump(checks/'evidence-manifest.json',{'files':files})
print(json.dumps({'implementation':implementation,'members':len(inventory),'trace_blocked':checked.blocked,'archive_files':len(files)}))
