# Independent code review: ci_consumer_shadow

Profile: CI correctness/trust reviewer; skills=[]; owner Chengyue-Lu. Reviewed new .github/scripts/ci_consumer_shadow.py in ci-consumer-shadow. No source changes, Git changes or network mutations. Two isolated Python function probes were run with bytecode writes disabled using the existing Python 3.11 environment; they did not run business tests. Main agent owns the evolving regression suite.

## Assessment

The B-only diagnostic architecture correctly preserves C and all coverage/smoke requirements, computes U as B followed by C-B, distinguishes effective skips from behavioral skips and identifies coverage-phase moves. Candidate execution, coverage equivalence, receipt/inventory authentication and activation remain explicitly unproved. Unknown/executable/mode/add/delete changes conservatively disable the Markdown pilot. No usable execution plan or activation authorization is produced.

Three P2 issues should close before the report is treated as a reliable diagnostic comparator.

## P2: Cross-check receipt envelope and parent/checkpoint outcomes

Location: .github/scripts/ci_consumer_shadow.py:187-223.

The comparator validates outcome vocabulary and separately checks successful/events, but never checks that the envelope agrees with its case/checkpoint contents. Reproduced with a one-case independently supplied inventory and retained candidate case:

- receipt row outcome=failed;
- successful=true, events failures=errors=skips=0;
- complete order/count and matching plan/target/Python.

compare_receipt returns status=observed-no-missed-failure and blockers=[] while listing the case in failing_ids. The absence of a missed case is a valid local fact, but contradictory evidence must not pass the complete-observation branch.

A second probe is more directly relevant to skipped evidence: row outcome=passed with a skipped checkpoint, events.skips=1 and successful=true; the candidate excludes that case. The comparator returns observed-no-missed-failure, inconclusive_ids=[] and blockers=[]. The accepted runner would emit passed_with_skips for that parent (run_unittest_suite.py:48-51,64-70); this supplied receipt contradicts the producer semantics and must not count as a complete passed observation.

Recommended repair: preserve local failing/missed information while adding an inconsistency blocker when parent/checkpoints/envelope disagree. Derive inconclusive status from skipped checkpoints as well as parent outcome. Check expected adverse events without assuming naive event-count equality, since subtests/fixture errors can affect aggregate counts differently. Add both probes as adversarial regressions. No production authority is currently bypassed; this is diagnostic correctness.

## P2: Canonical test IDs must not contain path wildcard characters

Location: .github/scripts/ci_consumer_shadow.py:31-37.

portable() intentionally permits * and ? for input_patterns, but identities() reuses it without an exact-path restriction. A direct probe confirms identities(['tests/test_*.py::C.test_x'], 'test') is accepted. Such an ID cannot name an exact ordinary Git test source, yet can populate the supplied inventory/runtime map and be joined with a matching synthetic receipt. Pins reject wildcard paths only for proposal entries, so inventory acceptance remains inconsistent.

Require exact canonical source paths without * or ? (and preserve existing traversal/absolute/Windows checks). Apply this to B/C inventory and proposal IDs; wildcard syntax remains confined to input_patterns. Include wildcard inventory IDs and matching receipt aliases in the regression so this is not tested only through proposal pin validation.

## P2: An empty diff is outside the modified-existing-Markdown pilot

Location: .github/scripts/ci_consumer_shadow.py:112-125.

The pilot only adds path fallback reasons inside the for-path loop. For different base/head commits with identical trees, paths is empty and the integration base==head check is false. Every otherwise valid consumer with no unknowns then proposes a skip because no declared input changed. The accepted planner explicitly treats an empty diff as requiring full evidence, and this slice states that eligibility is modified existing regular Markdown; an empty change has not met that trigger.

Require at least one eligible changed path, otherwise retain B with an explicit empty-diff/outside-pilot reason. Cover a same-tree non-integration commit pair rather than only base==head integration. The existing coverage retention still applies, but does not make this unimplemented pilot case eligible.

## Scope notes, not current blockers

- inventory.scope=plan-collection is a supplied assertion, not established by the current validator. The always-on unauthenticated-provenance blocker correctly prevents activation. Continue labeling results as observations relative to supplied inventory; a one-case artifact cannot establish full-plan completeness solely by choosing that scope string. Before any promotion, bind the independent collection producer/invocation/environment and verify its full inventory separately.
- Unknown/fixture extra rows remain preserved and force review, which is conservative. Coverage-execution receipts are required for phase proof; projected receipts therefore remain inconclusive instead of silently being accepted as ordered execution.
- Cost is correctly calculated only for effective execution skips and described as observed case durations rather than job or lifecycle savings. C-overlapping behavioral skips remain selected in candidate U and are recorded as moved phases.
- Optional duration/checkpoint validation currently occurs after the unknown-row branch. Invalid nonfinite durations on fixture/unexpected rows can therefore survive into a diagnostic artifact even though that artifact remains blocked. Uniform primitive-shape validation before classification would improve strict JSON/report hygiene; do not discard legitimate fixture failures to do it.

## Verification performed

Probe outputs:

    failed-row-success-envelope:
      status: observed-no-missed-failure
      failing: [tests/test_demo.py::C.test_x]
      blockers: []

    passed-parent-skipped-checkpoint:
      status: observed-no-missed-failure
      inconclusive: []
      blockers: []

    glob-in-canonical-path:
      accepted: true

The empty-diff finding is a static control-flow observation, not a claim that a real Git probe was executed. No approval to activate reductions is given by this review.
