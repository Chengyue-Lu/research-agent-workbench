# 2B staged consumer shadow comparator: independent design review

Profile: CI trust reviewer; skills=[]; owner Chengyue-Lu. Read-only review of AGENTS.md, ci_domain_audit.py, ci_contract_shadow.py, tests/run_unittest_suite.py and implementation plan section 5. No implementation, GitHub, or test execution changes. Root owns implementation and validation.

## Recommended first boundary

Implement a diagnostic proposal that can narrow behavioral B only for explicit consumer/test IDs under an existing-Markdown input rule, unchanged declared source/helper/policy pins and exact Git facts. Coverage C, all coverage subjects/coordinates/evidence, and package/repository smoke obligations stay equal to the accepted plan. Unknown cases stay selected. A matched declaration is a proposed invocation boundary, not accepted exclusion proof. Report execution_authority=false, activation=false and missing closure/evidence as blockers.

This is a useful first 2B slice. It does not complete independent candidate coverage replay, smoke execution, environment closure or 2C activation.

## Minimum input contract

1. Accepted plan: exact repository/base/head/merge-base/target and verified plan ID, checked by the existing observed-plan verifier; record policy/witness/runner/producer identities. Historical head replay and hosted merge-target evidence cannot share a binding.
2. Independent case inventory: version, exact plan/binding, ordered B and ordered C, canonical-ID to runtime-ID map, discovery producer hash/invocation, Python version/OS/dependency/config identity and source provenance. Do not derive expected IDs from the receipt being checked or from the candidate proposal. A supplied matching digest proves identity, not authenticity; preserve independently-collected/provided/unverified status.
3. Consumer proposal: version, explicit diagnostic authority flag, named consumer/invocation, exact input membership or narrowly defined input rule, exact canonical test IDs, declared source/helper/resource/policy pins, and unresolved closure dimensions. No negative ID wildcards, no domain-derived exclusion list, no candidate refresh repairing base drift. Every excluded ID needs a named declaration and assumption.
4. Receipt set: each receipt's original artifact hash, schema/suite/plan/target/Python binding, source run/artifact provenance if available, and original content. Preserve source coverage-execution receipt separately from projections. Missing provenance remains missing; do not generate a new successful receipt.
5. Optional cost and coverage artifacts: bind environment and producer/target; distinguish available observed artifacts from a claim that the candidate was executed. Missing data is not zero and absent jobs are not successful skips.

The consumer pins must be checked against exact base/head Git objects, not just current working files. Changed file modes and object types are independent of extension. For the initial Markdown pilot require existing regular files, status M, unchanged regular mode, and recognized non-executable facts; additions, deletions, rename pairs, mode/type changes, shebang-bearing files and unclosed public/runtime membership stay unknown/retained. Unchanged implementation pins do not close alternate invocation inputs or external environment dependencies.

## Set and lifecycle algebra

Let accepted order U = B followed by C minus B. Let proposed behavioral order B' preserve the relative accepted B order. Retain C unchanged, so proposed order U' = B' followed by C minus B'.

Report separately:

- proposed behavioral skips: B minus B';
- effective execution skips: U minus U';
- cases moved from behavioral into the later coverage phase: (B intersect C) minus B';
- accepted/candidate B, C, intersection and coverage-only order, with exact IDs;
- cases retained because no declaration or complete bound facts exist.

A behavioral skip can produce no execution saving because C still requires it. A moved overlapping case now runs after a different fixture lifecycle; accepted success/coverage does not prove the candidate schedule is equivalent. Do not call a filtered accepted receipt a candidate execution.

## Receipt join and validation

The 2A receipt_observation function is deliberately too weak to be the 2B proof validator: it summarizes supplied runtime IDs but does not independently establish inventory, canonical aliases, phase order or fixture events.

Use tests/run_unittest_suite.py as the format authority:

- Lines 122-141 distinguish private absolute-path canonical identity from portable evidence identity. Join receipts on portable canonical_id and also validate the corresponding runtime id against independent inventory. Detect duplicate canonical IDs, duplicate runtime IDs, aliases and unexpected rows.
- Receipt tests are sorted by duration, not execution order. execution_order contains canonical IDs. Read phase order from execution plus execution_order; never infer it from the tests list.
- Lines 272-296 preserve the original behavioral suite before C-B with a fresh fixture lifecycle. Source coverage-execution receipt must match ordered-behavioral-v1, B order, C order and U execution_order before claiming that accepted lifecycle was observed.
- Fixture setup/teardown _ErrorHolder events can produce rows outside the ordinary case inventory and are not ordinary selected tests. Preserve them as explicit failure/inconclusive signals. A missing planned case after fixture failure is missing, not passed or safely excluded. Do not require a failed receipt's test_count to equal all recorded rows without accounting for fixture events.
- Retain successful, events, problems, checkpoints and source failure rows. A parent passed record with failed checkpoint, nonzero failure/error events or inconsistent successful flag is inconsistent/failing evidence. A cancellation with no receipt is not zero failures.
- skipped, passed_with_skips, expected_failure, missing and unknown do not establish an unaffected consumer. unexpected_success is adverse evidence. A genuinely failing expected case in the effective skipped set is a diagnostic counterexample. Fixture/global failures that cannot be localized leave the relevant exclusion claim inconclusive.
- The existing _receipt_records/_project_execution helpers accept successful evidence for reuse and reject failures. A diagnostic comparator must still preserve and compare valid failed runs; it cannot simply use a successful-reuse validator and discard rejected failures.
- Projected full/impact/coverage-quality receipts lack the source phase/events structure. Their execution.source_receipt_sha256 must refer to the provided original coverage-execution receipt before a lifecycle claim is used. At line 336 the digest hashes sorted compact JSON without a trailing newline, unlike planner.digest which includes a newline. Keep digest algorithms explicit rather than comparing incompatible hashes.

## Coverage, smoke and cost interpretation

Accepted union coverage cannot prove retained candidate tests produce those same lines/arcs. Even exact per-test contexts describe the observed accepted schedule and do not prove moved phases or cold initialization. Keep candidate coverage status unproved until independently executed with preserved lifecycle and the required changed/critical/repository checks. Retaining C is necessary but is not itself proof of candidate coverage success.

Keep smoke obligations independent and unchanged. A required smoke with no actual bound result is not-run/missing; a legitimate accepted plan skip is distinct from evidence of successful execution. Report unavailable coverage/smoke artifacts as explicit blockers without pretending the whole comparator is invalid when a behavioral counterexample can still be identified.

Historical case-duration sums may estimate removed case work only over effective execution skips U-U'. Do not estimate new fixture setup cost or job critical path from case sums. Report missing duration IDs, observed environment, phase-move count, estimate assumptions and absence of candidate execution. No percentage speedup or complete-2B claim follows from a smaller B alone.

## Minimum regression matrix for this slice

- Related changed Markdown selects the real failing consumer; an unrelated declared input predicts only its documented behavioral exclusion; undeclared consumers remain retained.
- Every changed executable/helper/policy, add/delete/rename/mode/Gitlink or ambiguous input disables the relevant pilot condition without touching accepted execution.
- A case removed from B but present in C remains in U' and is labeled phase-moved, producing zero effective skip for that case.
- Missing/duplicate/aliased canonical IDs, stale target/plan, mixed Python receipts, partial execution order and changed independent inventory remain invalid/inconclusive as appropriate.
- Fixture failure plus missing cases, parent/checkpoint inconsistency, expected_failure and skipped cases cannot create a successful exclusion proof.
- A raw source receipt and its projection validate their exact digest relationship; a projection alone cannot attest B-to-C phase order.
- Missing coverage/smoke/receipt/environment evidence remains explicitly unproved while valid diagnostic facts are retained.
- Candidate proposal or report cannot overwrite plan/inventory/receipt inputs and cannot be consumed as an accepted worker plan.

## Disposition

Proceed with the staged B-only diagnostic comparator. Keep 2B coverage/lifecycle replay and independent exclusion authority as explicit unfinished work. No production reduction, Gate result, reuse receipt or measured speedup should be emitted by this slice.
