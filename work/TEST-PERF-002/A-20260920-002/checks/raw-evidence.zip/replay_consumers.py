"""Local subset observations; never invoke or replace accepted CI Gates."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow')
OUT = Path(__file__).parent
REPO = OUT / 'docs-probes/snapshot'
sys.path.insert(0, str(ROOT / '.github/scripts'))
import ci_consumer_shadow as shadow
import plan_ci as planner

NATIVE = '''
import json, platform, sys, time, unittest
from pathlib import Path
repo, plan_path, output = map(Path, sys.argv[1:])
sys.path[:0] = [str(repo), str(repo/'src'), str(repo/'tests')]
from tests import run_unittest_suite as runner
plan = json.loads(plan_path.read_bytes())
loader = unittest.TestLoader()
suite = loader.loadTestsFromNames(['tests.test_documentation', 'tests.test_public_surface', 'tests.test_kernel'])
assert not loader.errors, loader.errors
ids = runner._inventory(suite)
inventory = {'version':1, 'scope':'observed-subset', 'plan_id':plan['plan_id'], 'target':plan['binding']['target'],
 'source':'fresh isolated pre-execution unittest collection; 3 modules only', 'python_version':platform.python_version(),
 'behavioral_order':list(ids), 'coverage_order':[], 'runtime_ids':ids}
(output/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\\n')
start = time.perf_counter()
result = unittest.TextTestRunner(verbosity=2, resultclass=runner.TimedTextResult).run(suite)
runner._write_summary(output/'receipt.json', 'observed-subset', time.perf_counter()-start, result, 3, plan)
sys.exit(not result.wasSuccessful())
'''


def proposal(repo, base, ids):
    pins = ['tests/test_kernel.py', 'tests/__init__.py', 'src/research_workbench/__init__.py',
            'src/research_workbench/kernel/__init__.py', 'src/research_workbench/kernel/objects.py']
    return {'version':1, 'execution_authority':False, 'baseline':base, 'consumers':[
        {'id':'kernel-in-memory-objects', 'owner':'Chengyue-Lu',
         'invocation':'two KernelObjectTests using in-memory dataclasses; source reviewed at frozen baseline',
         'tests':[key for key in ids if key.startswith('tests/test_kernel.py::')],
         'input_patterns': pins,
         'pins':{path:hashlib.sha256(planner.read_at(repo,base,path)).hexdigest() for path in pins},
         'assumptions':['These two invocations use only constructors and properties, not repository documents',
                        'Python/stdlib/import lifecycle held fixed for local probe; independent witness pending'],
         'unknowns':[]}]}


def main():
    out = OUT/'replays'
    out.mkdir(exist_ok=True)
    cases = json.loads((OUT/'docs-probes/summary.json').read_bytes())['cases']
    summary=[]
    for case in cases[1:]:
        dest=out/case['name'];dest.mkdir(exist_ok=True)
        subprocess.run(['git','-C',str(REPO),'checkout','--detach',case['head']],check=True,capture_output=True)
        plan=planner.make_plan(REPO,base=case['base'],head=case['head'],target=case['head'],repository='Chengyue-Lu/research-agent-workbench',body='- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no')
        (dest/'plan.json').write_bytes(planner.canonical(plan))
        env={**os.environ,'PYTHONPATH':str(REPO/'src')+';'+str(REPO),'PYTHONUTF8':'1'}
        run=subprocess.run([sys.executable,'-c',NATIVE,str(REPO),str(dest/'plan.json'),str(dest)],env=env,cwd=REPO,capture_output=True)
        (dest/'stdout.log').write_bytes(run.stdout);(dest/'stderr.log').write_bytes(run.stderr)
        inventory=json.loads((dest/'inventory.json').read_bytes())
        receipt=json.loads((dest/'receipt.json').read_bytes())
        candidate=proposal(REPO,case['base'],inventory['runtime_ids'])
        (dest/'proposal.json').write_bytes(planner.canonical(candidate))
        report=shadow.build_report(REPO,plan,candidate,inventory,receipt)
        (dest/'report.json').write_bytes(planner.canonical(report))
        assert not report['comparison']['missed_failure_ids']
        assert len(report['behavioral_skips'])==2
        summary.append({'case':case['name'],'target':case['head'],'plan_id':plan['plan_id'],
                        'plan_behavioral':plan['behavioral_scope'],'plan_coverage':plan['coverage_scope'],
                        'observed_tests':len(inventory['behavioral_order']),'failed':report['comparison']['failing_ids'],
                        'behavioral_skips':len(report['behavioral_skips']),'effective_skips':report['effective_execution_skips'],
                        'missed_failures':report['comparison']['missed_failure_ids'],'exit_code':run.returncode,
                        'result':report['comparison']['status']})
    # Historical receipt is observational; its inventory shares a producer and is not an independent collection.
    previous=Path(r'D:\lcy\develop\_assessments\rwb-ci-domain-20260920\pr90\artifacts')
    plan=json.loads((previous/'ci-plan/ci-plan.json').read_bytes())
    receipt=json.loads((previous/'coverage-quality-evidence/execution-test-results.json').read_bytes())
    inventory={'version':1,'scope':'plan-collection','plan_id':plan['plan_id'],'target':plan['binding']['target'],
               'source':'historical execution receipt inventories; same producer, NOT independent discovery',
               'python_version':receipt['python_version'],'behavioral_order':receipt['execution']['behavioral_order'],
               'coverage_order':receipt['execution']['coverage_order'],
               'runtime_ids':{r['canonical_id']:r['id'] for r in receipt['tests']}}
    candidate=proposal(ROOT,plan['binding']['base'],inventory['runtime_ids'])
    report=shadow.build_report(ROOT,plan,candidate,inventory,receipt)
    dest=out/'pr90';dest.mkdir(exist_ok=True)
    for name,value in [('plan',plan),('receipt',receipt),('inventory',inventory),('proposal',candidate),('report',report)]:
        (dest/(name+'.json')).write_bytes(planner.canonical(value))
    assert not report['behavioral_skips'] and not report['effective_execution_skips']
    summary.append({'case':'pr90-mixed-source-schema-archive','target':plan['binding']['target'],
                    'B':len(inventory['behavioral_order']),'C':len(inventory['coverage_order']),
                    'behavioral_skips':0,'effective_skips':0,'result':report['comparison']['status'],
                    'historical_receipt_only':True,'coverage_gate_pass':False})
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
