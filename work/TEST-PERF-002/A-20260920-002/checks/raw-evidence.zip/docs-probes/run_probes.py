import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

SOURCE = Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow')
OUT = Path(__file__).resolve().parent
REPO = OUT / 'snapshot'
BASE = '09c6cb1c82680233c369014e0831874b6702d3b7'
PYTHON = sys.executable
OUT.mkdir(parents=True, exist_ok=True)

def command(args, cwd=REPO):
    done = subprocess.run(args, cwd=cwd, text=True, encoding='utf-8', errors='replace', capture_output=True)
    if done.returncode:
        raise RuntimeError((args, done.returncode, done.stdout, done.stderr))
    return done.stdout.strip()

assert REPO.resolve().is_relative_to(OUT.resolve())
if not REPO.exists():
    command(['git', '-c', 'core.autocrlf=false', 'clone', '-q', '--shared', '--no-checkout', str(SOURCE), str(REPO)], cwd=OUT)
else:
    assert Path(command(['git','remote','get-url','origin'])).resolve() == SOURCE.resolve()
    assert command(['git','status','--short']) == ''
command(['git', 'config', 'core.autocrlf', 'false'])
command(['git', 'config', 'user.name', 'Isolated documentation probe'])
command(['git', 'config', 'user.email', 'probe@example.invalid'])
command(['git', 'checkout', '-q', '--detach', BASE])

RUNNER = '''import hashlib, importlib, importlib.metadata, json, os, platform, sys, time, unittest
from pathlib import Path
root = Path.cwd()
sys.path[:0] = [str(root), str(root / 'src')]
names = ['tests.test_documentation', 'tests.test_public_surface', 'tests.test_kernel']
modules = [importlib.import_module(name) for name in names]
assert all(Path(m.__file__).resolve().is_relative_to(root) for m in modules)
import research_workbench.kernel
assert Path(research_workbench.kernel.__file__).resolve().is_relative_to(root)
class Result(unittest.TextTestResult):
    def addSubTest(self, test, subtest, err):
        if err is not None:
            failed_parents.add(test.id())
        super().addSubTest(test, subtest, err)
    def startTest(self, test):
        self.started = time.perf_counter()
        super().startTest(test)
    def stopTest(self, test):
        records.append({'id': test.id(), 'duration_seconds': time.perf_counter() - self.started})
        super().stopTest(test)
records = []
failed_parents = set()
suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(m) for m in modules)
started = time.perf_counter()
result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
failures = [{'id': t.id(), 'traceback': e} for t,e in result.failures]
errors = [{'id': t.id(), 'traceback': e} for t,e in result.errors]
failed = {row['id'] for row in failures + errors} | failed_parents
skipped = {t.id():reason for t,reason in result.skipped}
for row in records:
    row['status'] = 'failure' if row['id'] in failed else 'skip' if row['id'] in skipped else 'pass'
report = {'scope': 'observed documentation and public-surface modules plus kernel control; not accepted-full',
 'target': os.environ['PROBE_TARGET'], 'tests':records, 'count':result.testsRun, 'failures':failures,
 'errors':errors, 'skips':skipped, 'duration_seconds':time.perf_counter()-started,
 'python':sys.version, 'platform':platform.platform(),
 'dependencies':{p:importlib.metadata.version(p) for p in ['markdown-it-py','linkify-it-py','PyYAML']},
 'module_files':{m.__name__:str(Path(m.__file__).relative_to(root)) for m in modules}}
Path(os.environ['PROBE_RECEIPT']).write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\\n',encoding='utf-8')
sys.exit(not result.wasSuccessful())
'''

probes = [
    ('baseline', None, None),
    ('broken-internal-link', 'docs/README.md', lambda s:s + '\n[probe missing input](probe-input-missing.md)\n'),
    ('missing-public-navigation', 'README.md', lambda s:s.replace('SUPPORTED_FEATURES.md','PUBLIC_GUIDE.md')),
    ('public-internal-navigation', 'docs/GETTING_STARTED.md', lambda s:s + '\n[probe internal state](STATUS.md)\n'),
    ('unrelated-doc-control', 'docs/workstreams/chengyue-lu/TEST-PERF-002/DOMAIN_MODEL.md', lambda s:s + '\n本段为文档输入审计的独立中性对照。\n'),
]
rows = []
for name, path, mutate in probes:
    command(['git','checkout','-q','--detach',BASE])
    original = changed = None
    if path:
        target = REPO/path
        original = target.read_bytes()
        changed = mutate(original.decode('utf-8')).encode('utf-8')
        assert changed != original
        target.write_bytes(changed)
        command(['git','add','--',path])
        command(['git','commit','-q','-m','Isolated probe: '+name])
    head = command(['git','rev-parse','HEAD'])
    receipt = OUT / (name+'.json')
    environment = dict(os.environ, PROBE_TARGET=head, PROBE_RECEIPT=str(receipt), PYTHONUTF8='1')
    before = time.perf_counter()
    done = subprocess.run([PYTHON,'-c',RUNNER],cwd=REPO,env=environment,text=True,encoding='utf-8',errors='replace',capture_output=True)
    (OUT/(name+'.stdout.txt')).write_text(done.stdout,encoding='utf-8')
    (OUT/(name+'.stderr.txt')).write_text(done.stderr,encoding='utf-8')
    observed = json.loads(receipt.read_text(encoding='utf-8'))
    row = {'name':name,'base':BASE,'head':head,'path':path,'status':command(['git','diff','--name-status',BASE,head]),
      'before_sha256':hashlib.sha256(original).hexdigest() if original else None,
      'after_sha256':hashlib.sha256(changed).hexdigest() if changed else None,
      'exit_code':done.returncode,'wall_seconds':time.perf_counter()-before,'count':observed['count'],
      'failed_ids':[r['id'] for r in observed['failures']], 'error_ids':[r['id'] for r in observed['errors']],
      'kernel_statuses':[r for r in observed['tests'] if r['id'].startswith('tests.test_kernel.')]}
    rows.append(row)
    print(json.dumps(row,ensure_ascii=False),flush=True)
command(['git','checkout','-q','--detach',BASE])
input_names=['tests/test_documentation.py','tests/public_surface_helpers.py','tests/test_public_surface.py','tests/test_kernel.py','.github/release-surface.yml','tests/__init__.py']
summary={'source':str(SOURCE),'snapshot':str(REPO),'base':BASE,'cases':rows,
 'source_hashes':{p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in input_names},
 'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'snapshot_status':command(['git','status','--short']), 'execution_authority':False,
 'command':[PYTHON,'-c','RUNNER preserved in run_probes.py'], 'git_version':command(['git','--version']),
 'python':sys.version,'platform':platform.platform()}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
