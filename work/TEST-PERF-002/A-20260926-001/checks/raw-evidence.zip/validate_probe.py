from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, time
ROOT=Path(__file__).resolve().parent
WT=Path(r"D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe")
OUT=ROOT/'local-tests'
OUT.mkdir(exist_ok=False)
paths=['tests/test_ci_attribute_consumers.py','src/research_workbench/observability/trace.py','src/research_workbench/artifacts/integrity.py']
hashes={p:hashlib.sha256((WT/p).read_bytes()).hexdigest() for p in paths}
env={k:v for k,v in os.environ.items() if not k.startswith(('GITHUB_','COVERAGE_'))}
env.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join(str(WT/p) for p in ('','src','tests','.github/scripts')))
def run(version):
    py=Path('D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917')/('venv'+version)/'Scripts/python.exe'
    args=[str(py),'-X','utf8','-B','-m','unittest','test_ci_attribute_consumers','test_agent_trace.AgentTraceTests.test_hash_tamper_is_blocking','test_agent_trace.AgentTraceTests.test_transient_tool_result_ref_remains_hash_checked','-v']
    start=time.perf_counter()
    result=subprocess.run(args,cwd=WT,env=env,capture_output=True)
    (OUT/(version+'.stdout.log')).write_bytes(result.stdout)
    (OUT/(version+'.stderr.log')).write_bytes(result.stderr)
    record={'argv':args,'exit_code':result.returncode,'wall_seconds':time.perf_counter()-start,'source_hashes':hashes,'raw_sha256':{'stdout':hashlib.sha256(result.stdout).hexdigest(),'stderr':hashlib.sha256(result.stderr).hexdigest()},'parallel_validation':True,'performance_acceptance':False}
    (OUT/(version+'.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(run,['311','313']))
assert hashes=={p:hashlib.sha256((WT/p).read_bytes()).hexdigest() for p in paths},'source changed during tests'
(OUT/'summary.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps([{'python':r['argv'][0],'exit_code':r['exit_code'],'wall_seconds':r['wall_seconds']} for r in results],indent=2))
raise SystemExit(any(r['exit_code'] for r in results))
