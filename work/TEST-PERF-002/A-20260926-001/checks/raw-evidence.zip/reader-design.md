# Reader design: bind a real Attempt hash consumer to fresh checkout bytes

Profile independent consumer contract reviewer; Skills []; owner Chengyue-Lu. Read-only design, 2026-09-26. No tests, Git mutations, repository edits, GitHub writes or runtime experiments were performed by this review.

## Recommendation and accepted base

Use `research_workbench.observability.trace.validate_attempt_trace(root, attempt)` as the first concrete reader. It actually consumes the caller-selected Attempt index and its referenced files; this avoids assuming that a Skill ZIP audit capability reads an Attempt merely because both use the word archive.

The original assignment named `a542a06f781b4b4bce6696a2e6a888f4243f66c0`. Shared `origin/develop` was observed at `eb49093d6d89515c3e66bec29ee85e7a95bb9ce7`; root has created the independent `ci-attribute-consumer-probe` worktree from that accepted base. Git diff between those commits changes release-preflight files/policy only; the selected reader, helpers, schema loader and accepted shadow/input-facts interfaces below are unchanged. This is a test/experiment Draft; do not stack it implicitly on unaccepted PR99.

## Actual call and input relationship

Verified source chain at eb49093:

- `src/research_workbench/observability/trace.py:778`: `validate_attempt_trace(root, attempt)` resolves the explicit Attempt directory inside `root`, then reads that Attempt's `INDEX.yaml`.
- `trace.py:975-980`: obtains `INDEX.event_ledger`, passes it to `_checked_ref(..., detail='event-ledger-ref')`, then parses the referenced ledger as UTF-8 lines.
- `trace.py:1348-1397`: `_checked_ref` checks that the reference resolves inside the Attempt and exists, then compares `hash_file(path)` to the supplied digest. On mismatch it appends a blocking `TRACE-HASH-MISMATCH` risk whose message begins `[event-ledger-ref-hash]` for this call site. It still returns the path; a successfully parsed ledger does not cancel that BLOCK.
- `src/research_workbench/artifacts/integrity.py:30`: `hash_file` opens the actual file in binary mode and streams SHA256. The actual Trace chain calls this helper directly; it does **not** call the adjacent public `check_file_reference` helper.

Thus text newline conversion can preserve the parsed events while changing the raw bytes that the existing hash contract validates. `.gitattributes` is an indirect checkout input here; the Python validator does not itself read that attributes file.

Other real inputs must remain explicit: TASK/ACTORS references, message/index references and event references, `messages/` directory membership (`trace.py:1306`), `tool-events/` recursive membership (`trace.py:1592`), and runtime schema resources. `SchemaCatalog()` at trace.py:828 uses `RuntimeResources`; `validation/schemas.py:48-58` reads the entire selected schema-version catalog and builds its registry. This is not a proof that four named Trace schemas are the only schema inputs, nor that the reader's whole input closure is already closed.

## Minimal valid input producer

Reuse the real `AgentTraceRecorder` constructor from `tests/test_agent_trace.py:50` and its `seal('safe-paused')` path. Do not handwrite a partial INDEX fixture or mock the validator, hash helper or schema catalog.

```python
attempt = seed_root / 'work' / 'TRACE-TEST' / 'AT-0001'
recorder = AgentTraceRecorder(
    attempt,
    task_id='TRACE-TEST', task_revision=1, attempt_id='AT-0001',
    task_snapshot={'task_id': 'TRACE-TEST', 'revision': 1},
    accountable_owner='Chengyue-Lu', actor_id='runtime-AT-0001',
    runtime_identity='ci-attribute-consumer-probe', provider='openai-responses',
    read_allowlist=('inputs/**',), write_scope=('outputs/**',),
    tool_allowlist=('read_file',), created_at='2026-08-21T00:00:00Z',
)
recorder.seal('safe-paused')
```

Generate once, assert the original validator reports `not result.blocked`, and retain the actual INDEX/ledger bytes. The producer writes initial/final events and computes the ledger digest. Commit that one generated artifact set; never regenerate it separately for the comparison sides because event timestamps and other producer data would become confounds. The shown minimal fixture is a design expectation until the implementation executes the first valid assertion; if it does not pass, preserve the failure and repair fixture generation before interpreting a hash mutant.

The existing `AgentTraceTests.test_hash_tamper_is_blocking` and `test_transient_tool_result_ref_remains_hash_checked` establish the public risk oracle. The latter binds a real generated tool-result file and is an optional second consumer case, not needed to make the first event-ledger experiment larger.

## Smallest causal experiment

Create three distinct Git commits and materialize each with its own new checkout. Keep all data/index Git blobs identical across the three commits; only the scoped attributes blob changes.

| Case | Scoped rule for the Attempt ledger | Required actual assertion |
|---|---|---|
| valid | `events.jsonl text eol=lf` | `validate_attempt_trace(clone_root, attempt_relative).blocked is False` |
| bad hash through checkout | `events.jsonl text eol=crlf` | Same ledger Git blob and INDEX digest; different fresh ledger bytes/SHA; validator BLOCK with code `TRACE-HASH-MISMATCH` and detail `[event-ledger-ref-hash]` |
| repaired | restore `events.jsonl text eol=lf` | Fresh bytes/SHA equal the original valid bytes; validator returns not blocked again |

Do not repair by rewriting the expected hash in INDEX for the CRLF bytes. Restoring the actual checkout contract isolates the single cause and preserves the original reference producer. Directly appending garbage is an existing generic hash test, but it would not prove the attributes-to-checkout-to-consumer chain requested here.

Retain two cheap controls if practical: a whitespace-only attributes change that preserves materialized bytes and stays valid; and a second explicit Attempt outside the scoped attributes directory whose bytes and validation are unchanged. An out-of-scope fixture is a causal control for these invocations, not evidence that all other tests in the repository are unrelated.

For each case record the exact commit/tree, attributes and data modes/blob OIDs, binary materialized SHA256, INDEX expected digest, resolved argument paths, canonical test ID/driver source hash, reader/helper source identities, actual returned risks and process exit status. Bad-hash diagnosis must be specific: an arbitrary unrelated schema error or missing INDEX must not satisfy the intended negative assertion. Prefer asserting that no unrelated BLOCK explains the result and that the JSON event sequence/count is otherwise unchanged.

## Freshness and environment

Use new clones/checkouts, not repeated checkout-index writes over files left on disk. The previous boundary experiment already demonstrated that the latter may fail to replace existing bytes. Set and record Git version, `core.autocrlf`, `core.eol`, `core.attributesFile`, global/system config policy and `.git/info/attributes`; isolate global attributes/config and do not inherit a user filter. Preserve root/parent/nested attribute files and effective `git check-attr` observations for each selected input. Use real Git rather than reimplementing its pattern matching.

Keep the actual consumer source/runtime dependency environment the same across the compared fixture commits. Inherited `GIT_DIR`, `GIT_WORK_TREE`, alternate-object/index overrides and executable filter attributes must not silently change the experiment. Unsupported macro/filter/encoding/mode/symlink/junction cases remain unproved; do not run arbitrary repository commands described by a diagnostic record.

## Integration with existing CI diagnostics

Accepted eb49093 `ci_contract_shadow.build_report(repo, plan)` still emits schema3. It already calls `verify_observed_plan`, reuses Git-bound snapshots, emits typed `inputs`, retained dependency chains and producer-source hashes, and sets `execution_authority=false` / `activation.eligible=false`. There is no accepted `propagation_review` function at this base; the schema4 propagation implementation belongs to pending PR99.

`ci_input_facts.archive_attributes(raw)` recognizes a deliberately limited grammar and `describe` labels archive attributes/data while retaining unknown semantics. That parser must remain a syntax observation, not an independent Git materializer or permission to exclude tests.

For this Draft, keep implementation in root-assigned `tests/ci_attribute_probe.py` and `tests/test_ci_attribute_consumers.py`. The driver can call the real reader and reuse accepted `archive_attributes`/`input_facts` to show that LF and CRLF are both syntactically recognized while their effects differ. Store the probe result separately and bind any observed accepted shadow report by its plan/report digest; do not alter the production plan, group selection, fingerprint, coverage policy or existing schema3 output to turn this experiment into authority.

Suggested focused test responsibilities (method names may follow repository conventions): valid/bad/repaired fresh-checkout chain; scoped whitespace and outside-Attempt controls; full output identity including explicit caller parameters; malformed/unsupported attributes remain unknown. The three-case causal chain can retain separate named subtests/checkpoints, with assertions per case. Do not reuse a bad fixture's BLOCK as success without proving the valid and repaired controls.

A later diagnostic integration may add a bounded attribute-effects review row to the then-accepted shadow protocol. Its reader binding should name `validate_attempt_trace`, exact `(root, attempt)` arguments, selected INDEX ledger ref, source pins and materialized observations. Capabilities lacking such a binding stay unbound/unknown. Never execute arbitrary candidate-provided entrypoints while computing a shadow report. Keep the present implementation independent of that future API decision.

## Effects that this slice can and cannot establish

Successful execution would establish an actual hash consumer, the file it consumes for a particular invocation, a materialization-caused failure, and a recovery control. It can prevent an incorrect future rule that treats scoped attributes as always irrelevant.

It does not establish which current production tests consume any historical PR84/PR90 Attempt, prove exclusion of unrelated tests, remove schema-catalog or directory-membership dependencies, activate production reduction, or prove CI speedup. Those remain invocation mapping, independent witness and hosted B/C/lifecycle acceptance work. If no actual current test invocation reads a given historical Attempt, record that as unproved; do not manufacture necessity by adding a test and then claim it was previously required.

A 1/10/100 generated-Attempt extension is optional: separately measure one explicitly selected Attempt versus intentionally validating all N. Hold schema/runtime setup and cold/warm conditions explicit. One bounded invocation staying approximately flat shows only that invocation's cost, not that the existing whole-repository CI can skip the other N-1. Report case and process/setup times separately; do not call this a production reduction or coverage saving.

## Handoff

The precise reader chain, recorder parameters and public risk/detail oracle were sent to `/root/internal_cost`; root confirmed this Draft is a test/experiment slice on accepted eb49093, not a schema4 dependency. Subsequent independent code review should verify fixture validity before mutation, immutable data blobs, truly fresh checkout bytes, the specific blocking oracle, recovery without re-signing, retained unknown dependencies and honest effect claims.
