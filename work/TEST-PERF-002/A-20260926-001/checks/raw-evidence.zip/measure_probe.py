from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
ROOT=Path(__file__).resolve().parent
WT=Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
OUT=ROOT/'measurements';OUT.mkdir(exist_ok=False)
PY=Path('D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917/venv311/Scripts/python.exe')
env=dict(os.environ,PYTHONPATH=os.pathsep.join(str(WT/p) for p in ('','src','tests')),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
head=subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],text=True).strip()
source='tests/test_ci_attribute_consumers.py'
signature=hashlib.sha256((WT/source).read_bytes()).hexdigest()
assert signature==hashlib.sha256(subprocess.check_output(['git','-C',str(WT),'show',head+':'+source])).hexdigest()
rows=[]
for number in (1,2,3):
    output=OUT/('probe-'+str(number)+'.json')
    argv=[str(PY),'-X','utf8','-B','tests/test_ci_attribute_consumers.py','--root',str(OUT/('fresh-'+str(number))),'--probe-output',str(output)]
    start=time.perf_counter();r=subprocess.run(argv,cwd=WT,env=env,capture_output=True);wall=time.perf_counter()-start
    (OUT/('probe-'+str(number)+'.stdout.log')).write_bytes(r.stdout)
    (OUT/('probe-'+str(number)+'.stderr.log')).write_bytes(r.stderr)
    raw=json.loads(output.read_bytes()) if output.exists() else {}
    record={'repeat':number,'argv':argv,'exit_code':r.returncode,'wall_seconds':wall,'output_sha256':hashlib.sha256(output.read_bytes()).hexdigest() if output.exists() else None,'head':head,'source_sha256':signature,'scenarios':{label:{k:row.get(k) for k in ('consumer_seconds','setup_seconds','blocked','expectation_met','payload_sha256','payload_git_blob','index_sha256')} for label,row in raw.get('observations',{}).items()}}
    rows.append(record)
    (OUT/'runs.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode())
    assert r.returncode==0 and raw['status']=='PASS',record
    assert raw['source_head']==head and raw['source_pins'][source]==signature
    assert all(v.get('expectation_met') for v in raw['observations'].values())
    print('repeat',number,'PASS',round(wall,3),flush=True)
assert signature==hashlib.sha256((WT/source).read_bytes()).hexdigest()
scopes={label:{'consumer_median_seconds':statistics.median(r['scenarios'][label]['consumer_seconds'] for r in rows),'consumer_range_seconds':[min(r['scenarios'][label]['consumer_seconds'] for r in rows),max(r['scenarios'][label]['consumer_seconds'] for r in rows)],'setup_median_seconds':statistics.median(r['scenarios'][label]['setup_seconds'] for r in rows)} for label in rows[0]['scenarios'] if rows[0]['scenarios'][label]['consumer_seconds'] is not None}
summary={'status':'PASS-local-generated-fixture','head':head,'source_sha256':signature,'fresh_process_repeats':3,'wall_median_seconds':statistics.median(r['wall_seconds'] for r in rows),'scenario_timings':scopes,'hosted_speedup_proved':False,'safe_exclusions_proved':False,'production_test_changes':False}
(OUT/'summary.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps(summary,indent=2))
