from pathlib import Path
from dataclasses import asdict
import hashlib,json,os,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parent
WT=Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
BASE='eb49093d6d89515c3e66bec29ee85e7a95bb9ce7'
IMPL=subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],text=True).strip()
assert IMPL=='4793e81d4963f291ae956d33464f363b6af68468'
OUT=ROOT/'fixture-identities';OUT.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
def git(repo,*args):return subprocess.check_output(['git','--no-replace-objects','-C',str(repo),*args],env=env).decode().strip()
fixtures=[]
for repeat in (1,2,3):
    raw=json.loads((ROOT/'measurements'/('probe-'+str(repeat)+'.json')).read_bytes())
    assert raw['status']=='PASS' and raw['source_head']==IMPL
    seed=Path(raw['root'])/'seed'
    bundle=OUT/('fixture-'+str(repeat)+'.bundle')
    git(seed,'bundle','create',str(bundle),'--all')
    for label,row in raw['observations'].items():
        if not row.get('checkout_performed'):
            continue
        clone=Path(row['root'])
        fixtures.append({'repeat':repeat,'scenario':label,'commit':git(clone,'rev-parse','HEAD'),'tree':git(clone,'rev-parse','HEAD^{tree}'),'tracked_inputs':git(clone,'ls-tree','-r','HEAD'),'working_changes':git(clone,'status','--short'),'bundle':bundle.name,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest()})
(OUT/'snapshots.json').write_bytes((json.dumps(fixtures,indent=2)+'\n').encode())
ATTEMPT=WT/'work/TEST-PERF-002/A-20260926-001';ATTEMPT.mkdir(parents=True,exist_ok=False)
checks=ATTEMPT/'checks';checks.mkdir()
files=[ROOT/n for n in ('REQUEST.md','reader-design.md','CODE_REVIEW.md','validate_probe.py','validate_probe_status_guard.py','measure_probe.py','freeze_probe.py')]
for folder in ('local-tests','local-tests-status-guard','fixture-identities'):
    files += list((ROOT/folder).glob('*'))
files += [f for f in (ROOT/'measurements').glob('*') if f.is_file()]
manifest=[]
with zipfile.ZipFile(checks/'raw-evidence.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(files):
        raw=file.read_bytes();name=file.relative_to(ROOT).as_posix()
        archive.writestr(name,raw)
        manifest.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
(checks/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
summary=json.loads((ROOT/'measurements/summary.json').read_bytes())
summary.update(base=BASE,implementation=IMPL,related_tests_each_python=10,new_tests=8,prior_negative_controls=2,review='independent static PASS; source 0a0b7af4a01053e7623ac2b6d221f1618b247c5ccf90883c094207214af38b45',quality='production policies, thresholds, exclusions and tests unchanged',source_pins={p:hashlib.sha256((WT/p).read_bytes()).hexdigest() for p in ['tests/test_ci_attribute_consumers.py','docs/workstreams/chengyue-lu/TEST-PERF-002/ATTRIBUTE_CONSUMER_PROBE.md','docs/workstreams/chengyue-lu/TEST-PERF-002/RISK_LEDGER.md']})
for path,digest in summary['source_pins'].items():assert hashlib.sha256(subprocess.check_output(['git','-C',str(WT),'show',IMPL+':'+path])).hexdigest()==digest
for result in json.loads((ROOT/'local-tests-status-guard/summary.json').read_bytes()):
    assert result['exit_code']==0 and result['source_hashes']['tests/test_ci_attribute_consumers.py']==summary['source_sha256']
(checks/'summary.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
(ATTEMPT/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
(ATTEMPT/'RESULTS.md').write_bytes(f"""# Checkout-sensitive Attempt consumer experiment

Owner Chengyue-Lu; TEST-PERF-002; R2; required Skills [].
Accepted base `{BASE}`; implementation `{IMPL}`.

The existing Trace validator executes on a caller-selected generated Attempt.
Real fresh Git checkouts reproduce valid LF, whitespace-only, CRLF hash failure,
repaired LF, nested/outside controls and missing/renamed references. Unknown
attribute semantics stop before checkout. CRLF produces only the expected ledger
hash BLOCK; repaired data and INDEX preserve the original Git blob and digest.
No original test, production assertion or policy was modified.

Both Python 3.11 and 3.13 passed 10 related tests: 8 new named regressions and
2 existing hash/ref negatives. Initial 10/10 results are retained separately;
independent review then found that final probe status was not asserted by unittest.
The added overall-status assertion and the final 10/10 runs are separately bound.
Review also corrected repair freshness, canonical IDs, Git isolation and CLI
causal checks before the first actual execution. No full CI was run locally.

Three sequential fresh Python 3.11 CLI processes all passed, with total wall times
13.831 / 12.952 / 12.896 seconds. Each includes fixture creation, all scenario
checkouts and observations. With 1 / 10 / 100 additional unrelated Attempt copies,
the same selected reader's median call times were 0.370 / 0.371 / 0.350 seconds;
setup medians were 0.437 / 0.502 / 0.849 seconds. These are warm calls inside each
fresh process, not isolated cold starts. They show results and measured costs
for this invocation only, not absence of reads, safe exclusions or CI speedup.

[Summary](checks/summary.json), [raw archive](checks/raw-evidence.zip) and
[manifest](checks/manifest.json) retain commands, source identities, actual risks,
original failure findings, exact small Git snapshot trees and replay bundles.
Source hashes match the implementation Git blobs. This does not make local
results hosted target receipts. Schema-catalog and directory-membership closure,
historical production call mappings, independent witness and B/C acceptance
remain required before production reduction. Final-head validation and hosted
checks retain their subsequent identities.

Trace capture is partial: this record begins at evidence freeze. Earlier visible
tool/inter-agent messages were not a complete continuously captured event stream;
the written design/review findings are preserved without claiming otherwise.
Publication and subsequent checks occur after this seal and remain separate.
""".encode())
sys.path.insert(0,str(WT/'src'))
from research_workbench.observability.trace import AgentTraceRecorder,validate_attempt_trace
recorder=AgentTraceRecorder(ATTEMPT,task_id='TEST-PERF-002',task_revision=45,attempt_id=ATTEMPT.name,
 task_snapshot={'task_id':'TEST-PERF-002','revision':45,'request':'Continue and publish next Draft for early effect confirmation','scope':'Actual Attempt consumer and fresh checkout causal experiment; no execution authority','profile':'CI experiment engineer and independent consumer reviewer','required_skills':[],'delegation':True,'budget':'one bounded test slice, local dual Python and three small fresh observations','stop_condition':'Draft publication with actual local evidence; hosted/review separately'},
 accountable_owner='Chengyue-Lu',actor_id='main-agent',runtime_identity='Codex desktop',provider='OpenAI',
 read_allowlist=['AGENTS.md','docs/DEVELOPMENT.md','PROJECT_MEMORY.md','.github/scripts/**','tests/**','src/research_workbench/observability/trace.py','src/research_workbench/artifacts/integrity.py','src/research_workbench/validation/schemas.py','docs/workstreams/chengyue-lu/TEST-PERF-002/**'],
 write_scope=['tests/test_ci_attribute_consumers.py','docs/workstreams/chengyue-lu/TEST-PERF-002/ATTRIBUTE_CONSUMER_PROBE.md','docs/workstreams/chengyue-lu/TEST-PERF-002/RISK_LEDGER.md','work/TEST-PERF-002/A-20260926-001/**'],tool_allowlist=['collaboration','shell','git','gh','python'],baseline=BASE)
recorder.record_capture_gap('messages','Record begins at evidence freeze; design and review are retained but earlier visible tools/inter-agent transmissions are not a complete captured stream.')
recorder.record_capture_gap('external-actions','Publication and final-head/hosted checks follow this sealed local record and retain separate identities.')
recorder.record_tool_call(operation_id='freeze-checkout-consumer-probe',tool_name='python',status='succeeded',arguments={'operation':'freeze exact source, dual Python checks and three fresh causal observations'},result={'implementation':IMPL,'summary_sha256':hashlib.sha256((checks/'summary.json').read_bytes()).hexdigest()},result_entered_context=True)
recorder.seal('safe-paused')
result=validate_attempt_trace(WT,ATTEMPT)
validation={'blocked':result.blocked,'risks':[asdict(r) for r in result.risks]}
(checks/'trace-validation.json').write_bytes((json.dumps(validation,indent=2,default=str)+'\n').encode())
assert not result.blocked,validation
print(json.dumps({'attempt':str(ATTEMPT.relative_to(WT)),'trace':validation},default=str))
