# Next Draft scope

User request: continue and publish the next Draft PR, with effects available promptly.

Base: eb49093d6d89515c3e66bec29ee85e7a95bb9ce7 (accepted #98 after H4a).
Branch: feature/ci-attribute-consumer-probe.

Bounded executable experiment: actual Trace Attempt validator, fresh Git checkout, valid / whitespace / EOL hash failure / repair; nested and outside controls, missing reference. Reuse the accepted consumer and assertion codes. A small fixture probe and regression tests provide reproducible observations; no production selector/witness/workflow/coverage-policy changes.

This is A-ATTR-03 follow-up. Successful invocation-bound fault detection does not close the repository-wide input closure or authorize a skip. Preserve original CI receipts and prior diagnostics at their own base/head. No merge, no repeat of completed CI/review, no production2C/reuse/release activation.
