# Attribute consumer probe — independent code review

Profile: independent consumer contract reviewer. Required Skills: []. Accountable owner: Chengyue-Lu.

Scope: read-only review of `tests/test_ci_attribute_consumers.py` in worktree `ci-attribute-consumer-probe`, against the actual Trace reader and Git fixture semantics. No test, probe, CI, branch, remote, or memory mutation was performed by this reviewer. Root owns execution evidence and integration.

## Review identity

- Final frozen source SHA-256 reviewed: `0a0b7af4a01053e7623ac2b6d221f1618b247c5ccf90883c094207214af38b45`.
- Prior full-review frozen source: `a1624ec6078ed604686297a725a9dfe7db74f5e627cf65688c86e71aaed94fc8`.
- Read-only worktree HEAD: `eb49093d6d89515c3e66bec29ee85e7a95bb9ce7`. Source is still an untracked candidate file; the file hash binds this review.
- Earlier snapshots examined: `489ef5b263e103cff211e173929c1b26ac8eeb51044cf848d9055a8502d99fd6`, `4cddf6949f534a97706ed58ebb1e5545787383ef19634b3f81c453e21544051e`.
- Reader design and declared limits: `reader-design.md` and `REQUEST.md` beside this report.

## Resolved finding

**P2, resolved — propagate overall probe failure into the native unittest result.** At frozen-source lines 196–198, source-pin drift sets `report.status = FAIL` after all observations have already received successful `expectation_met` values. At lines 209–211, `setUpClass` only prints a failed report. Every test subsequently checks individual rows, so all eight methods can pass despite an overall failed probe. An exception in late post-processing can produce the same divergence. The CLI does fail because it exits using the overall status at line 290. Make a failed overall status raise in `setUpClass` (after preserving diagnostics), or assert overall status in a guaranteed test. This is a static control-flow finding; no fixture or test was executed to reproduce it.

The finding was sent to root and implementation agent before changing the frozen source. Root added `self.assertEqual('PASS', self.report['status'], self.report)` at final-source line 220 in the baseline test. The complete module suite therefore fails on an overall failed report while preserving individual scenario results. Removing exactly this one added line from the final file reproduces SHA-256 `a1624ec6078ed604686297a725a9dfe7db74f5e627cf65688c86e71aaed94fc8`; no other source content changed between these frozen revisions. The final hash and this delta were independently checked without executing the module. Root retained the first dual-Python logs at their original source identity and is separately testing the corrected source.

## Resolved review points in this frozen source

- Repair now restores the LF attribute contract in the seed, commits it, and creates a separate fresh clone. It does not overwrite a materialized CRLF ledger or regenerate/re-sign INDEX. The same Git ledger blob, INDEX blob and actual INDEX hash are checked by the shared CLI oracle.
- Native assertion owner IDs now use `test_ci_attribute_consumers.AttributeConsumerTests.<method>` and are explicitly labelled as owners, not native execution receipts.
- Git configuration removes inherited `GIT_*` input, disables system/global configuration and attributes, isolates home/XDG paths, fixes EOL/autocrlf, and supplies empty template/hooks directories. New seed and clone repositories are used; observed source checkout is read-only.
- CLI acceptance now verifies the same ledger/INDEX Git blobs, unchanged materialized INDEX, cached/effective attributes, the expected byte change or stability, and complete risk equality for valid controls. A Git error or individual scenario exception sets FAIL.
- CRLF requires one exact BLOCK with `TRACE-HASH-MISMATCH` and `[event-ledger-ref-hash]`; no additional BLOCK can masquerade as the expected fault. Missing/renamed ledger controls require the correct missing detail and allow only the actual reader's four related `TRACE-EVENT-MISSING` details, excluding unrelated BLOCKs. They do not require all four secondary details, which is adequate for this probe's narrow missing-reference oracle.
- Unknown attribute input is examined through staged Git `check-attr` before creating a checkout. Fresh clone materialization and the real `trace.validate_attempt_trace` call remain exercised for supported cases.

## Evidence and performance limits

`consumer_seconds` times only the real validator invocation (lines 79–82). Scenario `setup_seconds` starts before attribute/commit/clone work and includes all unrelated-Attempt copies (lines 131–162); copying is not disguised as validator work. Git commands retain their own wall times. These fields are not an exhaustive additive total: initial fixture validation, recording overhead outside the named timer, report assembly, and subprocess observations require root's external end-to-end wall time to assess total cost.

The 1/10/100 controls copy one frozen Attempt and invoke the same explicitly bound reader. They demonstrate observed result stability for that invocation. No file-read recorder exists here, so they do not establish absence of directory traversal, global dependency closure, a reusable selection edge, or permission to skip tests. Schema checks run in one process and may use the accepted successful-schema cache; these are not independent cold-process samples. No CI reduction or production selector activation follows from this experiment.

Runtime outcomes, cross-platform behavior, and actual timing numbers remain root's separately bound execution evidence. The single TestCase module plus CLI is an intentional scoped organization that avoids adding an opaque non-test helper seed; it does not modify production policy, selector, witness, workflow, or coverage thresholds.

## Current disposition

**PASS — no remaining substantive code-review finding for the bounded probe at `0a0b7af4a01053e7623ac2b6d221f1618b247c5ccf90883c094207214af38b45`.** The final status assertion closes the only remaining finding. This is a static independent review, not a runtime or CI approval; root must bind the corrected-source execution evidence separately. Source changes invalidate this hash-bound disposition until rechecked.