"""Freeze scoped rebase and business-propagation evidence without clone/config trees."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

R=Path(__file__).resolve().parent
W=Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
HEAD='7c2bc7fc627be7b9dde02fbdc2f879d062fdee6d'
BASE='97d3b3d3141419b34ad47e0f42d9f01d0dfbd535'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==HEAD
paths=[R/p for p in ('original.json','rebase.stdout.log','rebase.stderr.log','range-diff.txt',
                     'fingerprint-refresh.json','combination.py','freeze.py')]
for sub in ('rebase-independent','local-combination','local-combination-supplement'):
    paths += [p for p in (R/sub).iterdir() if p.is_file()]
for sub in ('m14-probes','m5-probes'):
    assert (R/sub/'REPORT.md').is_file()
    listed=json.loads((R/sub/'evidence_paths.json').read_bytes())
    entries=listed.get('files',listed.get('paths')) if isinstance(listed,dict) else listed
    hashes=json.loads((R/sub/'evidence_hashes.json').read_bytes()) if (R/sub/'evidence_hashes.json').is_file() else {}
    assert isinstance(entries,list)
    for entry in entries:
        relative=entry['path'] if isinstance(entry,dict) else entry
        p=(R/sub/relative).resolve(strict=True)
        assert p.is_relative_to((R/sub).resolve()) and p.is_file()
        assert '.git' not in p.parts and p.name!='config.toml'
        if isinstance(entry,dict):
            assert sha(p)==entry['sha256'] and p.stat().st_size==entry['bytes']
        elif relative in hashes:
            assert sha(p)==hashes[relative]['sha256'] and p.stat().st_size==hashes[relative]['size']
        paths.append(p)
    paths.append(R/sub/'evidence_paths.json')
paths=sorted(set(paths))
assert all(p.is_file() and p.is_relative_to(R) for p in paths)
assert not any('config-original' in p.name for p in paths)
assert sum(p.stat().st_size for p in paths)<60*1024*1024
for version in ('311','313'):
    primary=json.loads((R/f'local-combination/{version}.json').read_bytes())
    extra=json.loads((R/f'local-combination-supplement/{version}.json').read_bytes())
    assert primary['status']==extra['status']=='PASS'
    assert primary['count']==29 and extra['count']==3
    assert primary['head']==extra['head']==HEAD
A=W/'work/TEST-PERF-002/A-20260927-001';C=A/'checks';C.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(C/'raw-evidence.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,p.relative_to(R).as_posix())
(C/'manifest.json').write_text(json.dumps({p.relative_to(R).as_posix():sha(p) for p in paths},indent=2)+'\n',encoding='utf-8')
summary={'status':'PASS-local-scoped','base':BASE,'implementation_head':HEAD,
    'rebase_original_head':'d4e94e2db8172dade2df729a04c817d1786843e7',
    'rebase_patches_equivalent':10,'consumer_fingerprint_refresh':json.loads((R/'fingerprint-refresh.json').read_bytes()),
    'composition_tests_per_python':32,'full_suite_proved':False,'current_hosted_proved':False,
    'M14_M5_collection_is_not_full_execution':True,'production_reduction_activated':False,
    'scope_reports':{p:sha(R/p/'REPORT.md') for p in ('m14-probes','m5-probes','rebase-independent')},
    'raw_evidence_sha256':sha(C/'raw-evidence.zip')}
(C/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
(A/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
(A/'RESULTS.md').write_text(f'''# Latest-base and M14/M5 propagation validation

TEST-PERF-002; owner Chengyue-Lu; R2; Skills []. User request: rebase PR101 to
latest develop, validate M14-005 and M5-007 propagation and stop at Ready for
review. Base `{BASE}`, local implementation `{HEAD}`. No merge authority.

Ten original PR101 patches were replayed without conflicts, preserving their
nonoverlapping blobs and A001-A005. The accepted H4b and CI policies were combined
without lowering global90, critical95/90 or changed100/100. An independent review
found that the inherited fingerprint no longer matched the H4b inventory. Only
that field was refreshed, with432 input records independently verified; the
original conservative fallback and its cause remain recorded.

Both Python versions passed32 scoped composition tests (29 plus3 nonoverlapping
checks). These are local rebase checks; exact final-head hosted obligations remain
separate. M14/M5 reports distinguish original whole implementation changes, small
source edits, tests and shared inputs. Plans and inventories were reconstructed
without running broad suites solely to count them. Bounded fault probes retain
their actual executions separately from collection evidence.

The three diagnostic contracts in PR101 do not authorize M14 or M5 business
boundaries. Their remaining opaque execution paths and associated smoke/coverage
obligations are explicit follow-up work; this archive does not claim production
business reduction or use the earlier diagnostic timing ratio for these modules.
No business owner branch, source implementation, release/tag/main or quality
threshold was changed by this verification.

- [Summary](checks/summary.json), [manifest](checks/manifest.json), [raw evidence](checks/raw-evidence.zip)

The ZIP retains `m14-probes/REPORT.md`, `m5-probes/REPORT.md` and
`rebase-independent/REPORT.md` with their original adjacent raw evidence.

The earlier official36253369103 and three-pair36253369146 retain their original
d4e94e2/base5bf identities in the preceding work. They are not proofs for this
new base. Trace capture below honestly records prior capture gaps. The next
steps are final committed-head checks, one current-target hosted execution and
Ready for review; formal approval and merge remain external.
''',encoding='utf-8',newline='\n')
sys.path.insert(0,str(W/'src'))
from research_workbench.observability.trace import AgentTraceRecorder,validate_attempt_trace
t=AgentTraceRecorder(A,task_id='TEST-PERF-002',task_revision=49,attempt_id=A.name,
    task_snapshot={'task_id':'TEST-PERF-002','revision':49,
        'request':'Rebase latest, test M14-005 and M5-007 propagation, Ready for review then stop',
        'profile':'CI rebase and propagation engineer','required_skills':[],
        'scope':'PR101 CI implementation and isolated M14/M5 probes; preserve owner branches',
        'delegation':True,'budget':'independent rebase review; bounded M14/M5 cases; scoped local and current target hosted verification',
        'stop_condition':'Ready for review after required validation; no merge'},
    accountable_owner='Chengyue-Lu',actor_id='main-agent',runtime_identity='Codex desktop',provider='OpenAI',
    read_allowlist=['AGENTS.md','README.md','PROJECT_MEMORY.md','docs/DEVELOPMENT.md','.github/scripts/**','tests/**',
        'src/research_workbench/**','schemas/**','docs/workstreams/chengyue-lu/TEST-PERF-002/**','work/TEST-PERF-002/**'],
    write_scope=['tests/ci_impact_policy.yaml','work/TEST-PERF-002/A-20260927-001/**'],
    tool_allowlist=['collaboration','shell','git','gh','python'],baseline=BASE)
t.record_capture_gap('messages','Written delegation reports, exact command/identity records and raw checks retained; earlier inter-agent and tool events lack continuous recorder capture.')
t.record_capture_gap('external-actions','Final committed-head verification, push and Ready/current hosted results occur after this sealed local archive.')
t.record_tool_call(operation_id='freeze-rebase-business-propagation',tool_name='python',status='succeeded',
    arguments={'operation':'freeze exact rebase, inventory fingerprint correction and M14/M5 propagation evidence'},
    result={'implementation':HEAD,'summary_sha256':sha(C/'summary.json')},result_entered_context=True)
t.seal('safe-paused');v=validate_attempt_trace(W,A)
(C/'trace-validation.json').write_text(json.dumps({'blocked':v.blocked,'risks':[asdict(x) for x in v.risks]},indent=2)+'\n',encoding='utf-8')
assert not v.blocked
print(json.dumps({'archive':str(A.relative_to(W)),'files':len(paths),'zip_bytes':(C/'raw-evidence.zip').stat().st_size,'blocked':v.blocked}))
