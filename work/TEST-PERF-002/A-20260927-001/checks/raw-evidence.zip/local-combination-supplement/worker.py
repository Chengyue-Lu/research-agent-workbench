from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import combination
combination.SELECTORS=[
 'test_ci_plan.PlannerTests.test_missing_or_unmatched_anchor_history_retains_conservative_scope',
 'test_ci_consumer_contracts.ConsumerContractTests.test_policy_v1_v2_and_live_records_preserve_explicit_version_boundary',
 'test_ci_consumer_contracts.ConsumerContractTests.test_candidate_rewrite_removal_and_new_record_never_become_base_authority']
raise SystemExit(combination.worker(Path(sys.argv[1]),Path(sys.argv[2])))
