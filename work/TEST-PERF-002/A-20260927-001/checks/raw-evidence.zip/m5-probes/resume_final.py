"""Resume on the explicitly refreshed candidate, reusing completed accepted plans."""
from pathlib import Path
import json
import shutil
import probe as p

R=Path(__file__).parent
FINAL='7c2bc7fc627be7b9dde02fbdc2f879d062fdee6d'
p.OUT=R/'final';p.OUT.mkdir();(p.OUT/'commands').mkdir()
shutil.copyfile(R/'collect.py',p.OUT/'collect.py')
repos={label:R/'repos'/label for label in ('accepted','future')}
p.save(p.OUT/'inputs.json',dict(accepted=p.ACCEPTED,future_unaccepted=FINAL,
    retired_pre_refresh=p.FUTURE,explicit_stop='stopped-old-coordinator.json; no product/CI failure',
    reused_completed=['actual-h4b-accepted','local-function-accepted']))
# The new final source object must be locally available, without fetch or WT writes.
p.git(repos['future'],'cat-file','-e',FINAL+'^{commit}')
tree=p.git(repos['future'],'rev-parse',FINAL+'^{tree}')
synthetic=p.git(repos['future'],'commit-tree',tree,'-p',p.OLD101,'-m','EXPERIMENT ONLY H4b on PR101 with final refreshed anchor')
p.save(p.OUT/'h4b-replay.json',dict(base=p.OLD101,head=synthetic,tree=tree,tree_source=FINAL,
    semantics='counterfactual H4b plus composed fingerprint update on unaccepted old101; not historical execution'))
p.collect(repos['future'],p.OLD101,synthetic,'actual-h4b-with101-synthetic')
specs=[
    ('local-function',[(p.TARGET,'if slice_record["lifecycle"] != "completed":','if not slice_record["lifecycle"] == "completed":')]),
    ('test-only',[('tests/test_evaluation_harness_review.py','self.assertEqual(len(public["slots"]), 6)','self.assertEqual(len(public["slots"]), 6 + 0)')]),
    ('shared-fixture',[('tests/harness_execution_fixtures.py','self.output if self.output is not None else','self.output if not self.output is None else')]),
    ('schema',[('schemas/v0.1.0/evaluation-harness-review-policy.schema.json','"minItems": 1','"minItems": 2')]),
    ('mixed-diagnostic',[(p.TARGET,'if slice_record["lifecycle"] != "completed":','if not slice_record["lifecycle"] == "completed":'),
         ('.github/scripts/ci_consumer_shadow.py','if identity not in seen]','if not identity in seen]')]),
]
results={}
for name,changes in specs:
    results[name]={}
    for label,base in [('accepted',p.ACCEPTED),('future',FINAL)]:
        if name=='local-function' and label=='accepted':
            results[name][label]=str(R/'local-function-accepted')
            continue
        repo=repos[label];p.git(repo,'checkout','--detach','--quiet',base)
        for path,before,after in changes:p.change(repo,path,before,after)
        head=p.commit(repo,[x[0] for x in changes],'EXPERIMENT ONLY final M5 '+name+' '+label)
        p.git(repo,'branch','final-probe-'+name,head)
        p.save(p.OUT/(name+'-'+label+'-identity.json'),dict(base=base,head=head,changes=[x[0] for x in changes],synthetic=True))
        p.collect(repo,base,head,name+'-'+label)
        results[name][label]=str(p.OUT/(name+'-'+label))
p.save(p.OUT/'scenario-directories.json',results)
for label,repo in repos.items():p.git(repo,'checkout','--detach','--quiet',p.ACCEPTED if label=='accepted' else FINAL)
print('PASS final plans/collection; accepted completed rows reused without reexecution')
