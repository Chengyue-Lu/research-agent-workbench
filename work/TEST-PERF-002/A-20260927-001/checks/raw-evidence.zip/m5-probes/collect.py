"""Plan and collect exact B/C; never executes tests or fixtures."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import yaml

p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--base',required=True)
p.add_argument('--head',required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
repo=a.repo.resolve();out=a.output.resolve();out.mkdir()
sys.path[:0]=[str(repo/'.github/scripts'),str(repo),str(repo/'src')]
import plan_ci as planner
import build_backend
assert Path(planner.__file__).resolve()==repo/'.github/scripts/plan_ci.py'
assert Path(build_backend.__file__).resolve()==repo/'build_backend.py'
runtime_pin=build_backend.generate(repo)
body='- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no'
plan=planner.make_plan(repo,base=a.base,head=a.head,target=a.head,repository='Chengyue-Lu/research-agent-workbench',body=body)
(out/'plan.json').write_bytes(planner.canonical(plan))
planner.verify_plan(repo,plan)
spec=importlib.util.spec_from_file_location('probe_runner',repo/'tests/run_unittest_suite.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
B,C=runner._execution_suites(argparse.Namespace(plan=out/'plan.json',policy=repo/'tests/coverage_policy.yaml'),plan)
inventory={k:list(runner._inventory(s).items()) for k,s in [('B',B),('C',C)]}
ids={k:{row[0] for row in rows} for k,rows in inventory.items()}
policy=yaml.safe_load((repo/'tests/coverage_policy.yaml').read_text(encoding='utf-8'))
critical=sorted(set(plan['coverage_modules'])&set(policy['critical_modules']))
evidence=[m for m in policy['negative_acceptance'] if set(m['modules'])&set(critical)]
def save(name,value):
    (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
save('inventory.json',dict(collection_only=True,tests_executed=0,inventory=inventory,
    counts=dict(B=len(ids['B']),C=len(ids['C']),U=len(ids['B']|ids['C']))))
save('summary.json',dict(status='PASS-plan-and-collection',base=a.base,head=a.head,plan_id=plan['plan_id'],
    runtime_pin=runtime_pin,behavioral_scope=plan['behavioral_scope'],coverage_scope=plan['coverage_scope'],
    coverage_obligations=plan['coverage_obligations'],package_smoke=plan['package_smoke'],repository_smoke=plan['repository_smoke'],
    test_modules=len(plan['tests']),counts=dict(B=len(ids['B']),C=len(ids['C']),U=len(ids['B']|ids['C'])),
    blocked=plan['blocked_reasons'],reasons=plan['obligation_reasons'],coverage_modules=plan['coverage_modules'],
    critical_modules=critical,negative_acceptance=evidence,tests_executed=0,
    diagnostic_boundaries=plan.get('selection',{}).get('reviewed_opaque_boundary',[]),
    anchor=plan.get('selection',{}).get('reviewed_contract_anchor'),
    origin=planner.__file__))
print(json.dumps(dict(B=len(ids['B']),C=len(ids['C']),U=len(ids['B']|ids['C']),
    behavioral=plan['behavioral_scope'],coverage=plan['coverage_scope'],package=plan['package_smoke'],repository=plan['repository_smoke'])))
