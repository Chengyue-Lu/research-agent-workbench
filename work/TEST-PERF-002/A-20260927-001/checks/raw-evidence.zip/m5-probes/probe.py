"""M5 propagation comparison in isolated ordinary clones. Never publish refs."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

OUT=Path(__file__).parent
SOURCE=Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
ACCEPTED='97d3b3d3141419b34ad47e0f42d9f01d0dfbd535'
FUTURE='deae2679c7daba3fe23663aed65f5c8f786fb3b2'
PRIOR='5bf2227ca9b4d2f63f452e579185e7838028de78'
OLD101='d4e94e2db8172dade2df729a04c817d1786843e7'
TARGET='src/research_workbench/evaluation/harness_review.py'
POLICY='tests/ci_impact_policy.yaml'
def environment(repo):
    env={k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_','GITHUB_','PYTHON'))}
    env.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_NOSYSTEM='1',
        PYTHONPATH=os.pathsep.join(str(repo/p) for p in ('src','.','.github/scripts')))
    return env
counter=0
def call(argv,repo=SOURCE,stdin=None):
    global counter
    counter+=1; start=time.perf_counter()
    v=subprocess.run(list(map(str,argv)),cwd=repo,env=environment(repo),input=stdin,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    stem=OUT/'commands'/f'{counter:03}'
    stem.with_suffix('.stdout').write_bytes(v.stdout);stem.with_suffix('.stderr').write_bytes(v.stderr)
    save(stem.with_suffix('.json'),dict(argv=list(map(str,argv)),cwd=str(repo),returncode=v.returncode,seconds=time.perf_counter()-start))
    if v.returncode: raise RuntimeError(str(stem)+' failed')
    return v.stdout.decode().strip()
def git(repo,*args):
    return call(['git','-c','core.hooksPath='+os.devnull,'-c','core.autocrlf=false','-c','commit.gpgsign=false',
        '-c','user.name=M5 local probe','-c','user.email=probe@example.invalid','-C',repo,*args],repo)
def save(path,value):
    with path.open('x',encoding='utf-8') as f: json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def collect(repo,base,head,name):
    git(repo,'checkout','--detach','--quiet',head)
    call([sys.executable,OUT/'collect.py','--repo',repo,'--base',base,'--head',head,'--output',OUT/name],repo)
def commit(repo,paths,message):
    git(repo,'add','--',*paths)
    git(repo,'commit','--quiet','-m',message)
    return git(repo,'rev-parse','HEAD')
def change(repo,path,before,after):
    file=repo/path;data=file.read_text(encoding='utf-8');assert data.count(before)==1,(path,before,data.count(before))
    file.write_text(data.replace(before,after),encoding='utf-8',newline='\n')

def main():
    (OUT/'commands').mkdir();(OUT/'repos').mkdir()
    save(OUT/'inputs.json',dict(accepted=ACCEPTED,future_unaccepted=FUTURE,actual_h4b_parent=PRIOR,old101=OLD101,
        warning='offline plan/collection only; synthetic refs never production accepted'))
    repos={}
    for label,base in [('accepted',ACCEPTED),('future',FUTURE)]:
        repo=OUT/'repos'/label
        call(['git','clone','--no-hardlinks','--no-checkout','--quiet',SOURCE,repo],OUT)
        git(repo,'checkout','--detach','--quiet',base);repos[label]=repo
    # Real H4b exact historical delta, and the same semantic tree addition on old PR101.
    collect(repos['accepted'],PRIOR,ACCEPTED,'actual-h4b-accepted')
    tree=git(repos['future'],'rev-parse',FUTURE+'^{tree}')
    synthetic=git(repos['future'],'commit-tree',tree,'-p',OLD101,'-m','EXPERIMENT ONLY H4b on old PR101 source')
    save(OUT/'h4b-replay.json',dict(base=OLD101,head=synthetic,tree=tree,tree_source=FUTURE,
        semantics='counterfactual H4b addition on unaccepted PR101, no historical execution claim'))
    collect(repos['future'],OLD101,synthetic,'actual-h4b-with101-synthetic')
    specs=[
        ('local-function',[(TARGET,'if slice_record["lifecycle"] != "completed":','if not slice_record["lifecycle"] == "completed":')]),
        ('test-only',[('tests/test_evaluation_harness_review.py','self.assertEqual(len(public["slots"]), 6)','self.assertEqual(len(public["slots"]), 6 + 0)')]),
        ('shared-fixture',[('tests/harness_execution_fixtures.py','self.output if self.output is not None else','self.output if not self.output is None else')]),
        ('schema',[('schemas/v0.1.0/evaluation-harness-review-policy.schema.json','"minItems": 1','"minItems": 2')]),
        ('mixed-diagnostic',[(TARGET,'if slice_record["lifecycle"] != "completed":','if not slice_record["lifecycle"] == "completed":'),
             ('.github/scripts/ci_consumer_shadow.py','if identity not in seen]','if not identity in seen]')]),
    ]
    results={}
    for name,changes in specs:
        results[name]={}
        for label,base in [('accepted',ACCEPTED),('future',FUTURE)]:
            repo=repos[label];git(repo,'checkout','--detach','--quiet',base)
            for path,before,after in changes: change(repo,path,before,after)
            head=commit(repo,[x[0] for x in changes],'EXPERIMENT ONLY M5 '+name+' '+label)
            git(repo,'branch','probe-'+name,head)
            save(OUT/(name+'-'+label+'-identity.json'),dict(base=base,head=head,changes=[x[0] for x in changes],synthetic=True))
            collect(repo,base,head,name+'-'+label)
            results[name][label]=json.loads((OUT/(name+'-'+label)/'summary.json').read_bytes())
    save(OUT/'scenario-summary.json',results)
    for label,repo in repos.items():git(repo,'checkout','--detach','--quiet',ACCEPTED if label=='accepted' else FUTURE)
    print('PASS 6 scenarios / 12 exact plans and collections; no tests executed')
if __name__=='__main__':main()
