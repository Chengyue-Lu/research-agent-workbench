# M5-007 H4b / PR101 propagation audit

结论：PR101 的三个 CI diagnostic 契约没有误删 M5 的共享 validator、runtime schema、harness 或 smoke 义务；6 类场景的 accepted B/C 均被 future B/C 完整保留，既有用例的相对顺序也一致。M5 本地源码与共享 fixture 仍有接近全仓的保守扩散，残差尚未闭合，本轮没有登记未经审查的 M5 业务契约。

- accepted 基线：`97d3b3d3141419b34ad47e0f42d9f01d0dfbd535`（PR96 H4b 实际 squash），真实父提交 `5bf2227ca9b4d2f63f452e579185e7838028de78`。
- future 实验基线：`7c2bc7fc627be7b9dde02fbdc2f879d062fdee6d`（重基线 PR101 加唯一 consumer fingerprint 刷新），仅在隔离 clone 假设其已接受；不是 GitHub 正式 accepted plan。
- H4b future 整包回放是以旧 PR101 d4e94e2 为父、7c2bc7f 的组合 tree 为内容的合成提交，包含必要 fingerprint 组合；与真实 H4b 历史执行区分。旧 deae 回放和已停止协调器的记录原样保留，不作为最终 candidate。

## 计划与原生 collection

`B/C/U` 为通过真实 runner `_execution_suites`/`_inventory` 收集的准确用例数；没有执行这些全量/选定计划。full worker 实际 discovery 不以 `plan.tests` 数量代替。P/R 为 package/repository smoke 计划要求。

| 场景 | accepted B/C/U | future B/C/U | behavioral / coverage | P/R |
|---|---:|---:|---|---|
| 实际 H4b 整包及组合回放 | 1508/1482/1508 | 1556/1530/1556 | full / impact+repository | true/true |
| `_project` 内等价 guard | 1496/1470/1496 | 1544/1518/1544 | focused / impact | true/true |
| 单条测试断言 6 → 6+0 | 301/0/301 | 329/0/329 | focused / none | false/false |
| LocalDriver 内等价 output guard | 1496/0/1496 | 1544/0/1544 | focused / none | true/true |
| review policy schema minItems 1 → 2 | 1506/0/1506 | 1554/0/1554 | focused / none | true/true |
| M5 guard + diagnostic 函数小改 | 1496/1470/1496 | 1544/1518/1544 | focused / impact | true/true |

所有 12 份 plan verify PASS，blocked 为空；source-head、tree、canonical plan hash、inventory hash、作用域 diff 在 `frozen/`。每类新增库存按模块归因见 `preservation.json`：多数场景增加 48 个 CI 用例，test-only 增加 28 个；这属于 PR101 新测试库存，不是漏测后重新扩边。

## 精确残差与判断

1. M5 `_project` 小改在 future 仍选 105 模块、B1544/C1518。直接保守边为 `harness_review.py → cli.py`、`harness_review.py → research_state/gate.py`、`harness_review.py → tests/harness_execution_fixtures.py`，三者均是 `opaque-execution`；经 gate → research_state/__init__ → validation/research_state_registry → validation/documents 继续传入共享 validator，CLI/validator 可达性分别开启两 smoke。与此同时 `harness_review.py → test_evaluation_harness_review.py` 是真实 `syntax-reference`。

2. shared-fixture guard 同样通过 `tests/harness_execution_fixtures.py → cli.py/gate.py` 的 opaque-execution 边扩成 B1544，两 smoke 为 true；coverage 正确为 none。测试 helper 是可执行 Python，当前没有可证明其不会成为那些不透明 invocation 输入的 accepted 契约，不能仅凭 tests/ 目录就抹掉边。其直接 harness 引用应保留，额外 opaque 可达性属于下一轮 invocation 输入边界盘点。

3. 单测试断言为 focused B329 / coverage none / 两 smoke false。额外 CI 测试经真实测试清单/runner/plan 的 syntax-reference 边：test_evaluation_harness_review → tests/run_unittest_suite → ci_checks → CI contract/consumer tests，以及直接 → test_ci_plan。其不是 M5 全业务兼容扩散；329 仍是可继续分析的 CI 库存读取成本，不能在未拆分读取接口之前断言这些边全是错误。

4. schema minItems 修改经 schema → cli/gate/validation.documents 的 `unbounded-resource` 边，保留 B1554 与 package/repository smoke；这是 schema 运行时资源与共享 schema catalog 的现有边界。coverage none 只表示未改变可执行 coverage facts，不能据此跳过行为或资源证明。

5. 实际 H4b 整包的 full / impact+repository 原因记录包含 34 条未分类 archive/trace 原始文件 surface（具体原值见 propagation.json）；新增生产/关键模块仍需要 impact 和正反证据。即使没有业务函数依赖边，非 Markdown 证据归档的分类残差也可能单独引起全仓回退。当前记录只能证明这些回退被触发，不能证明所有归档都是可安全忽略的 inert 文件；本轮没有读取或更改其他 owner 归档内容，也未给它们新增 exclusion。

6. 混合 M5+diagnostic 场景只在 future 对 `.github/scripts/ci_consumer_shadow.py` 命中 reviewed_opaque_boundary，anchor 为 7c2bc7f；M5 仍沿自身 opaque 边传播。其完整 B/C（含顺序）与纯 M5 小改完全相等，critical harness_review 与具名 positive/negative evidence 保留，双 smoke 保留。没有发现“一个 diagnostic 命中使整个混合 PR 越权缩小”的问题。

## 已实际运行的正确/故障对照

在独立 clone 的正确 `_project` 等价变更 f9f1032a 上，用 Python 3.11 完整运行既有 `tests.test_evaluation_harness_review`：13 PASS，unittest 203.678 秒，命令 wall 204.577 秒。含 12 个既有单元用例和 1 个现有真实四臂执行 → evidence → review/freeze → fresh-process reveal integration。本轮没有新加 mock；现有单元用例的 evidence stub 与真实 integration 应分别理解。

局部 coverage 为 harness_review **141/141 行、12/12 分支**；changed **2/2 行、2/2 outgoing arcs**，满足该 critical 95/90 与 changed100/100。既有 mapping substitution、partial/unknown reviews、freeze/reveal replacement 和 authority 拒绝用例均通过。完整 JSON、原生 stdout/stderr 与命令绑定保存在 bounded-execution/correct。

再在故障 c28bf317 上反转生命周期 guard，执行既有 public projection 单用例：1 ERROR，EvaluationValidationError（completed-slice artifact 约束），非零返回，说明该合理故障被既有测试抓到；故障不是产品待修复提交。用例 0.691 秒、wall 1.140 秒，原始失败保留于 bounded-execution/fault。故障从未 push。

这只是一个完整 H4b 模块的局部实际执行，不能替代计划 B1544/C1518、双 Python、smokes、正式 hosted CI，也不能宣称 full workflow 缩时。没有为评估重新执行 1500+ 全基线。

## 后续边界

本次结果支持 PR101 在既有 scope 内继续 Ready 验证。M5 的剩余成本应单独开展 base-owned invocation 输入闭包证明：先覆盖 CLI command dispatch、gate validator invocation、harness 冷进程执行及 source-identity pin 的真实输入，再审查是否登记 M5 function-body 契约，始终保留完整 H4b test module、真实 integration、source drift/authority/freeze-replay 反例、critical95/90 与 changed100/100。shared fixture / schema / archive 应分别形成可审核规则；不在 PR101 混入未经审查的业务减测合同。

`evidence_paths.json` 给出可冻结文件的精确相对路径，`evidence_hashes.json` 绑定其 SHA256/size；完整 clone/.git/生成 runtime 不在列表。
