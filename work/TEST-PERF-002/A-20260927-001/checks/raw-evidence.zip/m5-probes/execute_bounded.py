"""Existing complete M5 review module plus one deliberate fault, locally only.

This is not execution of the much larger formal plan. No mocking is added; the
existing module includes its real H3/H4a/cold-process integration test.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
import probe as p

ROOT=Path(__file__).parent
p.OUT=ROOT/'bounded-execution';p.OUT.mkdir();(p.OUT/'commands').mkdir()
source=ROOT/'repos/future';repo=p.OUT/'repo'
identity=json.loads((ROOT/'final/local-function-future-identity.json').read_bytes())
assert identity['base']=='7c2bc7fc627be7b9dde02fbdc2f879d062fdee6d'
p.call(['git','clone','--no-hardlinks','--no-checkout','--quiet',source,repo],p.OUT)
p.git(repo,'checkout','--detach','--quiet',identity['head'])
p.call([sys.executable,'-c','import build_backend; build_backend.generate()'],repo)
def execute(label,argv):
    out=p.OUT/label;out.mkdir();env=p.environment(repo);env['COVERAGE_FILE']=str(out/'.coverage')
    start=time.perf_counter()
    result=subprocess.run(argv,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (out/'stdout.log').write_bytes(result.stdout);(out/'stderr.log').write_bytes(result.stderr)
    value=dict(argv=argv,returncode=result.returncode,wall_seconds=time.perf_counter()-start,
        source_head=p.git(repo,'rev-parse','HEAD'),source_sha256=hashlib.sha256((repo/p.TARGET).read_bytes()).hexdigest())
    p.save(out/'command.json',value)
    return out,value,env
out,good,env=execute('correct',[sys.executable,'-m','coverage','run','--branch','--source=research_workbench.evaluation.harness_review',
    '-m','unittest','tests.test_evaluation_harness_review','-v'])
assert good['returncode']==0,good
result=subprocess.run([sys.executable,'-m','coverage','json','-o',str(out/'coverage.json')],cwd=repo,env=env,
    stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/'export.stdout').write_bytes(result.stdout);(out/'export.stderr').write_bytes(result.stderr)
assert result.returncode==0
coverage=json.loads((out/'coverage.json').read_bytes());files={k.replace('\\','/'):v for k,v in coverage['files'].items()}
item=files[p.TARGET];s=item['summary']
line=100*s['covered_lines']/s['num_statements'];branch=100*s['covered_branches']/s['num_branches']
assert line>=95 and branch>=90
plan=json.loads((ROOT/'final/local-function-future/plan.json').read_bytes())
changed=set(plan['coverage_lines'][p.TARGET]);assert not changed & set(item['missing_lines'])
assert not any(a in changed for a,b in item['missing_branches'])
evidence=dict(line=s,changed_executable=sorted(changed & (set(item['executed_lines'])|set(item['missing_lines']))),
    changed_outgoing=sorted({tuple(row) for row in item['executed_branches']+item['missing_branches'] if row[0] in changed}),
    missing_changed_lines=[],missing_changed_branches=[])
p.save(out/'coverage-check.json',evidence)
p.change(repo,p.TARGET,'if not slice_record["lifecycle"] == "completed":','if slice_record["lifecycle"] == "completed":')
fault=p.commit(repo,[p.TARGET],'EXPERIMENT ONLY reverse completed lifecycle review guard')
_,bad,_=execute('fault',[sys.executable,'-m','unittest',
    'tests.test_evaluation_harness_review.HarnessReviewTests.test_public_projection_is_closed_and_fresh_private_mapping_covers_all_slices','-v'])
assert bad['returncode']!=0,'Existing positive test did not detect reversed lifecycle guard'
p.save(p.OUT/'summary.json',dict(status='PASS-bounded-correct-and-fault',base=identity['base'],correct_head=identity['head'],fault_head=fault,
    correct=good,fault=bad,coverage=evidence,critical_floor=dict(line=95,branch=90),
    scope='one complete existing H4b module, including existing real integration; fault uses one existing case',
    formal_plan_execution=False,full_repository_execution=False,smokes_executed=False,new_mocks_added=False))
p.git(repo,'checkout','--detach','--quiet',identity['head'])
print('PASS bounded M5 module and intentional fault refusal; not formal plan execution')
