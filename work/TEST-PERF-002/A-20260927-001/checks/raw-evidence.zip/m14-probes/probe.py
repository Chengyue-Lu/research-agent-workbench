"""Isolated local M14 propagation experiments; all refs and deliberate faults stay here."""
from __future__ import annotations
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT=Path(__file__).resolve().parent
SOURCE=Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
REPO=OUT/'clone'
PY311='D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917/venv311/Scripts/python.exe'
PY313='D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917/venv313/Scripts/python.exe'
ACCEPTED='97d3b3d3141419b34ad47e0f42d9f01d0dfbd535'
PROPOSED=os.environ.get('M14_PROPOSED_HEAD','deae2679c7daba3fe23663aed65f5c8f786fb3b2')
M14='f5f663e10869c927de6d4b1e67647b4fae968b80'
M14_BASE='5bf2227ca9b4d2f63f452e579185e7838028de78'
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1','GIT_NO_REPLACE_OBJECTS':'1'}
ENV['PYTHONPATH']=os.pathsep.join(str(p) for p in (REPO,REPO/'src',REPO/'.github/scripts',REPO/'tests'))
for key in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):
    ENV.pop(key,None)
PHASE=os.environ.get('M14_PROBE_PHASE','accepted')
counter=max([0,*[int(p.stem) for p in (OUT/'commands').glob('*.json')]])
def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def step(argv,cwd=REPO,allowed=(0,)):
    global counter
    counter+=1
    start=time.perf_counter()
    p=subprocess.run(argv,cwd=cwd,env=ENV,capture_output=True)
    stem=OUT/'commands'/f'{counter:03d}'
    stem.with_suffix('.stdout').write_bytes(p.stdout)
    stem.with_suffix('.stderr').write_bytes(p.stderr)
    save(stem.with_suffix('.json'),{'argv':argv,'cwd':str(cwd),'returncode':p.returncode,
                                    'wall_seconds':time.perf_counter()-start})
    if p.returncode not in allowed:
        raise RuntimeError(f'command {counter} failed {p.returncode}: {p.stderr.decode(errors="replace")}')
    return p.stdout.decode('utf-8').strip()
def git(*argv,cwd=REPO,allowed=(0,)):
    return step(['git','-c','core.hooksPath=NUL',*argv],cwd,allowed)
def commit(label,paths):
    git('add','--',*paths)
    git('-c','user.name=CI Local Probe','-c','user.email=ci-probe@invalid.local','commit','-qm',
        'LOCAL UNACCEPTED EXPERIMENT: '+label)
    return git('rev-parse','HEAD')
def edit_return(text,sign):
    tree=ast.parse(text)
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='positive')
    ret=next(n for n in fn.body if isinstance(n,ast.Return))
    lines=text.splitlines(keepends=True)
    assert lines[ret.lineno-1].strip()=='return value'
    lines[ret.lineno-1]=' '*ret.col_offset+'return '+sign+'value\n'
    return ''.join(lines)
def execute_pair(label,head):
    git('checkout','--detach',head)
    identity='tests.test_release_source_ci.AttestationTests.test_exact_push_attempt_and_app_bound_checks_produce_existing_source_ci_shape'
    records=[]
    for python in (PY311,PY313):
        before=counter
        step([python,'-B','-m','unittest','-v',identity],allowed=(0,1))
        fact=json.loads((OUT/'commands'/f'{counter:03d}.json').read_bytes())
        records.append({**fact,'command_index':counter,'case':identity})
    fact={'label':'ACTUAL SINGLE EXISTING TEST EXECUTION; not full selected suite or live GitHub attestation',
          'head':head,'file':'.github/scripts/release_source_ci.py',
          'source_sha256':hashlib.sha256((REPO/'.github/scripts/release_source_ci.py').read_bytes()).hexdigest(),
          'tests_sha256':hashlib.sha256((REPO/'tests/test_release_source_ci.py').read_bytes()).hexdigest(),
          'runs':records}
    save(OUT/(label+'-actual-execution.json'),fact)
    return fact
def plan_case(label,base,head):
    target=OUT/label
    target.mkdir()
    git('checkout','--detach',head)
    step([PY311,'-B',str(OUT/'worker.py'),'--repo',str(REPO),'--base',base,'--head',head,'--out',str(target)])
    value=json.loads((target/'summary.json').read_bytes())
    index['cases'].append({'label':label,'base':base,'head':head,'summary':str(target/'summary.json')})
    save(OUT/'index.json',index)
    print(json.dumps({'label':label,'B':value['inventory']['B'],'C':value['inventory']['C'],
                     'union':value['inventory']['union'],'scope':value['behavioral_scope'],
                     'coverage':value['coverage_scope'],'package':value['package_smoke'],
                     'repository':value['repository_smoke'],'blocked':value['blocked_reasons']}),flush=True)
    return value

if PHASE=='accepted':
    assert not REPO.exists(), 'Preserve any earlier probe checkout'
    (OUT/'commands').mkdir(exist_ok=False)
    original={'head':git('rev-parse','HEAD',cwd=SOURCE),'status':git('status','--porcelain',cwd=SOURCE)}
    save(OUT/'source-before.json',original)
    step(['git','clone','--no-hardlinks','--no-checkout',str(SOURCE),str(REPO)],cwd=OUT)
    git('config','core.autocrlf','false')
    git('config','user.name','CI Local Probe')
    git('config','user.email','ci-probe@invalid.local')
    git('remote','set-url','--push','origin','https://invalid.local/never-push-this-clone')
    index={'scope':'Local synthetic comparison; proposed PR101 is not accepted production authority; no hosted CI',
           'accepted':ACCEPTED,'proposed_pending_refresh':PROPOSED,'actual_m14_head':M14,'actual_m14_base':M14_BASE,
           'cases':[]}
    save(OUT/'actual-pr102-name-status.txt',git('diff','--name-status',M14_BASE+'...'+M14).splitlines())
    (OUT/'actual-pr102.patch').write_text(git('diff','--binary',M14_BASE+'...'+M14)+'\n',encoding='utf-8')
    plan_case('actual-pr102-original',M14_BASE,M14)
    epochs=[('accepted',ACCEPTED)]
else:
    assert PHASE=='proposed' and 'M14_PROPOSED_HEAD' in os.environ
    index=json.loads((OUT/'index.json').read_bytes())
    original=json.loads((OUT/'source-before.json').read_bytes())
    index['proposed']=PROPOSED
    git('fetch','origin',PROPOSED)
    epochs=[('proposed',PROPOSED)]
for epoch,base in epochs:
    git('checkout','--detach',base)
    git('merge','--no-ff','--no-commit',M14)
    git('commit','-qm','LOCAL UNACCEPTED EXPERIMENT: combine PR102 with '+epoch+' base')
    head=git('rev-parse','HEAD')
    plan_case('pr102-on-'+epoch,base,head)
    for case,path in [('source-function','.github/scripts/release_source_ci.py'),
                      ('test-only','tests/test_release_source_ci.py'),
                      ('shared-fixture-helper','tests/public_surface_helpers.py')]:
        git('checkout','--detach',base)
        text=(REPO/path).read_text(encoding='utf-8')
        if case=='source-function':
            text=edit_return(text,'+')
        elif case=='test-only':
            before="self.assertEqual(ATTEMPT, result['observation']['run_attempt'])"
            assert text.count(before)==1
            text=text.replace(before,"self.assertEqual(+ATTEMPT, result['observation']['run_attempt'])")
        else:
            before='    selected = set()\n'
            assert text.count(before)==1
            text=text.replace(before,'    pass  # local shared fixture helper equivalent edit\n'+before)
        (REPO/path).write_text(text,encoding='utf-8')
        head=commit(case+' on '+epoch,[path])
        plan_case(case+'-'+epoch,base,head)
        if epoch=='proposed' and case=='source-function':
            index['correct_execution']=execute_pair('source-correct',head)
            save(OUT/'index.json',index)
if PHASE=='accepted':
    git('checkout','--detach',ACCEPTED)
    index['accepted_phase_complete']=True
    save(OUT/'index.json',index)
    print('ACCEPTED phase complete; proposed phase waits for exact refreshed head',flush=True)
    sys.exit(0)
git('checkout','--detach',PROPOSED)
path='.github/scripts/release_source_ci.py'
(REPO/path).write_text(edit_return((REPO/path).read_text(encoding='utf-8'),'-'),encoding='utf-8')
fault=commit('intentional wrong positive identity return',[path])
plan_case('source-fault-proposed',PROPOSED,fault)
index['fault_execution']=execute_pair('source-fault',fault)
git('checkout','--detach',PROPOSED)
index['clone_final']={'head':git('rev-parse','HEAD'),'clean':not git('status','--porcelain')}
index['source_after']={'head':git('rev-parse','HEAD',cwd=SOURCE),'status':git('status','--porcelain',cwd=SOURCE)}
index['root_preserved']=index['source_after']==original
save(OUT/'index.json',index)
