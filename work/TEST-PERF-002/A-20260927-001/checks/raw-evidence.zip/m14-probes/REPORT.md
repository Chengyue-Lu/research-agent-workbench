# M14-005 propagation audit after latest-base rebase

结论：本轮隔离对照未发现 PR101 漏选或破坏原闭包；M14 的近全量传播仍是未迁移的已知边界。PR101 的三个诊断模块契约没有获得替 M14 源码或 release authority 缩小范围的权限。全部比较保留 accepted 侧的 B/C 用例及其相对顺序。

## Exact refs and scope

- accepted develop: `97d3b3d3141419b34ad47e0f42d9f01d0dfbd535`.
- proposed PR101: `7c2bc7fc627be7b9dde02fbdc2f879d062fdee6d`; 这是待审候选，仅在本地模拟 future base，不称 accepted。
- actual PR102: `f5f663e10869c927de6d4b1e67647b4fae968b80`, original base `5bf2227ca9b4d2f63f452e579185e7838028de78`.
- `deae2679...` 尚未运行候选情景；root 通知 H4b inventory 改变后，本轮候选都等到仅刷新 fingerprint 的 `7c2bc7fc...`。前后输入事实保留。
- 所有变更与 deliberate fault 仅在 `m14-probes/clone` 普通 Git clone，push URL 指向 invalid.local；无 owner 分支写入、PR 更新、网络 API、hosted CI 或 release 动作。

## Plan and collection

以下 B/C/union 全部为实际 runner 的 `_execution_suites` / `_inventory` **收集结果**，未运行这些大套件。FULL 时按完整 discovery 收集，repository coverage 时按实际 quality union 收集；没有仅把 plan selector 数当用例数。所有 plan 的 blocked_reasons 都为空。

| Probe | Behavioral | Coverage | B/C/union collected | Package/repository smoke |
|---|---|---|---|---|
| actual-pr102-original | full | impact+repository | 1503/1477/1503 | True/True |
| pr102-on-accepted | full | impact+repository | 1516/1490/1516 | True/True |
| source-function-accepted | focused | impact | 1496/1470/1496 | True/True |
| test-only-accepted | focused | none | 288/0/288 | False/False |
| shared-fixture-helper-accepted | focused | none | 1496/0/1496 | True/True |
| pr102-on-proposed | full | impact+repository | 1564/1538/1564 | True/True |
| source-function-proposed | focused | impact | 1544/1518/1544 | True/True |
| test-only-proposed | focused | none | 316/0/316 | False/False |
| shared-fixture-helper-proposed | focused | none | 1544/0/1544 | True/True |
| source-fault-proposed | focused | impact | 1544/1518/1544 | True/True |

`pr102-on-*` 是把真实 PR102 branch 合并进本地隔离 base 后的 synthetic integration target，保留两边所有内容。不是对 owner 分支执行 rebase，也不冒充 GitHub merge target。

## Edge attribution

1. **M14 单函数修改仍近全量。** `.github/scripts/release_source_ci.py::positive` 的 `return value` 改为等价 `return +value`，imports 不变且 `function_body_only=true`。两 base 均无对应 group，`reviewed_opaque_boundary=[]`。关键链为 `release_source_ci.py → cli.py` / `research_state/gate.py` 的 **opaque-execution**，随后普通 downstream 选中业务测试；CLI 和 validation 节点进一步要求两类 smoke。accepted 侧 dependency selection 为 102 个模块，其中 90 条选中路径含 opaque；这些是无法由当前输入契约证明无关的保守边，并非证明业务直接调用 release_source_ci。它们会继续影响后续 M14 小修。

2. **普通 test-only 没有 repository coverage 和 smoke。** 对 `tests/test_release_source_ci.py` 的现有断言加入数值一元加号，不改变实际断言含义；accepted 选 14 个模块、288 项，候选 15 个模块、316 项。路径包含 `test_release_source_ci.py → test_ci_plan.py`，以及 `test_release_source_ci.py → run_unittest_suite.py → ci_checks.py → test_release_preflight.py`，均标为 syntax-reference。测试加载、输入内容/路径和 CI 元测试的 conservative dependency 仍会传递；此次没有 opaque 或 unbounded-resource，也没有扩到业务全集。不能把 316 项统称纯业务回归必要最小值；CI 工具读取输入与执行消费之间的类型契约仍是后续成本项。

3. **共享 fixture/helper 仍有传播风险。** `tests/public_surface_helpers.py::selected_files` 内只增加 `pass`，coverage none，但该路径不是 `tests/test_*`，通用规则将其视为可被 opaque executor 消费的 Python seed，于是选出接近整个 behavioral suite 并要求两类 smoke。它是 shared executable helper，不能按 `.py` 位于 tests 下就豁免；可以后续通过已审 source/input/test/helper 契约区分真正 public-surface reader 和无关 opaque consumers。它不是 PR101 新增的扩散。

4. **PR102 真差异不是只改一个 API。** 新 `.github/workflows/release.yml`、`.github/release-surface.yml` policy 1.3.0 及新 `.github/scripts/release_public.py`，并将 shared helper 中的 public checks 移到该 checker，新增 coverage critical/正负 evidence。planner 明确因前两个未分类 authority surfaces 要求 FULL/repository；public checker 保持 impact。原始 PR102 的 98 条路径含 unbounded-resource。现阶段保留 fallback 正确；未来需要明确 release workflow/policy 的输入、执行权限与包/投影边界，不能临时改成 FAST 或仅按文件名减测。

5. **数字增量不是新增业务扇出。** source/shared-helper/PR102 whole-diff 候选比 accepted 各增加 48 项；对比完整 IDs，无原用例丢失，相对顺序全保留，增量属于 PR101 自身诊断/独立 witness 测试。test-only 路径只纳入其中 28 项。`REPORT.json` 的 comparisons 保存每个 added/removed ID，防止把新增测试成本误报为扇出回归。

## Actual small correct/fault execution

对候选 synthetic base 建立两个新 commit，只改变 `positive` 的 return。正确为 `return +value`，故障为 `return -value`。两个 source 差异均由实际 classifier 判断 function-body-only；选中的 B/C 和顺序完全相同。

- correct head: `2b2ecf9dfc81f1ef79991b0ca08315a6c26867b5`，source SHA256 `8722e538b9546fb9e58450f21d63425986724d2ad78c73188b81dd571f12b8ea`。
- fault head: `101169267879cad1620018cd3bb696d629621d64`，source SHA256 `862d0bd7f76c66fc50c48dc335eeb93a75f4b9a5ab2c4e642c71c074d5cb032a`。
- 未修改的现有方法 `AttestationTests.test_exact_push_attempt_and_app_bound_checks_produce_existing_source_ci_shape` 在两个 Python 的 fresh process 实际执行：正确各 PASS；故障各 ERROR，`ValueError: CI workflow identity mismatch`，exit 1。这是期望的故障捕获，原 stderr/traceback 全保留。
- 测试源码 SHA 两边相同：`d3558b41fbbe41512cfeadb817cb757016b8e8f0cb6980dde47ff60477e62e94`。使用既有离线 API fixture；没有 mock 新增测试义务、没有真实 source attestation 或 coverage gate 成功主张。单方法过程耗时约 0.16–0.19 秒不代表完整 CI 缩时。

## Next boundary

本轮不需要通过改 M14 业务代码或扩大 PR101 契约来达到 Ready。若下阶段要让 M14 函数修复真正减测，应提交单独的、base-owned 的 M14 source/input/test/helper 契约：完整 release_source_ci/preflight/public/oracle consumer 与受信 checker 字节读取闭包、imports/init/new consumer/动态调用/测试证据漂移反例、changed 100/100 和适用 critical 95/90，以及独立 accepted-base minimum witness。当前仅靠 imports 不变和函数体位置不足以证明 release 输入或外部 GitHub authority 不受影响；M14 的 transport 与 live authorization 仍归对应 owner 负责。

证据入口：`index.json` 为各 synthetic Git refs，逐情景 `plan.json`、`inventory.json`、`summary.json`、`scenario.diff`；`source-identities.json` 保存 changed blobs 与 classifier 检查，`commands/` 保存完整 subprocess argv/stdout/stderr/返回值，`analysis-commands.json` 保存只读归纳命令。clone 最终停在待审 7c2bc7 且 clean。root 同时完成已知 fingerprint 提交，所以 source-before/after head 不同；本任务在其 worktree 仅使用 read-only Git 命令，没有还原或覆盖并行修改。
