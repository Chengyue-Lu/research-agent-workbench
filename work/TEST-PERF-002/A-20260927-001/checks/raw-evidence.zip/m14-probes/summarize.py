"""Summarize preserved local evidence; no tests or remote operations."""
from __future__ import annotations
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import sys

R=Path(__file__).resolve().parent
repo=R/'clone'
sys.path.insert(0,str(repo/'.github/scripts'))
import ci_dependencies as deps
index=json.loads((R/'index.json').read_bytes())
commands=[]
def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def git(*args):
    argv=['git',*args]
    p=subprocess.run(argv,cwd=repo,capture_output=True,check=True)
    commands.append({'argv':argv,'cwd':str(repo),'returncode':p.returncode,
                     'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':p.stderr.decode('utf-8')})
    return p.stdout

cases={}
source_identities={}
for item in index['cases']:
    label=item['label']; d=R/label
    plan=json.loads((d/'plan.json').read_bytes())
    summary=json.loads((d/'summary.json').read_bytes())
    inventory=json.loads((d/'inventory.json').read_bytes())
    diff=git('diff','--binary',item['base'],item['head'])
    (d/'scenario.diff').write_bytes(diff)
    paths=git('diff','--name-only',item['base'],item['head']).decode().splitlines()
    source_identities[label]={'base':item['base'],'head':item['head'],'changed_paths':paths,
                             'diff_sha256':hashlib.sha256(diff).hexdigest(),'changed_blobs':{}}
    for p in paths:
        raw=git('show',item['head']+':'+p)
        source_identities[label]['changed_blobs'][p]=hashlib.sha256(raw).hexdigest()
    if label.startswith('source-'):
        p='.github/scripts/release_source_ci.py'
        old=git('show',item['base']+':'+p);new=git('show',item['head']+':'+p)
        source_identities[label]['function_body_only']=deps.function_body_only(old,new)
        source_identities[label]['imports_unchanged']=deps.imports(old)==deps.imports(new)
    selection=plan['selection']
    witnesses=selection.get('affected_witnesses',{})
    representative={p:w for p,w in witnesses.items() if p in {
        'src/research_workbench/cli.py','src/research_workbench/research_state/gate.py',
        'src/research_workbench/evaluation/harness_execution.py','tests/test_ci_plan.py',
        'tests/test_release_preflight.py','tests/test_release_source_ci.py','tests/test_public_surface.py',
        'tests/run_unittest_suite.py','.github/scripts/ci_checks.py'}}
    first_hops=Counter()
    for name,chain in selection.get('selected',{}).items():
        if len(chain)>1:
            first_hops[(chain[0],chain[1],selection['selected_edge_kinds'][name][0])]+=1
    facts={**{k:summary[k] for k in ('binding','plan_id','risk','behavioral_scope','coverage_scope',
             'coverage_obligations','package_smoke','repository_smoke','blocked_reasons','selection_summary',
             'reviewed_boundary','obligation_reasons','coverage_modules')},
           'test_module_count':len(plan['tests']),'coverage_module_selectors':len(plan['coverage_tests']),
           'inventory':summary['inventory'],'representative_edges':representative,
           'first_hops':[{'seed':seed,'first_consumer':consumer,'kind':kind,'selected_test_modules':n}
                         for (seed,consumer,kind),n in first_hops.most_common()]}
    cases[label]=facts

comparisons={}
for kind in ('pr102-on','source-function','test-only','shared-fixture-helper'):
    a=json.loads((R/(kind+'-accepted')/'inventory.json').read_bytes())
    p=json.loads((R/(kind+'-proposed')/'inventory.json').read_bytes())
    comparisons[kind]={}
    for scope in ('B','C'):
        old=a[scope+'_ids'];new=p[scope+'_ids']
        removed=set(old)-set(new);added=set(new)-set(old)
        comparisons[kind][scope]={'old':len(old),'new':len(new),'removed':sorted(removed),'added':sorted(added),
                                 'retained_relative_order':old==[t for t in new if t in set(old)]}
        assert not removed and comparisons[kind][scope]['retained_relative_order']

correct=json.loads((R/'source-function-proposed'/'inventory.json').read_bytes())
fault=json.loads((R/'source-fault-proposed'/'inventory.json').read_bytes())
assert correct['B_ids']==fault['B_ids'] and correct['C_ids']==fault['C_ids']
assert all(r['returncode']==0 for r in index['correct_execution']['runs'])
assert all(r['returncode']==1 for r in index['fault_execution']['runs'])
assert index['correct_execution']['tests_sha256']==index['fault_execution']['tests_sha256']
quality={epoch:hashlib.sha256(git('show',ref+':tests/coverage_policy.yaml')).hexdigest()
         for epoch,ref in [('accepted',index['accepted']),('proposed',index['proposed'])]}
# The PR101 addition retains accepted quality semantics and adds its own critical witness.
report={'status':'PASS_WITH_DOCUMENTED_RESIDUAL_PROPAGATION','scope':'Local exact-Git plan plus collection; one named real test correct/fault pair only',
        'refs':{k:index[k] for k in ('accepted','proposed','actual_m14_head','actual_m14_base')},
        'cases':cases,'comparisons':comparisons,'quality_policy_sha256':quality,
        'fault_detection':{'correct_head':index['correct_execution']['head'],'fault_head':index['fault_execution']['head'],
          'test_source_identical':True,'planned_B_C_identical':True,'correct_dual_python':'PASS',
          'fault_dual_python':'EXPECTED ERROR: CI workflow identity mismatch',
          'scope':'One unchanged test executed, using its existing API fixture. No full suite, coverage gate, or live source attestation claim.'},
        'residuals':[
          'M14 source and public_surface helper have no accepted bounded group; generic opaque execution causes near-full selected behavioral suites.',
          'Test-only CI infra closure follows content/path/dynamic-loader inputs; this is narrower than business-wide closure but remains 288/316 test cost.',
          'Actual PR102 has new release authority surfaces and critical public checker; unknown workflow/policy fallback remains required until a separately reviewed contract exists.',
          'PR101 diagnostic contracts do not prove an M14-specific complete consumer or runtime input contract.'],
        'root_source_observation':{'before':json.loads((R/'source-before.json').read_bytes()),'after':index['source_after'],
           'note':'Root concurrently committed the announced fingerprint refresh; this observer never ran a write command in root worktree. False raw before/after equality is not observer mutation.'},
        'clone_final':index['clone_final'],'remote_writes':False,'hosted_ci_triggered':False,
        'no_accepted_test_removed':True,'retained_relative_order':True}
save(R/'REPORT.json',report)
save(R/'source-identities.json',source_identities)
save(R/'analysis-commands.json',commands)

rows=[]
for label,s in cases.items():
    i=s['inventory']
    rows.append(f"| {label} | {s['behavioral_scope']} | {s['coverage_scope']} | {i['B']}/{i['C']}/{i['union']} | {s['package_smoke']}/{s['repository_smoke']} |")
text='''# M14-005 propagation audit after latest-base rebase

结论：本轮隔离对照未发现 PR101 漏选或破坏原闭包；M14 的近全量传播仍是未迁移的已知边界。PR101 的三个诊断模块契约没有获得替 M14 源码或 release authority 缩小范围的权限。全部比较保留 accepted 侧的 B/C 用例及其相对顺序。

## Exact refs and scope

- accepted develop: `97d3b3d3141419b34ad47e0f42d9f01d0dfbd535`.
- proposed PR101: `7c2bc7fc627be7b9dde02fbdc2f879d062fdee6d`; 这是待审候选，仅在本地模拟 future base，不称 accepted。
- actual PR102: `f5f663e10869c927de6d4b1e67647b4fae968b80`, original base `5bf2227ca9b4d2f63f452e579185e7838028de78`.
- `deae2679...` 尚未运行候选情景；root 通知 H4b inventory 改变后，本轮候选都等到仅刷新 fingerprint 的 `7c2bc7fc...`。前后输入事实保留。
- 所有变更与 deliberate fault 仅在 `m14-probes/clone` 普通 Git clone，push URL 指向 invalid.local；无 owner 分支写入、PR 更新、网络 API、hosted CI 或 release 动作。

## Plan and collection

以下 B/C/union 全部为实际 runner 的 `_execution_suites` / `_inventory` **收集结果**，未运行这些大套件。FULL 时按完整 discovery 收集，repository coverage 时按实际 quality union 收集；没有仅把 plan selector 数当用例数。所有 plan 的 blocked_reasons 都为空。

| Probe | Behavioral | Coverage | B/C/union collected | Package/repository smoke |
|---|---|---|---|---|
'''+ '\n'.join(rows)+'''

`pr102-on-*` 是把真实 PR102 branch 合并进本地隔离 base 后的 synthetic integration target，保留两边所有内容。不是对 owner 分支执行 rebase，也不冒充 GitHub merge target。

## Edge attribution

1. **M14 单函数修改仍近全量。** `.github/scripts/release_source_ci.py::positive` 的 `return value` 改为等价 `return +value`，imports 不变且 `function_body_only=true`。两 base 均无对应 group，`reviewed_opaque_boundary=[]`。关键链为 `release_source_ci.py → cli.py` / `research_state/gate.py` 的 **opaque-execution**，随后普通 downstream 选中业务测试；CLI 和 validation 节点进一步要求两类 smoke。accepted 侧 dependency selection 为 102 个模块，其中 90 条选中路径含 opaque；这些是无法由当前输入契约证明无关的保守边，并非证明业务直接调用 release_source_ci。它们会继续影响后续 M14 小修。

2. **普通 test-only 没有 repository coverage 和 smoke。** 对 `tests/test_release_source_ci.py` 的现有断言加入数值一元加号，不改变实际断言含义；accepted 选 14 个模块、288 项，候选 15 个模块、316 项。路径包含 `test_release_source_ci.py → test_ci_plan.py`，以及 `test_release_source_ci.py → run_unittest_suite.py → ci_checks.py → test_release_preflight.py`，均标为 syntax-reference。测试加载、输入内容/路径和 CI 元测试的 conservative dependency 仍会传递；此次没有 opaque 或 unbounded-resource，也没有扩到业务全集。不能把 316 项统称纯业务回归必要最小值；CI 工具读取输入与执行消费之间的类型契约仍是后续成本项。

3. **共享 fixture/helper 仍有传播风险。** `tests/public_surface_helpers.py::selected_files` 内只增加 `pass`，coverage none，但该路径不是 `tests/test_*`，通用规则将其视为可被 opaque executor 消费的 Python seed，于是选出接近整个 behavioral suite 并要求两类 smoke。它是 shared executable helper，不能按 `.py` 位于 tests 下就豁免；可以后续通过已审 source/input/test/helper 契约区分真正 public-surface reader 和无关 opaque consumers。它不是 PR101 新增的扩散。

4. **PR102 真差异不是只改一个 API。** 新 `.github/workflows/release.yml`、`.github/release-surface.yml` policy 1.3.0 及新 `.github/scripts/release_public.py`，并将 shared helper 中的 public checks 移到该 checker，新增 coverage critical/正负 evidence。planner 明确因前两个未分类 authority surfaces 要求 FULL/repository；public checker 保持 impact。原始 PR102 的 98 条路径含 unbounded-resource。现阶段保留 fallback 正确；未来需要明确 release workflow/policy 的输入、执行权限与包/投影边界，不能临时改成 FAST 或仅按文件名减测。

5. **数字增量不是新增业务扇出。** source/shared-helper/PR102 whole-diff 候选比 accepted 各增加 48 项；对比完整 IDs，无原用例丢失，相对顺序全保留，增量属于 PR101 自身诊断/独立 witness 测试。test-only 路径只纳入其中 28 项。`REPORT.json` 的 comparisons 保存每个 added/removed ID，防止把新增测试成本误报为扇出回归。

## Actual small correct/fault execution

对候选 synthetic base 建立两个新 commit，只改变 `positive` 的 return。正确为 `return +value`，故障为 `return -value`。两个 source 差异均由实际 classifier 判断 function-body-only；选中的 B/C 和顺序完全相同。

- correct head: `2b2ecf9dfc81f1ef79991b0ca08315a6c26867b5`，source SHA256 `8722e538b9546fb9e58450f21d63425986724d2ad78c73188b81dd571f12b8ea`。
- fault head: `101169267879cad1620018cd3bb696d629621d64`，source SHA256 `862d0bd7f76c66fc50c48dc335eeb93a75f4b9a5ab2c4e642c71c074d5cb032a`。
- 未修改的现有方法 `AttestationTests.test_exact_push_attempt_and_app_bound_checks_produce_existing_source_ci_shape` 在两个 Python 的 fresh process 实际执行：正确各 PASS；故障各 ERROR，`ValueError: CI workflow identity mismatch`，exit 1。这是期望的故障捕获，原 stderr/traceback 全保留。
- 测试源码 SHA 两边相同：`d3558b41fbbe41512cfeadb817cb757016b8e8f0cb6980dde47ff60477e62e94`。使用既有离线 API fixture；没有 mock 新增测试义务、没有真实 source attestation 或 coverage gate 成功主张。单方法过程耗时约 0.16–0.19 秒不代表完整 CI 缩时。

## Next boundary

本轮不需要通过改 M14 业务代码或扩大 PR101 契约来达到 Ready。若下阶段要让 M14 函数修复真正减测，应提交单独的、base-owned 的 M14 source/input/test/helper 契约：完整 release_source_ci/preflight/public/oracle consumer 与受信 checker 字节读取闭包、imports/init/new consumer/动态调用/测试证据漂移反例、changed 100/100 和适用 critical 95/90，以及独立 accepted-base minimum witness。当前仅靠 imports 不变和函数体位置不足以证明 release 输入或外部 GitHub authority 不受影响；M14 的 transport 与 live authorization 仍归对应 owner 负责。

证据入口：`index.json` 为各 synthetic Git refs，逐情景 `plan.json`、`inventory.json`、`summary.json`、`scenario.diff`；`source-identities.json` 保存 changed blobs 与 classifier 检查，`commands/` 保存完整 subprocess argv/stdout/stderr/返回值，`analysis-commands.json` 保存只读归纳命令。clone 最终停在待审 7c2bc7 且 clean。root 同时完成已知 fingerprint 提交，所以 source-before/after head 不同；本任务在其 worktree 仅使用 read-only Git 命令，没有还原或覆盖并行修改。
'''
(R/'REPORT.md').write_text(text,encoding='utf-8')
paths=[]
for p in sorted(R.rglob('*')):
    if not p.is_file() or 'clone' in p.relative_to(R).parts or p.name=='evidence_paths.json':
        continue
    paths.append({'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                  'bytes':p.stat().st_size})
save(R/'evidence_paths.json',{'relative_to':'m14-probes','scope':'Reports, scripts, plans, collection, source diffs/hashes, actual single-test failure and command evidence; clone/.git/generated Runtime excluded',
                            'files':paths})
print(json.dumps({'status':report['status'],'cases':len(cases),'evidence_files':len(paths),
                  'no_accepted_test_removed':True,'relative_order_preserved':True}))
