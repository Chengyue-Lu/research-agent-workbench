"""Read-only local plan and native-runner collection. Never execute collected suites."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--base', required=True)
parser.add_argument('--head', required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
repo = args.repo.resolve()
sys.path[:0] = [str(repo/'.github/scripts'), str(repo/'tests'), str(repo/'src'), str(repo)]
import plan_ci as planner
import run_unittest_suite as runner
assert planner.ROOT == runner.ROOT == repo
body = '- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no'
plan = planner.make_plan(repo, base=args.base, head=args.head, target=args.head,
                        repository='Chengyue-Lu/research-agent-workbench', body=body)
def save(name, value):
    (args.out/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
save('plan.json', plan)
inventory = {'label':'COLLECTION ONLY; no TestCase, class setup, or suite execution',
             'plan_id':plan['plan_id'], 'B_ids':[], 'C_ids':[]}
try:
    options = argparse.Namespace(plan=args.out/'plan.json', policy=repo/'tests/coverage_policy.yaml')
    b, c = runner._execution_suites(options, plan)
    inventory.update(B_ids=list(runner._inventory(b)), C_ids=list(runner._inventory(c)))
    inventory['status']='PASS'
except Exception as error:
    inventory.update(status='ERROR', error=repr(error))
b, c = inventory['B_ids'], inventory['C_ids']
inventory.update(B=len(b), C=len(c), union=len(set(b)|set(c)), C_minus_B=len(set(c)-set(b)))
save('inventory.json', inventory)
summary = {key:plan[key] for key in ('binding','plan_id','risk','behavioral_scope','coverage_scope',
           'coverage_obligations','python_versions','package_smoke','repository_smoke','blocked_reasons',
           'test_groups','tests','coverage_tests','coverage_modules','obligation_reasons','reasons')}
summary.update(inventory={key:inventory[key] for key in ('status','B','C','union','C_minus_B')},
               sources={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in (
                   '.github/scripts/plan_ci.py','.github/scripts/ci_dependencies.py',
                   'tests/ci_impact_policy.yaml','tests/coverage_policy.yaml','tests/run_unittest_suite.py')})
summary['selection_summary']=plan['selection'].get('scope_summary')
summary['reviewed_boundary']=plan['selection'].get('reviewed_opaque_boundary')
summary['opaque_consumers']=plan['selection'].get('opaque_consumers')
save('summary.json', summary)
print(json.dumps({k:summary[k] for k in ('plan_id','behavioral_scope','coverage_scope','package_smoke',
                  'repository_smoke','inventory','reviewed_boundary','blocked_reasons')}))
