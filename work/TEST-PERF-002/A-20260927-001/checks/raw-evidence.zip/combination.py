"""Scoped rebase-composition tests in a fresh exact Git checkout, both Python versions."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest

R = Path(__file__).resolve().parent
W = Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
HEAD = '7c2bc7fc627be7b9dde02fbdc2f879d062fdee6d'
BASE = '97d3b3d3141419b34ad47e0f42d9f01d0dfbd535'
SELECTORS = ['test_coverage_policy'] + ['test_ci_plan.PlannerTests.'+name for name in (
    'test_diagnostic_fixture_accepts_equivalent_negated_membership_source',
    'test_real_diagnostic_contracts_require_base_acceptance_and_complete_family_proof',
    'test_real_diagnostic_contracts_restore_scope_for_boundary_and_proof_drift',
    'test_real_diagnostic_contracts_keep_new_direct_and_opaque_consumers',
    'test_diagnostic_policy_refresh_keeps_anchor_and_retains_new_changed_consumers',
    'test_contract_evidence_requires_refreshed_accepted_anchor_after_test_review',
    'test_monotonic_local_critical_addition_has_local_proof_and_cannot_remove_old_obligations',
    'test_coverage_authority_semantics_require_repository_proof')]

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def worker(root, out):
    sys.path[:0] = [str(root/p) for p in ('', 'src', 'tests', '.github/scripts')]
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == HEAD
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromNames(SELECTORS)
    assert not loader.errors, loader.errors
    def flat(node):
        if isinstance(node, unittest.TestSuite):
            for child in node: yield from flat(child)
        else: yield node.id()
    ids = list(flat(suite)); assert len(ids)==len(set(ids))
    rows=[]
    class Result(unittest.TextTestResult):
        def addSuccess(self,test): rows.append({'id':test.id(),'outcome':'PASS'});super().addSuccess(test)
        def addFailure(self,test,err): rows.append({'id':test.id(),'outcome':'FAIL'});super().addFailure(test,err)
        def addError(self,test,err): rows.append({'id':test.id(),'outcome':'ERROR'});super().addError(test,err)
        def addSkip(self,test,reason): rows.append({'id':test.id(),'outcome':'SKIP','reason':reason});super().addSkip(test,reason)
    start=time.perf_counter()
    result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
    ok=result.wasSuccessful() and not result.skipped and len(rows)==len(ids) and all(x['outcome']=='PASS' for x in rows)
    save(out,dict(status='PASS' if ok else 'FAIL',head=HEAD,base=BASE,python=sys.version,
        captured_utc=datetime.now(timezone.utc).isoformat(),selected=SELECTORS,ids=ids,events=rows,
        count=result.testsRun,wall_seconds=time.perf_counter()-start,full_suite_proved=False,
        source_hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in
            ('tests/test_ci_plan.py','tests/test_coverage_policy.py','tests/ci_impact_policy.yaml','tests/coverage_policy.yaml',
             '.github/scripts/plan_ci.py','.github/scripts/ci_dependencies.py')}))
    return 0 if ok else 1

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--worker',action='store_true');parser.add_argument('--root',type=Path);parser.add_argument('--output',type=Path)
    a=parser.parse_args()
    if a.worker: return worker(a.root,a.output)
    out=R/'local-combination';out.mkdir(exist_ok=False);root=out/'repository'
    env={k:v for k,v in os.environ.items() if not k.startswith(('GITHUB_','COVERAGE_','PYTHON'))}
    env.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
    commands=[]
    def run(label,args,cwd=None):
        p=subprocess.run(args,cwd=cwd,env=env,capture_output=True)
        (out/(label+'.stdout.log')).write_bytes(p.stdout);(out/(label+'.stderr.log')).write_bytes(p.stderr)
        commands.append({'label':label,'args':args,'cwd':str(cwd),'exit_code':p.returncode})
        save(out/'commands.json',commands);assert p.returncode==0,label
    run('clone',['git','clone','--no-local','-c','core.longpaths=true','-c','core.autocrlf=false',str(W),str(root)])
    run('checkout',['git','checkout','--detach',HEAD],root)
    pyroot=Path('D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917')
    python=str(pyroot/'venv311/Scripts/python.exe')
    run('runtime',[python,'-X','utf8','-B','-c','from pathlib import Path;import build_backend;build_backend.generate(Path.cwd())'],root)
    processes=[]
    for version in ('311','313'):
        log=(out/f'{version}.stdout.log').open('wb');err=(out/f'{version}.stderr.log').open('wb')
        args=[str(pyroot/f'venv{version}/Scripts/python.exe'),'-X','utf8','-B',str(Path(__file__)),
              '--worker','--root',str(root),'--output',str(out/f'{version}.json')]
        processes.append((version,subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=err),log,err))
    results={}
    for version,p,log,err in processes:
        code=p.wait();log.close();err.close();results[version]={'exit_code':code,'receipt':str(out/f'{version}.json')}
    save(out/'summary.json',{'head':HEAD,'base':BASE,'status':'PASS' if all(x['exit_code']==0 for x in results.values()) else 'FAIL','results':results})
    print(json.dumps(results));return int(any(x['exit_code'] for x in results.values()))

if __name__=='__main__': raise SystemExit(main())
