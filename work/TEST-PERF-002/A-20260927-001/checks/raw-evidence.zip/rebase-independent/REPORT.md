# PR101 independent rebase/composition review

**Content preservation PASS; the original P2 fingerprint finding is closed by the exact 7c2bc7f follow-up below.** This is a read-only review of explicit rebased head `deae2679c7daba3fe23663aed65f5c8f786fb3b2` only. Later root-owned fixes are outside this disposition. No tests, candidate Python code, Git mutations, downloads, or source edits were performed.

## Exact composition

Ten commits from old head `d4e94e2db8172dade2df729a04c817d1786843e7` / base `5bf2227ca9b4d2f63f452e579185e7838028de78` were replayed onto accepted base `97d3b3d3141419b34ad47e0f42d9f01d0dfbd535`. All ten `git range-diff` rows are `=`. The saved rebase log reports a conflict-free successful replay. The new base is the exact merge base of the reviewed head.

The PR owns 76 changed paths and accepted #96 advances 59 paths. Their only overlap is `tests/ci_impact_policy.yaml` and `tests/coverage_policy.yaml`. All 74 PR-owned nonoverlap blobs and all 57 accepted nonoverlap blobs preserve their Git object identities and modes. There are no extra changed paths beyond the original PR set. All A001-A005 archive objects are byte-identical by Git identity (57 files total); historical raw evidence has not been regenerated. Local config hash `4081be99df3267b54a692bdd07570b7f31638298d22e2af89dbed4ee6827ab47` matches the saved original exactly.

The impact policy is the exact disjoint-key composition: accepted #96's consumer-contract pins are retained, while PR101's three diagnostic groups/surfaces and fingerprint key are preserved. The coverage policy preserves accepted version 2.3.2, both sides' complete suite/critical inventories in their original relative orders, and both H4b and witness positive/negative records without modification. It contains 64 critical modules. Global90, critical95/90, impact100/100, source root and all justified exclusions are unchanged.

## P2: the preserved fingerprint has no anchor after rebasing

Stored fingerprint: `6d3a6ca86db8477642481ea4d8536b077aada0d1710576edb59d071074f26bec`.

Independent recomputation for the composed 432-entry inventory: `3d1a46f8603b5b9eabb87d0e32481df1cb39efd368f385bc910faa1f5ab23b56`.

The first policy-history point `fecaf0536347e0f768f62895f016867263d1ad12` has the same authority configuration but computes the latter fingerprint, so it cannot establish the preserved fingerprint. The next point `a23441dff1017942ebea4d8e34d72c0f15ba502d` is an authority barrier. Thus no matching anchor exists in the allowable continuous authority epoch of reviewed head deae. The accepted H4b schemas/source/tests and composed coverage policy changed the fingerprint inputs. `summary.json` lists the exact affected input paths.

This is conservative failure: the planner should retain ordinary opaque-consumer closure. It is not an unauthorized reduction or loss of tests, but it prevents this rebased state from proving the intended bounded reduction. Recompute the fingerprint after the root's final source/test/policy composition; do not bypass the anchor or consumer-evidence checks. The expected value above applies only to deae's current content and must not be copied if further measured inputs change.

## Minimum follow-up checks

1. Refresh the fingerprint from the final composed Git inventory; verify an authority-compatible anchor exists and that source/test/policy bytes used by the calculation match the final commit. Preserve the accepted #96 consumer pin updates.
2. Run the existing three diagnostic-contract methods (27 scenarios) plus the fixed historical variant regression against the composed policy, retaining candidate-only, missing-anchor, proof drift and new-consumer fallback controls. No unrelated full local suite is justified solely by this content-equivalent replay.
3. Resolve the combined coverage suite and both new critical/positive/negative mappings, including H4b's accepted review module and PR101's witness. Check all thresholds/exclusions remain unchanged; execute only the composition-sensitive registration checks locally.
4. Obtain a fresh exact-head plan/configuration/governance and the actual accepted-base independent witness for the new target. The formal authority PR can still require FULL; do not substitute old-run results or synthetic M14/M5 probe evidence for those new target gates.

This review neither requests another human review nor authorizes merging. User authorization currently covers rebase/probes/Ready, with no merge authority. Detailed commit pairs, preserved path identities, policy records, archive identities, config hash, and the fingerprint calculation are recorded in `summary.json`.

## Exact fingerprint correction follow-up

Commit `7c2bc7fc627be7b9dde02fbdc2f879d062fdee6d` has exact parent deae and changes only `tests/ci_impact_policy.yaml`, with only its `consumer_fingerprint` field changed. Independent recomputation remains `3d1a46f8603b5b9eabb87d0e32481df1cb39efd368f385bc910faa1f5ab23b56` over the same 432 inventory entries and now equals the stored field. This commit is the first authority-compatible policy-history point and itself supplies a matching proposed-head anchor. Policy SHA256 is `f60a7c2d2667aab214a32f190d1ed932f8e08fab7ad8b92266864aafa350a971`. All preceding composition/preservation results therefore remain applicable, and the deae fingerprint finding is closed. Its original failed state remains recorded above and in the original `fingerprint_finding` object.

This does not make proposed 7c2 an accepted production base. Actual accepted base remains97d3; formal PR obligations continue to come from that base. No tests or candidate code were executed for this follow-up.

For the root's bounded dual-Python composition check, the four diagnostic methods are the three existing `test_real_diagnostic_contracts_*` methods plus `test_diagnostic_fixture_accepts_equivalent_negated_membership_source`. Add these targeted controls rather than rerunning unchanged business suites locally:

- `test_ci_plan.PlannerTests.test_diagnostic_policy_refresh_keeps_anchor_and_retains_new_changed_consumers`
- `test_ci_plan.PlannerTests.test_missing_or_unmatched_anchor_history_retains_conservative_scope`
- `test_ci_consumer_contracts.ConsumerContractTests.test_policy_v1_v2_and_live_records_preserve_explicit_version_boundary`
- `test_ci_consumer_contracts.ConsumerContractTests.test_candidate_rewrite_removal_and_new_record_never_become_base_authority`
- `test_coverage_policy.CoveragePolicyCheckerTests.test_repository_policy_covers_bounded_capability_validation_surfaces`
- `test_coverage_policy.CoveragePolicyCheckerTests.test_policy_cannot_downgrade_the_quality_floor`

These ten selected methods target the changed inventory/anchor and the combined registration semantics. The accepted H4b and original PR nonoverlap implementation bytes were preserved, so fresh local reruns of all their behavioral suites are unnecessary solely for this rebase. The new actual hosted plan still determines its own required full/focused/coverage/smoke execution.
