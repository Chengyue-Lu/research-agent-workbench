"""Freeze scoped reduction implementation and retained real experiment evidence."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

R = Path(__file__).resolve().parent
W = Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
BASE = '5bf2227ca9b4d2f63f452e579185e7838028de78'
IMPL = json.loads((R/'implementation.json').read_bytes())['head']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip() == IMPL
security = json.loads((R/'minimum-witness/final-security/summary.json').read_bytes())
assert security['status'] == 'PASS-local'
assert security['python311_tests'] == security['python313_tests'] == 17
assert not security['coverage']['missing_lines'] and not security['coverage']['missing_branches']
for name, value in security['source_sha256'].items():
    assert sha(W/name) == value
contracts = json.loads((R/'contract-regressions/summary.json').read_bytes())
for name, value in contracts['owned_files'].items():
    assert sha(W/name) == value
assert (R/'minimum-witness-review/FOLLOWUP.md').is_file()
assert (R/'contract-regressions/count-closure/summary.json').is_file()
assert (R/'hosted-probe-review/FINAL.json').is_file()
A = W/'work/TEST-PERF-002/A-20260926-004'
C = A/'checks'
C.mkdir(parents=True, exist_ok=False)
paths = [R/name for name in ('implementation.json','staged-composition.json','policy-before.json','freeze.py')]
for name in ('design','consumers','minimum-witness','minimum-witness-review','contract-regressions',
             'group-prototype','hosted-probe','hosted-probe-review','registration-checks'):
    paths += [p for p in (R/name).rglob('*') if p.is_file()
              and not any(x in {'clone','repositories','__pycache__','.git'} for x in p.relative_to(R/name).parts)]
paths = sorted(set(paths))
assert sum(p.stat().st_size for p in paths) < 60 * 1024 * 1024
with zipfile.ZipFile(C/'raw-evidence.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for path in paths:
        archive.write(path,path.relative_to(R).as_posix())
(C/'manifest.json').write_text(json.dumps({p.relative_to(R).as_posix():sha(p) for p in paths},indent=2)+'\n',encoding='utf-8')
summary = {'status':'PASS-local-scoped-with-retained-negative-results','base':BASE,'implementation':IMPL,
    'witness':security,'contracts':contracts,
    'count_fault_closure':json.loads((R/'contract-regressions/count-closure/summary.json').read_bytes()),
    'local_reduced_union':[20,9,25], 'old_same_source_union':1510,
    'local_producer_seconds':[33.78,12.94,38.75],
    'hosted_execution_proved':False,'hosted_speedup_proved':False,'production_reduction_activated':False,
    'checker_accepted':False,'cross_commit_reuse_activated':False,
    'independent_review_sha256':sha(R/'minimum-witness-review/FOLLOWUP.md'),
    'paired_harness_review':json.loads((R/'hosted-probe-review/FINAL.json').read_bytes()),
    'raw_evidence_sha256':sha(C/'raw-evidence.zip')}
(C/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
(A/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
(A/'RESULTS.md').write_text(f'''# Bounded diagnostic test contracts

Owner Chengyue-Lu; TEST-PERF-002; R2; Skills []. Base `{BASE}`;
implementation `{IMPL}`. The implementation reuses the existing accepted-base
function-body contract mechanism for consumer shadow, shadow pair and domain
audit. It preserves complete proof suites, authority anchors, fingerprints,
old/new consumers, evidence drift fallback and fixed quality obligations.

The new isolated minimum checker authenticates complete Git objects and exact
planner/helper sources before executing the accepted planner. It compares the
candidate against that minimum using external identities and metadata. Independent
review first found object-chain and graft weaknesses; the fixes and second review
are retained alongside the original findings. The checker is registered as selection
authority and critical95/90. Its new source measured187/187 statements and32/32
branches;17 related tests passed under each Python. Additional in-process path
measurements supplement the original real isolated CLI tests.

Three new planner tests cover27 real Git scenarios. Candidate-only contracts cannot
reduce their own plan; imports, calls, initialization, proof drift, missing anchors
and new consumers restore conservative obligations. The registration, coverage
policy and documentation check ran41 tests successfully under3.11. Existing
thresholds90/95/90, changed100/100 and exclusions are unchanged.

Under explicit **unaccepted synthetic bases**, the same-source old union1510
contracts to20,9,25. All three correct changes passed real ordered3.11 coverage
and impact checks and3.13 behavioral execution. Local producer times were about
34,13,39 seconds. The consumer/pair/domain files measured237/237+86/86,
125/125+42/42 and121/121+38/38. Each correct probe covered1/1 changed line and
0/0 outgoing changed arcs. These are local results, not a hosted speedup ratio.

Consumer union, percentage and route faults were detected. The original domain
count1-to2 mutation was missed by25 tests and impact coverage. That original
failure of detection remains in the raw archive. Explicit domain count assertions
now yield25PASS for the correct version and24PASS+1FAIL for that same Git fault
under both Python versions. Its exact original raw bytes also fail the new assertion
in fresh processes. A failed producer provides no successful impact projection.

The paired hosted harness passed an independent review and one reduced20-case
execution. It prepares identical non-policy source/test trees, authentic native
B/C/order/projections and quality evidence. Three fresh hosted pairs remain to be
executed; their timing scope excludes setup and smokes. Formal new-head CI and
post-acceptance official reduction each retain their own execution identity.

[Summary](checks/summary.json), [manifest](checks/manifest.json) and
[raw evidence](checks/raw-evidence.zip) preserve hashes, exact refs, commands,
failed attempts, faults, repairs and reviews. Older A001/A002/A003 are unchanged.
Trace capture begins at this freeze; gaps in prior tool/inter-agent events are
declared. Candidate checker pins do not establish human acceptance. No production
2C activation, cross-commit reuse, release or merge is claimed by this archive.
''',encoding='utf-8',newline='\n')
sys.path.insert(0,str(W/'src'))
from research_workbench.observability.trace import AgentTraceRecorder, validate_attempt_trace
t = AgentTraceRecorder(A,task_id='TEST-PERF-002',task_revision=48,attempt_id=A.name,
    task_snapshot={'task_id':'TEST-PERF-002','revision':48,'request':'Continue until actual test reduction',
        'scope':'bounded diagnostic contracts; independent minimum; actual fault/coverage and hosted pair preparation',
        'profile':'CI boundary engineer','required_skills':[],'delegation':True,
        'budget':'three existing family contracts and minimum witness; focused local verification and three fresh hosted pairs',
        'stop_condition':'reviewable activation evidence; formal acceptance remains external'},
    accountable_owner='Chengyue-Lu',actor_id='main-agent',runtime_identity='Codex desktop',provider='OpenAI',
    read_allowlist=['AGENTS.md','README.md','PROJECT_MEMORY.md','docs/DEVELOPMENT.md','.github/scripts/**','tests/**',
        'docs/workstreams/chengyue-lu/TEST-PERF-002/**','work/TEST-PERF-002/**'],
    write_scope=['.github/scripts/ci_minimum_witness.py','.github/scripts/plan_ci.py','.github/scripts/selection_witness.py',
        'tests/test_ci_minimum_witness.py','tests/test_ci_plan.py','tests/test_ci_domain_audit.py',
        'tests/test_selection_witness.py','tests/ci_impact_policy.yaml','tests/coverage_policy.yaml',
        'docs/workstreams/chengyue-lu/TEST-PERF-002/**','work/TEST-PERF-002/A-20260926-004/**'],
    tool_allowlist=['collaboration','shell','git','gh','python'],baseline=BASE)
t.record_capture_gap('messages','Written independent reviews and raw checks retained; earlier tool/inter-agent events are not a complete continuous capture.')
t.record_capture_gap('external-actions','Final committed-head validation, publication and hosted pairs occur after this sealed local record.')
t.record_tool_call(operation_id='freeze-diagnostic-contract-proof',tool_name='python',status='succeeded',
    arguments={'operation':'freeze implementation and real fault/correct execution, source review and coverage'},
    result={'implementation':IMPL,'summary_sha256':sha(C/'summary.json')},result_entered_context=True)
t.seal('safe-paused')
v=validate_attempt_trace(W,A)
(C/'trace-validation.json').write_text(json.dumps({'blocked':v.blocked,'risks':[asdict(x) for x in v.risks]},indent=2)+'\n',encoding='utf-8')
assert not v.blocked
print(json.dumps({'archive':str(A.relative_to(W)),'files':len(paths),'zip_bytes':(C/'raw-evidence.zip').stat().st_size,'blocked':v.blocked}))
