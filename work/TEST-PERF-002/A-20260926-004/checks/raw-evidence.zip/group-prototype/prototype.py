"""Local synthetic-base experiment. Never publish any generated ref or policy."""
from __future__ import annotations
import ast
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

OUT = Path(__file__).resolve().parent
SOURCE = Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
REPO = OUT / 'clone'
ORIGINAL = '8d94296c2fffe5bc7baf738e603376388fa24c59'
BODY = '- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no'

def command(*args, cwd=REPO):
    return subprocess.check_output(list(args), cwd=cwd, stderr=subprocess.STDOUT).decode().strip()

def git(*args):
    return command('git', '-c', 'core.hooksPath=NUL', *args)

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def commit(message, paths):
    git('add', '--', *paths)
    git('-c', 'user.name=CI Local Prototype', '-c', 'user.email=ci-prototype@invalid.local', 'commit', '-m', message)
    return git('rev-parse', 'HEAD')

def inventory(plan):
    # Collection only: no TestCase, setUp, setUpClass, or suite is run.
    loader = unittest.TestLoader()
    def expand(names):
        suite = loader.loadTestsFromNames(names)
        if loader.errors:
            raise ValueError(loader.errors)
        def walk(item):
            if isinstance(item, unittest.TestSuite):
                for child in item:
                    yield from walk(child)
            else:
                yield item.id()
        ids = list(walk(suite))
        assert len(ids) == len(set(ids)), 'duplicate collection'
        return ids
    b = expand(plan['tests']) if plan['behavioral_scope'] != 'none' else []
    c = expand(plan['coverage_tests']) if plan['coverage_obligations'] else []
    return {'scope': 'collection only; no execution proof', 'B': len(b), 'C': len(c),
            'union': len(set(b) | set(c)), 'B_ids': b, 'C_ids': c}

def main():
    assert not REPO.exists(), 'Refuse to overwrite previous prototype'
    command('git', 'clone', '--no-hardlinks', '--no-checkout', str(SOURCE), str(REPO), cwd=OUT)
    git('checkout', '--detach', ORIGINAL)
    sys.path[:0] = [str(REPO / '.github/scripts'), str(REPO / 'tests'), str(REPO / 'src'), str(REPO)]
    import plan_ci as planner
    import ci_dependencies as deps
    assert planner.ROOT == REPO
    path = 'tests/ci_impact_policy.yaml'
    original_policy = json.loads((REPO/path).read_bytes())
    policy = json.loads(json.dumps(original_policy))
    specs = {
        'consumer-shadow': {
            'file': '.github/scripts/ci_consumer_shadow.py',
            'tests': ['test_ci_consumer_shadow', 'test_ci_shadow_pair'],
            'positive': 'test_ci_consumer_shadow.ConsumerGitTests.test_real_git_proposal_drift_membership_and_overlapping_consumers',
            'negative': 'test_ci_consumer_shadow.ConsumerOutcomeTests.test_malformed_or_rebound_inputs_are_rejected',
            'before': 'if identity not in seen]', 'after': 'if identity in seen]'},
        'shadow-pair': {
            'file': '.github/scripts/ci_shadow_pair.py', 'tests': ['test_ci_shadow_pair'],
            'positive': 'test_ci_shadow_pair.PairedExecutionTests.test_identical_complete_orders_allow_same_native_invocation',
            'negative': 'test_ci_shadow_pair.PairedExecutionTests.test_changed_behavioral_or_coverage_order_requires_distinct_driver_roles',
            'before': '(a-b)/a*100 if a else None', 'after': '(a-b)/a*99 if a else None'},
        'domain-audit': {
            'file': '.github/scripts/ci_domain_audit.py',
            'tests': ['test_ci_domain_audit', 'test_ci_consumer_shadow', 'test_ci_shadow_pair'],
            'positive': 'test_ci_domain_audit.DomainModelTests.test_named_repository_model_satisfies_official_validator',
            'negative': 'test_ci_domain_audit.DomainModelTests.test_declarations_cannot_add_authority_or_hide_unknown_protocols',
            'before': "counts[match['domain']] += 1", 'after': "counts[match['domain']] += 2"}}
    for name, spec in specs.items():
        group = 'diagnostic-' + name + '-local-function'
        policy['surfaces'][group] = {'paths': [spec['file']], 'class': 'focused', 'groups': [group]}
        policy['groups'][group] = {'tests': spec['tests'], 'downstream': [], 'coverage': [spec['file']],
             'coverage_tests': spec['tests'], 'change_scope': 'function-body', 'package': False,
             'repository': False, 'impact_evidence': {'positive_tests': [spec['positive']], 'negative_tests': [spec['negative']]}}
    leaves = {p for g in policy['groups'].values() for p in g['coverage']}
    policy['consumer_fingerprint'] = planner.consumer_fingerprint(REPO, ORIGINAL, leaves)
    planner.validate_policy(policy)
    for key in original_policy:
        if key not in {'surfaces', 'groups', 'consumer_fingerprint'}:
            assert original_policy[key] == policy[key]
    for key in ('surfaces', 'groups'):
        assert all(policy[key][name] == value for name, value in original_policy[key].items())
    (REPO/path).write_text(json.dumps(policy, indent=2) + '\n', encoding='utf-8')
    synthetic = commit('EXPERIMENT ONLY: synthetic future diagnostic contract base', [path])
    git('branch', 'synthetic-unaccepted-base', synthetic)
    save('synthetic-policy.json', policy)
    summary = {'warning': 'SYNTHETIC UNACCEPTED POLICY; NOT CURRENT PR OR HOSTED EVIDENCE',
               'original': ORIGINAL, 'synthetic_base': synthetic, 'cases': []}
    def plan_case(label, base, head, function_body=None):
        plan = planner.make_plan(REPO, base=base, head=head, target=head,
                     repository='Chengyue-Lu/research-agent-workbench', body=BODY)
        save(label + '-plan.json', plan)
        facts = inventory(plan)
        save(label + '-inventory.json', facts)
        row = {'label': label, 'base': base, 'head': head, 'plan_id': plan['plan_id'],
               'function_body_only': function_body,
               'risk': plan['risk'], 'behavioral_scope': plan['behavioral_scope'],
               'coverage_scope': plan['coverage_scope'], 'package_smoke': plan['package_smoke'],
               'repository_smoke': plan['repository_smoke'], 'blocked': plan['blocked_reasons'],
               'B': facts['B'], 'C': facts['C'], 'union': facts['union'],
               'B_selectors': plan['tests'], 'C_selectors': plan['coverage_tests'],
               'opaque_residual': plan.get('selection', {}).get('opaque_consumers'),
               'bounded': plan.get('selection', {}).get('reviewed_opaque_boundary'),
               'anchor': plan.get('selection', {}).get('reviewed_contract_anchor'),
               'reasons': plan.get('reasons'), 'obligation_reasons': plan.get('obligation_reasons')}
        summary['cases'].append(row)
        save('summary.json', summary)
        print(json.dumps({k: row[k] for k in ('label','head','behavioral_scope','coverage_scope','B','C','union','package_smoke','repository_smoke','bounded')}), flush=True)
    for name, spec in specs.items():
        for base_name, base in [('existing', ORIGINAL), ('synthetic', synthetic)]:
            git('checkout', '--detach', base)
            file = REPO/spec['file']; old = file.read_text(encoding='utf-8')
            assert old.count(spec['before']) == 1
            new = old.replace(spec['before'], spec['after'])
            assert deps.function_body_only(old.encode(), new.encode()), name
            file.write_text(new, encoding='utf-8')
            head = commit('EXPERIMENT ONLY: intentional wrong local ' + name, [spec['file']])
            label = name + '-' + base_name
            git('branch', label, head)
            plan_case(label, base, head, True)
    git('checkout', '--detach', synthetic)
    file = REPO/'.github/scripts/plan_ci.py'
    old = file.read_text(encoding='utf-8'); assert old.count('ANCHOR_HISTORY_LIMIT = 64') == 1
    file.write_text(old.replace('ANCHOR_HISTORY_LIMIT = 64', 'ANCHOR_HISTORY_LIMIT = 63'), encoding='utf-8')
    head = commit('EXPERIMENT ONLY: selection authority self-change control', ['.github/scripts/plan_ci.py'])
    git('branch', 'authority-control', head)
    plan_case('authority-control', synthetic, head, False)
    assert summary['cases'][-1]['behavioral_scope'] == 'full'
    git('checkout', '--detach', synthetic)
    save('preservation.json', {'original': ORIGINAL, 'synthetic_base': synthetic,
         'only_policy_changed': git('diff', '--name-only', ORIGINAL, synthetic) == path,
         'coverage_policy_unchanged': git('rev-parse', ORIGINAL+':tests/coverage_policy.yaml') == git('rev-parse', synthetic+':tests/coverage_policy.yaml'),
         'remote_written': False, 'behavioral_tests_run': False, 'clone_clean': not git('status', '--porcelain')})

if __name__ == '__main__':
    main()
