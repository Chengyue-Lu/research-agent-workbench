"""Run isolated unaccepted-contract probes; never push or overwrite old evidence."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
REPO=ROOT/'clone'
BASE='0e712d5039232860a51f97b1d43857b76f6e98f1'
PY={'311':'D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917/venv311/Scripts/python.exe',
    '313':'D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917/venv313/Scripts/python.exe'}
BODY='- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no'
ENV=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1', PYTHONPATH=os.pathsep.join(map(str,(REPO/'src',REPO,REPO/'.github/scripts'))))
for key in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):
    ENV.pop(key,None)

def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def git(*args):
    return subprocess.check_output(['git','-c','core.hooksPath=NUL',*args],cwd=REPO,env=ENV,stderr=subprocess.STDOUT).decode().strip()

def step(directory,name,args,env):
    started=time.perf_counter()
    with (directory/(name+'.log')).open('wb') as log:
        result=subprocess.run(args,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
    fact={'argv':args,'returncode':result.returncode,'wall_seconds':time.perf_counter()-started}
    save(directory/(name+'.json'),fact)
    return fact

def run_probe(label,head,plan,kind,python='311'):
    directory=OUT/(label+'-'+python)
    assert not directory.exists(), 'Never overwrite retained run'
    directory.mkdir()
    git('checkout','--detach',head)
    env=dict(ENV,COVERAGE_FILE=str(directory/'.coverage'))
    identity={'head':head,'base':BASE,'plan_id':json.loads(plan.read_bytes())['plan_id'],
       'kind':kind,'python':subprocess.check_output([PY[python],'-VV'],env=env).decode().strip(),
       'python_executable':PY[python],'pythonpath':env['PYTHONPATH'],
       'sources':{p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in (
          '.github/scripts/ci_consumer_shadow.py','.github/scripts/ci_shadow_pair.py','.github/scripts/ci_domain_audit.py',
          '.github/scripts/plan_ci.py','.github/scripts/ci_checks.py','tests/run_unittest_suite.py','tests/ci_impact_policy.yaml','tests/coverage_policy.yaml')},
       'scope':'local synthetic unaccepted contract; actual execution; not hosted proof'}
    save(directory/'identity.json',identity)
    records={}
    if python=='311':
        config=directory/'coverage.ini'
        records['configure']=step(directory,'configure',[PY[python],'.github/scripts/ci_checks.py','configure','--plan',str(plan),'--config',str(config)],env)
        if records['configure']['returncode']==0:
            records['producer']=step(directory,'producer',[PY[python],'-m','coverage','run','--rcfile='+str(config),
               'tests/run_unittest_suite.py','--suite','coverage-execution','--plan',str(plan),
               '--json-output',str(directory/'execution.json'),'--coverage-results',str(directory/'impact-results.json'),
               '--verbosity','1'],env)
            records['coverage_json']=step(directory,'coverage-json',[PY[python],'-m','coverage','json','--rcfile='+str(config),'-o',str(directory/'coverage.json')],env)
            if (directory/'impact-results.json').exists():
                records['impact']=step(directory,'impact',[PY[python],'.github/scripts/ci_checks.py','impact','--plan',str(plan),
                    '--coverage',str(directory/'coverage.json'),'--results',str(directory/'impact-results.json')],env)
    else:
        records['behavioral']=step(directory,'behavioral',[PY[python],'tests/run_unittest_suite.py','--suite','focused',
           '--plan',str(plan),'--json-output',str(directory/'execution.json'),'--verbosity','1'],env)
    summary={'identity':identity,'steps':records}
    if (directory/'execution.json').exists():
        receipt=json.loads((directory/'execution.json').read_bytes())
        summary['execution']={k:receipt.get(k) for k in ('test_count','successful','events','wall_seconds','execution')}
        summary['failures']=[{'id':t['id'],'outcome':t['outcome']} for t in receipt['tests'] if t['outcome']!='passed']
    if (directory/'coverage.json').exists():
        c=json.loads((directory/'coverage.json').read_bytes())
        summary['coverage']={k:v['summary'] for k,v in c['files'].items()}
    save(directory/'summary.json',summary)
    print(json.dumps({'label':label,'python':python,'steps':{k:v['returncode'] for k,v in records.items()},
          'test_count':summary.get('execution',{}).get('test_count'),'failures':summary.get('failures',[])},ensure_ascii=False),flush=True)
    return summary

def main():
    assert not (OUT/'index.json').exists()
    original=json.loads((ROOT/'summary.json').read_bytes())
    index={'scope':'unaccepted synthetic contracts; intentional faults remain local','base':BASE,'runs':[],'correct_refs':{}}
    for row in original['cases']:
        if row['label'].endswith('-synthetic'):
            summary=run_probe(row['label']+'-fault',row['head'],ROOT/(row['label']+'-plan.json'),'intentional fault')
            index['runs'].append({'label':row['label']+'-fault','python':'311','head':row['head'],'steps':{k:v['returncode'] for k,v in summary['steps'].items()}})
            save(OUT/'index.json',index)
    git('checkout','--detach',BASE)
    sys.path.insert(0,str(REPO/'.github/scripts'))
    import plan_ci as planner
    import ci_dependencies as deps
    edits={'consumer-shadow':('.github/scripts/ci_consumer_shadow.py','if identity not in seen]','if not identity in seen]'),
       'shadow-pair':('.github/scripts/ci_shadow_pair.py','(a-b)/a*100 if a else None','(a-b)/a*100.0 if a else None'),
       'domain-audit':('.github/scripts/ci_domain_audit.py',"counts[match['domain']] += 1","counts[match['domain']] += +1")}
    for label,(name,before,after) in edits.items():
        git('checkout','--detach',BASE)
        path=REPO/name;old=path.read_text(encoding='utf-8');assert old.count(before)==1
        new=old.replace(before,after);assert deps.function_body_only(old.encode(),new.encode())
        path.write_text(new,encoding='utf-8');git('add','--',name)
        git('-c','user.name=CI Local Prototype','-c','user.email=ci-prototype@invalid.local','commit','-m','EXPERIMENT ONLY: equivalent '+label+' expression')
        head=git('rev-parse','HEAD');git('branch',label+'-equivalent',head)
        plan=planner.make_plan(REPO,base=BASE,head=head,target=head,repository='Chengyue-Lu/research-agent-workbench',body=BODY)
        plan_path=OUT/(label+'-equivalent-plan.json');save(plan_path,plan)
        index['correct_refs'][label]={'head':head,'plan_id':plan['plan_id'],'before':before,'after':after}
        for python in ('311','313'):
            summary=run_probe(label+'-equivalent',head,plan_path,'semantic-equivalent expression',python)
            index['runs'].append({'label':label+'-equivalent','python':python,'head':head,'steps':{k:v['returncode'] for k,v in summary['steps'].items()}})
            save(OUT/'index.json',index)
            if any(x['returncode']!=0 for x in summary['steps'].values()):
                break
    git('checkout','--detach',BASE)
    index['final_clone_head']=git('rev-parse','HEAD');index['clone_clean']=not git('status','--porcelain')
    save(OUT/'index.json',index)

if __name__=='__main__':
    main()
