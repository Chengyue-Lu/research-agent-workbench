# Reduced-contract actual execution probes

2026-09-26. The three proposed small diagnostic contracts have now been exercised using real selected tests and the repository's native producer/checker, with independently started Python processes. Correct expressions pass in both Python versions and all three sensitive fault classes are detected. One additional mutation exposed a genuine assertion gap, retained below.

**Scope:** all probes use synthetic, unaccepted policy base `0e712d5039232860a51f97b1d43857b76f6e98f1` in the isolated `group-prototype/clone`. No policy or fault was pushed. These are local actual executions, not the current PR's official CI, not accepted exclusion authority, and not hosted speed comparisons. No 1510-case baseline was rerun.

## Correct reduced execution

| Module | B / C / union (3.11 producer) | 3.11 runner wall | 3.13 behavioral wall | Subject lines | Subject branches | Impact checker |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| consumer shadow | 20 / 20 / 20 | 33.775438 s | 24.698404 s (20 tests) | 237/237 | 86/86 | PASS |
| shadow pair | 9 / 9 / 9 | 12.938757 s | 6.777098 s (9 tests) | 125/125 | 42/42 | PASS |
| domain audit | 25 / 25 / 25 | 38.745169 s | 28.165790 s (25 tests) | 121/121 | 38/38 | PASS |

All six correct runs have zero failures/errors/skips. Each 3.11 plan retains `focused/impact` with neither smoke required, and the unchanged `ci_checks.py impact` command passes with its exact producer projection and coverage artifact. Each probe has one changed executable line, covered 1/1; no outgoing coverage branch is attributed to that edited line (0/0, not an invented nonzero branch proof). Entire subject line and branch coverage is 100% as shown. These diagnostic files are not presently critical-inventory subjects; no unrelated repository-wide coverage proof is claimed.

The Python 3.11 runs use `coverage run --rcfile=<generated config> tests/run_unittest_suite.py --suite coverage-execution`, preserving native ordered behavioral execution and coverage projection. Python 3.13 runs use native `focused` behavioral execution, matching the repository's split responsibilities; the native ordered coverage producer deliberately requires Python 3.11. Full declared modules are selected, with no mocked replacement of their existing real subprocess/fixture/producer work. Existing test implementation and fixtures were not changed.

Correct exact heads and expression changes:

- Consumer: `468ab514dde242e5ac9a73628ca388c31da70728`, `identity not in seen` → `not identity in seen`.
- Pair: `7b09226f5e7df967b5357e48567381e9afbcd452`, arithmetic multiplier `100` → `100.0` in the already floating-point percentage expression.
- Domain: `bdb4329c43b8d89e6accac333f4bb7b50643d456`, integer increment `1` → `+1`.

Each is a non-comment AST change accepted by the existing function-body boundary guard. Corresponding plans, native source/coverage receipts and checked Git identities are retained under `*-equivalent-plan.json` and the six `*-equivalent-311/313` directories. `correct-metrics.json` includes exact counts, changed-line/branch denominators and measured timings.

## Fault sensitivity and one retained miss

| Fault | Exact local head | Reduced actual result | Runner wall |
| --- | --- | --- | ---: |
| Consumer union retains duplicate members and drops new members (`not in` → `in`) | `2113a1ba5d204b4ed512675cab8bdd456cff3726` | 20 attempted; 6 failures + 2 errors; producer exit1 | 29.028732 s |
| Pair percentage multiplier100 →99 | `fab8816b1e3127dfbc651c8981f63626f5f6fd60` | 9 attempted; 1 failure; producer exit1 | 12.741069 s |
| Domain count increment1 →2 | `1ce53f031822fd318cb48d46d55d42c0754b5b68` | **25 PASS and impact PASS: missed mutation** | 37.865762 s |
| Additional domain route predicate inversion | `f686dbc7e1d278104f2b2c7152c8b2f10f480c61` | 25 attempted; 2 failures; producer exit1 | 36.076076 s |

The original domain count-mutation miss is preserved unchanged in `domain-audit-synthetic-fault-311`, including native receipt and coverage. It measured **121/121 lines and 38/38 branches** despite incorrect aggregate counts. This is direct evidence that executing a line does not establish its numerical meaning. It must not be summarized as a successful fault-detection result, nor does this experiment establish whether a full-suite run would catch it elsewhere.

The supplemental route fault is separate evidence, not a replacement for the miss. It negates the `routes()` matching predicate and fails:

- `DomainGitTests.test_real_git_archive_routing_keeps_execution_and_ignores_worktree_rewrite`.
- `DomainModelTests.test_overlapping_runtime_document_is_not_collapsed_into_docs`.

The pair multiplier is caught by `PairedExecutionTests.test_actual_wall_pair_keeps_coverage_and_distinguishes_phase_movement`; its whole-file coverage remained100% while the behavioral assertion failed. Consumer failures include real-Git membership, fixture phase movement, driver roles and lifecycle completeness. Failing producers retain raw coverage but do not emit successful impact projections or proceed to an impact PASS.

Recommended narrow follow-up is an explicit domain-count assertion with a hand-computed small inventory containing unmatched, single-domain and overlapping-domain paths. Assert per-domain counts (including zero or missing-domain conventions) and the tracked inventory total. Retest the original +2 fault against that added assertion while preserving this first miss. No tests or expected outputs were modified during this experiment.

## Environment, provenance and cost limits

Each `run_probe` starts independent subprocesses after checking out the exact committed source, sets a clone-only `PYTHONPATH` containing clone `src`, repository root and `.github/scripts`, and disables bytecode output. Therefore no previously imported diagnostic module in the orchestration process supplies test implementation. Each `identity.json` records Python executable/version and exact SHA256 for diagnostic source, planner, checker, native runner and both policies; each step retains argv, return code, elapsed command time and raw log. Successful native receipts carry exact plan ID, target, behavioral order and coverage order.

Environment: Python3.11.16 and3.13.15 on Windows build26200; coverage7.16.1, PyYAML6.0.3, jsonschema4.26.0, hypothesis6.168.0, setuptools79.0.1. Full observed interpreter-reported values are in `environment.json`; no credentials or arbitrary process environment was captured.

`execute.py` and `supplement_domain_fault.py` are local orchestration scripts; neither overwrites original prototype plans/refs/inventories. Final clone returns clean to the synthetic policy base, and no background process remains. No acceptance/merge, production2C, cross-commit result reuse, release/tag/main or remote state was changed.

The times above are actual per-run local runner walls, excluding configuration and coverage/checker postprocessing. They establish that the selected proof can execute in seconds locally and can catch representative faults. They do not establish a statistically controlled or hosted speedup against the prior37-minute CI. Actual policy acceptance, independent review, and fresh hosted pair evidence remain coordinator-owned next steps.
