"""Additional sensitive fault after preserving the original count-mutation miss."""
import sys
import execute as e

e.git('checkout','--detach',e.BASE)
sys.path.insert(0,str(e.REPO/'.github/scripts'))
import ci_dependencies as deps
import plan_ci as planner
path=e.REPO/'.github/scripts/ci_domain_audit.py'
old=path.read_text(encoding='utf-8')
before='if any(fnmatchcase(path, pattern) for key in PATTERNS for pattern in domain[key])]'
after='if not any(fnmatchcase(path, pattern) for key in PATTERNS for pattern in domain[key])]'
assert old.count(before)==1
new=old.replace(before,after)
assert deps.function_body_only(old.encode(),new.encode())
path.write_text(new,encoding='utf-8')
e.git('add','--','.github/scripts/ci_domain_audit.py')
e.git('-c','user.name=CI Local Prototype','-c','user.email=ci-prototype@invalid.local','commit','-m','EXPERIMENT ONLY: sensitive domain route inversion')
head=e.git('rev-parse','HEAD')
e.git('branch','domain-sensitive-fault',head)
plan=planner.make_plan(e.REPO,base=e.BASE,head=head,target=head,repository='Chengyue-Lu/research-agent-workbench',body=e.BODY)
plan_path=e.OUT/'domain-sensitive-fault-plan.json'
assert not plan_path.exists()
e.save(plan_path,plan)
summary=e.run_probe('domain-sensitive-fault',head,plan_path,'additional intentional route inversion fault')
e.save(e.OUT/'domain-sensitive-fault-result.json',{'head':head,'plan_id':plan['plan_id'],'before':before,'after':after,
    'steps':{k:v['returncode'] for k,v in summary['steps'].items()},'execution':summary.get('execution'),'failures':summary.get('failures')})
e.git('checkout','--detach',e.BASE)
