# Offline diagnostic group prototype

2026-09-26. Result: the existing accepted-base group/function-body/fingerprint-anchor mechanism can sharply reduce the **complete planned B/C union** for bounded local changes to the three diagnostic modules. No new dependency algorithm was required for this experiment.

**All added policy is synthetic and unaccepted. No generated commit or policy was pushed. These are planner and collection results, not executed-test/coverage proof, not a current PR plan, and not an observed CI speedup.**

## Inputs and isolation

- Content source: PR101 `8d94296c2fffe5bc7baf738e603376388fa24c59`.
- Ordinary independent Git clone: `D:/lcy/develop/_assessments/rwb-ci-reduction-20260926/group-prototype/clone` (`--no-hardlinks`, not a worktree).
- Reproducible script: `prototype.py`, SHA256 `b884eed9a75d073b44c55240f2454cf198347839d0f86089687d464f4839b5fc`. Script refuses to overwrite an existing experiment clone.
- Synthetic future-base commit: `0e712d5039232860a51f97b1d43857b76f6e98f1`, branch `synthetic-unaccepted-base`.
- Prototype base differs from the source commit in **only** `tests/ci_impact_policy.yaml`. All old surfaces/groups and all other policy fields retain their exact values. Added three surfaces/groups and refreshed the synthetic consumer fingerprint using the existing helper. `tests/coverage_policy.yaml` retains its exact Git blob; thresholds, exclusions and negative-acceptance inventory remain unchanged.
- `preservation.json` records those assertions and clean final clone status. No main worktree or remote writes occurred.

## Complete plan and collection comparison

The same intentional function-local change was committed independently over the source base and over the synthetic policy base. Each change passes the existing `ci_dependencies.function_body_only` guard; no strings, imports, callable boundaries, initialization or fixtures were changed. Each plan uses `target=head`, exact Git refs and R2 governance metadata.

| Source changed | Policy base | Behavioral | Coverage | B | C | B∪C | Package | Repository |
| --- | --- | --- | --- | ---: | ---: | ---: | --- | --- |
| consumer shadow | Existing | focused | impact | 1510 | 1484 | 1510 | yes | yes |
| consumer shadow | Synthetic | focused | impact | 20 | 20 | 20 | no | no |
| shadow pair | Existing | focused | impact | 1510 | 1484 | 1510 | yes | yes |
| shadow pair | Synthetic | focused | impact | 9 | 9 | 9 | no | no |
| domain audit | Existing | focused | impact | 1510 | 1484 | 1510 | yes | yes |
| domain audit | Synthetic | focused | impact | 25 | 25 | 25 | no | no |
| planner authority self-change | Synthetic | **full** | impact | 1510 | 1484 | 1510 | yes | yes |

All seven plans have `blocked_reasons=[]`. The three bounded synthetic plans have **zero residual opaque consumers** and identify `0e712d5...` as their matching policy anchor. Risk remains R2. The authority control retains full behavioral regression and broad impact proof; it does not falsely report repository coverage.

Counts were obtained by loading the complete plan-selected unittest names and enumerating test identities, without running suites, tests, setUp or setUpClass. Behavioral and coverage orders are saved independently in each `*-inventory.json`; full plan JSONs retain coverage modules, changed lines, positive/negative evidence, obligation reasons and graph witnesses. No claim about physical line/branch coverage follows from collecting cases.

## Added groups and proof membership

Each group uses `change_scope: function-body`, its exact diagnostic path in `coverage`, full test modules in both `tests` and `coverage_tests`, and false package/repository flags. Shared consumers are included explicitly:

- `diagnostic-consumer-shadow-local-function`: `test_ci_consumer_shadow` + `test_ci_shadow_pair` (20 collected cases).
- `diagnostic-shadow-pair-local-function`: `test_ci_shadow_pair` (9 cases).
- `diagnostic-domain-audit-local-function`: `test_ci_domain_audit` + `test_ci_consumer_shadow` + `test_ci_shadow_pair` (25 cases).

Named positive and negative evidence is included in each group using existing real tests, rather than invented selectors. The consumer group binds the real-Git proposal/membership test and malformed/rebound-input refusal; the pair group binds identical complete native ordering and changed-order driver-role refusal; the domain group binds the real repository-model validator and authority/unknown-protocol refusal. Full modules preserve all other adversarial cases, including accepted-template and actual producer-pair checks.

Prototype policy: `synthetic-policy.json`. Existing `consumer_contracts` declarations were not promoted to execution authority. This experiment uses the separate existing base-side groups mechanism.

## Exact synthetic refs and mutations

| Case | Local branch / head | Mutation |
| --- | --- | --- |
| consumer, existing base | `consumer-shadow-existing` / `28971f6781df93f6e47bb599b37ed4d5b0206e44` | `ordered_union`: `identity not in seen` → `identity in seen` |
| consumer, synthetic base | `consumer-shadow-synthetic` / `2113a1ba5d204b4ed512675cab8bdd456cff3726` | Same intentional wrong logic |
| pair, existing base | `shadow-pair-existing` / `6ce763e6d402c4d9ce9d0fc6aac46e00d2d9264f` | percentage multiplier 100 → 99 |
| pair, synthetic base | `shadow-pair-synthetic` / `fab8816b1e3127dfbc651c8981f63626f5f6fd60` | Same intentional wrong logic |
| domain, existing base | `domain-audit-existing` / `c2bdad55815af1465c77378baee245f78a8028c3` | domain count increment 1 → 2 |
| domain, synthetic base | `domain-audit-synthetic` / `1ce53f031822fd318cb48d46d55d42c0754b5b68` | Same intentional wrong logic |
| selection-authority control | `authority-control` / `59de72ec3e84ed399f17da5785e396f631e7bc0a` | planner `ANCHOR_HISTORY_LIMIT` 64 → 63 |

These deliberately wrong probes were not executed or published. They are intended only to show what obligations the planner selects, and must never enter a production branch. Existing-base branches descend directly from source8d; synthetic branches descend directly from synthetic0e. `summary.json` records each complete base/head/plan identity.

## Why this works and what is still required

The current production graph attaches every Python seed to unknown execution consumers. Without a base group, even a local diagnostic arithmetic/filter change enters CLI/research-state/fixture consumers and their large closure. The established local-contract mechanism can recognize a previously accepted, unchanged proof boundary: the source change passes the function-body guard, the policy fingerprint finds an immutable accepted anchor, proof/test-side input evidence has not drifted, and unchanged consumers are covered by the base group. The group supplies the complete selected proof modules while unrelated opaque consumers are not reintroduced.

This directly addresses the targeted bounded diagnostic use case without changing business invocation semantics. It is narrower than arbitrary new code or input changes: imports, calls, strings, helper/test evidence drift, changed/new consumers, missing anchor and authority changes must still restore their existing conservative obligations.

Recommended next step is an actual reviewed policy-addition patch using these three groups and regression cases for both reductions and invalidation. That patch cannot authorize its own smaller plan from candidate-side policy; it must first be accepted into develop under current gates. Then a fresh accepted-base diagnostic probe must verify actual B/C union, changed100/100, applicable95/90, smokes and fixed aggregates. The experiment does not activate the proposed raw consumer-template exclusion mechanism, cross-commit reuse, or generic production2C.

No heavy tests were run for this task. The next execution should be a bounded functional/coverage probe with named acceptance and a plan proving the small obligations, rather than immediately repeating the former 1510-case coverage run.
