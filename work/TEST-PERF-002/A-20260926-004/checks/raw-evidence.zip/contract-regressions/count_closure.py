"""Fresh local fixture executions closing the previously retained domain-count miss."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).parent / 'count-closure'
OUT.mkdir(exist_ok=False)
SOURCE = OUT.parents[1] / 'group-prototype/clone'
REPO = OUT / 'clone'
WORKTREE = Path(r'D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
ORIGINAL = '0e712d5039232860a51f97b1d43857b76f6e98f1'
PY = {v: str(Path(r'D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917') /
             ('venv' + v) / 'Scripts/python.exe') for v in ('311', '313')}
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1',
           PYTHONPATH=os.pathsep.join(map(str, (REPO, REPO / 'src', REPO / '.github/scripts'))))
for key in ('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy', 'all_proxy'):
    ENV.pop(key, None)
BODY = '- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no'
TEST = 'tests.test_ci_domain_audit.DomainModelTests.test_overlapping_runtime_document_is_not_collapsed_into_docs'
SUBJECT = '.github/scripts/ci_domain_audit.py'
TEST_FILE = 'tests/test_ci_domain_audit.py'


def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def git(*args, repo=REPO):
    return subprocess.check_output(['git', '-c', 'core.hooksPath=NUL', '-C', str(repo), *args],
                                   env=ENV, stderr=subprocess.PIPE).decode().strip()


def step(directory, label, argv, env=ENV):
    started = time.perf_counter()
    with (directory / (label + '.log')).open('wb') as stream:
        result = subprocess.run(argv, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT)
    fact = {'argv': argv, 'returncode': result.returncode, 'wall_seconds': time.perf_counter() - started}
    save(directory / (label + '.json'), fact)
    return fact


source_before = {'head': git('rev-parse', 'HEAD', repo=SOURCE),
                 'status': git('status', '--porcelain', repo=SOURCE)}
subprocess.run(['git', 'clone', '-q', '--no-hardlinks', '-c', 'user.name=CI count closure fixture',
                '-c', 'user.email=ci-count-closure@invalid.local', '-c', 'core.autocrlf=false',
                str(SOURCE), str(REPO)], env=ENV, check=True)
git('checkout', '--detach', ORIGINAL)
assert not (REPO / '.git/objects/info/alternates').exists()
test_bytes = (WORKTREE / TEST_FILE).read_bytes()
assert hashlib.sha256(test_bytes).hexdigest() == '3fbf1bb6f1bfa28c5902d6fe82ee0ae759a4d5f5ce0b1660d552a2273be390ce'
(REPO / TEST_FILE).write_bytes(test_bytes)
git('add', '--', TEST_FILE)
git('commit', '-qm', 'EXPERIMENT ONLY: assert domain inventory counts')
test_commit = git('rev-parse', 'HEAD')
sys.path.insert(0, str(REPO / '.github/scripts'))
import plan_ci as planner

policy = json.loads((REPO / planner.POLICY).read_bytes())
leaves = {path for group in policy['groups'].values() for path in group['coverage']}
old_fingerprint = policy['consumer_fingerprint']
policy['consumer_fingerprint'] = planner.consumer_fingerprint(REPO, test_commit, leaves)
assert old_fingerprint != policy['consumer_fingerprint']
(REPO / planner.POLICY).write_bytes(planner.canonical(policy))
git('add', '--', planner.POLICY)
git('commit', '-qm', 'EXPERIMENT ONLY: new count-assertion contract fixture base')
BASE = git('rev-parse', 'HEAD')
git('branch', 'count-closure-fixture', BASE)
index = {'scope': 'unaccepted synthetic contract; local fresh executions; no hosted or production acceptance',
         'original_synthetic_base': ORIGINAL, 'test_commit': test_commit, 'fixture_base': BASE,
         'test_sha256': hashlib.sha256(test_bytes).hexdigest(), 'source_clone_before': source_before,
         'old_fingerprint': old_fingerprint, 'new_fingerprint': policy['consumer_fingerprint'], 'cases': []}
save(OUT / 'index.json', index)
old = (REPO / SUBJECT).read_text(encoding='utf-8')
needle = "counts[match['domain']] += 1"
assert old.count(needle) == 1
for label, replacement, expect_pass in (
        ('correct', "counts[match['domain']] += +1", True),
        ('same-count-fault', "counts[match['domain']] += 2", False)):
    git('checkout', '--detach', BASE)
    updated = old.replace(needle, replacement)
    assert planner.dependencies.function_body_only(old.encode(), updated.encode())
    (REPO / SUBJECT).write_text(updated, encoding='utf-8')
    git('add', '--', SUBJECT)
    git('commit', '-qm', 'EXPERIMENT ONLY: ' + label + ' domain-count probe')
    head = git('rev-parse', 'HEAD')
    git('branch', 'count-' + label, head)
    plan = planner.make_plan(REPO, base=BASE, head=head, target=head,
                             repository='Chengyue-Lu/research-agent-workbench', body=BODY)
    assert not plan['blocked_reasons']
    assert plan['tests'] == plan['coverage_tests'] == ['test_ci_consumer_shadow', 'test_ci_domain_audit', 'test_ci_shadow_pair']
    assert plan['coverage_modules'] == [SUBJECT]
    assert plan['selection']['reviewed_contract_anchor'] == BASE
    assert not plan['package_smoke'] and not plan['repository_smoke']
    plan_path = OUT / (label + '-plan.json')
    save(plan_path, plan)
    row = {'label': label, 'base': BASE, 'head': head, 'plan_id': plan['plan_id'],
           'subject_sha256': hashlib.sha256((REPO / SUBJECT).read_bytes()).hexdigest(), 'expected_pass': expect_pass,
           'B_selectors': plan['tests'], 'C_selectors': plan['coverage_tests'], 'runs': {}}
    for version in ('311', '313'):
        directory = OUT / (label + '-' + version)
        directory.mkdir()
        identity = {'base': BASE, 'head': head, 'plan_id': plan['plan_id'], 'python': PY[version],
                    'subject': SUBJECT, 'subject_sha256': row['subject_sha256'],
                    'test_file': TEST_FILE, 'test_sha256': index['test_sha256'], 'fixture_clone': str(REPO)}
        save(directory / 'identity.json', identity)
        # A fresh interpreter authenticates the actual imports and then runs the same method.
        direct_code = "import hashlib,json,pathlib,sys,unittest; import tests.test_ci_domain_audit as t; " \
            "root=pathlib.Path.cwd().resolve(); paths={'test':pathlib.Path(t.__file__).resolve(),'subject':pathlib.Path(t.audit.__file__).resolve()}; " \
            "assert paths['test']==root/'tests/test_ci_domain_audit.py'; assert paths['subject']==root/'.github/scripts/ci_domain_audit.py'; " \
            "print(json.dumps({k:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in paths.items()}),flush=True); " \
            "r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('" + TEST + "')); sys.exit(not r.wasSuccessful())"
        steps = {'direct': step(directory, 'direct-count', [PY[version], '-B', '-c', direct_code])}
        assert (steps['direct']['returncode'] == 0) == expect_pass
        env = dict(ENV, COVERAGE_FILE=str(directory / '.coverage'))
        if version == '311':
            config = directory / 'coverage.ini'
            steps['configure'] = step(directory, 'configure', [PY[version], '-B', '.github/scripts/ci_checks.py',
                'configure', '--plan', str(plan_path), '--config', str(config)], env)
            assert steps['configure']['returncode'] == 0
            steps['producer'] = step(directory, 'producer', [PY[version], '-B', '-m', 'coverage', 'run',
                '--rcfile=' + str(config), 'tests/run_unittest_suite.py', '--suite', 'coverage-execution',
                '--plan', str(plan_path), '--json-output', str(directory / 'execution.json'),
                '--coverage-results', str(directory / 'impact-results.json'), '--verbosity', '1'], env)
            steps['coverage_json'] = step(directory, 'coverage-json', [PY[version], '-B', '-m', 'coverage', 'json',
                '--rcfile=' + str(config), '-o', str(directory / 'coverage.json')], env)
            assert steps['coverage_json']['returncode'] == 0
            steps['impact'] = step(directory, 'impact', [PY[version], '-B', '.github/scripts/ci_checks.py', 'impact',
                '--plan', str(plan_path), '--coverage', str(directory / 'coverage.json'),
                '--results', str(directory / 'impact-results.json')], env)
            assert (steps['producer']['returncode'] == 0) == expect_pass
            assert (steps['impact']['returncode'] == 0) == expect_pass
        else:
            steps['behavioral'] = step(directory, 'behavioral', [PY[version], '-B', 'tests/run_unittest_suite.py',
                '--suite', 'focused', '--plan', str(plan_path), '--json-output', str(directory / 'execution.json'),
                '--verbosity', '1'], env)
            assert (steps['behavioral']['returncode'] == 0) == expect_pass
        receipt = json.loads((directory / 'execution.json').read_bytes())
        failures = [{'id': test['id'], 'outcome': test['outcome']} for test in receipt['tests'] if test['outcome'] != 'passed']
        assert receipt['test_count'] == 25
        assert receipt['successful'] == expect_pass
        if not expect_pass:
            assert len(failures) == 1 and failures[0]['id'].endswith('test_overlapping_runtime_document_is_not_collapsed_into_docs')
        result = {'identity': identity, 'steps': steps, 'test_count': receipt['test_count'],
                  'successful': receipt['successful'], 'failures': failures, 'wall_seconds': receipt['wall_seconds']}
        save(directory / 'summary.json', result)
        row['runs'][version] = result
        save(OUT / ('pending-' + label + '.json'), row)
        print(json.dumps({'label': label, 'python': version, 'tests': receipt['test_count'], 'failures': failures,
                          'steps': {k: v['returncode'] for k, v in steps.items()}}), flush=True)
    index['cases'].append(row)
    save(OUT / 'index.json', index)
git('checkout', '--detach', BASE)
index['final_clone'] = {'head': git('rev-parse', 'HEAD'), 'status': git('status', '--porcelain')}
index['source_clone_after'] = {'head': git('rev-parse', 'HEAD', repo=SOURCE),
                               'status': git('status', '--porcelain', repo=SOURCE)}
assert index['source_clone_after'] == source_before
index['status'] = 'PASS: original count fault rejected by fresh actual selected suites on both Python versions'
save(OUT / 'index.json', index)
print(index['status'], flush=True)
