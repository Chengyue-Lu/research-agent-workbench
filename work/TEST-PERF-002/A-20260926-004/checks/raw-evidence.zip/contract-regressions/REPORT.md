# Diagnostic contract regression handoff

Role: CI dependency boundary reviewer / regression implementer. Required Skills: none. Owner: Chengyue-Lu / TEST-PERF-002.

Status: PASS-local-scoped. Only the two assigned repository test files were changed. No commit, push, PR mutation, business-code edit or full-suite execution was performed.

## Changes

`tests/test_ci_plan.py` adds three named tests using the existing isolated Git fixture, the actual three diagnostic sources, current actual policy records, and real proof modules:

1. `test_real_diagnostic_contracts_require_base_acceptance_and_complete_family_proof`: each member first attempts candidate-only policy activation and must retain the unrelated opaque consumer in B and C. After the same real policy is explicitly accepted into the fixture base, supported equivalent function logic yields exact complete proof B/C: consumer shadow two modules, shadow pair one, domain audit three. Risk remains R2, coverage impact, source subject remains explicit, exact positive/negative evidence retained, both smokes false in this isolated closed case, and plan verification succeeds.
2. `test_real_diagnostic_contracts_restore_scope_for_boundary_and_proof_drift`: three members times six variants (import, call, initialization, added function, proof bytes, missing anchor). The contracted leaf is invalidated, old opaque consumers and complete family proof return to both B/C, and impact remains required.
3. `test_real_diagnostic_contracts_keep_new_direct_and_opaque_consumers`: both new direct invocation and new opaque reader remain selected. Actual proof modules reference test-directory membership, so the new members also invalidate evidence and restore the older opaque reader. The test checks this real conservative behavior, not a fabricated narrow outcome.

`tests/test_ci_domain_audit.py` strengthens the existing overlapping document case. A six-path inventory now has an overlapping document, multiple independent members in each domain, one unassigned input, and an exact test-route record. It asserts tracked count 6, per-domain counts `{docs: 3, runtime: 3}`, exact overlaps, unassigned input and test routes. A separate unmatched-only inventory must have count 1 and empty domain counts. This directly detects the observed increment-by-two mutant without adding a new redundant test identity.

## Validation

Both Python 3.11 and 3.13 passed the modified domain case in the first invocation. The unchanged domain source hash remains recorded. The first planner invocation exposed two mistaken fixture expectations: a version expression inside a call violates the deliberately fixed call-expression boundary, and new test consumers legitimately invalidate directory membership. Those failures were retained; no production code was changed to accommodate them.

After choosing the independently demonstrated supported logic forms and asserting the observed membership fallback, all three planner methods passed once on each Python: 27.232 seconds / 27.150 seconds of unittest time. The tests cover 27 parameterized Git scenarios across three members. Full command arguments, hashes, exit codes, stdout and stderr are under `final-311` and `final-313`. The first 3.11 final output chunk is retained verbatim; first 3.13 raw output exists only in the interactive tool stream, so it is not described as a complete filesystem archive. `git diff --check` passes for the assigned paths.

These are plan/regression checks. They do not attest hosted execution, changed coverage, performance savings or production acceptance. The parent task's paired real suites and independent accepted-root minimum witness remain separate evidence.

## Remaining boundary

The groups deliberately accept only the existing narrow function-body predicate. Changed call arguments, new functions/API, source helpers, changed proof/member inventory, unsupported imports and unavailable fingerprint anchors remain conservative. The current candidate policy cannot supply its own exclusion authority. A fixture-accepted base is a test history, not an assertion that PR101 has been formally accepted or merged.

The reported original domain count mutant and its fresh recheck belong to the separate real execution assessment. This subtask did not repeat that full suite. The minimum witness adversarial inventory and actual hosted plan/coverage/smoke/aggregate validation remain with the parent and their assigned reviewer.

See `summary.json` for exact final test hashes and `owned.diff` for this subtask's full owned changes.
