import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(r'D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
OUT = Path(__file__).parent / ('final-' + sys.argv[1])
OUT.mkdir(exist_ok=False)
python = Path(r'D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917') / ('venv' + sys.argv[1]) / 'Scripts/python.exe'
names = [
    'tests.test_ci_plan.PlannerTests.test_real_diagnostic_contracts_require_base_acceptance_and_complete_family_proof',
    'tests.test_ci_plan.PlannerTests.test_real_diagnostic_contracts_restore_scope_for_boundary_and_proof_drift',
    'tests.test_ci_plan.PlannerTests.test_real_diagnostic_contracts_keep_new_direct_and_opaque_consumers',
]
argv = [str(python), '-B', '-m', 'unittest', '-v', *names]
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}
start = time.monotonic()
result = subprocess.run(argv, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(OUT / 'stdout.txt').write_bytes(result.stdout)
(OUT / 'stderr.txt').write_bytes(result.stderr)
summary = {'argv': argv, 'cwd': str(ROOT), 'returncode': result.returncode, 'seconds': time.monotonic() - start,
           'test_sources': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                            for name in ('tests/test_ci_plan.py', 'tests/test_ci_domain_audit.py')},
           'tests': names}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))
print(result.stderr.decode('utf-8', errors='replace'))
raise SystemExit(result.returncode)
