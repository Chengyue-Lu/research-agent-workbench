# Domain count fault: actual closure evidence

Status: PASS-local-count-closure. New independent ordinary Git clone; no production worktree or remote writes. The fixture is explicitly unaccepted and does not activate CI exclusions.

## Inputs and bindings

- Original synthetic base: `0e712d5039232860a51f97b1d43857b76f6e98f1`.
- New assertion-only commit: `20e2d90198ce4cc0cc7a4df2848b310d3da5350c`.
- New fingerprint fixture base: `654937e79e0f196688b8d12db57a545159a2298a`.
- Final test source SHA256: `3fbf1bb6f1bfa28c5902d6fe82ee0ae759a4d5f5ce0b1660d552a2273be390ce`.
- The new base contains the exact final count assertions and then a fresh consumer fingerprint. This is a new local test history, not a re-signing of the original missed-fault execution.

## Fresh actual executions

| Variant | Head | Python 3.11 producer | Python 3.13 behavioral | B/C/union |
| --- | --- | --- | --- | --- |
| correct | `164d26b96af0a8cd5c9eb46f82eb5d1676aa9726` | 25 PASS | 25 PASS | 25/25/25 |
| same-count-fault | `804cb5b932a54542f5679c54370c9c79d0900cae` | 24 PASS + 1 FAIL | 24 PASS + 1 FAIL | 25/25/25 |

Both variants retained identical ordered B and C identities; actual unique execution is 25 cases, with no C-only additions. The selected modules are the complete consumer-shadow, domain-audit and shadow-pair modules.

The correct equivalent increment (`+= +1`) passed direct count checks on both Python versions. Its actual Python 3.11 coverage producer and impact checker passed. The domain subject covered 121/121 executable lines and 38/38 branches; impact checked the changed coordinates. This proves scoped impact, not repository-wide coverage. Python 3.11 receipt wall time was 40.287003 seconds and Python 3.13 26.88987 seconds; these local single executions are not hosted performance acceptance.

The original increment-by-two fault failed exactly `test_overlapping_runtime_document_is_not_collapsed_into_docs`: expected `{docs: 3, runtime: 3}`, observed `{docs: 6, runtime: 6}`. Both full selected suites executed 25 cases and retained that one failing identity. The Python 3.11 producer withheld `impact-results.json` after failure. The subsequently recorded impact invocation therefore fails because that projection is missing; it is not described as a second semantic detector or a passing coverage receipt.

## Exact original faulty source bytes

The first fresh full pair used the same committed faulty Git blob as original missed-fault head `1ce53f031822fd318cb48d46d55d42c0754b5b68`. Its just-written Windows worktree bytes had a different newline representation, retained in its identity files. After the full pair completed, a clean checkout materialized the original exact LF bytes. New independent Python 3.11 and 3.13 processes both imported those exact bytes and failed the same single test.

- Identical original/new faulty Git blob: `d7e231c74ce6e7459e375a9b69718cc4f09a9828`.
- Exact original faulty raw SHA256: `ce9faa73585454c9afceb7813efe4f04811848ffbda3a396a9f432e33945d607`.
- `exact-raw-fault-311/direct.log` and `exact-raw-fault-313/direct.log` print actual imported file paths and SHA256 before execution, then the failing assertion. Neither changes the test expectation.

## Preservation and limits

The original group-prototype clone head/status remained unchanged, and its original missed-fault logs remain untouched. The new clone ends clean at its own new fixture base. All source, test, plan, run arguments, outputs, receipts, coverage and expected failures are retained beneath this directory; `summary.json`, `index.json` and `exact-raw-closure.json` provide machine-readable navigation.

This closes the specific missing count assertion with real positive and negative execution. It does not establish hosted timing, production group acceptance, independent minimum-witness acceptance or a full repository coverage baseline. No 1510-case suite or remote CI was run.
