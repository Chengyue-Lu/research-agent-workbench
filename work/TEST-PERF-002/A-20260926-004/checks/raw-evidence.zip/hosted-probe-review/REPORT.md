# Independent paired-harness review

2026-09-26. **PASS for the bounded diagnostic experiment harness after two repairs.** A single reduced arm executed successfully through the real producer/coverage checker/behavioral projection; the subsequent evidence-only additions were checked with fresh preparation, Git bundle verification and import-origin commands without repeating the producer. No baseline1510 execution or hosted/remote operation was performed in this review.

Final reviewed script SHA256: `7dd613aee2b4bb7bf3142de84909fa3b7c53f9001cf7d3b88fc6eb7e0e4d35f3`.

Final reviewed workflow template SHA256: `e563d0c9a20fba20944a8879eb6e6000e73f23484af53a942ff1ec610b19ed4d`.

The template still contains `__SOURCE_HEAD__`; deployment must replace it with the exact intended source commit. This report does not authorize a production policy, official test-result reuse, PR merge, or a claim of measured hosted savings.

## Repairs and retained original evidence

1. Initial inspection found that synthetic child processes inherited `GITHUB_EVENT_PATH/NAME/SHA`. Both actual `ci_checks.main` and the native runner `_verified_plan` read the outer event and would bind their offline synthetic plan to the wrong hosted event. The coordinator changed the experiment environment to remove `GITHUB_*` while saving outer provenance separately. This is appropriate because the script explicitly measures an offline synthetic policy experiment and cannot attest official CI authority.
2. Preparation/plan exercise exposed a real filename collision: the plan child wrote `plan.json`, then `command(name='plan')` attempted to create the same filename for step metadata using exclusive creation. The retained pre-repair snapshot is `prepare-original/reviewed-script.py`, SHA256 `328450e5db2c972d7ba503fe1650c3fbdb508aa460321d0dae6430a18d003bb2`. The coordinator changed all step records to `name-command.json`. Artifact names are now distinct from `plan.json`, `origins.json` and receipts.

The environment repair had already reached the snapshot before the filename failure was captured. Accordingly `event-original/event-configure.json` shows `retained_event_vars={}` and configure exit0. The review helper's final assertion still expected an original-version failure and raised `AssertionError`; that helper expectation was stale, not a product failure. Its files remain unchanged. The successful isolation observation is retained and the final reduced execution confirms the repaired behavior.

## Real reduced-arm acceptance

The repaired executable path at SHA256 `25c8ca2fa6b1d758ff39d57a791a2bffa1c51814dad525cf843f3c2a2178e1cd` ran once in a new independent clone/output directory (`reduced-fixed`). Content came from the previously prepared synthetic source commit `0e712d5039232860a51f97b1d43857b76f6e98f1`, as explicitly authorized for harness acceptance.

- Synthetic arm base: `e2d4937a4e1190959a5a39d38d9623dfdaee1796`.
- Exact head/target: `dd9e1e20a91f5872e43fce7b367c6f1da69d3624`.
- Plan: `b36bc995a77fe35355977d07f5b6b0858e986f1f74e53aa26bf8b5ed696f31d3`.
- Actual B/C/U: **20/20/20**, all successful, no failed or skipped case.
- Fresh plan, generated coverage configuration, native ordered producer, coverage JSON, quality checker and behavioral projection all returned0.
- Native producer command wall: **36.137962 seconds**. This is one local acceptance run, not a hosted comparison.
- Plan obligations: focused/impact; neither smoke required. Smoke results were not fabricated or folded into the measured producer cost.
- `import-origins.json` separately confirmed `research_workbench` came from this clone's `src` and `plan_ci` from this clone's `.github/scripts`, avoiding accidental use of the outer editable checkout.

All raw command logs/argv, source binding, coverage JSON and original receipts are under `reduced-fixed/`. No original prototype plan/inventory, fault evidence or test source was changed.

## Final evidence additions

The final script adds source-prerequisite incremental Git bundles, saved policies, per-arm fresh import-origin checks and `pip freeze --all` with its SHA256. These additions do not change the producer, quality or projection commands exercised above.

`final-light/summary.json` records the final hash and fresh checks for **both** baseline and reduced preparation:

- both ordinary clones were clean after preparation;
- both exact heads contain precisely two new synthetic commits above the explicit source prerequisite;
- base parent equals source and head parent equals base;
- `git bundle verify` succeeds and advertised bundle head matches the prepared head;
- all implementation/test tree records outside `tests/ci_impact_policy.yaml` are equal across arms;
- the new actual import command succeeds in a fresh process for each root;
- `imports-command.json` and `origins.json` do not collide;
- no additional producer/test run was performed.

The bundles deliberately require the named source commit; they are not standalone complete-repository bundles. Raw policies and source/target identities remain necessary audit inputs.

## Producer semantics and comparison validity

The native runner was inspected directly:

- `_behavioral_suite` selects `plan['behavioral_scope']`.
- `full` enters `_suite_for('full')`, which discovers all `test_*.py`; it does **not** reduce a full worker to `plan.tests`.
- `OrderedCoverageExecution` runs the complete original behavioral hierarchy/order before collecting and running C-only extras.
- `_project_execution` recollects expected B/C inventories, verifies exact canonical/runtime identities, complete plan/target binding, successful fixture events, and exact `execution_order` plus the original behavioral/coverage order contract.
- The harness obtains B and C from those validated native projections; its set-union and duplicate checks are additional guards, not substitutes for order verification.

A separate no-execution negative (`projection-negative/`) swaps the first two entries in the retained U execution order. The real `behavioral-evidence` verifier rejects it with `execution receipt does not preserve behavioral fixture/order contract` and emits no successful projection. Original receipt files were not altered and no test case was rerun.

Preparation applies the same equivalent consumer-source change to both arms and compares complete Git tree records except the policy file. Fingerprints are freshly computed from each synthetic staged tree using a fresh planner import from that root. The different policies are the intentional intervention; source/tests, interpreter and installed dependency environment remain shared within a pair. Arbitrary semantic source differences cannot silently enter the comparison without failing the tree comparison.

## Hosted interpretation and failure handling

Per coordinator clarification, **each pair's two arms must execute serially on one machine; the three pairs may run on separate fresh matrix runners**. The workflow template satisfies that structure: matrix1/2/3 invokes one process per runner, whose ordered calls run baseline→reduced for odd pairs and reduced→baseline for even pairs. `fail-fast:false` retains independent pair outcomes. Cross-pair ImageVersion, Python/dependency freeze and architecture must be compared before a combined conclusion; heterogeneous pairs must remain separate evidence.

All timings are scoped to the Python3.11 coverage producer, excluding install/setup, queue, smokes and total workflow wall. Changed-line/branch and applicable critical floors are still checked by the real coverage command; passing impact is not repository-wide coverage.

The harness fails closed on a command error after retaining its log and return-code record. It creates `pair.json` only after both arms pass and reduced U is a strict subset of baseline U. Exclusive output creation prevents overwriting an earlier run. The workflow's `if:always()` artifact upload preserves successful and failed arms' raw logs, JSON, configuration, policies, dependency record and bundles. A failure or a cancelled partial pair must not be counted as a valid performance pair.

No material blocker remains in the reviewed final harness for this bounded experimental purpose. Actual full baseline success, three hosted pair outcomes, current source-content identity and cross-run environment matching remain future execution facts, not claims made by this local review.
