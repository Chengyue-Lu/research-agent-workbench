"""No test execution: reject reordered retained execution evidence."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
FIXED=ROOT/'reduced-fixed'
OUT=ROOT/'projection-negative';assert not OUT.exists();OUT.mkdir()
spec=importlib.util.spec_from_file_location('frozen_fixed_probe',FIXED/'reviewed-script.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
repo=FIXED/'repositories/reduced'
payload=json.loads((FIXED/'reduced/execution.json').read_bytes())
payload['execution_order'][0],payload['execution_order'][1]=payload['execution_order'][1],payload['execution_order'][0]
m.save(OUT/'reordered-receipt.json',payload)
args=[sys.executable,'tests/run_unittest_suite.py','--suite','behavioral-evidence',
   '--plan',str(FIXED/'reduced/plan.json'),'--execution-results',str(OUT/'reordered-receipt.json'),
   '--json-output',str(OUT/'behavioral.json')]
result=subprocess.run(args,cwd=repo,env=m.environment(repo),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'projection.log').write_bytes(result.stdout)
assert result.returncode!=0 and b'preserve behavioral fixture/order contract' in result.stdout
assert not (OUT/'behavioral.json').exists()
m.save(OUT/'result.json',{'status':'PASS-negative-refusal','argv':args,'returncode':result.returncode,
   'test_execution_performed':False,'original_receipt_modified':False})
print(result.stdout.decode())
