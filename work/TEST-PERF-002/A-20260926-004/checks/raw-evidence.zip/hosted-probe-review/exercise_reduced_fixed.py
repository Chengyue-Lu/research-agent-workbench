"""One reduced arm acceptance run for the repaired experiment harness."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

OUT=Path(__file__).resolve().parent/'reduced-fixed'
SOURCE=Path('D:/lcy/develop/_assessments/rwb-ci-reduction-20260926/group-prototype/clone')
HEAD='0e712d5039232860a51f97b1d43857b76f6e98f1'
SCRIPT=Path('D:/lcy/develop/_assessments/rwb-ci-reduction-20260926/hosted-probe/paired_probe.py')
raw=SCRIPT.read_bytes();ast.parse(raw)
assert not OUT.exists();OUT.mkdir();(OUT/'reviewed-script.py').write_bytes(raw)
spec=importlib.util.spec_from_file_location('fixed_paired_probe',OUT/'reviewed-script.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
workspace=OUT/'repositories';workspace.mkdir()
repo,binding=m.prepare(SOURCE,HEAD,workspace,'reduced')
old=json.loads((OUT.parent/'prepare-original/prepared.json').read_bytes())
assert binding['tree_without_policy_sha256']==old['baseline']['tree_without_policy_sha256']
origin_args=[sys.executable,'-B','-c',
    'import json,sys;from pathlib import Path;import research_workbench,coverage,plan_ci;'
    'print(json.dumps({"python":sys.executable,"cwd":str(Path.cwd()),"package":research_workbench.__file__,"coverage":coverage.__file__,"planner":plan_ci.__file__}))']
origin=json.loads(subprocess.check_output(origin_args,cwd=repo,env=m.environment(repo)))
assert Path(origin['package']).resolve().is_relative_to((repo/'src').resolve())
assert Path(origin['planner']).resolve().is_relative_to((repo/'.github/scripts').resolve())
m.save(OUT/'import-origins.json',{'argv':origin_args,'origins':origin})
m.save(OUT/'identity.json',{'script_sha256':hashlib.sha256(raw).hexdigest(),'source':HEAD,'binding':binding,
    'source_tests_tree_equals_previous_baseline':True,'baseline_producer_runs':0})
result=m.execute(repo,binding,OUT/'reduced')
plan=json.loads((OUT/'reduced/plan.json').read_bytes())
assert plan['behavioral_scope']=='focused' and plan['coverage_scope']=='impact'
assert not plan['package_smoke'] and not plan['repository_smoke']
assert result['counts']=={'U':20,'B':20,'C':20},result['counts']
m.save(OUT/'review-result.json',{'status':'PASS-reduced-harness-only','counts':result['counts'],
   'head':binding['head'],'base':binding['base'],'plan_id':result['plan_id'],
   'script_sha256':hashlib.sha256(raw).hexdigest(),'smokes_required':False,'baseline_executed':False})
print(json.dumps({'status':'PASS-reduced-harness-only','counts':result['counts'],'script_sha256':hashlib.sha256(raw).hexdigest()}))
