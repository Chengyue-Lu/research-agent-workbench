"""Reproduce ambient-event binding against the frozen original reviewed script."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'event-original';assert not OUT.exists();OUT.mkdir()
SUBJECT=ROOT/'prepare-original/reviewed-script.py'
spec=importlib.util.spec_from_file_location('original_paired_probe',SUBJECT)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
prepared=json.loads((ROOT/'prepare-original/prepared.json').read_bytes())
repo=ROOT/'prepare-original/repositories/reduced';binding=prepared['reduced']
plan=OUT/'synthetic-plan.json'
expression=('import json,sys;from pathlib import Path;sys.path.insert(0,".github/scripts");import plan_ci as p;'
    'v=p.make_plan(Path.cwd(),base=sys.argv[1],head=sys.argv[2],target=sys.argv[2],repository="Chengyue-Lu/research-agent-workbench",body=sys.argv[3]);'
    'Path(sys.argv[4]).write_bytes(p.canonical(v))')
m.command(repo,OUT,'generate-plan',[sys.executable,'-B','-c',expression,binding['base'],binding['head'],m.BODY,str(plan)])
event=OUT/'outer-event.json';m.save(event,{'repository':{'full_name':'Chengyue-Lu/research-agent-workbench'}})
overrides={'GITHUB_EVENT_PATH':str(event),'GITHUB_EVENT_NAME':'push','GITHUB_SHA':'0e712d5039232860a51f97b1d43857b76f6e98f1'}
previous={k:os.environ.get(k) for k in overrides};os.environ.update(overrides);env=m.environment(repo)
for key,value in previous.items():
    if value is None:os.environ.pop(key,None)
    else:os.environ[key]=value
args=[sys.executable,'-B','.github/scripts/ci_checks.py','configure','--plan',str(plan),'--config',str(OUT/'event-config.ini')]
result=subprocess.run(args,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'event-configure.log').write_bytes(result.stdout)
m.save(OUT/'event-configure.json',{'argv':args,'returncode':result.returncode,
   'retained_event_vars':{k:env[k] for k in env if k in overrides},'producer_executed':False})
print(result.stdout.decode());assert result.returncode!=0
