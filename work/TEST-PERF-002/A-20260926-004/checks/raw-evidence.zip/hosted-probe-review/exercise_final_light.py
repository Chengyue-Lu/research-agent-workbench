"""Final metadata/bundle additions only; no producer or behavioral test is run."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

OUT=Path(__file__).resolve().parent/'final-light'
SOURCE=Path('D:/lcy/develop/_assessments/rwb-ci-reduction-20260926/group-prototype/clone')
HEAD='0e712d5039232860a51f97b1d43857b76f6e98f1'
SCRIPT=Path('D:/lcy/develop/_assessments/rwb-ci-reduction-20260926/hosted-probe/paired_probe.py')
WORKFLOW=SCRIPT.parent/'ci-reduction-experiment.yml'
raw=SCRIPT.read_bytes();tree=ast.parse(raw)
assert not OUT.exists();OUT.mkdir();(OUT/'reviewed-script.py').write_bytes(raw)
(OUT/'reviewed-workflow.yml').write_bytes(WORKFLOW.read_bytes())
spec=importlib.util.spec_from_file_location('final_paired_probe',OUT/'reviewed-script.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
origin=next(ast.literal_eval(n.value) for f in tree.body if isinstance(f,ast.FunctionDef) and f.name=='execute'
     for n in f.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='origin_expression' for t in n.targets))
workspace=OUT/'repositories';workspace.mkdir();facts={}
for label in ('baseline','reduced'):
    repo,binding=m.prepare(SOURCE,HEAD,workspace,label)
    directory=OUT/label;directory.mkdir()
    bundle=OUT/(label+'.bundle')
    args=['git','-C',str(repo),'bundle','verify',str(bundle)]
    verified=subprocess.run(args,env=m.environment(repo),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (directory/'bundle-verify.log').write_bytes(verified.stdout)
    assert verified.returncode==0
    listed=m.git(repo,'bundle','list-heads',str(bundle))
    assert binding['head'] in listed
    assert m.git(repo,'rev-list','--count',binding['head'],'^'+HEAD)=='2'
    assert m.git(repo,'show','-s','--format=%P',binding['base'])==HEAD
    assert m.git(repo,'show','-s','--format=%P',binding['head'])==binding['base']
    m.command(repo,directory,'imports',[sys.executable,'-c',origin,str(directory/'origins.json')])
    assert not m.git(repo,'status','--porcelain')
    facts[label]={'binding':binding,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),
       'bundle_verify_argv':args,'bundle_verify_returncode':verified.returncode,'bundle_list_heads':listed,
       'new_commits':2,'clone_clean':True,'imports_command_pass':True}
assert facts['baseline']['binding']['tree_without_policy_sha256']==facts['reduced']['binding']['tree_without_policy_sha256']
freeze=subprocess.check_output([sys.executable,'-m','pip','freeze','--all'],text=True)
(OUT/'pip-freeze.txt').write_text(freeze,encoding='utf-8')
m.save(OUT/'summary.json',{'status':'PASS-final-metadata-only','source':HEAD,
    'script_sha256':hashlib.sha256(raw).hexdigest(),'workflow_sha256':hashlib.sha256(WORKFLOW.read_bytes()).hexdigest(),
    'dependencies_sha256':hashlib.sha256(freeze.encode()).hexdigest(),'arms':facts,
    'producer_runs':0,'new_tests_run':0,'remote_written':False})
print(json.dumps({'status':'PASS-final-metadata-only','script_sha256':hashlib.sha256(raw).hexdigest(),
    'workflow_sha256':hashlib.sha256(WORKFLOW.read_bytes()).hexdigest(),'producer_runs':0}))
