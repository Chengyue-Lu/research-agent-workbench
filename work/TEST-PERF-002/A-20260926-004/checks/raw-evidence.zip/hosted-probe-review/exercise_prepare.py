"""Preparation/event-binding inspection only; never runs the full baseline."""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

OUT=Path(__file__).resolve().parent/'prepare-original'
SOURCE=Path('D:/lcy/develop/_assessments/rwb-ci-reduction-20260926/group-prototype/clone')
HEAD='0e712d5039232860a51f97b1d43857b76f6e98f1'
SCRIPT=Path('D:/lcy/develop/_assessments/rwb-ci-reduction-20260926/hosted-probe/paired_probe.py')
raw=SCRIPT.read_bytes();ast.parse(raw)
assert not OUT.exists();OUT.mkdir()
(OUT/'reviewed-script.py').write_bytes(raw)
spec=importlib.util.spec_from_file_location('paired_probe_review_subject',SCRIPT)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
workspace=OUT/'repositories';workspace.mkdir()
prepared={label:m.prepare(SOURCE,HEAD,workspace,label) for label in ('baseline','reduced')}
assert prepared['baseline'][1]['tree_without_policy_sha256']==prepared['reduced'][1]['tree_without_policy_sha256']
m.save(OUT/'prepared.json',{k:v[1] for k,v in prepared.items()})
plans={}
for label,(repo,binding) in prepared.items():
    directory=OUT/label;directory.mkdir();plan=directory/'plan.json'
    expression=('import json,sys;from pathlib import Path;sys.path.insert(0,".github/scripts");import plan_ci as p;'
        'v=p.make_plan(Path.cwd(),base=sys.argv[1],head=sys.argv[2],target=sys.argv[2],repository="Chengyue-Lu/research-agent-workbench",body=sys.argv[3]);'
        'Path(sys.argv[4]).write_bytes(p.canonical(v));print(json.dumps({k:v[k] for k in ["plan_id","behavioral_scope","coverage_scope","tests","package_smoke","repository_smoke","blocked_reasons"]}))')
    m.command(repo,directory,'plan',[sys.executable,'-B','-c',expression,binding['base'],binding['head'],m.BODY,str(plan)])
    value=json.loads(plan.read_bytes());plans[label]={k:value[k] for k in ('plan_id','behavioral_scope','coverage_scope','package_smoke','repository_smoke','blocked_reasons')}
    assert not value['blocked_reasons']
    if label=='reduced':
        # Simulate an outer hosted push event. The synthetic checkout must not be
        # bound to this unrelated outer event. This invokes configure only.
        event=OUT/'outer-event.json';m.save(event,{'repository':{'full_name':'Chengyue-Lu/research-agent-workbench'}})
        overrides={'GITHUB_EVENT_PATH':str(event),'GITHUB_EVENT_NAME':'push','GITHUB_SHA':HEAD}
        previous={k:os.environ.get(k) for k in overrides}
        os.environ.update(overrides)
        env=m.environment(repo)
        for key,value in previous.items():
            if value is None:
                os.environ.pop(key,None)
            else:
                os.environ[key]=value
        args=[sys.executable,'-B','.github/scripts/ci_checks.py','configure','--plan',str(plan),'--config',str(directory/'event-config.ini')]
        result=subprocess.run(args,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (directory/'outer-event-configure.log').write_bytes(result.stdout)
        m.save(directory/'outer-event-configure.json',{'argv':args,'returncode':result.returncode,'retained_event_vars':{k:env[k] for k in env if k in {'GITHUB_EVENT_PATH','GITHUB_EVENT_NAME','GITHUB_SHA'}}})
m.save(OUT/'summary.json',{'script_sha256':hashlib.sha256(raw).hexdigest(),'source':HEAD,'syntax_pass':True,
    'plans':plans,'outside_policy_tree_equal':True,'producer_runs':0,'remote_written':False})
print(json.dumps({'script_sha256':hashlib.sha256(raw).hexdigest(),'plans':plans,'producer_runs':0}))
