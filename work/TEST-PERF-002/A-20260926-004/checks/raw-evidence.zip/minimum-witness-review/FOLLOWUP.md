# Minimum witness security follow-up

Profile: CI trust-boundary reviewer; required Skills: []. Reviewer: attempt_review_v2.
Read-only follow-up of the final source and existing evidence. No tests, Git commands, repository writes or external calls were performed. The original REPORT.md is preserved.

Result: the original P1/P2 findings are closed in the reviewed source. No remaining substantive finding was identified within the declared candidate-repository and independent-minimum scope. This is source/evidence review, not formal human approval, hosted execution proof, or production activation authorization.

## Exact source identities

| Source | SHA-256 |
| --- | --- |
| .github/scripts/ci_minimum_witness.py | f847918c7abb35297c7eec549508bca0edd9e9e440cb375704ecf70e288a73e5 |
| tests/test_ci_minimum_witness.py | 9dab317be6c81c28d15bc8241e2bcf72666623c523313ea7998f17d6dc7416ca |
| .github/scripts/plan_ci.py | 9cf11cd330493c8ac4955075dfd88a209521b104ae2796604eb59f3a5132276b |
| .github/scripts/ci_dependencies.py | 5768999e3e6929f69ac87c56b94b9ecb66bf4ee527f48d97a21beb839110a20f |
| .github/scripts/check_pr_governance.py | 54257b48b6fab0fb644d501f514c20cb1959def340e578c490e68e38ef66de16 |
| .github/scripts/ci_checks.py | d1ef2da6a92be90b9d91e3c31a02198dba41b3e52e493703be0dfa4e3fb3cba6 |
| tests/run_unittest_suite.py | 36bf86a6325e5465dc624356455e5376702ac6475b515572c405e7a487a607f9 |
| .github/scripts/selection_witness.py | 49b380a441dc92fcbb624aac4cff1baba2f3188ed1ce3174f39b52761d2a8432 |
| tests/coverage_policy.yaml | 56ab72a2763816e883f876f9534b1d239b1e4c6b0f4ebe0abbf2ec58ce192afd |

## Closed findings

P1 — both checker checkout and candidate data now pass through `copy_database`. Filesystem metadata inspection precedes source Git operations; the independent bare copy receives `git --no-replace-objects fsck --full --strict --no-reflogs` before helpers are read. Source fsck configuration is not carried into that clean copy. This covers intermediate trees, commits and ancestor objects, so leaf-blob checks are no longer the only authentication of externally named accepted source. The worker runner is checked again against the authenticated SELF digest before launch.

P2 — unsupported alternates, grafts, shallow state and promisor objects are rejected before cloning and on the copied database. Config includes, fsck override sections and the inspected execution/partial-object settings are rejected before source Git use. Raw input commit bytes are SHA-1 checked and target parents are checked in the clean, fully checked store. The original pre-clone candidate-history parent assertion is gone. `--no-replace-objects` and the cleaned Git environment also apply to accepted helper subprocesses.

Regular Git modes and local source bytes remain checked for the checker and the accepted helper copies. Imported project helper locations and hashes are validated in the isolated worker. Exclusive output creation preserves existing files and aliases; no candidate source checkout/import is added by the new authentication path.

## Worker response and receipt boundary

Worker output now carries `kind=internal-planner-comparison` without a final `status` receipt. The outer launcher requires that kind and removes it before `receipt.update(result)`, retaining `kind=ci-minimum-witness` in the outer envelope. The fixed, authenticated worker implementation supplies only its comparison fields; the kind does not overwrite the outer identity.

Direct `--worker` calls remain possible and can use caller-selected helpers, as expected for an internal protocol endpoint. They are not authenticated receipts. Deployments must invoke the externally selected accepted launcher and accept only its complete, externally bound outer envelope; raw worker comparison, exit code or a self-computed receipt hash is insufficient. Host Python/Git/runtime integrity stays a trusted infrastructure precondition. These limits are retained rather than claimed solved by candidate self-verification.

## Obligation comparison and actual execution consumers

The reviewed accepted `require_obligations` retains independent risk, behavioral, coverage-set, Python matrix, smoke, policy, dependency-selection and impact obligations. When behavioral scope is FULL, `run_unittest_suite._suite_for` performs actual `unittest` discovery of `test_*.py`; it does not execute the candidate plan's tests array as the FULL inventory. For repository coverage, `coverage-plan` loads the coverage-quality modules/test IDs from the policy, then unions any impact selection. `ci_checks` invokes the repository policy checker whenever the repository obligation is present, while impact modules, changed lines/arcs and positive/negative evidence remain checked separately. Therefore the deliberate absence of equality constraints on those unused FULL/repository plan arrays is not a newly identified plan-floor bypass.

This still depends on retaining the separate trusted selection/runner authority controls: the new checker is now included in planner CI executable and selection-authority sets and the independent selection witness authority list. Its module is registered in coverage-quality, critical modules and positive/negative acceptance mappings. The observed policy keeps global line 90, critical line/branch 95/90 and impact 100/100. This source registration preserves a FULL bootstrap for authority changes; it does not by itself activate this new checker in production.

## Existing execution evidence inspected

`minimum-witness/final-security/summary.json` SHA-256: d965b61dc032a98752f0fd42a5619fcf010b77005c643a9af9b3e3371daaea43.

The recorded hashes of final-311.log, final-313.log, final-311.coverage and final-311.json were independently recomputed and match the summary. Both log tails contain 17 tests and OK (58.477s / 53.627s). The summary reports 187/187 statements, 32/32 branches and zero exclusions for the exact new witness source.

The measurement deliberately separates eight real isolated CLI tests from supplementary in-process path tests using a documented sys proxy. The latter measure actual candidate source paths while retaining real Git/object checks and accepted child execution; they are not independent certificates of interpreter isolation. The earlier CLI tests provide that separate behavioral evidence. No old or copied subprocess coverage is promoted to this source's measured lines.

No repeated execution was performed for this review. Committed-head plan, hosted native evidence, independent accepted-checker deployment and applicable human review remain root-task steps. The original report's event-specific obligation and external caller-binding requirements remain applicable.
