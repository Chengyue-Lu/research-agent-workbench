# Independent minimum witness: source review

Profile: CI trust-boundary reviewer. Required Skills: []. Reviewer: attempt_review_v2.
Scope: read-only review of the new witness/tests, accepted planner/dependency/governance helper interfaces and implementation report. No repository edits, tests, Git execution, or external calls were performed. Only this assessment report was written. Findings below are source-grounded reasoning, not claims of an executed exploit.

## Source identities reviewed

- `.github/scripts/ci_minimum_witness.py`: f18524236ce66375714d13e9fc2b9d741c79bddfa0c8b30afa3662fb019af468
- `tests/test_ci_minimum_witness.py`: c06568e9b3d6b1bddb8263b46e7815b540818c27ee66508fcf4ff8f447de31cb
- `.github/scripts/plan_ci.py`: 8dd97ff415398dddefa1f8bfab4e0f6814dae8140626489608d510999db4b851
- `.github/scripts/ci_dependencies.py`: 5768999e3e6929f69ac87c56b94b9ecb66bf4ee527f48d97a21beb839110a20f
- `.github/scripts/check_pr_governance.py`: 54257b48b6fab0fb644d501f514c20cb1959def340e578c490e68e38ef66de16

Status: changes required for the object-input trust claim. Root has relayed the findings for implementation; this report does not claim those subsequent changes are already verified.

## P1: Authenticate the commit/tree chain before importing accepted helpers

`blob()` (lines 70-81) recomputes only leaf blob identity. `authenticate_checkout()` and `witness()` treat `rev-parse`/`ls-tree` responses as sufficient authentication of the external commit pin. Git normally reads local objects by their stored object name; those commands are not an integrity check of every object on the commit-to-path chain. The local bare clone is a filesystem object copy and does not supply that missing integrity check.

When the candidate object store is untrusted, it can contain a replaced loose commit or intermediate tree under a pinned object's filename, pointing to a different internally valid tree/helper blob. All leaf hashes can still pass. The copied worker can then import bytes that are not descendants of the externally pinned accepted commit. This is inside the declared candidate-repository input boundary; it does not require replacing the host Python/Git executables.

Required fix: verify the actual commit, intermediate tree and blob identities before trusting paths. Since the accepted planner also reads merge-base and ancestor history, verification must cover the full reachable history/object closure that these operations may consult, not only current base/head root trees. A strict full object check on an isolated object store is a reasonable conservative approach. Apply the same chain authentication to the running checker checkout before relying on its helper/self pin. Add real malformed commit and tree object cases; existing dirty-working-file tests do not exercise this failure.

## P2: Validate parents and history in the sanitized object store

The parent check at lines 143-148 runs against the original candidate repository before cloning. `--no-replace-objects` disables replacement refs but does not constitute a prohibition on every local history/configuration input; local graft state can affect history queries. The clone then computes the minimum using a different repository state without rechecking target parents there. An accepted target-parent statement must not be derived from candidate local history overrides.

Required fix: reject unsupported grafts, shallow state, external alternates and promisor/lazy-object behavior before any operation that may use them; preserve a sanitized candidate-data path. Recheck exact commits and parent headers after object authentication, on that clean store (or directly from authenticated raw commit headers). Do not rely solely on environment cleanup: repository-local configuration remains a separate input. Tests should retain a graft/history-override negative case alongside replacement-ref handling.

## Required deployment boundary: the private worker is not an authenticated receipt endpoint

`--worker` at lines 210-213 accepts arbitrary stdin `trusted`, `sources`, `repo`, `inputs` and `plan`. It intentionally skips `authenticate_checkout()` and can import caller-chosen helper bytes. A direct invocation can therefore produce `comparison: PASS` without checking an external witness commit. It can also exit zero for a BLOCK comparison because worker success means protocol execution completed. Its output currently omits the outer receipt identity and authority flags.

The direct worker does not produce the complete outer receipt, so this is not evidence that the current outer launcher accepts such a forged receipt. It is a material deployment/consumer constraint: designate the response as an internal, unauthenticated worker result; accept it only in the authenticated launcher's bound child-process channel. A workflow/receipt consumer must reject raw worker output, require the full expected outer envelope and external run/head/base/metadata/checker binding, and never interpret exit zero or `comparison=PASS` alone as authority.

The current candidate implementation cannot approve itself by echoing an `expected-witness` argument. Before production use, a caller outside candidate control must select and execute an already accepted checker commit, obtain repository/base/head/target/ref/body from authoritative event state, and bind the receipt to that execution. A receipt hash is an integrity checksum, not a signature. The existing false checker-acceptance/execution-authority fields correctly preserve this boundary and must not be removed merely because local tests pass.

The function currently models PR minimum inputs; callers must separately retain any event-specific force-full/integration obligations that are not represented by its input contract. This witness verifies a plan floor, not actual test inventories, coverage results, smoke completion, or governance review.
