# PR101 opaque consumer boundary inventory

2026-09-26. Independent read-only inventory for the CI coordinator. Repository worktree: `D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe`; examined candidate `8d94296c2fffe5bc7baf738e603376388fa24c59`, accepted base `5bf2227ca9b4d2f63f452e579185e7838028de78`. No business/source/test/remote writes and no behavioral test rerun were performed. The only output is this assessment.

## Concrete result

The three supplied fanout witnesses arise from recognizable invocation sites, not demonstrated consumption of `ci_consumer_shadow.py`. Each can support a narrowly defined invocation contract, but the current raw declaration template alone cannot authorize excluding it. **Prioritize the fixed fresh-actor invocation in `research_state/gate.py`: a graph-only counterfactual shows this one opaque edge accounts for 32 of the current 103 selected modules.** Removing the CLI edge alone gives no reduction because another opaque consumer leads back to CLI; removing the harness test edge alone also gives no reduction because fixtures retain independent dynamic execution.

These are static source findings and graph counterfactuals. This assessment did not observe fresh business executions. It does not certify complete read closure, B/C inventory, or production exclusion authority.

## Three actual scenarios and their boundaries

### 1. Context Git identity: fixed Git metadata command

- Source: `src/research_workbench/cli.py`, `_context_resume_check` around lines 1233–1260 and `_context_checkpoint` around lines 1446–1459. Both subprocess calls are exactly `['git', '-C', str(root), 'rev-parse', 'HEAD']`, with capture/text and `check=False`; there is no shell, Python command, script path, or user-controlled command fragment at either call.
- Existing real scenarios: `tests/test_m3_context_observability.py::test_explicit_git_capture_fails_closed_outside_repository` creates a temporary project, passes `--capture-git-head`, and expects failure without an output state; `test_resume_check_rejects_git_head_conflict` uses the repository root and a wrong pinned SHA, expecting `RESUME-CONFLICT-GIT`. `test_safe_pause_fixture_is_file_recoverable` covers the valid continuation path.
- Constant execution target shape: Git executable plus the `rev-parse HEAD` operation. Variable input is a project path; related Python input documents are the state, protocol, machine-state references and runtime/schema resources. Git also consumes repository metadata and process configuration/environment.
- Static inference: these calls do not ask Git to execute the diagnostic Python script. A specific diagnostic `.py` source edit should not become an arbitrary-code input merely because this module imports `subprocess`.
- Remaining unknown: `git` is selected through PATH and environment is inherited; no interpreter/executable provenance or Git configuration closure is established by the current declaration. CLI has many other operations/imports, so this is a contract for these two invocations rather than an exemption for every CLI behavior.
- Useful counterexamples for a base-owned checker: replace the command executable/verb; add `shell=True`; replace the command literal with a value obtained from input; alias/rebind `subprocess.run`; mutate the containing function, helper, or environment builder. Each must invalidate a bounded contract and retain ordinary closure.

### 2. Phase C gate: fixed module in a fresh actor with staged documents

- Source: `src/research_workbench/research_state/gate.py::run_gate_case`, lines 342–398. Its only subprocess is `sys.executable -m research_workbench.research_state.fresh_actor <actor-manifest> <answer>`, with `cwd=actor_root`, where `actor_root` is a fresh temporary directory. It copies the environment, removes `RWB_PHASE_C_ORACLE`, and fixes `PYTHONHASHSEED=0`.
- Existing real scenario: `tests/test_phase_c_gate.py::CanonicalGateTest.setUpClass` runs two fixed case manifests under `examples/phase-c/m10-003-gate/case-a` and `case-b`. Tests assert distinct actor PIDs, exact case-data read surfaces, retained private-oracle isolation, source-manifest/oracle hashes, and the combined gate-input digest.
- Input staging: `_stage_case` accepts manifest-listed `source_ref.path` values only within `project_root`, rejects oracle inclusion and duplicates, verifies content SHA/kind/identity, copies only those document bytes into `actor_root/inputs/...`, and writes the actor manifest. The source read occurs before document-type validation, so do not claim a general prohibition on reading a `.py` path for every possible caller; scoped canonical manifest bytes and their reference closure are the evidence boundary.
- Actor: `fresh_actor.py::run_actor` imports fixed RWB modules, constructs `SchemaCatalog`, then installs `FileAccessPolicy` allowing the exact staged files, output, and catalog directory. This hook starts **after imports and catalog initialization**. It is strong case-data evidence but does not itself prove startup import or Runtime manifest closure. `load_document_bytes` only parses JSON/YAML suffixes.
- Static inference: the subprocess executes the named module; it never executes `ci_consumer_shadow.py` as an entrypoint. The canonical manifest bytes choose fixed document roots. A bounded invocation witness can add an explicit dependency on `fresh_actor.py` and preserve its normal import closure without adding every `.py` seed to `gate.py`.
- Remaining unknown: inherited `PYTHONPATH`, Python site startup, package resolution and pre-hook Runtime initialization. A witness should bind accepted caller/child/loader and helper bytes, executable identity, import origins and environment policy, plus complete Runtime manifest membership. The existing actor case-data policy alone cannot close these.
- Useful counterexamples: mutate `-m` target, switch to `-c`/script path or alias; inject an execution-capability escape; modify module loader/PYTHONPATH; new runtime member or manifest drift; changed case manifest referencing a previously unrelated path; candidate-only contract or changed caller/child hash; add a second unknown subprocess. In all cases the exclusion must fail closed and normal dependency edges remain.

### 3. Harness cold replay: fixed inline runner, with a separate dynamic fixture path

- Source: `tests/test_evaluation_harness_execution.py::HarnessReplayTests.test_fresh_process_replay_forbids_ports_tools_and_checker_execution`, lines 327–350. It launches `sys.executable -c <literal script>` with temporary fixture root, explicit repository `schemas`, serialized run ref and context. The script imports fixed replay types/functions, installs an audit hook rejecting subprocess/socket operations and execution under the project root, and invokes real `replay_harness`.
- Existing lifecycle is broader than that subprocess. `HarnessReplayTests.setUpClass` first creates the complete archive using real `execute_harness`; the resulting prototype is copied for each adversarial replay. Observing only the cold replay omits this setup cost and its execution input closure.
- In `tests/harness_execution_fixtures.py::ExecutionFixture.ports`, lines 126–131, a **second dynamic boundary** loads `self.root / self.bindings['plain-agent-tool']['implementation_ref']['path']` via `spec_from_file_location` and `exec_module`. Its generated tool belongs to fixture state; it is not the diagnostic script, but that fact requires checking the fixture builder and generated binding/bytes. `tests/system_evaluation_fixtures.py` is another opaque helper and retains its own path to the harness tests.
- Static inference: the literal cold-replay child is bounded more tightly than the graph currently represents, but suppressing its one edge cannot remove the harness module from selection. A safe witness must cover the full setup + actual helper/tool invocation and runtime/input closure. The replay's existing patches are assertions that unavailable ports must not be invoked; they must not be used to replace actual archive creation or required integrations.
- Useful counterexamples: mutate literal child source; inject exec/run-module through a passed value; change the serialized ref to an unlisted input; change generated tool path/bytes; symlink escape; alter helper import/Runtime membership; rename or add a fixture input. The contract must not survive these changes as an unchanged consumer proof.

## Read-only graph experiment

Used the current `.github/scripts/ci_dependencies.py::select` against exact base/head and only seed `.github/scripts/ci_consumer_shadow.py`. Called existing `reviewed_seeds`/`reviewed_consumers` parameters directly in memory to model hypothetical exclusions. **No policy was modified or accepted, no test or CI ran, and these counts are not full planner obligations/B-C union.**

| Counterfactual omitted opaque consumer edges | Dependency-selected modules |
| --- | ---: |
| None | 103 |
| CLI only | 103 |
| Phase C gate only | 71 |
| CLI + gate | 71 |
| CLI + gate + cold-replay test | 71 |
| All preceding + harness execution fixture | 71 |

Alternative actual graph paths explain the lack of additional reduction:

- `ci_consumer_shadow.py -> artifacts/run_reconstruction.py [opaque] -> cli.py [syntax]`.
- `ci_consumer_shadow.py -> tests/system_evaluation_fixtures.py [opaque] -> tests/test_evaluation_harness_execution.py [syntax]`.
- The same system-evaluation fixture reaches `tests/harness_execution_fixtures.py`.

Only filename/path metadata from these alternative paths was used to identify the next audit scope; unrelated archive contents were not opened.

## Implementation order and acceptance

1. Implement a **base-owned structural invocation checker** for the fixed module call as the smallest useful activation domain. The external accepted base must own both checker and its invocation specification; a candidate cannot self-certify a new exclusion. Require exact accepted/candidate call-site and environment/loader shape or explicit invalidation. Add named child-module/import dependencies to the ordinary graph, keep unknown subprocess/exec reflection conservative, and retain coverage policy and independent selection floor.
2. Verify canonical positive cases and adversarial mutations against that checker plus the real child. Prove candidate/new/missing/mismatched specs reject; prove helper/child/runtime or manifest changes remain selected. Merely matching a source hash is provenance, not semantic independence.
3. Run full planner for a bounded diagnostic-source change under the accepted checker and compare **B, C, B∪C and smoke obligations**, not only the 103→71 dependency counterfactual. Changed-line/branch 100/100 and applicable critical95/90 remain required. A new selection-authority implementation PR may itself require broad regression; the reduction claim belongs to a subsequent accepted-base probe.
4. Test organization is secondary: moving the cold replay into a dedicated module can isolate that single subprocess, but the fixture's dynamic tool execution and shared helpers still select the remaining harness tests. Moving imports into another file without closing the invocation simply relocates the expansion. Preserve original integrations and failure-specific test names.
5. Expanding the fixed-call checker to Git identity can improve explanation/edge accuracy but has no additional reduction in the measured current graph while `run_reconstruction` remains opaque. Larger fixture contracts can follow only after their generated tool and input roots are independently checked.

No wall-clock speedup is claimed. The main actionable result is a bounded, measurable first candidate and the alternative paths that would otherwise make an apparent fix ineffective.
