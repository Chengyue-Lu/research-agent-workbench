# PR101 dependency reduction design review

Owner: Chengyue-Lu / TEST-PERF-002 / Issue 87. Role: CI dependency boundary reviewer.
Date: 2026-09-26. Scope: read-only source analysis and dependency replay; no repository/remote edits or test execution.

## Recommendation

**First reuse the accepted base-side group mechanism for one bounded offline CI diagnostics family.** Add a reviewed group for `ci_consumer_shadow.py`, `ci_shadow_pair.py`, and `ci_domain_audit.py`, with complete family proof suites and `change_scope: function-body`. Independently enforce the full accepted planner minimum. This is substantially smaller than introducing a new subprocess-argv compiler and directly addresses a missing maintained domain in the existing policy.

The scope is future bounded function-logic changes to that family. It does not establish that arbitrary CI files, arbitrary subprocesses, current PR101's new API/functions, or business runtime changes are independent. The group should not be used as a blanket `.github/scripts/**` exemption.

## Verified cause and existing foundation

The exact dependency replay used base `5bf2227ca9b4d2f63f452e579185e7838028de78`, head `8d94296c2fffe5bc7baf738e603376388fa24c59`, and only `.github/scripts/ci_consumer_shadow.py` as seed. It returned **103 test modules**. This is a dependency replay, not test execution or a performance result.

`ci_dependencies.py` lines 650–653 connects any non-test Python seed to every old/new opaque consumer. All subprocess calls are opaque in `_file_facts`. This synthetic edge reaches CLI, research-state gate, harness, build/registry/other tests and then ordinary reverse imports. The observed seed does not actually import or call all these business consumers. Removing one shortest witness path cannot prove absence of alternate paths.

The existing `plan_ci.py` lines 560–670 already supports a narrower accepted rule:

- Base-side surface/group selects explicit coverage leaves and complete proof tests.
- Imports must be unchanged; `function-body` additionally fixes definitions, module/class initialization, calls, names, attributes, strings and execution/resource boundary facts.
- `reviewed_contract_anchor` locates a continuous accepted authority epoch and a matching fingerprint.
- `evidence_drift` invalidates a contracted group when direct proof tests, their known helpers/resources, or package initializer membership changes.
- `reviewed_consumers` includes only paths whose Git mode/object metadata are unchanged in anchor, base and head.
- Old/new graph union retains new or changed consumers and all necessary additions. Missing anchor or insufficient function boundary restores ordinary closure.
- Coverage evidence, critical mappings and smoke dimensions remain independently additive.

Current `ci_impact_policy.yaml` has Provider, Claim and Projection leaf groups; it has no corresponding CI diagnostic source family. Validation already permits `.github/scripts/*.py` coverage leaves and complete module `coverage_tests`, so this path requires no new contract language.

## Proposed family contract

Use a maintained family name such as `ci-offline-diagnostics` and explicit three source members:

- `.github/scripts/ci_consumer_shadow.py`
- `.github/scripts/ci_shadow_pair.py`
- `.github/scripts/ci_domain_audit.py`

Use `class: focused`, `change_scope: function-body`, `package: false`, `repository: false`, and the complete `test_ci_consumer_shadow`, `test_ci_shadow_pair`, `test_ci_domain_audit` modules for behavioral and coverage proof. Add every other actual direct consumer/proof module discovered from both accepted graph and current critical mappings; this starting trio is a minimum, not a declaration that no other consumers exist. Keep current named positive/negative acceptance IDs and their downstream helper evidence. The family may instrument all three leaves when one changes, which is a deliberate bounded cost rather than a weakened threshold.

`ci_shadow_pair` imports `ci_consumer_shadow`, which imports `ci_domain_audit`; these dependencies make a real family, rather than three unrelated convenient filenames. Existing imported shared helpers (`ci_contract_shadow`, `ci_input_facts`, planner/checkers) are not granted the family's narrow leaf treatment. Changing those helpers remains ordinary closure/authority behavior.

Refresh the consumer fingerprint only against the explicitly recorded composition, retaining all other policy groups. Candidate policy changes cannot supply the current candidate's own exclusion minimum: the existing planner reads base policy. A declaration newly introduced in PR101 becomes usable only after actual acceptance into the baseline.

## Exact admissible reduction

The existing `function_body_only` check permits a deliberately small class of edits. It strips function bodies to compare surrounding initialization/definitions, then checks changed body names/calls/imports/attributes/string inputs and rejects opaque execution in the changed function context.

Thus comparator/set/boolean logic fixes with stable boundary expressions can potentially use the new family. Added/deleted functions, new imports, changed calls or bindings, changed strings/resource paths, changed execution arguments, evidence/helper drift and unknown consumers restore the broad closure. Current PR101 adds accepted-template functions and CLI options, so it does not satisfy this leaf predicate. Do not present its 103-module source run as a reduction case; use a subsequent tiny correct/wrong logic probe with existing tests on an accepted-equivalent fixture.

`package=false` and `repository=false` mean this group's own work does not require those smokes. They do not override smokes arising from new consumers, other touched surfaces, unknowns or integration.

## Independent accepted minimum enforcement

The current `selection_witness.py` independently enforces only the selection-authority FULL floor. Keep it. Its accepted AUTHORITY covers planner, dependencies, checks, ordered runner, workflow and itself, so changing this mechanism on the implementation PR remains FULL.

The smallest stronger witness reuses the accepted planner rather than implementing a second planner:

1. Obtain repository/base/head/merge target and actual plan from the API or explicit trusted inputs. Never take those roots solely from candidate plan fields.
2. Use a clean, independent full-history accepted checkout. Verify exact root commit and every imported repository module originates from and matches that accepted tree. Candidate checkout/Git object inputs are data; candidate Python, imports, config, optional shadow files and environment paths cannot execute in the witness.
3. Invoke accepted `make_plan` with the same explicit Git facts and documented metadata/event inputs. Its policy is read from accepted base; candidate coverage changes can only add obligations under accepted rules.
4. Invoke accepted `require_obligations(candidate_plan, minimum)`. This already checks independent risk, behavior, coverage obligations, Python versions, smokes, policy identity, dependency proof, tests/groups, coverage modules/tests, exact changed lines and positive/negative mappings. Do not merely check `behavioral_scope` or count tests.
5. Bind witness source/dependency identity, accepted base, candidate target, plan ID, content run and minimum digest into the external receipt. Worker/fixed aggregates require the applicable receipt; unknown version, missing/stale/canceled/failed receipt blocks.

A trusted checkout label or PR101's accepted-template argument is not reviewer approval. Until this checker itself is accepted, its new result is implementation/experiment evidence. The old accepted witness remains the actual bootstrap authority.

## Minimum adversarial proof

- Correct bounded logic and intentionally wrong equivalent-shape logic in each family member; current tests must catch the wrong variant. Preserve positive/negative identities and changed 100/100, whole critical files 95/90.
- Added import/call/string/path/function/default/module initializer; dynamic execution/reflection/escaped callback; ordinary closure restored.
- Changed/new consumer, helper, test evidence, __init__, fixture directory membership, deleted/renamed/symlink/gitlink source and alternate import path; old/new closure retained.
- Candidate-only policy group, changed fingerprint or empty evidence cannot grant exclusions against actual old base.
- Accepted family source change plus another unrelated new consumer in one PR; additions remain selected.
- Candidate forges B/C lists, changed coordinates, impact proof, skips a required smoke or lowers risk/coverage; accepted planner minimum rejects it.
- Candidate changes selector/witness/its dependency and marks itself docs/focused; old independent FULL floor catches it.
- With a FULL candidate plan, verify actual complete collected inventory and execution receipts as well as planner comparison; a FULL label does not prove execution.
- Existing Provider/Claim/Projection group histories continue to behave the same. Missing/discontinuous fingerprint anchor or proof drift restores conservative selection.
- Actual group code mutation must stay diagnostic-only: no report can acquire `execution_authority=true` or activate cross-commit reuse through this CI selection contract.

## Execution and acceptance sequence

1. Implement base group and stronger independent minimum witness, record family closure/evidence. Keep source-reader business code unchanged. Run focused/adversarial validations and one mandatory FULL implementation CI.
2. Build isolated Git histories with the proposed authority accepted only as a **test fixture**. Reuse the unmodified original accepted baseline separately as a control, demonstrating candidate-only policy cannot lower its plan. Never call a fixture root production-accepted.
3. For the same target and runner environment, compare old and family candidate selected identities and B/C union. Execute both actual suites, including coverage and existing order/lifecycle receipts. A reduced declared B with the same effective B union C is not a reduction.
4. Publish first pair as an engineering observation. The accepted performance matrix calls for at least three fresh hosted same-environment pairs before a reliable performance acceptance claim. Keep setup/job/suite/total compute separate and do not compare old 410-case test-only runs with source changes.
5. Deliver a concrete independently reviewable activation PR with observed exclusions, faults, quality, receipt checks and remaining fallback cases. Current permission allows implementing and testing toward reduction, but PR101 Ready/merge remains unauthorised. Obtain applicable review and final integration authorization only after that concrete result exists.
6. After actual acceptance into a trusted baseline, a subsequent bounded source probe must show the reduced **official** plan and native executions. Actual inventory and elapsed cost close production reduction; integration/develop continues fresh full/repository evidence.

## Deferred generic execution compiler

A future compiler can replace proved synthetic opaque edges with typed finite execution domains, useful for broader structural changes outside this narrow family. It should recognize supported invocation classes, not whitelist subject paths. Fixed Git metadata calls, fixed Python -m/-c and runpy paths require environment, argument and recursive child-input proof. In particular a fixed `-m fresh_actor` entrypoint may still load executable references from its manifest, so entrypoint recognition alone cannot close its domain. Any unresolved site or child capability retains opaque fallback.

This additional mechanism is unnecessary to demonstrate the first family reduction and should not delay it. It also cannot be simulated safely by simply marking every subprocess in CLI/gate/harness bounded.

## Result limits

No elapsed saving is proved by this review. The exact 103-module replay confirms the cause. The preferred reuse path is implementable with fewer new semantics, but deliberately applies only to the existing function-boundary predicate. Formal reduced CI requires the new family/independent root to be accepted first; current-slice paired runs can establish the effect without pretending that acceptance has occurred.
