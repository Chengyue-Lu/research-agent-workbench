# Security follow-up and measured source coverage

This addendum supersedes the implementation identities in the preceding report. The original report and all earlier evidence remain unchanged. Only the two assigned source/test files were edited; root-owned policy, documentation, and shared records were not changed by this agent.

## Authentication corrections

Before the first Git subprocess against an input repository, filesystem inspection locates standard/bare/linked-worktree Git metadata and rejects alternate object files, grafts, shallow history, promisor objects, and config that enables includes or nonstandard execution/partial-object behavior. It then creates a fresh bare copy using local, non-hardlinked objects, inspects that copy, and runs `git --no-replace-objects fsck --full --strict --no-reflogs` with cleaned Git/Python environment. Source repository fsck ignore/skip settings cannot suppress errors in the clean copy.

Both the caller-pinned checker checkout and the candidate Git data receive full-object validation before any accepted planner source is read or imported. This checks intermediate commit/tree objects and ancestor history, not only leaf blob hashes. Exact input commit raw SHA-1 and merge-candidate parents are also checked in the clean copied database. The runner source is checked again against its authenticated source digest before spawning the child.

Worker transport output is explicitly `kind=internal-planner-comparison` and lacks a final `status` receipt. The outer process validates that kind and emits `kind=ci-minimum-witness` with complete identities. A bare worker comparison or exit code does not attest checker acceptance or authorize reduction.

## Verification at final source

- Python 3.11: **17 tests PASS**, 58.477 seconds, under branch coverage.
- Python 3.13: **17 tests PASS**, 53.627 seconds.
- Exact new witness file: **187/187 executable statements and 32/32 branches**; zero missing, zero exclusions. This exceeds critical 95/90 and supplies local 100/100 for the wholly new module. Exact committed-head/hosted changed-line verification remains the root task's responsibility.

Eight original real-Git, real `Python -I` CLI cases remain as independent process-isolation evidence. Nine additional path tests directly measure the actual candidate source path. Those supplementary tests use a documented sys proxy only to enter the outer isolated-only API in the test process; real Git cloning, object authentication, accepted planner child execution, and module-source validation are retained. Worker path tests execute actual accepted helper source and restore `sys.path`/`sys.modules`. No mock substitutes candidate helper code for accepted code; no copied subprocess source, old accepted helper, path remapping, or synthetic coverage records are counted as new-witness coverage.

Additional adversarial paths include corrupt intermediate tree objects, corrupt raw commits and blobs, graft/alternate/shallow/promisor metadata, unsafe config, linked worktree metadata, malformed JSON and duplicate keys, wrong plan signatures/shapes/bindings, helper identity/origin mismatch, missing loaded governance helper, outer worker failure, and output preservation.

## Preserved failed attempts

The first path-only attempt had seven passes and two fixture errors when Windows rejected normal overwrite of a hidden `.git` marker/read-only newly created Git object. The fixture now opens these explicitly owned temporary files with `r+b` after granting the owner write bit. The first coverage invocation also mistakenly passed a file as `--source`, yielding no data; it is not coverage evidence. `path-first.coverage` remains under the parent assessment directory. The corrected path-only run passed all nine tests in 23.752 seconds and already measured 187/187 and 32/32 (`path-second.coverage`, `path-second.json`). Final complete runs then verified the security-adjusted source and both retained CLI and new path tests together.

## Evidence and identities

`summary.json` records hashes of final logs, coverage database/JSON, and source files. Raw logs are `../final-311.log` and `../final-313.log`; measurements are `../final-311.coverage` and `../final-311.json`.

- `.github/scripts/ci_minimum_witness.py`: `f847918c7abb35297c7eec549508bca0edd9e9e440cb375704ecf70e288a73e5`
- `tests/test_ci_minimum_witness.py`: `9dab317be6c81c28d15bc8241e2bcf72666623c523313ea7998f17d6dc7416ca`

No commit or push was performed by this subtask. This is local source verification, not hosted execution or formal independent checker approval. The caller's Python/Git/runtime installation remains trusted infrastructure; host-admin replacement of those executables is outside this checker boundary. Root-owned authority/critical/evidence registration and final independent review remain separate.
