# Independent minimum witness implementation

Scope: CI trusted-execution engineer. Required Skills: none. Source writes were restricted to `.github/scripts/ci_minimum_witness.py` and `tests/test_ci_minimum_witness.py` in the PR101 worktree. No commit, push, shared-memory update, existing test deletion, selector change, or production activation was performed.

## Implemented

The new stdlib-only launcher requires an isolated Python invocation and a caller-supplied exact witness commit. It authenticates its own running checkout plus the planner, dependency helper, governance helper, and governance JSON as regular `100644` Git blobs, verifies Git object hashes, and rejects local source drift. The running script chooses its own checkout root; callers cannot provide a different authentication root.

The repository, base, head, target, base ref, and PR metadata body are external inputs. It validates exact commits and target parents, makes a temporary bare copy of the Git object data without checking out candidate files or using external object alternates, and copies only the four accepted-base planner inputs to a separate temporary tree. A fresh `Python -I -B` process imports these helpers, calls the original `make_plan` and `require_obligations`, and authenticates the loaded project-helper paths and bytes. No candidate Python is imported. Candidate plan fields do not choose the external base, head, target, metadata, or checker commit.

Receipts include the minimum plan, comparison, witness commit and source identities, accepted planner base and source identities, base/head/target tree identities, hashes of the external inputs/body/candidate plan, and YAML runtime origin/version/source hash. Exclusive output creation rejects an existing receipt or a plan/output alias without overwriting evidence.

`execution_authority`, `checker_acceptance_proved`, and `execution_checks_proved` remain false. The current accepted develop does not contain this new checker; only a separately accepted, externally pinned checker commit can support a formal future exclusion witness. This implementation alone grants no production reduction or review acceptance.

## Actual verification

Real Git repositories and real isolated CLI processes are used for all eight tests. No mocks stand in for isolation or accepted-source authentication.

- Python 3.11 initial eight-test run: PASS, 27.620 seconds.
- Python 3.13 subsequent eight-test run: seven PASS and one test-harness ERROR, 27.735 seconds. The newly strengthened plan/output-alias case passed `plan` twice to the test helper, causing a Python argument-binding error before invoking the checker. This was not a checker result. The helper argument was renamed to `candidate`.
- Only the affected alias case was rerun after correction: Python 3.11 PASS (1.947 seconds); Python 3.13 PASS (1.903 seconds). No redundant full rerun was performed.

Cases cover authentic focused-plan reproduction; required-test removal; coverage/package/repository obligation removal after resigning the candidate plan; candidate policy and bootstrap guard rewrites; external repository/commit/target/metadata binding; dirty pinned checker/helper and wrong checker commit; absent/nonregular accepted helper; candidate `yaml.py`, same-name planner/dependency modules, `sitecustomize.py`, and `PYTHONPATH` injection; existing output and input/output aliases.

These are local behavioral results, not hosted evidence. The isolation tests execute copied committed checker source in child processes. Ordinary parent-process coverage does not automatically measure these child copies; no changed-line/branch coverage claim is made. Critical coverage registration, truthful subprocess measurement, final source review, exact committed-head plan/governance, and hosted native validation remain with the root task.

## Final source identities

- `.github/scripts/ci_minimum_witness.py`: `f18524236ce66375714d13e9fc2b9d741c79bddfa0c8b30afa3662fb019af468`
- `tests/test_ci_minimum_witness.py`: `c06568e9b3d6b1bddb8263b46e7815b540818c27ee66508fcf4ff8f447de31cb`

Existing `.codex/config.toml` and concurrent root-owned policy/documentation changes were left untouched. All historical original test bodies remain intact.
