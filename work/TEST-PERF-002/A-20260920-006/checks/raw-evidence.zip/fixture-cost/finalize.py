import hashlib,json,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=Path('D:/lcy/develop/_worktrees/RWB/ci-fixture-clone')
def read(name):return json.loads((OUT/name).read_bytes())
def sha(data):return hashlib.sha256(data).hexdigest()
source=(ROOT/'tests/test_ci_plan.py').read_bytes();rows=[]
for label,count in (('311-fixture',1),('313-fixture',1),('311-full',74),('313-full',74)):
    receipt=read(label+'-receipt.json');process=read(label+'-process.json');preflight=read(label+'-preflight.json')
    assert receipt['successful'] and receipt['test_count']==count and receipt['outcomes']['passed']==count
    assert receipt['events']=={'failures':0,'errors':0,'skips':0}
    assert process['exit_code']==0 and preflight['candidate_file_sha256']==sha(source)
    rows.append({'label':label,'python':preflight['python_version'],'count':count,'outcomes':receipt['outcomes'],'process_wall_seconds':process['wall_seconds'],'runner_wall_seconds':receipt['wall_seconds'],'receipt_sha256':sha((OUT/(label+'-receipt.json')).read_bytes()),'log_sha256':sha((OUT/(label+'.log')).read_bytes())})
doc=ROOT/'docs/workstreams/chengyue-lu/TEST-PERF-002/FIXTURE_CLONE_COST.md'
text=doc.read_text(encoding='utf-8')
old='The final validation results and raw evidence hashes are recorded by the enclosing\nTask Attempt. Until that record is complete, this note does not claim final CI or\nmerge-target acceptance.'
new='The current worktree source passes these fresh checks:\n\n| Scope | Python | Result | External process wall |\n| --- | --- | --- | ---: |\n'
for row in rows:new+=f"| {'New fixture regression' if row['count']==1 else 'Complete PlannerTests'} | {row['python']} | {row['count']} PASS, zero skip/error/failure | {row['process_wall_seconds']:.3f} s |\n"
new+='\nThe tested `tests/test_ci_plan.py` SHA-256 is\n`'+sha(source)+'`.\nThe source remains an uncommitted worktree change against the stated base; these\nchecks are not authenticated merge-target CI. Raw native receipts, process commands,\ninventories, dependency versions and hashes are retained for the enclosing Task\nAttempt. Independent source review found no material issue and did not run tests.'
assert old in text;doc.write_text(text.replace(old,new),encoding='utf-8')
check=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True);assert check.returncode==0,check.stdout+check.stderr
patch=subprocess.check_output(['git','diff','--binary','--','tests/test_ci_plan.py'],cwd=ROOT);(OUT/'implementation.diff').write_bytes(patch)
(OUT/'FIXTURE_CLONE_COST.md').write_bytes(doc.read_bytes())
summary={'execution_authority':False,'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip(),'source_worktree_uncommitted':True,'source_sha256':sha(source),'doc_sha256':sha(doc.read_bytes()),'unchanged_existing_test_asts':73,'added_regression':1,'checks':rows,'independent_review':'review.md; source SHA unchanged; final documentation adds measured validation facts','diff_check':True,'git_status':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True).strip(),'performance_claim':'three Git invocations removed per fixture; execution timings only, no paired or hosted improvement claim'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['# Fixture clone cost handoff','',f"Base `{summary['base']}`, branch `{summary['branch']}`; source remains uncommitted.",'','Only `tests/test_ci_plan.py` and `FIXTURE_CLONE_COST.md` changed. Three per-case configuration subprocesses move into the real clone command. `--no-hardlinks`, identity, branch, LF, original fixtures/assertions and cleanup are retained.','',f"73 prior test-method ASTs unchanged; new actual config/object/seed-isolation regression passes both Python versions. Source SHA-256 `{summary['source_sha256']}`.",'','| Run | Result | Process wall |','| --- | --- | ---: |']
for row in rows:lines.append(f"| {row['label']} / Python {row['python']} | {row['count']} PASS, no skips/errors/failures | {row['process_wall_seconds']:.3f} s |")
lines+=['','Independent source review: no material issue; no tests run by reviewer. No controlled performance comparison was performed while other tasks were active. The historical prototype measurements are not reused as current results.','', 'Raw commands, source snapshots, environment/dependency metadata, inventories, native receipts, logs, review, patch and manifest are retained here. No policy, production code, old branch or frozen evidence was modified; no commit, push or PR operation occurred. Final commit/merge-target CI and named-owner acceptance remain with the root task.']
(OUT/'HANDOFF.md').write_text('\n'.join(lines)+'\n')
manifest={p.name:sha(p.read_bytes()) for p in OUT.iterdir() if p.is_file() and p.name!='sha256.json'}
(OUT/'sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'checks':rows,'source_sha256':summary['source_sha256'],'doc_sha256':summary['doc_sha256'],'handoff_sha256':manifest['HANDOFF.md']},indent=2))
