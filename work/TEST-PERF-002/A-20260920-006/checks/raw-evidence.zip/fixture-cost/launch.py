import json,os,subprocess,sys,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=Path('D:/lcy/develop/_worktrees/RWB/ci-fixture-clone')
label=sys.argv[1];version='311' if label.startswith('311') else '313'
python=Path('D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917')/('venv'+version)/'Scripts/python.exe'
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONUTF8']='1';env['PYTHONPATH']=os.pathsep.join([str(ROOT/'src'),str(ROOT),str(ROOT/'tests'),str(ROOT/'.github/scripts')])
args=[str(python),'-B',str(OUT/'run_checks.py'),'--label',label,*sys.argv[2:]]
start=time.perf_counter()
with (OUT/(label+'.log')).open('wb') as log:p=subprocess.run(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'command':args,'exit_code':p.returncode,'wall_seconds':time.perf_counter()-start,'timing_scope':'test execution record on shared host; no paired performance claim'}
(OUT/(label+'-process.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(p.returncode)
