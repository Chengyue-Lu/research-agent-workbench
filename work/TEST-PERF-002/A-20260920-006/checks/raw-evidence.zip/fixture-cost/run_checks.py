import argparse,ast,hashlib,importlib.metadata,importlib.util,json,os,platform,subprocess,sys,time,unittest
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('D:/lcy/develop/_worktrees/RWB/ci-fixture-clone')
parser=argparse.ArgumentParser();parser.add_argument('--label',required=True);parser.add_argument('--fixture-only',action='store_true');args=parser.parse_args()
def sha(data):return hashlib.sha256(data).hexdigest()
def canonical(value):return (json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
def write(name,value):(OUT/name).write_bytes(canonical(value))
started=time.perf_counter()
raw=subprocess.check_output(['git','show','HEAD:tests/test_ci_plan.py'],cwd=ROOT)
candidate=(ROOT/'tests/test_ci_plan.py').read_bytes()
def tests(data):
    owner=next(n for n in ast.parse(data).body if isinstance(n,ast.ClassDef) and n.name=='PlannerTests')
    return {n.name:ast.dump(n,include_attributes=False) for n in owner.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
old,new=tests(raw),tests(candidate)
assert len(old)==73 and len(new)==74 and all(new.get(k)==v for k,v in old.items())
assert set(new)-set(old)=={'test_fixture_clone_keeps_local_identity_line_endings_and_isolation'}
write(args.label+'-preflight.json',{'execution_authority':False,'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_worktree_uncommitted':True,'base_file_sha256':sha(raw),'candidate_file_sha256':sha(candidate),'unchanged_test_asts':len(old),'added_tests':sorted(set(new)-set(old)),'python_version':platform.python_version(),'executable':sys.executable,'dependencies':sorted((dist.metadata['Name'],dist.version) for dist in importlib.metadata.distributions()),'driver_sha256':sha(Path(__file__).read_bytes()),'command':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pythonpath':os.environ.get('PYTHONPATH')})
(OUT/'base-test_ci_plan.py.txt').write_bytes(raw)
(OUT/'candidate-test_ci_plan.py.txt').write_bytes(candidate)
sys.path[:0]=[str(ROOT),str(ROOT/'src'),str(ROOT/'tests'),str(ROOT/'.github/scripts')]
import test_ci_plan
assert Path(test_ci_plan.__file__).resolve()==ROOT/'tests/test_ci_plan.py'
assert Path(test_ci_plan.planner.__file__).resolve()==ROOT/'.github/scripts/plan_ci.py'
spec=importlib.util.spec_from_file_location('native_runner',ROOT/'tests/run_unittest_suite.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
names=['test_fixture_clone_keeps_local_identity_line_endings_and_isolation'] if args.fixture_only else sorted(new)
suite=unittest.TestSuite(test_ci_plan.PlannerTests(name) for name in names)
write(args.label+'-inventory.json',{'runtime_ids':[test.id() for test in suite],'count':suite.countTestCases(),'test_source':str(test_ci_plan.__file__),'planner_source':str(test_ci_plan.planner.__file__)})
result=unittest.TextTestRunner(verbosity=2,resultclass=runner.TimedTextResult).run(suite)
runner._write_summary(OUT/(args.label+'-receipt.json'),'planner-fixture-focused' if args.fixture_only else 'planner-full',time.perf_counter()-started,result,20)
assert (ROOT/'tests/test_ci_plan.py').read_bytes()==candidate
raise SystemExit(0 if result.wasSuccessful() else 1)
