"""Run one unchanged existing test with read-only Python audit observations."""
from pathlib import Path
import collections,hashlib,importlib.metadata,io,json,os,platform,subprocess,sys,time,unittest

WT=Path(r'D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe').resolve()
case, destination=sys.argv[1:]
out=Path(destination);assert not out.exists();out.mkdir(parents=True)
for p in (WT,WT/'src',WT/'tests'):sys.path.insert(0,str(p))
head=subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],text=True).strip()
before={p.relative_to(WT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for folder in ('src/research_workbench','tests') for p in (WT/folder).rglob('*.py') if '__pycache__' not in p.parts}
temp=Path(os.environ['TEMP']).resolve()
rows=collections.Counter();unknown=collections.Counter();active=True
def audit(event,args):
    if not active or event not in ('open','os.listdir','os.scandir'):return
    value=args[0] if args else None
    if not isinstance(value,(str,bytes,os.PathLike)):
        unknown[event+':nonpath']+=1;return
    path=Path(os.path.abspath(os.fsdecode(value)))
    if path.is_relative_to(WT):scope,relative='source',path.relative_to(WT).as_posix()
    elif path.is_relative_to(temp):scope,relative='temporary',path.relative_to(temp).as_posix()
    elif path.is_relative_to(Path(sys.prefix)):scope,relative='interpreter',path.relative_to(Path(sys.prefix)).as_posix()
    else:scope,relative='outside-declared-roots',path.name
    mode=str(args[1]) if event=='open' and len(args)>1 else ''
    flags=args[2] if event=='open' and len(args)>2 else None
    rows[(event,scope,relative,mode,flags)]+=1
sys.addaudithook(audit)
start=time.perf_counter()
stream=io.StringIO()
suite=unittest.defaultTestLoader.loadTestsFromName(case)
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
elapsed=time.perf_counter()-start
active=False
after={p:hashlib.sha256((WT/p).read_bytes()).hexdigest() for p in before}
events=[{'event':k[0],'scope':k[1],'path':k[2],'mode':k[3],'flags':k[4],'count':n} for k,n in sorted(rows.items(),key=lambda row:str(row[0]))]
archive=[e for e in events if e['scope']=='source' and ('/attempts/' in e['path'] or e['path'].startswith('work/'))]
pins={e['path']:hashlib.sha256((WT/e['path']).read_bytes()).hexdigest() for e in events if e['scope']=='source' and (WT/e['path']).is_file()}
data={'status':'PASS' if result.wasSuccessful() and not result.skipped and result.testsRun==1 and before==after else 'FAIL',
      'case':case,'head':head,'source_root':str(WT),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
      'dependencies':{n:importlib.metadata.version(n) for n in ['PyYAML','jsonschema','referencing']},
      'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),
      'elapsed_seconds':elapsed,'events':events,'unresolved_events':dict(unknown),'source_archive_events':archive,
      'source_pins':pins,'python_sources_unchanged':before==after,'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'execution_authority':False,'closure_complete':False,
      'limits':['Audit open events record attempts, not successful reads.','Stat/resolve/native IO/child processes are not a complete dependency oracle.',
                'This is a current-base unchanged existing test, not historical hosted execution.','Existing test fixtures and mocks are retained verbatim; no extra substitution introduced.',
                'No observed source archive-data event is not absence proof or permission to skip.']}
(out/'observation.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'unittest.log').write_text(stream.getvalue(),encoding='utf-8')
print(json.dumps({k:data[k] for k in ['status','case','head','testsRun','elapsed_seconds','source_archive_events']}))
raise SystemExit(data['status']!='PASS')
