# Two observed test methods: historical source addendum

Profile: source auditor. Required Skills: none. Owner: Chengyue-Lu / TEST-PERF-002. Scope: exact Git source reads only; no tests, GitHub access, production writes, or edits to the earlier frozen `historical-consumers/REPORT.md`. This addendum resolves the method-identity question for the two additional existing-test observations selected by the coordinator. It does not certify those dynamic observations.

Accepted comparison: `5bf2227ca9b4d2f63f452e579185e7838028de78`. Historical snapshots: PR84 `dfe3165a90ebcef99d107aef8e790bf7abc0c13f`; PR90 `b9ad97ebf256351dd5e1540d5e688087394d474d`. These names identify the frozen commits, not current GitHub PR state.

## Results

| Observed method / setup | PR84 → accepted | PR90 → accepted |
| --- | --- | --- |
| `HarnessEvidenceTests.test_blocked_receipt_and_unstarted_slices_have_no_actual_facts` | Its test file is absent in this PR84 snapshot; no equality claim | Exact source bytes and normalized AST equal; the whole test file differs due to other changes |
| `HarnessEvidenceFixture.setUpClass`, `setUp`, `compile`, `validate` | File absent | All four exact source bytes / AST equal |
| `ExecutionFixture.shared_view_inputs`, `build_execution`, `ports` | Its helper file is absent | All three exact source bytes / AST equal; entire helper file equal |
| `GenericExecutionCloseoutTests.test_trace_or_validation_tamper_blocks_file_replay` | Exact source bytes / AST equal; entire test file equal | Exact source bytes / AST equal; entire test file equal |
| Generic closeout `_write`, `_bundle_and_view`, `_validated_receipt` | All three exact source bytes / AST equal | All three exact source bytes / AST equal |

`comparison.json` records every commit/path/symbol, exact line bounds, file and symbol SHA256, normalized AST SHA256, equality result, Git command and missing-path stderr. Exact source files are frozen under `sources/<snapshot>/tests/`. Source equality includes decorators and the complete selected function body; AST equality discards positional attributes only. No production function is executed by this comparison.

## Data consumption distinctions

The H4 blocked-receipt test is an existing actual harness invocation, not a new test manufactured for an archive path. In accepted source, `HarnessEvidenceFixture.setUpClass` (27–31) builds a temporary `ExecutionFixture`; `setUp` (33–38) copies that temporary prototype. The named test (72–82) executes the harness with `ports(lifecycle="blocked")`, compiles evidence and revalidates it. Assertions require zero driver calls, preflight-blocked / not-started slices, absent actual facts and the expected diagnostic/receipt presence. `ExecutionFixture.build_execution` (107–113) builds harness inputs and a preflight document; `ports` (115–136) also imports the qualified tool from the generated fixture root. Thus local-provider/driver fixtures, generated inputs, schemas and transitive validation code remain relevant. Equality of the selected methods does not prove unchanged or complete transitive input closure.

The generic closeout test's name mentions Trace, but the fault in its actual body (373–385) is specifically **validation artifact byte tampering**: it appends `b"\n# drift\n"` to `receipt.document["validation_refs"][0]["path"]`, then requires `GenericCloseoutValidationError` when replaying the original receipt and original expected receipt hash. It does not mutate a Trace ledger in this test.

Its `_validated_receipt` helper (111–268) creates a temporary Bundle/view/Host execution and Trace, seals that Trace, writes a deterministic checker and a validation document whose subjects include Host, Trace index and artifacts, builds a receipt, then validates it once before returning. `_bundle_and_view` (94–109) uses `ExecutionViewFixture` and explicit `ROOT / "schemas"`; this test follows its `no-skill` branch. The final fault therefore retains a real closeout/replay path, but is not evidence that a committed development Attempt's original payload was consumed. This bounded comparison does not recursively compare `ExecutionViewFixture`, all production validators, or the entire environment.

## Permitted wording for the new report

“Four existing-test observations cover three consumer families: exporter normal plus its related post-seal failure, blocked H4 harness evidence, and generic closeout validation-artifact tamper. The blocked H4 method and its selected setup helpers match the frozen PR90 source; the generic closeout method and selected setup helpers match frozen PR84/PR90 and accepted source. Their tests generate temporary execution inputs. Historical method equality and present observations do not establish that historical CI consumed the workstream's committed Attempt payloads.”

Keep observed open attempts, directory enumeration, successful validation, and historical source equivalence as separate evidence. No historical CI execution, full closure, exclusion authority, or speed improvement is claimed. `execution_authority=false`.

## Coordinator handoff

This addendum is the persisted output. The coordinator can summarize it in the existing PR101/TEST-PERF-002 project-memory entry; this auditor has no shared-memory write scope. Stop condition met: the two selected methods and their local setup helpers have exact-source and AST comparisons, plus consumption distinctions.
