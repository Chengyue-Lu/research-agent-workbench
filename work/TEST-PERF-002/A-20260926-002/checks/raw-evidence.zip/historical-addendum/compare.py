"""Read exact Git objects; never execute candidate tests or modify repository files."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
WT = Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
REFS = {
    'pr84': 'dfe3165a90ebcef99d107aef8e790bf7abc0c13f',
    'pr90': 'b9ad97ebf256351dd5e1540d5e688087394d474d',
    'accepted': '5bf2227ca9b4d2f63f452e579185e7838028de78',
}
SYMBOLS = {
    'tests/test_evaluation_harness_evidence.py': [
        'HarnessEvidenceFixture.setUpClass', 'HarnessEvidenceFixture.setUp',
        'HarnessEvidenceFixture.compile', 'HarnessEvidenceFixture.validate',
        'HarnessEvidenceTests.test_blocked_receipt_and_unstarted_slices_have_no_actual_facts',
    ],
    'tests/harness_execution_fixtures.py': [
        'ExecutionFixture.shared_view_inputs', 'ExecutionFixture.build_execution',
        'ExecutionFixture.ports',
    ],
    'tests/test_generic_execution_closeout.py': [
        'GenericExecutionCloseoutTests._write',
        'GenericExecutionCloseoutTests._bundle_and_view',
        'GenericExecutionCloseoutTests._validated_receipt',
        'GenericExecutionCloseoutTests.test_trace_or_validation_tamper_blocks_file_replay',
    ],
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def symbols(source):
    result = {}
    lines = source.splitlines(keepends=True)
    for cls in ast.parse(source).body:
        if not isinstance(cls, ast.ClassDef):
            continue
        for node in cls.body:
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            start = min([node.lineno] + [d.lineno for d in node.decorator_list])
            raw = ''.join(lines[start-1:node.end_lineno]).encode('utf-8')
            normalized = ast.dump(node, include_attributes=False).encode('utf-8')
            result[f'{cls.name}.{node.name}'] = {
                'start_line': start, 'end_line': node.end_lineno,
                'source_sha256': sha(raw), 'ast_sha256': sha(normalized),
                'text': raw.decode('utf-8'),
            }
    return result

observations = {}
for label, ref in REFS.items():
    observations[label] = {}
    for path, selected in SYMBOLS.items():
        cmd = ['git', '-C', str(WT), 'show', ref + ':' + path]
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        record = {'git_ref': ref, 'path': path, 'command': cmd, 'exit_code': proc.returncode}
        if proc.returncode:
            record.update(present=False, stderr=proc.stderr.decode('utf-8', errors='replace'))
        else:
            dest = ROOT / 'sources' / label / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(proc.stdout)
            mapping = symbols(proc.stdout.decode('utf-8'))
            record.update(present=True, source_sha256=sha(proc.stdout),
                          frozen_source=dest.relative_to(ROOT).as_posix(),
                          symbols={name: mapping.get(name) for name in selected})
        observations[label][path] = record

comparisons = []
for old in ('pr84', 'pr90'):
    for path, names in SYMBOLS.items():
        a, b = observations[old][path], observations['accepted'][path]
        for name in names:
            lhs, rhs = a.get('symbols', {}).get(name), b.get('symbols', {}).get(name)
            row = {'historical': old, 'path': path, 'symbol': name,
                   'historical_present': lhs is not None, 'accepted_present': rhs is not None,
                   'file_equal': a.get('source_sha256') == b.get('source_sha256') if a['present'] else None,
                   'source_equal': lhs['source_sha256'] == rhs['source_sha256'] if lhs and rhs else None,
                   'ast_equal': lhs['ast_sha256'] == rhs['ast_sha256'] if lhs and rhs else None}
            comparisons.append(row)

result = {
    'schema_version': 1, 'authority': 'read-only exact Git source comparison',
    'execution_authority': False, 'tests_run': False, 'github_accessed': False,
    'refs': REFS, 'observations': observations, 'comparisons': comparisons,
    'limitations': [
        'Symbol equivalence does not prove complete transitive consumer closure.',
        'Historical source existence does not establish historical CI execution.',
        'No inference that committed development Attempt payloads are read from a shared directory name.',
        'No observation or assertion of temporal speed improvement.',
    ],
}
(ROOT / 'comparison.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
for row in comparisons:
    print(row['historical'], row['symbol'], 'file', row['file_equal'], 'source', row['source_equal'], 'ast', row['ast_equal'])
