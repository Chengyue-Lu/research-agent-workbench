# Independent review: Attempt input diagnostic slice

Reviewer: delegated agent `attempt_review_v2`; profile: CI boundary correctness reviewer.
Required Skills: []. Inputs: current repository AGENTS/README, REQUEST, target test/doc, and narrowly relevant existing probe, consumer declaration and Trace reader source. Write scope: this assessment directory only. Budget: one bounded read-only review. Stop condition: substantive findings communicated and exact-source report persisted. No tests, GitHub writes, or source edits were performed by this reviewer.

## Reviewed identity

Worktree: `D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe`.
These are uncommitted file identities, not hosted execution receipts or final-commit approval.

| File | SHA-256 |
| --- | --- |
| tests/test_ci_attempt_inputs.py | 5d4ac3109c2784f528accf3722d3c0d957f053de6bbef2cb464e6cfc4bdb91ca |
| docs/workstreams/chengyue-lu/TEST-PERF-002/ATTEMPT_INPUT_BOUNDARY.md | 87f37c297c484f24a785cc33b1d0bb4b12f0ceae8ed129c2d69323df43a5bfb1 |

Result: no remaining substantive correctness or trust-boundary finding in the reviewed diagnostic scope. This is source review only, not an APPROVED GitHub event, cross-owner review, or execution result.

## Finding resolved during review

The initial test source (`a8e2c99b4cfa6ee5767cf282ee719a38d799148da6e17af28472febcad82cf73`) made every scenario expectation part of `setUpClass` success. One consumer-result mismatch therefore prevented all 12 named methods from executing and collapsed the result into a class setup error. This obscured which behavioral contract failed.

The refreshed source reserves setup failure for infrastructure and source-integrity failures. Each owning test uses `row()` to assert its scenario expectation; the scope/completeness test retains the overall PASS guard. The class still performs one shared 16-scenario observation run by design, so independently selecting one method does not imply proportionally reduced fixture cost. That is a declared bounded cost, not an exclusion claim.

## Checks and boundaries

- Default reader and alternate transcript API invoke real copied production code. Every observed imported `research_workbench` module must resolve inside the declared package copy and match source bytes; generated package contents are recorded and compared before/after invocation. Fresh isolated children prevent Python module-cache carry-over between scenarios.
- Reference/membership failures match the exact BLOCK code/detail multiset. The escaping reference correctly expects both schema rejection and containment rejection; missing or additional BLOCK categories fail the assertion.
- Runtime orphan and drift controls require the specific ResourceError type, exact message, reader phase, and exception exit code. Restored package contents must match the baseline inventory and produce the baseline reader outcome. Manifest hashes remain fixed.
- Transcript equality under non-Trace-schema drift is sufficient for this causal input-boundary control. It does not establish general transcript correctness or complete consumer closure, and the documentation does not claim either.
- Audit hooks record attempted Python operations. Bootstrap/native/other unobserved activity and unknown closure remain explicit. Neither observed absence nor a materialized inventory is promoted to a safe-exclusion witness.
- Documentation now distinguishes four existing invocations across three families and identifies the M6 mutation as retained-validation artifact tampering, not Trace-ledger tampering. Historical source findings remain separate from current execution observations.
- No production selector, workflow, policy threshold, independent witness, or CI authorization changes were requested or introduced by this slice. Hosted validation and human cross-owner review remain separate steps.

## Review limitations

This reviewer did not rerun tests, independently recreate the four existing observations, or authenticate their external execution identities. Those claims require the root agent's preserved raw observations and final local/hosted checks. Final source bytes must retain the hashes above for this review to apply; subsequent substantive changes need focused follow-up review.
