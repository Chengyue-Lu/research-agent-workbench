from pathlib import Path
from dataclasses import asdict
import hashlib,json,subprocess,sys,zipfile

ROOT=Path(__file__).resolve().parent
WT=Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
BASE='5bf2227ca9b4d2f63f452e579185e7838028de78'
IMPL=json.loads((ROOT/'implementation.json').read_bytes())['head']
assert subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],text=True).strip()==IMPL
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
finals={v:json.loads((ROOT/f'local-tests/{v}-final/summary.json').read_bytes()) for v in ('311','313')}
for value in finals.values():
    assert value['status']=='PASS' and value['tests']==22 and not value['skips']
    for path,digest in value['source_pins'].items():
        assert sha(WT/path)==digest
        assert hashlib.sha256(subprocess.check_output(['git','-C',str(WT),'show',IMPL+':'+path])).hexdigest()==digest
assert (ROOT/'independent-review/REPORT.md').is_file()
assert (ROOT/'historical-addendum/REPORT.md').is_file()
ATTEMPT=WT/'work/TEST-PERF-002/A-20260926-002'
ATTEMPT.mkdir(parents=True,exist_ok=False)
checks=ATTEMPT/'checks';checks.mkdir()
roots=['local-tests','historical-consumers','historical-addendum','independent-review']
files=[p for name in roots for p in (ROOT/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [ROOT/name for name in ('REQUEST.md','rebase.json','range-diff.txt','implementation.json','run_local.py','observe_existing.py','consumer-proposal.json','proposal-validation.json','diagnostic-failure-attribution.log','diagnostic-failure-attribution.json','freeze_boundary.py')]
# Preserve observer records only, not the temporary materialized projects.
files += [p for p in (ROOT/'existing-observations').rglob('*') if p.is_file() and
          (p.parent==ROOT/'existing-observations' or p.parent.name in {'case-1','case-2','case-3','case-4'})]
assert len(files)==len(set(files))
with zipfile.ZipFile(checks/'raw-evidence.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(files):archive.write(path,path.relative_to(ROOT).as_posix())
(checks/'manifest.json').write_text(json.dumps({p.relative_to(ROOT).as_posix():sha(p) for p in sorted(files)},indent=2)+'\n',encoding='utf-8')
(checks/'consumer-proposal.json').write_bytes((ROOT/'consumer-proposal.json').read_bytes())
summary={'status':'PASS-local-scoped','base':BASE,'implementation':IMPL,'execution_authority':False,
         'complete_input_closure_proved':False,'hosted_execution_proved':False,
         'new_tests':12,'new_scenarios_per_python':16,'related_tests_per_python':22,
         'existing_observations':4,'families':3,'existing_observation_head':'bbdb4d4beacbd01527c652c3e7993f39c49b73e6',
         'source_pins':finals['311']['source_pins'],'local_results':finals,
         'independent_review_sha256':sha(ROOT/'independent-review/REPORT.md'),
         'raw_zip_sha256':sha(checks/'raw-evidence.zip'),
         'diagnostic_scope':'audit open attempts and materialized inventories; not complete successful read receipts',
         'first_failure':'outside_ref legitimately produced both schema-invalid and path-escape BLOCK; initial expected-one assertion was corrected',
         'review_history':'initial delegated review could not authenticate; subsequent independent static review completed; formal owner approval remains pending'}
(checks/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
(ATTEMPT/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
(ATTEMPT/'RESULTS.md').write_text(f'''# Attempt invocation input boundaries

Owner Chengyue-Lu; TEST-PERF-002; R2; required Skills [].
Accepted base `{BASE}`; implementation `{IMPL}`.

This extends the original checkout experiment with real default Trace input
observations. Twelve new named regressions share sixteen fresh-process scenarios:
directory/INDEX entry points, top-level message and recursive tool membership,
deleted/renamed/outside references, an unrelated sibling, alternate transcript
reader, unchanged-manifest schema and non-schema resource drift, and restoration.
The default reader verifies every packaged Runtime resource before its schema
catalog loads. Imported workbench modules are pinned to the independent package
copy. The validator, resources, hash reader and catalog are unchanged.

Both Python 3.11 and 3.13 passed 22 related tests (12 new, 8 prior checkout tests,
2 unchanged hash/ref controls), with no skips/errors/failures. These local runs
bind exact source bytes, before the implementation commit was created. They are
not hosted receipts. Shared scenario preparation keeps fixture cost bounded;
scenario failures now reach their named tests. A diagnostic-only saved-report
replay confirms one injected mismatch fails its owning test while a separate
unaffected test passes. That replay does not execute or substitute a business
reader and is separate from the real execution results.

The first local attempt is retained: outside-reference validation produced two
correct BLOCKs (schema and containment), while the experiment expected one.
The final check requires the exact two, retaining exact single-BLOCK checks for
other faults. Independent static review found and closed class-wide failure
attribution before the final dual-Python runs. The initial review-agent login
failure is a capture boundary; the later source review completed successfully.

Four unchanged tests were separately observed at rebased head `bbdb4d4`:
H4 CLI success, H4 post-seal tamper, blocked evaluation evidence, and M6 retained
validation tamper replay. All passed with their existing fixture behavior intact.
H4 opens archived executable exporters; this does not establish reads of every
adjacent historical Trace. Audit hooks record attempted operations, including
failed opens; missing events cannot prove safe exclusion. The historical source
map and addendum preserve their own source identities and limitations.

[Summary](checks/summary.json), [proposal](checks/consumer-proposal.json),
[raw evidence](checks/raw-evidence.zip) and [manifest](checks/manifest.json)
retain source pins, original failure, complete final observations, four existing
invocations and historical findings. The proposal validates the existing shadow
format and retains unknowns with `execution_authority=false`.

Production policy, selector, witness, workflows, existing tests and quality
thresholds are unchanged. Complete consumer closures, accepted independent
exclusion evidence and fresh B/C/coverage/smoke/lifecycle acceptance remain
separate requirements. No hosted speedup, safe exclusion or result reuse is
claimed. Final-head and hosted verification follow this seal under their own
identities.

Trace capture starts at evidence freeze. Earlier tool/inter-agent messages were
not continuously retained in full; findings and raw observations are preserved
with a truthful capture-gap warning. Publication is a subsequent external action.
''',encoding='utf-8',newline='\n')
sys.path.insert(0,str(WT/'src'))
from research_workbench.observability.trace import AgentTraceRecorder,validate_attempt_trace
recorder=AgentTraceRecorder(ATTEMPT,task_id='TEST-PERF-002',task_revision=46,attempt_id=ATTEMPT.name,
 task_snapshot={'task_id':'TEST-PERF-002','revision':46,'request':'Continue on PR101',
 'scope':'real Attempt input boundaries and historical invocation mapping; diagnostic only',
 'profile':'CI boundary engineer','required_skills':[],'delegation':True,
 'budget':'one bounded slice; scoped dual Python, four existing observations and static review',
 'stop_condition':'updated Draft with fresh hosted obligations and remaining activation boundaries'},
 accountable_owner='Chengyue-Lu',actor_id='main-agent',runtime_identity='Codex desktop',provider='OpenAI',
 read_allowlist=['AGENTS.md','README.md','PROJECT_MEMORY.md','docs/DEVELOPMENT.md','.github/scripts/**','tests/**','src/research_workbench/**','docs/workstreams/chengyue-lu/TEST-PERF-002/**'],
 write_scope=['tests/test_ci_attempt_inputs.py','docs/workstreams/chengyue-lu/TEST-PERF-002/**','work/TEST-PERF-002/A-20260926-002/**'],
 tool_allowlist=['collaboration','shell','git','gh','python'],baseline=BASE)
recorder.record_capture_gap('messages','Evidence freeze retains source findings and raw observations but not the complete earlier visible tool/inter-agent stream. Initial review authentication failed; later independent static review completed.')
recorder.record_capture_gap('external-actions','Final-head validation and Draft publication follow this sealed local evidence and retain separate identities.')
recorder.record_tool_call(operation_id='freeze-attempt-input-boundaries',tool_name='python',status='succeeded',
 arguments={'operation':'freeze exact source, real input observations and source review'},
 result={'implementation':IMPL,'summary_sha256':sha(checks/'summary.json')},result_entered_context=True)
recorder.seal('safe-paused')
result=validate_attempt_trace(WT,ATTEMPT)
validation={'blocked':result.blocked,'risks':[asdict(r) for r in result.risks]}
(checks/'trace-validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8')
assert not result.blocked,validation
print(json.dumps({'attempt':str(ATTEMPT.relative_to(WT)),'raw_files':len(files),'zip_bytes':(checks/'raw-evidence.zip').stat().st_size,'trace':validation}))
