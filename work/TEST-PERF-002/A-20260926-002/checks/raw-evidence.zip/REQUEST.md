# PR101 continuation: invocation and input boundaries

User instruction: “继续推进，在101基础上继续前进。”

Owner Chengyue-Lu; TEST-PERF-002; R2. Required Skills: [].
Accepted baseline 5bf2227ca9b4d2f63f452e579185e7838028de78; original PR101
1eafb0233dd033b27ae557c7b164c7c2f22c65b5. The two original patches were rebased
once, equivalently, to bbdb4d4beacbd01527c652c3e7993f39c49b73e6. Remote publication
is deferred until this coherent slice has been checked.

Profile: CI boundary engineer. Scope: existing PR101 test experiments, historical
source call mappings, diagnostic declarations and workstream evidence. Keep the
production selector, witness, policy, quality thresholds and workflow unchanged.
Main checkout and local configuration are preserved. No merge or production
exclusion/reuse activation is authorized by this continuation.

Inputs: current AGENTS/README/DEVELOPMENT/PROJECT_MEMORY, Issue87 and PR101,
relevant .github consumer/shadow APIs, Trace/RuntimeResources/SchemaCatalog and
their actual test call sites. Historical PR84/PR90 source is pinned independently;
new regression tests cannot establish historical necessity.

Delegation:
- domain_inventory: read-only historical consumer source/identity mapping;
  writes historical-consumers only. One bounded audit, no tests/remote writes.
- pair_role_review: first read-only input-boundary design; then implement only
  tests/test_ci_attempt_inputs.py and local boundary-review evidence. Real recorder,
  default Trace/RuntimeResources, isolated package copies and fresh subprocesses;
  no patched validator/resource reader. Named tests and diagnostic observations.

Root runs four unchanged existing tests across three families with Python audit observations,
then verifies new regressions, documentation, committed-head plan/governance and
independent accepted-base selection floor. Hosted receipts keep their actual target.
Read observations are not completeness or exclusion witnesses. Existing tests keep
their own fixture substitutions; none are introduced by the observation driver.

Budget/stop: one bounded follow-up test/diagnostic slice in the existing Draft,
with current-head execution and remaining activation conditions stated. No local
full behavioral/coverage run when the accepted plan does not require one.

Capture boundary: command outputs, observer bytes, agent written findings and the
new test records are retained. This is not a complete continuous tool-message
capture; the eventual Trace must retain that capture-gap warning. Remote actions
after sealing retain their own separate records.
