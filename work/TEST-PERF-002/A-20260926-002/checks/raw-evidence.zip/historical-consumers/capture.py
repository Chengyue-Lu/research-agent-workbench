import ast, hashlib, json, subprocess
from pathlib import Path

OUT=Path(__file__).resolve().parent
REPO=Path(r'D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
REFS={'pr101':'1eafb0233dd033b27ae557c7b164c7c2f22c65b5','accepted':'5bf2227','pr84':'dfe3165a90ebcef99d107aef8e790bf7abc0c13f','pr90':'b9ad97ebf256351dd5e1540d5e688087394d474d'}
commands=[]
def command(*args):
    argv=['git','-C',str(REPO),*args]
    p=subprocess.run(argv,capture_output=True)
    commands.append({'argv':argv,'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':p.stderr.decode('utf-8','replace')})
    return p
refs={name:command('rev-parse',f'{ref}^{{commit}}').stdout.decode().strip() for name,ref in REFS.items()}
core=['src/research_workbench/observability/trace.py','src/research_workbench/artifacts/integrity.py','src/research_workbench/validation/schemas.py','src/research_workbench/resources.py','src/research_workbench/cli.py','src/research_workbench/evaluation/harness_evidence.py','src/research_workbench/evaluation/harness_execution.py','src/research_workbench/evaluation/harness_runtime.py','src/research_workbench/evaluation/pins.py','tests/harness_execution_fixtures.py','tests/system_evaluation_fixtures.py','tests/test_evaluation_harness_evidence.py','tests/test_m5_trace_export.py','tests/test_documentation.py','tests/public_surface_helpers.py','.github/workflows/ci.yml','.github/scripts/ci_consumer_contracts.py','tests/ci_impact_policy.yaml']
exp='docs/workstreams/chengyue-lu/M5-SYSTEM-EVALUATION-DESIGN/attempts/M5-007-H4-001/export_capture.py'
archive84='docs/workstreams/huangyi/M6-BASELINE-EXECUTION/attempts/M6-CLOSEOUT-001/INDEX.yaml'
paths={'pr101':core+[exp,'docs/workstreams/chengyue-lu/TEST-PERF-002/ATTRIBUTE_CONSUMER_PROBE.md','docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_CONTRACTS_V1.md'],
       'accepted':core+[exp],
       'pr84':['tests/test_documentation.py','.github/workflows/ci.yml',archive84,'docs/workstreams/huangyi/M6-BASELINE-EXECUTION/CLOSEOUT.md','src/research_workbench/observability/trace.py'],
       'pr90':['tests/test_m5_trace_export.py','tests/test_evaluation_harness_evidence.py','tests/harness_execution_fixtures.py','tests/system_evaluation_fixtures.py','src/research_workbench/evaluation/harness_evidence.py','src/research_workbench/evaluation/harness_execution.py','src/research_workbench/evaluation/harness_runtime.py','src/research_workbench/evaluation/pins.py',exp]}
sources={}
for label,items in paths.items():
    for path in items:
        p=command('show',f'{refs[label]}:{path}')
        if p.returncode: continue
        dest=OUT/'sources'/label/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.stdout)
        item={'commit':refs[label],'path':path,'sha256':hashlib.sha256(p.stdout).hexdigest(),'snapshot':str(dest.relative_to(OUT)),'symbols':{}}
        if path.endswith('.py'):
            data=p.stdout.decode('utf-8');tree=ast.parse(data)
            for node in tree.body:
                if isinstance(node,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef)):
                    segment=ast.get_source_segment(data,node)
                    item['symbols'][node.name]={'line':node.lineno,'end_line':node.end_lineno,'source_sha256':hashlib.sha256(segment.encode()).hexdigest()}
                    if isinstance(node,ast.ClassDef):
                        for method in node.body:
                            if isinstance(method,(ast.FunctionDef,ast.AsyncFunctionDef)):
                                segment=ast.get_source_segment(data,method)
                                item['symbols'][node.name+'.'+method.name]={'line':method.lineno,'end_line':method.end_lineno,'source_sha256':hashlib.sha256(segment.encode()).hexdigest()}
        sources[label+':'+path]=item
searches=[]
for label,pattern in [('pr84','M6-CLOSEOUT-001|M6-BASELINE-EXECUTION/attempts'),('pr90','M5-007-H4-001|M5-007-H4-CI-REPAIR-001|M5-007-H4-ENTRY-001')]:
    p=command('grep','-n','-E',pattern,refs[label],'--','tests','src','.github')
    artifact=OUT/f'{label}-literal-references.txt';artifact.write_bytes(p.stdout)
    searches.append({'commit':refs[label],'pattern':pattern,'scope':['tests','src','.github'],'exit_code':p.returncode,'artifact':artifact.name,'lines':p.stdout.decode().splitlines(),'negative_result_is_not_dynamic_absence':True})
(OUT/'sources.json').write_text(json.dumps({'execution_authority':False,'refs':refs,'sources':sources,'searches':searches},indent=2)+'\n',encoding='utf-8')
(OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf-8')
for key,item in sources.items():
    if key.startswith('pr90:tests/test_'):
        print(key,json.dumps({name:rows for name,rows in item['symbols'].items() if '.test_' in name},ensure_ascii=False))
print('refs',json.dumps(refs))
