# Attempt archives：历史真实调用映射

Owner：Chengyue-Lu；TEST-PERF-002；本轮为只读源码审计，未运行测试。审计起点 #101 为 `1eafb0233dd033b27ae557c7b164c7c2f22c65b5`；当前 accepted 对照为 `5bf2227ca9b4d2f63f452e579185e7838028de78`。工作树已有 `.codex/config.toml` 修改，未读取或触碰；下面的源证据全部由精确 Git 对象冻结。

**最窄下一步是观察已有 H4 exporter 测试的真实调用阶段，而不是再给任意归档路径补一个新消费者测试。** #101 证明的是新生成 Attempt 上的 attributes→materialized bytes→原 validator 因果链，不能反推 PR84/90 的已提交归档数据曾被历史 CI 消费。

| 历史场景 | 原有具名调用与实际输入 | 与 accepted 5bf 的比较 | 已有证明／尚缺 |
| --- | --- | --- | --- |
| PR84：`dfe3165a90ebcef99d107aef8e790bf7abc0c13f` 的 `M6-CLOSEOUT-001` 数据 | 在该 commit 的 `tests/src/.github` 搜索两个具名 archive 字符串，零命中。`INDEX.yaml` 有 task、actors、ledger、decision、tool-result 引用，只有显式传给 `validate_attempt_trace` 才形成该读取链。 | 原 validator 的精确符号比较另存 JSON；没有找到可比较的历史测试调用。 | 不能称“从未动态读取”；拼接路径、目录扫描和其他入口仍未知。新手动 replay 也不能冒充历史 CI 调用。 |
| PR84：文档链接消费者 | `DocumentationTests.test_internal_markdown_links_resolve`，`tests/test_documentation.py:32` 起：遍历 README 与 `docs/**/*.md`，检查链接目标存在。`CLOSEOUT.md` 链接 closeout evidence JSON。 | 整测试文件与方法均字节相同。 | 真实依赖是 Markdown 内容、Markdown 目录成员、目标存在性；该方法不读取目标 JSON 内容或验证 Trace。无本轮动态结果。 |
| PR90：归档 exporter **代码** | `b9ad97ebf256351dd5e1540d5e688087394d474d` 的 `tests/test_m5_trace_export.py:26–32` 在 collection 导入 H4 `export_capture.py`。`H4TraceExportTests.setUp` 复制脚本字节到临时 archive；`invoke` 调用原 main。原 normal 方法在 168 行。 | 测试整文件、setUp、invoke、normal 方法、exporter main 全部保持相同字节。 | 输入是归档脚本，以及测试生成的 TASKS/spool/trace；不能据同目录关系认定读取原提交的 INDEX/events/tool-results。 |
| PR90：原 exporter 相关失败 | 原 `H4TraceExportTests.test_post_seal_tampering_blocks_cli_and_persists_failure_report` 在 224 行：seal 后修改生成 tool-event 字节，要求非零、blocked、持久化失败报告。 | 方法和文件均保持相同字节。 | 已有真实 hash 断言，可直接观察；它是上一场景的相关故障，不算第三个独立业务场景。本轮未重跑。 |
| PR90：H4 execution evidence | `HarnessEvidenceFixture.setUpClass` 生成临时 ExecutionFixture；setUp 复制该临时树。原 `HarnessEvidenceTests.test_failed_actual_binding_cannot_be_replaced_with_plan` 在 50 行执行 harness，再 compile/validate exact receipts。 | 该方法、两个 setup、`compile_harness_evidence` 均保持相同符号字节；整 evidence 源/测试文件后来有其他变动。 | 真实输入是运行时生成的 H3 archives、原 helper/实例 refs/schema，不是 workstream 的开发 Attempt。继承 helper、实例闭包、fixture 成本仍需动态观察。 |

每条在 `consumer-map.json` 绑定历史/current commit、path、function、精确行号、整文件 SHA256 与符号 SHA256；完整对应源文件在 `sources/`。PR84/90 指上述冻结历史快照，不声称代表其当前 GitHub 状态。`pr84-literal-references.txt` 的空结果和命令退出 1 均保留。

## 实际读取闭包与替代路径

- `validate_attempt_trace(root, attempt)`（trace.py:778）先解析 root/Attempt，拒绝越界；允许传目录或 INDEX。加载 INDEX 后创建默认 `SchemaCatalog()`（828）。`_checked_ref`（1348）在 Attempt 内解析路径、检查存在、用二进制 `hash_file` 校验实际字节。原 ledger 后续再按 UTF-8 解析（975–994），两种义务不能混为一谈。
- task/actors、handoff/decision/output/check refs、ledger、message refs、tool-result refs 必须按原分支保留。`messages` 是直接子文件成员检查（1302–1315）；`tool-events` 是递归文件成员检查（1588–1601）。这不是“同目录全部字节都读”，也不是只有被 INDEX 列出的文件才相关。新增 orphan、删除/rename、替代路径、解析逃逸均需单独观察；嵌入文档里的普通字符串引用不能自动当作又一次读取。
- 默认 schema 路径进入 RuntimeResources：`resources.py:85–143` 读取外部生成 pin/manifest，逐项验字节与路径、遍历整个实际资源树校验成员；SchemaCatalog 再加载完整版本 schema 目录。必须保留 **manifest/资源成员/字节及 schema catalog**，不能把 invocation 只消费 `agent_trace_index` 理解成只加载一张 schema。manifest 初始化和 `validate_catalog()` 的额外语义遍历须分别计量。
- 原 H4 exporter main 读取当前 CWD 下 `docs/TASKS.md` 与 `.rwb/h4-capture.json`，以自身 `__file__` 决定输出 archive，要求新 trace 目录；原测试已有 CWD、Git HEAD、`__file__` patch。README scope_ref 是记录的路径，main 没有读取 README 内容。保留这些原 fixture 行为，不能用新的 mock 代替原消费者。
- H4 evidence 经 `compile_harness_evidence → replay_harness → _inspect` 沿 execution/journal/receipt refs 回放；EvaluationInputs 把文件读限制在实例 root、验证 hash/schema。`replay_harness`（harness_execution.py:313）还比较该 run 目录 `*-started.json`、`*-finished.json` 的成员数量与 attempt refs，目录成员是真实输入。baseline 与 M11 replay 是不同分支，并可进一步进入 Trace/closeout。继承 fixture 会读取真实 example/registry/schema 输入，不能只 pin 单一 H4 文件。CLI `trace validate`、execution archive、generic/baseline closeout、receipt validator 是另外的入口；观察一个入口不闭合所有入口。
- 现有 consumer 框架 `ci_consumer_contracts.inspect_record` 仅核对声明 pins/符号，明确 `complete_input_closure_proved=false`。历史 literal 无命中或当前 source pins 相同都不是排除 witness。

## 下一诊断切片

在 accepted 5bf 的独立完整环境，给以下**已有 canonical IDs**加外部只读 audit hook，分别记录 collection、setUpClass/setUp、test-body、seal、validator、output 阶段。保持现有 suite hierarchy/fixture/order 与 authored patch；将实际数据读取、代码 import、目录成员观察和仅路径存在性分开。首轮先用 exporter 两方法建立 normal/相关故障，随后选一项独立 docs 或 H4 fixture 调用；H4 fixture 可能明显更重，先保留 setup 成本。

1. `tests/test_m5_trace_export.py::H4TraceExportTests.test_cli_preserves_observed_results_outcomes_and_task_binding`
2. `tests/test_m5_trace_export.py::H4TraceExportTests.test_post_seal_tampering_blocks_cli_and_persists_failure_report`
3. `tests/test_evaluation_harness_evidence.py::HarnessEvidenceTests.test_failed_actual_binding_cannot_be_replaced_with_plan`
4. `tests/test_documentation.py::DocumentationTests.test_internal_markdown_links_resolve`

已有 trace reader 的 membership/runtime 负对照可以与这张映射联合形成新的诊断证据，但必须标成后续实测。不能把无关 1/10/100 Attempt 不影响一次调用推广成全仓排除；不能降低原 B/C、coverage authority、smoke 或 integration 要求。三类消费者、相关失败与无关对照、稳定输入/环境和独立 witness 齐备前，本映射 `execution_authority=false`。
