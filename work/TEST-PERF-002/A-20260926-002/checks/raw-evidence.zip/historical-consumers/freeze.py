import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((root/'sources.json').read_text(encoding='utf-8'))
for item in sources['sources'].values():assert sha(root/item['snapshot'])==item['sha256']
manifest={p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'}
(root/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'report_sha256':sha(root/'REPORT.md'),'map_sha256':sha(root/'consumer-map.json'),'manifest_sha256':sha(root/'SHA256SUMS.json'),'files':len(manifest)},indent=2))
