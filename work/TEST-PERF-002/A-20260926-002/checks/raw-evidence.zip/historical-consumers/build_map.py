import hashlib, json
from pathlib import Path
OUT=Path(__file__).resolve().parent
data=json.loads((OUT/'sources.json').read_text(encoding='utf-8'))
sources=data['sources']
def bind(label,path,symbol=None,line=None):
    source=sources[label+':'+path]
    result={k:source[k] for k in ('commit','path','sha256','snapshot')}
    result['function']=symbol
    if symbol: result.update(source['symbols'][symbol])
    elif line: result['line']=line
    return result
def compare(label,path,symbol):
    old=bind(label,path,symbol);new=bind('accepted',path,symbol)
    return {'historical':old,'current_base':new,'same_file_bytes':old['sha256']==new['sha256'],
            'same_named_symbol_bytes':old['source_sha256']==new['source_sha256']}
exp='docs/workstreams/chengyue-lu/M5-SYSTEM-EVALUATION-DESIGN/attempts/M5-007-H4-001/export_capture.py'
rows=[
 {'id':'pr84-attempt-data','fact':'No literal reference to the named Attempt was found in historical tests/src/.github; this does not prove absence of dynamic or prefix-root readers.',
  'historical':bind('pr84','docs/workstreams/huangyi/M6-BASELINE-EXECUTION/attempts/M6-CLOSEOUT-001/INDEX.yaml',line=1),
  'search':data['searches'][0], 'function':None,'current_base_status':'No exact historical test invocation exists to compare; trace validator separately remains available.',
  'reader_if_explicitly_invoked':compare('pr84','src/research_workbench/observability/trace.py','validate_attempt_trace'),
  'inputs':['INDEX task/actors/ledger/tool-event/decision refs become inputs only when this named Attempt is actually passed to the validator'],
  'gap':'No historical CI call or observed read of this committed Attempt established; explicit manual replay would be new observation, not retroactive CI evidence.'},
 {'id':'pr84-documentation-links','fact':'Existing documentation test recursively reads docs Markdown and checks link-target existence, including the archived closeout-evidence link; it does not parse or hash that target JSON.',
  **compare('pr84','tests/test_documentation.py','DocumentationTests.test_internal_markdown_links_resolve'),
  'inputs':['README.md','docs/**/*.md membership and content','each nonexternal link target existence'],
  'gap':'Dynamic filesystem observation not run; link-root membership must be retained separately from archive data byte consumption.'},
 {'id':'pr90-exporter-code','fact':'Historical test module imports the archived exporter, copies its actual bytes to a temporary archive, and calls original main with existing CWD/Git/__file__ fixture patches; generated trace data is its input/output, not committed original trace payload.',
  **compare('pr90','tests/test_m5_trace_export.py','H4TraceExportTests.test_cli_preserves_observed_results_outcomes_and_task_binding'),
  'bindings':[compare('pr90','tests/test_m5_trace_export.py','H4TraceExportTests.setUp'),compare('pr90','tests/test_m5_trace_export.py','H4TraceExportTests.invoke'),compare('pr90',exp,'main')],
  'collection_import':bind('pr90','tests/test_m5_trace_export.py',line=26),
  'inputs':[exp,'temporary docs/TASKS.md','temporary .rwb/h4-capture.json','temporary archive/trace absence','runtime schema/catalog closure','mocked Git HEAD already present in original test'],
  'gap':'Fresh audit must separate import/setup/producer/seal/validator/output stages; no original H4 committed INDEX/events/tool-event read is established.'},
 {'id':'pr90-exporter-original-fault','fact':'Original post-seal mutation appends bytes to generated tool-event JSON; original CLI/report assertions require block and exit1.',
  **compare('pr90','tests/test_m5_trace_export.py','H4TraceExportTests.test_post_seal_tampering_blocks_cli_and_persists_failure_report'),
  'inputs':['same exporter fixture closure','generated tool-events/*.json glob membership','generated tool result bytes','fresh report output'],
  'gap':'Existing authored negative assertion, not executed in this audit; preserve existing seal wrapper and fixture lifecycle.'},
 {'id':'pr90-h4-execution-fixture','fact':'H4 evidence tests build an ExecutionFixture in a temporary root; execute_harness creates archives, compile/validate follows exact receipt references under that root.',
  **compare('pr90','tests/test_evaluation_harness_evidence.py','HarnessEvidenceTests.test_failed_actual_binding_cannot_be_replaced_with_plan'),
  'bindings':[compare('pr90','tests/test_evaluation_harness_evidence.py','HarnessEvidenceFixture.setUpClass'),compare('pr90','tests/test_evaluation_harness_evidence.py','HarnessEvidenceFixture.setUp'),compare('pr90','src/research_workbench/evaluation/harness_evidence.py','compile_harness_evidence')],
  'inputs':['generated ExecutionFixture root and harness receipts','tests/harness_execution_fixtures.py and inherited fixture sources','root-bound source/schema/registry pins','complete explicit schema directory plus inner default RuntimeResources consumers'],
  'gap':'Inherited helpers copy real example/registry files; no full closure or cost claim. Fixture setup and real local drivers/receipt replay must remain; not evidence that committed workstream Attempt payload is consumed.'},
]
test_ids=[]
for row in rows:
    h=row.get('historical',{})
    if h.get('function','') and '.test_' in h['function']:
        test_ids.append(h['path']+'::'+h['function'])
result={'version':1,'execution_authority':False,'observed_execution_this_audit':False,'refs':data['refs'],'cases':rows,'existing_canonical_test_ids':test_ids,
        'next_slice':'Fresh-process staged observation of original H4TraceExportTests normal and post-seal fault, preserving authored patches; independent H4 ExecutionFixture or Markdown membership invocation. No selector edit.',
        'unknowns':['source and dependency/environment closure','historical hosted test actual invocation/merge identity','dynamic/prefix readers outside bounded search','all alternate receipt/closeout callers','independent exclusion witness']}
(OUT/'consumer-map.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for row in rows:
    print(row['id'],row.get('same_file_bytes'),row.get('same_named_symbol_bytes'))
    for item in row.get('bindings',[]):print(' ',item['historical']['function'],item['same_file_bytes'],item['same_named_symbol_bytes'])
