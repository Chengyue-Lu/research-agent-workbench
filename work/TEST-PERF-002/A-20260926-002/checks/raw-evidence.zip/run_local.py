from pathlib import Path
import hashlib,io,json,os,platform,sys,time,unittest
W=Path(r'D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
sys.path[:0]=[str(W),str(W/'src'),str(W/'tests'),str(W/'.github/scripts')]
names=sys.argv[2:] or ['test_ci_attempt_inputs']
files=['tests/test_ci_attempt_inputs.py','tests/test_ci_attribute_consumers.py','src/research_workbench/observability/trace.py','src/research_workbench/resources.py']
pins={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in files}
stream=io.StringIO();start=time.perf_counter()
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
summary={'status':'PASS' if result.wasSuccessful() and not result.skipped else 'FAIL','tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'seconds':time.perf_counter()-start,'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'argv':sys.argv,'source_pins':pins,'hosted_receipt':False}
assert pins=={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in files},'source changed during execution'
(out/'unittest.log').write_text(stream.getvalue(),encoding='utf-8')
for mod,cls in [('test_ci_attempt_inputs','AttemptInputTests'),('test_ci_attribute_consumers','AttributeConsumerTests')]:
 if mod in sys.modules:
  report=getattr(getattr(sys.modules[mod],cls),'report',None)
  if report is not None:(out/(mod+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False));print(stream.getvalue() if not result.wasSuccessful() else '')
raise SystemExit(summary['status']!='PASS')
