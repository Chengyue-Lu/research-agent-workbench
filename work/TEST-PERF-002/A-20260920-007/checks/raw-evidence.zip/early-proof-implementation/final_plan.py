"""Compute only the exact-head plan and independent accepted-base witness."""
from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, sys
repo = Path(r'D:\lcy\develop\_worktrees\RWB\ci-runner-preflight')
out = Path(__file__).resolve().parent
base = '171d4654f88e926f239cdf25bc8168109b81f391'
initial = '4119f8b2d8e1e64a0afead138d13061e2d89e996'
def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args])
head = git('rev-parse', 'HEAD').decode().strip()
assert not git('status', '--porcelain'), 'dirty final checkout'
sys.path.insert(0, str(repo / '.github/scripts'))
import plan_ci
plan = plan_ci.make_plan(repo, base=base, head=head, target=head,
    repository='Chengyue-Lu/research-agent-workbench', body='- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: yes')
plan_ci.verify_plan(repo, plan)
(out / 'final-plan.json').write_bytes(plan_ci.canonical(plan))
paths = ['tests/run_unittest_suite.py', 'tests/test_test_runner.py', 'tests/test_ci_plan.py',
    'tests/ci_impact_policy.yaml', 'tests/coverage_policy.yaml', '.github/scripts/plan_ci.py',
    '.github/scripts/ci_checks.py', '.github/scripts/selection_witness.py', '.github/scripts/ci_dependencies.py',
    '.github/scripts/ci_consumer_contracts.py', '.github/scripts/ci_input_facts.py', '.github/scripts/ci_contract_shadow.py',
    '.github/workflows/ci.yml', '.github/scripts/check_coverage_policy.py']
equivalence = {}
for path in paths:
    a, b = (git('show', sha + ':' + path) for sha in (base, initial))
    assert a == b, path
    equivalence[path] = hashlib.sha256(a).hexdigest()
# Execute exact accepted-base witness bytes; it reads candidate Git objects but never imports them.
raw = git('show', base + ':.github/scripts/selection_witness.py')
source = out / 'accepted-selection-witness.py'
source.write_bytes(raw)
spec = importlib.util.spec_from_file_location('accepted_witness', source)
witness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(witness)
result = witness.witness(repo, 'Chengyue-Lu/research-agent-workbench', base, head, plan)
result.update(witness_commit=base, witness_source_sha256=hashlib.sha256(raw).hexdigest(),
              source='exact accepted Git blob loaded offline; no hosted authentication claimed')
(out / 'final-witness.json').write_text(json.dumps(result, indent=2) + '\n')
doc = repo / 'docs/workstreams/chengyue-lu/TEST-PERF-002/EARLY_PROOF.md'
# This narrow workstream note contains no Markdown links requiring targets.
import re
links = re.findall(r'\[[^\]]*\]\(([^)]+)\)', doc.read_text(encoding='utf-8'))
assert not links, links
summary = {'base': base, 'initial_test_base': initial, 'head': head,
    'production_input_equivalence': equivalence, 'plan_id': plan['plan_id'],
    'obligations': {key: plan[key] for key in ('behavioral_scope', 'coverage_scope', 'coverage_obligations',
         'package_smoke', 'repository_smoke', 'blocked_reasons')},
    'witness_status': result['status'], 'documentation_links': len(links),
    'scope': 'local plan/witness validation; no test/coverage/hosted success claim'}
(out / 'final-binding.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
