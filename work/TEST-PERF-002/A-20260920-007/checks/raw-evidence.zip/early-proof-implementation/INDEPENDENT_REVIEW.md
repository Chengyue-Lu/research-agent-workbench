# Independent runner-preflight implementation review

Profile: CI runner preflight reviewer. Skills: none. Owner: Chengyue-Lu. Task: TEST-PERF-002.

## Disposition

No material blocking defect found in the scoped implementation. This is a read-only code/protocol review of the dirty `ci-runner-preflight` tree at base `4119f8b2d8e1e64a0afead138d13061e2d89e996`; it is not exact-head test, hosted CI, integration or merge acceptance. Four source hashes are retained in `source-hashes.json`, and the three tracked source/test diffs in `reviewed.diff`.

## Verified boundaries

1. **Producer-only Python restriction.** `tests/run_unittest_suite.py:466-489` handles `behavioral-evidence` before the new guard at lines 486-487. Only the ordered `coverage-execution` producer reaches that guard. Ordinary full/focused/impact/coverage-quality execution uses the unchanged other branch. The comparison is the same actual `platform.python_version()` 3.11 prefix already required by `_receipt_records` at lines 303-310; this moves an existing producer failure earlier. Exact-plan verification still precedes the guard; the claim is before test collection/fixtures, not before every Python import or Git read.

2. **Invalid full B is rejected before fixtures.** `_suite_for` at lines 190-195 checks the real `TestLoader.errors` and aggregate case count after native discovery, before returning the suite. `main` constructs `OrderedCoverageExecution` only after `_behavioral_suite` returns. A full discovery import error or zero-case result therefore cannot reach `TextTestRunner.run`. Test module imports and `load_tests` still occur as part of collection; these are deliberately not represented as fixture-free import execution.

3. **C remains deferred until B teardown.** No change was made to `OrderedCoverageExecution.__call__` at lines 284-296. The original B suite runs and completes its top-level fixture teardown before the callback invokes `_suite_for(... coverage-plan ...)`. The new repository loader check at lines 240-242 runs at that existing deferred boundary. It neither imports C early nor folds C into B's hierarchy. The coverage union now receives an exception from a repository loader whose own `errors` would otherwise be separate from the outer loader.

4. **Intentionally absent B remains legal.** `_behavioral_suite` at lines 255-262 still returns an empty suite for a verified `behavioral_scope=none`. The new full-suite zero-count check applies only when full behavior is actually required. The new regression at `tests/test_test_runner.py:482` distinguishes these cases and checks C's native module/class lifecycle.

5. **Existing interpreter and failure evidence preserved.** The real subprocess scenario at `tests/test_ci_plan.py:1217` still runs ordinary full behavior on the actual current interpreter and checks its sentinel. On 3.11 it retains original ordered execution, projection, ordering, deduplication and tampered-receipt assertions. On other interpreters the producer now must fail before receipt/sentinel creation. The class/module fixture fault scenario at line 1280 still requires real ordinary-full failure on both interpreters and retains ordered-worker failure/order equivalence on 3.11. It does not substitute success mocks for the previously required fault behavior.

6. **Regression design matches the change.** The six new `PreflightTests` methods at lines 432-511 use real disposable modules, native loaders and module/class sentinels. Their plan/Python patches isolate the local preflight branch; the two exact-Git subprocess scenarios provide the separate actual-interpreter path. The code does not change receipt projection, fixture identity, selected-case semantics, coverage thresholds or smoke requirements.

## Non-blocking diagnostic follow-up

The new exceptions at runner lines 193 and 242 use a generic missing/empty message and discard the loader's detailed module traceback. The early failure is safe, but preserving or printing `loader.errors` would make a hosted import failure easier to locate. This is an observability improvement, not a reason to broaden scope or delay this bounded correctness repair.

## Evidence limits

No tests were rerun and no source, frozen artifact, branch or external state was modified by this reviewer. The parent was already running the intended focused/interpreter checks; their results must be attributed separately. The four recorded hashes bound this review, so any later source delta needs the corresponding recheck. The pending PR #92 dependency and exact-target CI/review remain integration prerequisites. This repair reduces time spent on already-invalid producer/discovery inputs; it demonstrates no speedup for valid passing suites.
