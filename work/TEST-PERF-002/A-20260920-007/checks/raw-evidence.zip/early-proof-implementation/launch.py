from pathlib import Path
import hashlib, json, os, subprocess, sys, time
out = Path(__file__).resolve().parent
repo = Path(r'D:\lcy\develop\_worktrees\RWB\ci-runner-preflight')
label = sys.argv[1]
python = Path(r'D:\lcy\develop\_assessments\rwb-ci-schema-parse-20260917') / ('venv' + label) / 'Scripts/python.exe'
argv = [str(python), '-B', str(out / 'verify.py'), label]
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUTF8': '1',
       'PYTHONPATH': os.pathsep.join(str(repo / p) for p in ('', 'src', 'tests')),
       'GITHUB_EVENT_PATH': '', 'GITHUB_EVENT_NAME': 'pull_request', 'GITHUB_STEP_SUMMARY': ''}
started = time.perf_counter()
with (out / (label + '.log')).open('w', encoding='utf-8') as log:
    result = subprocess.run(argv, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
data = {'argv': argv, 'cwd': str(repo), 'returncode': result.returncode,
        'process_wall_seconds': time.perf_counter() - started,
        'log_sha256': hashlib.sha256((out / (label + '.log')).read_bytes()).hexdigest()}
(out / (label + '-process.json')).write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(data))
raise SystemExit(result.returncode)
