from pathlib import Path
import hashlib, json, os, platform, sys, time, unittest

REPO = Path(r'D:\lcy\develop\_worktrees\RWB\ci-runner-preflight')
OUT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path[:0] = [str(REPO), str(REPO / 'src'), str(REPO / 'tests')]
from tests import run_unittest_suite as runner
assert Path(runner.__file__).resolve() == REPO / 'tests/run_unittest_suite.py'
label = sys.argv[1]
sources = ['tests/run_unittest_suite.py', 'tests/test_test_runner.py', 'tests/test_ci_plan.py']
pins = {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in sources}
started = time.perf_counter()
loader = unittest.TestLoader()
suite = loader.loadTestsFromNames(['tests.test_test_runner', 'tests.test_ci_plan'])
assert not loader.errors, loader.errors
ids = [t.id() for t in runner._iter_tests(suite)]
assert len(ids) == len(set(ids))
(OUT / (label + '-preflight.json')).write_text(json.dumps({'python': platform.python_version(),
    'executable': sys.executable, 'source_sha256': pins, 'test_ids': ids,
    'collection_seconds': time.perf_counter() - started}, indent=2) + '\n')
result = unittest.TextTestRunner(verbosity=2, resultclass=runner.TimedTextResult).run(suite)
elapsed = time.perf_counter() - started
runner._write_summary(OUT / (label + '-receipt.json'), 'runner-preflight-focused', elapsed, result, 12)
assert pins == {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in sources}
print(json.dumps({'python': platform.python_version(), 'wall_seconds': elapsed, 'test_count': result.testsRun,
                  'successful': result.wasSuccessful(), 'source_sha256': pins}))
raise SystemExit(0 if result.wasSuccessful() else 1)
