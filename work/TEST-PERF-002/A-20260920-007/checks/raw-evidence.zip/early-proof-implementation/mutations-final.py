from pathlib import Path
import hashlib,json,os,subprocess,time
repo=Path(r'D:\lcy\develop\_worktrees\RWB\ci-runner-preflight')
out=Path(r'D:\lcy\develop\_assessments\rwb-ci-next-20260920\early-proof-implementation')
python=r'D:\lcy\develop\_assessments\rwb-ci-schema-parse-20260917\venv311\Scripts\python.exe'
source=(repo/'tests/run_unittest_suite.py').read_text()
markers={
'producer-version': ('        if not platform.python_version().startswith("3.11."):', '        suite = OrderedCoverageExecution'),
'full-collection': ('        if loader.errors or loaded.countTestCases() == 0:\n            details', '        _assert_unique_tests(loaded)'),
'coverage-collection': ('    if loader.errors or loaded.countTestCases() == 0:\n        details', '    _assert_unique_tests(loaded)')}
rows=[]
for name,(start,end) in markers.items():
 start=source.index(start)
 end=source.index(end,start)
 root=out/'mutants-final'/name
 (root/'tests').mkdir(parents=True,exist_ok=True)
 (root/'tests/__init__.py').write_text('')
 (root/'tests/run_unittest_suite.py').write_text(source[:start]+source[end:],encoding='utf-8')
 (root/'tests/test_test_runner.py').write_bytes((repo/'tests/test_test_runner.py').read_bytes())
 env={**os.environ,'PYTHONPATH':str(root),'PYTHONDONTWRITEBYTECODE':'1','GITHUB_EVENT_PATH':'','GITHUB_STEP_SUMMARY':''}
 cmd=[python,'-B','-m','unittest','tests.test_test_runner.PreflightTests','-v']
 started=time.perf_counter()
 r=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True)
 (root/'result.log').write_text(r.stdout+r.stderr,encoding='utf-8')
 rows.append({'mutant':name,'argv':cmd,'cwd':str(root),'exit':r.returncode,'wall_seconds':time.perf_counter()-started,'source_sha256':hashlib.sha256((root/'tests/run_unittest_suite.py').read_bytes()).hexdigest(),'log_sha256':hashlib.sha256((root/'result.log').read_bytes()).hexdigest()})
 assert r.returncode!=0, name
 assert 'FAILED (failures=2)' in r.stderr, r.stderr
(out/'mutant-final-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
