from pathlib import Path
import hashlib, json, subprocess
repo = Path(r'D:\lcy\develop\_worktrees\RWB\ci-runner-preflight')
out = Path(__file__).resolve().parent
def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args]).decode().strip()
paths = ['tests/run_unittest_suite.py', 'tests/test_test_runner.py', 'tests/test_ci_plan.py',
         'docs/workstreams/chengyue-lu/TEST-PERF-002/EARLY_PROOF.md']
pins = {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in paths}
checks = {}
for label in ('311', '313', '311-final', '313-final'):
    receipt = json.loads((out / (label + '-receipt.json')).read_bytes())
    process = json.loads((out / (label + '-process.json')).read_bytes())
    preflight = json.loads((out / (label + '-preflight.json')).read_bytes())
    assert process['returncode'] == 0 and receipt['successful'] is True
    assert receipt['test_count'] == (23 if 'final' in label else 96)
    assert not any(receipt['events'][x] for x in ('errors', 'failures', 'skips'))
    if 'final' in label:
        assert all(pins[p] == sha for p, sha in preflight['source_sha256'].items())
    checks[label] = {'python_version': preflight['python'], 'test_count': receipt['test_count'],
        'successful': receipt['successful'], 'events': receipt['events'],
        'runner_wall_seconds': receipt['wall_seconds'], 'process_wall_seconds': process['process_wall_seconds'],
        'source_sha256': preflight['source_sha256'],
        'receipt_sha256': hashlib.sha256((out / (label + '-receipt.json')).read_bytes()).hexdigest(),
        'process': process}
binding = json.loads((out / 'final-binding.json').read_bytes())
assert git('rev-parse', 'HEAD') == binding['head']
assert git('rev-parse', 'HEAD^') == binding['base']
assert not git('status', '--porcelain')
assert set(git('diff', '--name-only', binding['base'], 'HEAD').splitlines()) == set(paths)
source_out = out / 'final-source'
source_out.mkdir(exist_ok=True)
for p in paths:
    (source_out / (Path(p).name + '.txt')).write_bytes((repo / p).read_bytes())
mutation = json.loads((out / 'mutant-final-results.json').read_bytes())
assert len(mutation) == 3 and all(x['exit'] == 1 for x in mutation)
validation = {'source_sha256': pins, 'execution_authority': False,
    'commit': binding['head'], 'accepted_base': binding['base'], 'initial_test_base': binding['initial_test_base'],
    'branch': git('branch', '--show-current'), 'worktree_clean': True,
    'original_commit_before_rebase': 'b0a80c181519fc85f56ad8a76b5b80b6d540a83d',
    'rebased_commit_before_documentation_amend': 'fef9c35bd54f0c8f7e5a4595664c6c28f26d50d5',
    'checks': checks, 'mutant_controls': mutation, 'binding': binding,
    'scope': 'focused local tests and independent selection witness; full behavioral/repository coverage/smokes/hosted CI remain pending'}
(out / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n', encoding='utf-8')
table = '\n'.join('| ' + label + ' | ' + str(checks[label]['test_count']) + ' PASS | ' +
    str(checks[label]['runner_wall_seconds']) + ' | ' + f"{checks[label]['process_wall_seconds']:.6f}" + ' |'
    for label in checks)
pin_table = '\n'.join('| `' + p + '` | `' + sha + '` |' for p, sha in pins.items())
report = f'''# EARLY-PROOF implementation handoff

Owner Chengyue-Lu; Task TEST-PERF-002; Skills []. Branch `{validation['branch']}`.
Final commit **`{binding['head']}`**, direct parent/accepted develop **`{binding['base']}`**.
Only four authorized files changed. No push, PR, Trace archive or production reduction was performed.

## Behavior and scope

The runner now rejects unsupported ordered coverage producers before B collection, rejects native full-B loader errors/zero cases before fixture execution, and rejects nested repository-C loader errors/zero cases at the original deferred boundary. Invalid loaders retain the original module/ImportError traceback; an empty suite reports `no tests collected`. Explicit B=none remains valid. Normal full/focused/impact work on both supported Pythons remains covered, while the existing ordered producer remains 3.11-only. B's original hierarchy, fixtures and order, delayed C import, receipt projection and all quality policies are unchanged.

Root explicitly extended write scope to the two real worker regressions in test_ci_plan.py: `test_real_workers_preserve_order_and_project_exact_git_plan_evidence` and `test_real_ordered_worker_preserves_class_and_module_fixture_failures`. These retain actual 3.11 order/failure behavior and actual 3.13 ordinary behavior, while asserting 3.13 producer rejection without a raw receipt or sentinel execution. Six new runner scenarios use real disposable modules/loaders and fixture events; their plan/version patches isolate unit entry points, supplemented by those exact-Git subprocess workers.

## Verification phases (do not collapse their hashes)

| Run | Cases | Runner wall seconds | Process wall seconds |
| --- | ---: | ---: | ---: |
{table}

The first two runs were the complete **23 runner + 73 PlannerTests** combination on the original pending PR92 snapshot `{binding['initial_test_base']}`. Source hashes at that phase:

```json
{json.dumps(checks['311']['source_sha256'], indent=2)}
```

After both complete runs passed, root authorized the review's diagnostic improvement: the two new loader exceptions now append original loader.errors, or an explicit empty message. Existing regression fixtures were strengthened to check the precise ImportError/module and to ensure a nonempty impact suite cannot mask an empty repository suite. The producer-version fixture also declares valid coverage selectors so its removed-guard control reaches the existing late receipt enforcement instead of an unrelated missing field.

Only the 23 runner cases were rerun on both Pythons after that final improvement, as directed. test_ci_plan.py remained byte-identical to the full 96-case runs. The final runner/test source hashes match both final receipts; final source follows below. The old full-run producer scripts, raw logs/receipts/preflight JSON and original tested-source snapshot are retained untouched. We do not describe the earlier full 96 runs as testing the last error-message format.

Three final isolated controls remove exactly one new guard each. Each runs the same six real-module regressions, producing two expected assertion failures. The full-empty control reproduces the old empty-B acceptance; the mixed impact+repository control proves nonempty impact cannot substitute for empty required repository-C. The producer control reaches the old late receipt mismatch after executing behavior. Original earlier mutant observations are also retained, including their less precise fixture failure, and are not substituted for these final controls.

## Independent review and rebase

`INDEPENDENT_REVIEW.md` found no material blocker and recommended retained loader diagnostics. Root arranged a separate final recheck; its report binds the last code and controls. Earlier review files are preserved. The final documentation changes only explain validation phases and independent accepted-base integration.

Initial local commit `b0a80c181519fc85f56ad8a76b5b80b6d540a83d` was rebased with the authorized `git rebase --onto {binding['base']} {binding['initial_test_base']} fix/ci-runner-preflight`, yielding `fef9c35bd54f0c8f7e5a4595664c6c28f26d50d5`; a documentation-only amend yielded final HEAD. There were no conflicts. Fourteen relevant production/test/policy/selector/witness inputs are byte-identical between accepted develop and the initial PR snapshot, as recorded in final-binding.json. Final source/test bytes remain identical to their final focused runs. Full discovery membership differs because PR92 adds three diagnostic modules/tests; this assessment does not claim a final-head full-suite run.

`final_plan.py` recomputes and verifies the exact final-HEAD plan, then loads immutable accepted-base witness bytes and evaluates candidate Git objects without importing candidate code. Plan `{binding['plan_id']}` requires behavioral **full**, coverage **impact+repository**, and both smokes; blocked_reasons is empty. The independent local witness is **PASS**. These are plan/selection checks, not full-suite, coverage, smoke, hosted authentication or merge acceptance. The workstream note has zero Markdown links; `git diff --check` passed.

## Final source pins

| Repository-relative path | SHA256 |
| --- | --- |
{pin_table}

## Raw retention and next owner action

Archive the top-level producer scripts, `*-preflight.json`, `*-receipt.json`, `*-process.json`, all `.log` files, `tested-source-pins.json`, original/final source snapshots, mutant results, original/final mutant source and result.log, final plan/binding/witness, accepted witness source, both review reports and hash files, this report, validation.json and sha256.json. The mutation fixture roots contain only small source copies and logs required to replay the controls; they are not Git clones.

No temporary Git clone or venv exists under this scratch output. Exclude any `__pycache__` and `.pyc` if later created. The persistent `ci-runner-preflight` worktree and shared read-only venvs are not archive inputs; reference the commit and recorded interpreter paths. Native temporary test repositories were removed by their own fixture lifecycle.

Root owns Task Attempt A-20260920-007, push and Draft PR. CI still must execute the exact final target's required plan, complete coverage and smokes, and obtain review. This is early invalid-input rejection; no hosted duration reduction or passing-suite speedup is claimed.
'''
(out / 'REPORT.md').write_text(report, encoding='utf-8')
manifest = {p.relative_to(out).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'sha256.json'
            and '__pycache__' not in p.parts and p.suffix != '.pyc'}
(out / 'sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'commit': binding['head'], 'validation_sha256': manifest['validation.json'],
                  'report_sha256': manifest['REPORT.md'], 'source_sha256': pins, 'retained_files': len(manifest)}, indent=2))
