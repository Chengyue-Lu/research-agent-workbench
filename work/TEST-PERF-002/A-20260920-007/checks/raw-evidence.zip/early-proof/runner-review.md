# Runner early-proof diagnostic audit

Agent Profile: CI runner auditor. Owner: Chengyue-Lu. Required Skills: [].

Scope: `tests/run_unittest_suite.py`, root `AGENTS.md`, and only `verify_plan` / `require_obligations` in `.github/scripts/plan_ci.py`. No tests, workflow edits, external calls or source edits were performed. This report grants no execution, reduction or acceptance authority.

Observed HEAD: `4119f8b2d8e1e64a0afead138d13061e2d89e996`.

## Checks already performed before execution

1. **CLI and plan loading.** `main` parses suite choices, paths and verbosity at runner lines 448-459. Any supplied plan is verified at line 461. `coverage-execution` requires a plan, nonempty coverage obligations and a coverage-results output argument (462-466, 480-481). It does not prevalidate whether output files can be written.
2. **Git and plan binding.** `_verified_plan` imports the worktree planner, reads the plan and optional event, then calls `verify_plan` (144-157). Planner lines 716-722 reject tracked drift and untracked `.github` / `src` / `tests` input, verify the plan digest and bind the target to checkout HEAD. Lines 724-731 recompute minimum obligations, compare top-level shape and event binding, and invoke `require_obligations`.
3. **Declared obligation pins.** Planner lines 324-350 check version 4, blocked reasons, minimum risk/behavior/coverage, change-class consistency, the declared Python matrix, smoke requirements, policy hash, selection proof, required selective tests/groups and required impact modules/tests/evidence/line mappings. The Python field check at 334-335 is a declared-plan matrix check, not a check of the running interpreter. The internals of recomputation helpers were not inspected under this scope.
4. **Behavioral selection.** `coverage-execution` constructs B through `_behavioral_suite` at runner lines 482-483. Scope `none` yields an intentionally empty suite; `full` and `focused` use `_suite_for` (251-257). `full` performs discovery and duplicate checking (190-193). `focused` re-verifies the plan, requires a selective behavioral scope, and explicitly rejects `loader.errors` or zero cases (194-200, 222-225).
5. **Duplicates and evidence IDs.** `_assert_unique_tests` rejects both repeated runtime IDs and repeated source/class/method identities, including source aliases (122-132, 160-179). `_inventory` repeats that check and maps portable evidence IDs to runtime IDs (135-141, 267-269); `OrderedCoverageExecution.__init__` captures B's inventory before execution (274-278). It does not explicitly reject an empty inventory or assert that this final evidence-ID map has the same cardinality as the collected tests. Standard in-repository TestCase IDs are substantially protected by the two existing duplicate checks; no concrete evidence-ID collision was demonstrated.
6. **Coverage selection remains deferred.** C is passed as a loader closure (482-483). `coverage-plan` requires obligations, unions repository and impact suites by canonical identity, rejects outer-loader errors or an empty union and checks duplicates (201-219). Impact alone checks its exact obligation set and missing/empty loaded groups (220-225). Repository `coverage-quality` checks policy mapping, nonempty string modules, string test IDs, duplicate selector names and duplicate loaded identities (107-111, 227-240). These C checks occur after B in ordered execution. The nested repository loader's errors are not forwarded to the outer coverage-plan loader.

## What occurs after tests start

`runner.run(suite)` is the execution boundary (487). Within ordered execution, B runs with its original suite hierarchy and completes top-level teardown (282). The runner resets `_previousTestClass` and `_moduleSetUpFailed`, loads C, builds its inventory, and runs only C tests whose evidence IDs are absent from B (285-291). This is done even if B reported failures; no success guard surrounds the C load.

After the complete runner returns, `main` captures wall time, chooses the receipt label and writes the raw summary (488-493). Only a successful `coverage-execution` then calls `_project_execution` and writes projected coverage results (494-496). An exception during deferred C loading escapes the execution call before this summary-writing path.

`_receipt_records` then verifies exact plan/target/schema/obligations/suite/success binding, actual Python `3.11.*` and equality to the current interpreter (299-307); exact test-ID sets/counts, duplicate runtime/evidence IDs, successful allowed outcomes and checkpoints (308-319). `_project_execution` additionally requires zero failure/error fixture events, exact behavioral/coverage order contract and exact execution order (323-335). These are receipt checks after B and C, not early runtime/configuration checks.

The runner contains no direct coverage-engine/version/configuration/branch/source measurement check. Those may exist in callers or coverage validators, which were not read. The only actual Python pin in this file is the late receipt check above.

## Cheap candidates before B, without loading C early

- **Reject B discovery errors at the existing collection boundary.** Add the same `loader.errors` rejection used by focused/impact to the `full` branch before returning its already collected suite (190-193). An unresolved import currently becomes a unittest failure placeholder and is not explicitly rejected here; B can execute other tests before the overall failed result. Preserve the suite object, order and fixture hierarchy.
- **Reject empty required B.** Immediately after collecting B or forming its inventory, require at least one test when `behavioral_scope` is `full` or `focused`; retain the explicit empty allowance for `none`. This closes more than a delayed failure: from source inspection, empty `full` B plus nonempty successful C can satisfy the current receipt checks and produce a successful behavioral projection with `test_count=0`, because no independent nonempty-B invariant is enforced (190-193, 253-254, 267-278, 308-312, 338-350). This is a static control-flow conclusion, not a reproduced test result.
- **Check final B evidence cardinality.** At `_inventory`, compare the evidence-ID map cardinality with the original collected entries and reject empty or invalid ID strings. This is a cheap defensive proof against dictionary overwrite, independent of running fixtures. No demonstrated collision is claimed, and the existing canonical/runtime duplicate checks should remain.
- **Move the actual interpreter compatibility check to the execution entry point.** For `coverage-execution`, an unsupported running Python version can be rejected before constructing/running B, matching the already enforced post-run `3.11.*` receipt condition. Preserve the receipt check as well. Do not apply this reuse-specific restriction to ordinary full/focused Python 3.13 runs.
- **Validate only static C selector prerequisites early.** Plan-field or policy-list shape, required nonempty selector lists and repeated selector strings can be checked without importing C modules. Share that pure validation with the late loader to avoid drift. This does not establish that selectors resolve to real tests or that C's actual inventory is nonempty; those checks must remain at the existing deferred C boundary. In particular, add the missing `loader.errors` / zero-case checks to `coverage-quality` there, so errors in its nested loader are not mistaken for valid nonempty coverage evidence.

Do not call `_execution_suites` as an early preflight: it collects both B and C (260-264). Do not import C, flatten/rebuild B, execute fixture methods, or reset lifecycle state earlier merely to obtain these proofs. Existing B collection already imports modules and may execute custom `load_tests`; reuse its outcome rather than repeating collection.

## Limits and source identity

This audit does not establish workflow/toolchain pins, actual coverage configuration, selector contents, source instrumentation, measured cost, hosted behavior or efficacy. It establishes the visible order and guards in the scoped source only.

SHA-256:

- `tests/run_unittest_suite.py`: `b759929d5ca97ff243e2cdc0b8e6949661b78cb35fd9647faf4e1a01feffa3c2`
- `.github/scripts/plan_ci.py`: `55c21010a31671199908053b7d044355be0fe4cead16ffeb799bc2d5f7057ecb`
