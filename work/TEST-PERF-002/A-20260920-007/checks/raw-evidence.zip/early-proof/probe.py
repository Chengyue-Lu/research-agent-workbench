"""Offline diagnostics only: no test collection, test execution, or authority changes."""
from pathlib import Path
import hashlib, importlib.util, io, json, os, platform, subprocess, sys, time, zipfile
import coverage
import yaml

OUT = Path(__file__).resolve().parent
REPO = Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow')
PILOT = Path(r'D:\lcy\develop\_assessments\rwb-ci-ready-20260920\coverage-pilot')
started = time.perf_counter()
inputs = {}
def read(path):
    raw = path.read_bytes()
    inputs[str(path)] = hashlib.sha256(raw).hexdigest()
    return raw
def load(name, path):
    read(path)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
sys.dont_write_bytecode = True
sys.path.insert(0, str(REPO / '.github/scripts'))
checker = load('ci_checks_probe', REPO / '.github/scripts/ci_checks.py')
runner = load('runner_probe', REPO / 'tests/run_unittest_suite.py')
for path in ['.github/scripts/plan_ci.py', '.github/scripts/check_coverage_policy.py']:
    read(REPO / path)
rows = []
for label, folder, snapshot in [
    ('guard-real-negative', PILOT / 'provider-pair', PILOT / 'snapshot'),
    ('assignment-real-positive', PILOT / 'provider-positive/short-temp-pair', PILOT / 'provider-positive/snapshot')]:
    plan = json.loads(read(folder / 'plan.json'))
    raw = json.loads(read(folder / 'accepted-coverage.json'))
    receipt = json.loads(read(folder / 'accepted-coverage-receipt.json'))
    policy = yaml.safe_load(read(snapshot / 'tests/coverage_policy.yaml'))
    # Code hashes, not patching ROOT, establish native checker equivalence to the target.
    assert read(snapshot / '.github/scripts/ci_checks.py') == (REPO / '.github/scripts/ci_checks.py').read_bytes()
    assert read(snapshot / '.github/scripts/check_coverage_policy.py') == (REPO / '.github/scripts/check_coverage_policy.py').read_bytes()
    failures = []
    try:
        result = checker.impact_coverage(plan, policy, raw, receipt)
    except ValueError as error:
        failures.append(str(error)); result = None
    rows.append({'scenario': label, 'target': plan['binding']['target'], 'plan_id': plan['plan_id'],
                 'native_impact_failures': failures, 'native_impact_result': result,
                 'phase': 'retained-postexecution-evidence; NOT static prediction'})
    config_bytes = read(folder / 'coverage.ini')
    os.chdir(snapshot)
    config = coverage.Coverage(config_file=str(folder / 'coverage.ini'))
    rows[-1]['configuration'] = {'branch': config.get_option('run:branch'),
        'source': config.get_option('run:source'), 'plugins': config.get_option('run:plugins')}
    # A native parser accepts branch=False; current checker can reject only after real results.
    if label == 'assignment-real-positive':
        changed = config_bytes.replace(b'branch = True', b'branch = False')
        assert changed != config_bytes
        mutant = OUT / 'branch-disabled-control.ini'
        mutant.write_bytes(changed)
        alternate = coverage.Coverage(config_file=str(mutant))
        rows.append({'scenario': 'scratch-config-branch-disabled', 'synthetic_mutant': True,
                     'parsed_branch': alternate.get_option('run:branch'),
                     'early_contradiction': alternate.get_option('run:branch') is not True,
                     'production_config_changed': False})
        execution = json.loads(read(folder / 'accepted-receipt.json'))
        expected = {r['canonical_id']: r['id'] for r in execution['tests']}
        try:
            runner._receipt_records(execution, 'coverage-execution', expected, plan)
            version_result = 'accepted'
        except ValueError as error:
            version_result = str(error)
        rows.append({'scenario': 'native-receipt-current-interpreter', 'actual_python': platform.python_version(),
                     'retained_producer_python': execution['python_version'], 'result': version_result,
                     'no_test_body_ran': True})

# Read only previously authorized frozen PR90 artifacts, never another owner's branch.
archive = REPO / 'work/TEST-PERF-002/A-20260920-001/checks/raw-evidence.zip'
with zipfile.ZipFile(io.BytesIO(read(archive))) as outer:
    with zipfile.ZipFile(io.BytesIO(outer.read('pr90/ci-plan.zip'))) as inner:
        pr90 = json.loads(inner.read('ci-plan.json'))
    with zipfile.ZipFile(io.BytesIO(outer.read('pr90/coverage-quality-evidence.zip'))) as inner:
        data = json.loads(inner.read('coverage.json'))
    subject = next(p for p in pr90['coverage_modules'] if p.endswith('export_capture.py'))
    # Metadata-only exact target tree inventory suffices to show package discovery gap.
    target = pr90['binding']['target']
    ancestor_inits = [str(p / '__init__.py').replace('\\', '/') for p in Path(subject).parents if str(p) != '.']
    cmd = ['git', '-C', str(REPO), 'ls-tree', '-r', target, '--', subject, *ancestor_inits]
    result = subprocess.run(cmd, capture_output=True, text=True)
    rows.append({'scenario': 'PR90-retained-missing-subject', 'target': target,
                 'subject': subject, 'absent_in_raw_coverage': subject not in data['files'],
                 'git_metadata_argv': cmd, 'git_metadata_returncode': result.returncode,
                 'git_metadata_stdout': result.stdout, 'git_metadata_stderr': result.stderr,
                 'early_classification': 'dynamic-execution-proof-needed; warning only',
                 'reason': 'Non-package auxiliary source may be measured through real dynamic execution; no static failure proved.'})

report = {'execution_authority': False, 'python_version': platform.python_version(),
          'coverage_version': coverage.__version__, 'input_sha256': inputs,
          'rows': rows, 'wall_seconds': time.perf_counter() - started,
          'test_suites_loaded': 0, 'tests_executed': 0}
out = OUT / ('probe-' + platform.python_version().split('.')[1] + '.json')
out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'output': str(out), 'wall_seconds': report['wall_seconds'],
                  'rows': [{k:v for k,v in row.items() if k in {'scenario','native_impact_failures','result','early_contradiction','early_classification'}} for row in rows]}))
