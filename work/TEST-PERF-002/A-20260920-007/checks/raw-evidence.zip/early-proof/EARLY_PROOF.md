# EARLY-PROOF bounded diagnostic assessment

Owner: Chengyue-Lu. Agent Profile: CI preflight analyst. Skills: [].
`execution_authority=false`. This assessment changes no repository files, workflow, Gate, policy, test selection or coverage threshold. It does not run or collect any test suite.

## Finding and recommended slice

Start with small fail-early checks at existing execution boundaries. The current system already verifies exact Git/plan authority and many selection invariants; a second planner or a second coverage checker would duplicate authority. The useful first slice is **early rejection of impossible execution inputs**, not static prediction of whether a line or branch will execute.

The strongest bounded implementation is in the existing unittest runner:

1. For `coverage-execution` only, reject a running interpreter other than Python 3.11 before B is collected or executed. The same restriction currently applies only during successful receipt projection after the entire run. Ordinary Python 3.13 full/focused execution remains valid and must stay supported.
2. At the existing full B collection point, reject `loader.errors` and a zero-case result when behavior is required. Return the same suite object and preserve its hierarchy, order and fixture lifecycle. Retain the explicit empty `behavioral_scope=none` allowance.
3. At the existing deferred repository-C collection point, reject that loader's errors and zero-case result. The outer coverage-plan loader does not inherit the nested repository loader's error list. Do not collect C before B merely to perform this check.

These prevent wasted failure runs and strengthen empty-suite handling. They do not accelerate a valid passing full run, and no hosted minutes saved are claimed. Source changes to this authority surface require the existing conservative validation/review rules.

## Exact read identity

Audited CI worktree HEAD: `4119f8b2d8e1e64a0afead138d13061e2d89e996`. Its accepted develop base is `171d4654f88e926f239cdf25bc8168109b81f391`. Independent runner review is in `runner-review.md`; full source hashes and retained-input hashes are in `probe-11.json` and `probe-13.json`.

The consumer-read scope was extended locally only to the concrete caller `.github/scripts/ci_checks.py`, because it owns coverage configuration and impact enforcement. Coverage package implementation metadata was read to distinguish permitted tracing from discovery of unexecuted package files. No business-owner branch or source was read; PR90 inputs came only from the already authorized frozen TEST-PERF-002 archive.

## Already checked, and why not to build them twice

| Obligation | Existing check and timing | Assessment |
| --- | --- | --- |
| Exact refs and checkout | `plan_ci.exact_commit`, `make_plan` 391–424; `verify_plan` 715–731: clean tracked checkout, untracked CI/source/test inputs, digest, target HEAD, recomputed base minimum, event binding | Already before execution. Reuse it; diagnostics must not substitute their own digest validation. |
| Minimum scope / Python matrix / smokes / policy hash | `require_obligations` 322–350; impact subject, proof and line mappings bound to recomputed minimum | Already before execution. Declared Python versions differ from actual process validation. |
| Reviewed consumer pins and strict body boundary | `make_plan` 531–551 plus evidence drift and accepted fingerprint anchor | Existing selection authority. Known anchor drift belongs to the separate root repair, not this preflight. |
| Critical positive/negative mappings | `make_plan` 568–575 and 631 rejects missing mapping or overlapping impact IDs | Already checked for the impacted closure. Do not treat mapping presence as proof of PASS outcomes. |
| Executable line map / syntax | `coverage_lines` 92–116; `make_plan` 655 | Already before execution. Static mapping does not establish runtime line or outgoing-branch coverage. |
| Safe coverage subject/filter path | `ci_checks.coverage_config` 18–47 rejects unsafe path syntax, matching symlinks, invalid ancestors and unsafe omit entries | Already part of configure. It does not independently require every planned subject to exist as a regular file or prove effective instrumentation. |
| Focused/impact selector load and nonempty suite | Runner 194–225 | Existing pre-execution check for the suite being loaded. B is loaded first; C remains deliberately deferred. |
| Duplicate runtime/canonical test identities | Runner 160–179, 267–269 | Already checked. A further evidence-map cardinality assertion is defense in depth; no actual collision was found. |
| Full B and nested repository-C loader errors/emptiness | Runner 190–193 and 227–240 do not explicitly reject them | Narrow implementation gap; reuse current collection, never run a second discovery. |

The full-B empty case is more than a late error: static inspection shows that an empty full B and nonempty C can reach a successful projected behavioral receipt with test_count=0. No synthetic execution was constructed in this read-only task, so this is a source-level finding to reproduce in the implementation regression.

## Additional pure configuration checks worth extracting, not copying

`check_coverage_policy.check_policy` currently checks root, floors and declaration structure together with runtime coverage at lines 109–203. `ci_checks.impact_coverage` performs the same relevant root/floor, impact 100/100, exclusion and evidence checks only after execution (56–99).

A subsequent small change could extract a shared pure policy validator and call it during configuration. It can prove contradictions before tests: invalid source_root, under-floor or nonnumeric thresholds, an impact threshold different from 100/100, malformed exact exclusions, contradictory positive/negative declarations. It must preserve the current postexecution checks. Avoid inventing new floor values or a second independently maintained validation routine. Static policy validity is neither actual exclusion equality nor coverage success.

The effective coverage process can also report its actual engine/version, branch mode and effective config digest before B. In normal CI, the existing configurator explicitly writes branch=True and source/omit paths, so this is primarily invocation/setup hardening. The prototype only confirms that a copied branch=False config is parseable and structurally contradicts the existing branch obligation. It does not demonstrate that the production workflow currently passes that bad config.

For source subjects, safe early errors include a verified plan subject absent from its exact target/checkout, a disallowed file type or a subject excluded by the effective engine configuration. Some are already unreachable through current planner invariants; implement a case only after a real counterexample or direct configurator regression establishes need. A missing package initializer or absent static import is not by itself an impossible measurement condition.

## Real retained evidence, and the critical limitation

The offline `probe.py` imports only unchanged CI checkers and the runner's receipt validator. It never loads B or C and never executes source/test bodies. Both coverage checker source files were byte-equal to the historical target copies before replay. Raw coverage/receipts are read in place and unchanged.

| Control | Exact evidence | Observed result |
| --- | --- | --- |
| Real guard negative | Target `09361362c7d4d8fdf4599f066965ee092c05b939`, plan `ba72b403769293830600ece8f6f09183572f8804cdabc77f493221be44c610e8` | Native impact checker rejects uncovered changed lines in OpenAI provider; retained run has 81 PASS but missing line 65 / branch 64→65. This requires actual runtime evidence, not static failure prediction. |
| Real assignment positive | Target `51eb115119d3ea7b9639fae86ba94e0f5f0be8ea`, plan `f8091e8ca27f552f3c30a9c99bf36a74bf614344999c816098294856a9885736` | Same native checker accepts retained impact evidence; its original independent B/C/smoke pair remains the authority for what ran. No new test execution claimed. |
| Real native receipt and actual interpreter | Same positive execution receipt, fresh Python 3.11.16 versus fresh Python 3.13.15 processes | 3.11 accepts; 3.13 rejects the binding. Source proves the current producer checks this only after executing and writing the raw receipt. |
| Copied config negative | `branch-disabled-control.ini`, derived from real positive config with only branch=True changed to False | Native coverage.py parser accepts it; the pre-run fact contradicts branch coverage required by the existing Gate. Explicitly a scratch mutant, not a historical production failure. |
| PR90 auxiliary script | Target `737fb4198eac1e51f42da2f2204971ef96ec5ace`, plan `8ca44bba92c53e16a9bcf324b191f3abcc9adb68e142f2e2e425ee43e15527ea` | Raw hosted artifact lacks planned export_capture.py. Exact Git metadata proves the script is a regular blob with no package initializers in its docs ancestor chain. This is an early warning of dynamic execution proof needed, not a sound early rejection. |

PR90's original B1425/C1399 execution spent 2239.890768 seconds in the runner and all tests passed before missing-subject enforcement failed. Native coverage discovery visits only importable package directories unless namespace inclusion is enabled. `source=.` plus permission to trace a planned archive file does not guarantee an unexecuted file appears in JSON. A legitimate selected test can nevertheless execute that exact auxiliary file dynamically, in which case it is measured. Therefore a preflight must **not** reject all non-discovered auxiliary files or claim no static import means no runtime consumer. Missing declared measurable entry/accepted reader contract is an actionable diagnostic until a reviewed contract makes it enforceable.

A hypothetical cheap C-first run to prove that auxiliary script would change ordering/lifecycle and rerun tests. This assessment does not recommend it. If a future separate probe is introduced, its results cannot replace normal B/C obligations or be silently merged as equivalent evidence.

## Execution and retained files

Commands were run sequentially with `PYTHONDONTWRITEBYTECODE=1`:

```text
D:\lcy\develop\_assessments\rwb-ci-schema-parse-20260917\venv311\Scripts\python.exe -B D:\lcy\develop\_assessments\rwb-ci-next-20260920\early-proof\probe.py
D:\lcy\develop\_assessments\rwb-ci-schema-parse-20260917\venv313\Scripts\python.exe -B D:\lcy\develop\_assessments\rwb-ci-next-20260920\early-proof\probe.py
```

Both exited 0. Internal offline evaluation wall was 0.150238 s and 0.150685 s respectively. These are small diagnostic script timings, not suite speedups. Both report zero loaded test suites and zero tests executed.

Retained files: this report, `runner-review.md`, exact `probe.py`, both JSON outputs and their full input hashes, the explicitly labeled config mutant, and `sha256.json`. Old evidence, source files and receipts were not edited. There are no commits, external messages or new workflow/Gate claims.

## Acceptance for the next implementation

- Reproduce actual unsupported producer Python, full B import error and non-none empty B; prove rejection happens before any sentinel fixture runs.
- For valid B, retain original suite object/order, class/module setup/teardown and normal failures; B=none remains legal where the verified plan requires none.
- Confirm C is not imported before B completes. Reproduce a nested repository-C loader error at that existing deferred boundary.
- Keep post-run native receipt and coverage enforcement unchanged. Recheck focused, impact, full, repository and mixed B/C runner paths on both supported Python workers.
- Treat config/policy extraction as a separate slice, using the same shared functions before and after execution. PR90 warning must not acquire exclusion or pass authority.
