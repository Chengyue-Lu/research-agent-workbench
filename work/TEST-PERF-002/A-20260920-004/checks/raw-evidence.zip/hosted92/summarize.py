import json
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime

root = Path(__file__).parent
def read(path):
    return json.loads((root / path).read_text(encoding='utf-8-sig'))
plan = read('artifacts/ci-plan/ci-plan.json')
execution = read('artifacts/coverage-quality-evidence/execution-test-results.json')
compatibility = read('artifacts/compatibility-3.13-evidence/full-test-results-3.13.json')
run = read('run.json')
def modules(result):
    out = defaultdict(lambda: {'count': 0, 'seconds': 0})
    for row in result['tests']:
        out[row['module']]['count'] += 1
        out[row['module']]['seconds'] += row['duration_seconds']
    return dict(sorted(out.items(), key=lambda p: -p[1]['seconds']))
def seconds(a,b):
    return (datetime.fromisoformat(b.replace('Z','+00:00'))-datetime.fromisoformat(a.replace('Z','+00:00'))).total_seconds()
b=execution['execution']['behavioral_order']
c=execution['execution']['coverage_order']
e=execution['execution_order']
cm=modules(compatibility)
em=modules(execution)
summary = {
    'binding': plan['binding'],
    'plan_id': plan['plan_id'],
    'policy_sha256': plan['policy_sha256'],
    'plan': {key: plan[key] for key in ('risk','behavioral_scope','coverage_scope','coverage_obligations','coverage_modules','package_smoke','repository_smoke')},
    'reason_counts': {key: dict(Counter(x.split(':',1)[0] for x in value)) for key,value in plan['obligation_reasons'].items()},
    'policy_reason': [x for x in plan['reasons'] if 'coverage' in x or 'policy metadata' in x],
    'B':len(b), 'C':len(c), 'B_union_C':len(set(b)|set(c)), 'B_intersection_C':len(set(b)&set(c)), 'C_minus_B':len(set(c)-set(b)), 'B_minus_C':len(set(b)-set(c)),
    'executed':len(e), 'executed_unique':len(set(e)), 'ordered_B_then_C_minus_B':e == b+[x for x in c if x not in set(b)],
    'coverage_execution': {'wall_seconds':execution['wall_seconds'], 'sum_case_seconds':sum(x['duration_seconds'] for x in execution['tests']), 'outcomes':execution['outcomes'], 'python_version':execution['python_version']},
    'compatibility_execution': {'wall_seconds':compatibility['wall_seconds'], 'sum_case_seconds':sum(x['duration_seconds'] for x in compatibility['tests']), 'outcomes':compatibility['outcomes'], 'python_version':compatibility['python_version']},
    'module_costs': [{'module':k, 'cases':v['count'], 'coverage_seconds':v['seconds'], 'compatibility_313_seconds':cm.get(k,{}).get('seconds'), 'case_seconds_percent':100*v['seconds']/sum(x['duration_seconds'] for x in execution['tests'])} for k,v in em.items()],
    'slowest':[{k:row[k] for k in ('canonical_id','duration_seconds','outcome')} for row in execution['slowest']],
    'jobs':[{'name':j['name'],'start':j['startedAt'],'end':j['completedAt'],'wall_seconds':seconds(j['startedAt'],j['completedAt']),'conclusion':j['conclusion'], 'steps':[{'name':s['name'],'seconds':seconds(s['startedAt'],s['completedAt']),'conclusion':s['conclusion']} for s in j['steps']]} for j in run['jobs']],
    'created_to_first_job_seconds':min(seconds(run['createdAt'],j['startedAt']) for j in run['jobs']),
    'workflow_elapsed_seconds':seconds(run['createdAt'],run['updatedAt']),
    'job_wall_sum_seconds':sum(seconds(j['startedAt'],j['completedAt']) for j in run['jobs']),
}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('module_costs','slowest','jobs')},indent=2))
print(json.dumps(summary['module_costs'][:10],indent=2))
