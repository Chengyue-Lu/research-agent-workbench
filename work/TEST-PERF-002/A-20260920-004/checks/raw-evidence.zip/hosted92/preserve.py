import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

root=Path(__file__).parent
env=dict(os.environ)
for key in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY'):
    env.pop(key,None)
artifacts=json.loads((root/'artifacts.json').read_text(encoding='utf-8-sig'))['artifacts']
verified=[]
for row in artifacts:
    path=root/(row['name']+'.zip')
    with path.open('wb') as handle:
        subprocess.run(['gh','api',f"repos/Chengyue-Lu/research-agent-workbench/actions/artifacts/{row['id']}/zip"],stdout=handle,check=True,env=env)
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    assert 'sha256:'+digest==row['digest'],row['name']
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        for name in archive.namelist():
            dest=root/'artifacts'/row['name']/name
            assert dest.resolve().is_relative_to(root.resolve())
            if not name.endswith('/'):
                dest.parent.mkdir(parents=True,exist_ok=True)
                dest.write_bytes(archive.read(name))
    verified.append({'artifact':row['name'],'id':row['id'],'sha256':digest,'api_digest_match':True,'zip_crc_ok':True})
(root/'verification.json').write_text(json.dumps(verified,indent=2)+'\n',encoding='utf-8')
print(json.dumps(verified,indent=2))
