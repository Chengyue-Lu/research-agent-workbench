import hashlib
import json
from pathlib import Path

root=Path(__file__).parent
def read(name):return json.loads((root/name).read_text(encoding='utf-8-sig'))
s=read('summary.json'); c=read('checks.json'); run=read('run.json'); pr=read('pr.json')
jobs={j['name']:j for j in s['jobs']}
comparison=c['prior_pr92_comparison']
lines=[
'# PR #92 current-head hosted acceptance evidence', '',
'Run [35497858451](https://github.com/Chengyue-Lu/research-agent-workbench/actions/runs/35497858451) completed successfully. This read-only observation downloads existing logs and artifacts; no CI rerun, branch change, or remote comment was performed.', '',
'## Binding', '',
f"- Base and merge-base: `{c['binding']['base']}`.",
f"- Head: `{c['binding']['head']}`.",
f"- Tested merge target: `{c['binding']['target']}`.",
f"- Plan ID: `{c['plan_id']}`.",
f"- Producer canonical SHA256: `{c['producer_canonical_sha256']}`.",
f"- PR observed state: {pr['state']}; draft={str(pr['isDraft']).lower()}. This is an observation at retrieval time, not merge authorization.", '',
'The merge-commit API confirms the exact base/head parents. All execution receipts bind the same plan and target; both projected 3.11 behavioral and coverage receipts match the producer hash. Worker, smoke and aggregate checkout logs show this same merge SHA. All original artifact ZIPs were verified against the GitHub API SHA256 digests and ZIP CRCs.', '',
'## Obligations and execution', '',
f"Plan: behavioral `{s['plan']['behavioral_scope']}`, coverage `{s['plan']['coverage_scope']}`, package_smoke={str(s['plan']['package_smoke']).lower()}, repository_smoke={str(s['plan']['repository_smoke']).lower()}.", '',
'The full/repository fallback still comes from `docs/workstreams/chengyue-lu/TEST-PERF-002/domain-model.json` being unclassified. Changes introduce diagnostic subjects, not activation of reduction. Impact subjects:', '',
*[f'- `{m}`' for m in s['plan']['coverage_modules']], '',
f"B={s['B']}, C={s['C']}, intersection={s['B_intersection_C']}, C-B={s['C_minus_B']}, B-C={s['B_minus_C']}, union={s['B_union_C']}. Executed={s['executed']}, unique IDs={s['executed_unique']}; exact ordered B then C-B={s['ordered_B_then_C_minus_B']}.", '',
f"3.11 producer outcomes: `{json.dumps(s['coverage_execution']['outcomes'],separators=(',',':'))}`.",
f"3.13 behavioral outcomes: `{json.dumps(s['compatibility_execution']['outcomes'],separators=(',',':'))}`.", '',
'## Quality and smoke Gates', '',
f"Hosted impact and repository coverage enforcement PASS. Canonical source-root line coverage {c['source_root_covered_lines']}/{c['source_root_statements']} = {c['source_root_line_percent']:.6f}% (floor 90%). All {c['critical_inventory_count']} registered critical modules pass 95% line / 90% branch.", '',
'| Impact module | Covered statements | Covered branches |', '|---|---:|---:|',
*[f"| `{m}` | {v['covered_lines']}/{v['num_statements']} | {v['covered_branches']}/{v['num_branches']} |" for m,v in c['impact_summary'].items()], '',
'Repository validation: 186 validated / 0 errors / 0 warnings. Package smoke: four install routes per Python (direct and sdist-wheel, isolated and non-isolated), eight total probes PASS; each reports 142 resources, 94 schemas and identical runtime resources. Both fixed `test (3.11)` and `test (3.13)` aggregates pass against their required job set.', '',
'Separate governance run 35497858893 also PASS on this same head and merge target; its raw log and run metadata are retained. The PR rollup retains an earlier cancelled governance run 35497858467 (completed 07:48:28 UTC) followed by the successful run (completed 07:48:46 UTC). The successful run is the observed current governance evidence; the cancelled historical entry is preserved, not hidden.', '',
'## Observed cost', '',
'| Measurement | Seconds |', '|---|---:|',
f"| Whole workflow elapsed | {s['workflow_elapsed_seconds']:.0f} |",
f"| Initial created-to-first-job gap | {s['created_to_first_job_seconds']:.0f} |",
f"| Coverage job API wall | {jobs['coverage-quality (3.11)']['wall_seconds']:.0f} |",
f"| Coverage producer wall | {s['coverage_execution']['wall_seconds']:.6f} |",
f"| Sum of coverage case durations | {s['coverage_execution']['sum_case_seconds']:.6f} |",
f"| Compatibility 3.13 job API wall | {jobs['compatibility (3.13)']['wall_seconds']:.0f} |",
f"| Compatibility 3.13 runner wall | {s['compatibility_execution']['wall_seconds']:.6f} |",
f"| Sum of all job API walls | {s['job_wall_sum_seconds']:.0f} |", '',
'Job-wall sum is an execution-cost proxy, not a billed CPU measurement. Case timers do not independently expose shared class/fixture/runner lifecycle costs. Full step timing is preserved in summary.json.', '',
'| Largest coverage modules | Cases | Coverage seconds | 3.13 seconds |', '|---|---:|---:|---:|',
*[f"| `{m['module']}` | {m['cases']} | {m['coverage_seconds']:.3f} | {m['compatibility_313_seconds']:.3f} |" for m in s['module_costs'][:8]], '',
'## Differences and claim limits', '',
f"Compared with earlier PR #92 run {comparison['old_run_id']} at `{comparison['old_head']}`, common case IDs={comparison['common_count']}, earlier-only={comparison['only_old_count']}, current-only={comparison['only_new_count']}. Exact differing case IDs are retained in checks.json.", '',
'Coverage job time increased from 1191 to 1655 seconds; producer wall increased from 1169.746930 to 1632.793267 seconds. The six added test_ci_shadow_pair cases take only 2.513358 seconds under coverage (1.346470 seconds in 3.13), so their direct measured execution does not account for the additional 463.046337 seconds. Existing modules also run slower: H3 execution 318.473 to 458.025 seconds, CI plan 86.691 to 117.768 seconds. This observation identifies where the increase is recorded, not whether host variance, instrumentation, or other interactions caused it. Same-environment paired evidence is required.', '',
'This is fresh validation of a changed Git target and workload. It is not a paired same-target performance experiment, and lower job time cannot be attributed to the diagnostic implementation. Different Python workers also do not isolate coverage instrumentation overhead. Activation, review and any performance claim require their own evidence.', '',
'## Preserved raw evidence', '',
'- run.json, pr.json and timestamped run snapshots: current head and job/Gate observations.',
'- governance-run.json and governance.log: successful current governance run, head and merge-target evidence.',
'- target-commit-api.json: exact tested merge parents and tree.',
'- workflow.log and coverage.log: full checkout, smoke, threshold, Gate and duration evidence.',
'- artifacts.json, original ZIPs, artifacts/, verification.json: raw receipts/coverage/plan/shadow and verified API digests.',
'- summary.json: all job/step times, B/C counts, ordered-union verification and complete module costs.',
'- checks.json: plan/target/producer binding, threshold inventory, smoke outputs and case differences.',
'- SHA256SUMS.json: byte lengths and SHA256 hashes, excluding itself.', '',
]
(root/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
manifest=[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(root.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json']
(root/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('REPORT.md and SHA256SUMS.json written')
