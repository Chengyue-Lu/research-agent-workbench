import hashlib
import json
from pathlib import Path
import re

root=Path(__file__).parent
def read(path):
    return json.loads((root/path).read_text(encoding='utf-8-sig'))
plan=read('artifacts/ci-plan/ci-plan.json')
execution=read('artifacts/coverage-quality-evidence/execution-test-results.json')
cov_receipt=read('artifacts/coverage-quality-evidence/coverage-test-results.json')
b311=read('artifacts/compatibility-3.11-evidence/full-test-results-3.11.json')
b313=read('artifacts/compatibility-3.13-evidence/full-test-results-3.13.json')
coverage=read('artifacts/coverage-quality-evidence/coverage.json')
log=(root/'workflow.log').read_text(encoding='utf-8-sig')
clog=(root/'coverage.log').read_text(encoding='utf-8-sig')
run=read('run.json')
pr=read('pr.json')
target=plan['binding']['target']
assert run['headSha']==plan['binding']['head']=='387d18ebac7817b2a7492a60568b4ef194f557e3'
assert pr['headRefOid']==plan['binding']['head']
assert run['status']=='completed' and run['conclusion']=='success'
assert all(job['conclusion']=='success' for job in run['jobs'])
canonical_digest=hashlib.sha256(json.dumps(execution,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert b311['execution']['source_receipt_sha256']==canonical_digest
assert cov_receipt['execution']['source_receipt_sha256']==canonical_digest
for receipt in (execution,cov_receipt,b311,b313):
    assert receipt['target']==target
    assert receipt['plan_id']==plan['plan_id']
checkout={}
for name in ('coverage-quality (3.11)','compatibility (3.13)','compatibility (3.11)','package-smoke (3.11)','package-smoke (3.13)','repository_smoke','test (3.11)','test (3.13)'):
    rows=[line for line in log.splitlines() if line.startswith(name+'\t') and 'git checkout --progress --force '+target in line]
    assert len(rows)==1,(name,rows)
    checkout[name]=rows[0]
last_global=list(re.finditer(r'global line=([\d.]+)% threshold=90.00%',clog))[-1]
final_clog=clog[last_global.start():]
critical=[]
for line in final_clog.splitlines():
    match=re.search(r'critical (\S+) line=([\d.]+)%/95.00% branch=([\d.]+)%/90.00%',line)
    if match:
        path,line_pc,branch_pc=match.groups()
        critical.append({'path':path,'line_percent_rounded':float(line_pc),'branch_percent_rounded':float(branch_pc)})
assert critical and all(row['line_percent_rounded']>=95 and row['branch_percent_rounded']>=90 for row in critical)
assert 'coverage-policy: PASS' in final_clog
source=[f for name,f in coverage['files'].items() if name.startswith('src/research_workbench/')]
covered=sum(f['summary']['covered_lines'] for f in source)
statements=sum(f['summary']['num_statements'] for f in source)
old=json.loads(Path(r'D:\lcy\develop\_assessments\rwb-ci-paired-shadow-20260920\pr92\artifacts\coverage-quality-evidence\execution-test-results.json').read_text(encoding='utf-8-sig'))
old_ids=set(old['execution_order']); new_ids=set(execution['execution_order'])
packages={}
for name in ('package-smoke (3.11)','package-smoke (3.13)'):
    row=next(line for line in log.splitlines() if line.startswith(name+'\t') and '"runtime_resources_identical": true' in line)
    payload=json.loads(row[row.index('{'):])
    assert payload['runtime_resources_identical'] and len(payload['installs'])==4
    packages[name]=payload
extra={
    'binding':plan['binding'],'plan_id':plan['plan_id'],'run_id':35497858451,
    'producer_canonical_sha256':canonical_digest,
    'all_ci_jobs_passed':True,
    'receipts_same_target_and_plan':True,
    'coverage_and_behavioral_projection_bound_to_producer':True,
    'job_checkout_evidence':checkout,
    'repository_validation_log':[line for line in log.splitlines() if line.startswith('repository_smoke\t') and 'validated=' in line],
    'package_smoke':packages,
    'source_root_covered_lines':covered,'source_root_statements':statements,'source_root_line_percent':100*covered/statements,
    'coverage_policy_gate':'PASS','critical_inventory_count':len(critical),'critical_rounded_results':critical,
    'impact_summary':{name:coverage['files'][name]['summary'] for name in plan['coverage_modules']},
    'prior_pr92_comparison':{'old_head':'b8b21b72459236508613e751d68aa02fc86967b1','old_run_id':35468682117,'only_old_count':len(old_ids-new_ids),'only_new_count':len(new_ids-old_ids),'common_count':len(old_ids & new_ids),'only_old':sorted(old_ids-new_ids),'only_new':sorted(new_ids-old_ids),'paired_speedup_proof':False},
}
(root/'checks.json').write_text(json.dumps(extra,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in extra.items() if k not in ('critical_rounded_results','job_checkout_evidence','impact_summary','prior_pr92_comparison','package_smoke')},indent=2))
print({k:v for k,v in extra['prior_pr92_comparison'].items() if not isinstance(v,list)})
