import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import zipfile

repo = Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow')
out = Path(__file__).parent / 'document-pair-recheck'
out.mkdir(exist_ok=True)
sys.path.insert(0, str(repo / '.github/scripts'))
import ci_shadow_pair as pair

archive_path = 'work/TEST-PERF-002/A-20260920-003/checks/raw-evidence.zip'
archive = subprocess.check_output(['git', '-C', str(repo), 'show', '387d18e:' + archive_path])
with zipfile.ZipFile(io.BytesIO(archive)) as zipped:
    values = {}
    hashes = {}
    for key, name in (('plan', 'plan.json'), ('proposal', 'proposal-scoped.json'),
                      ('inventory', 'inventory.json'), ('accepted', 'accepted-bundle.json'),
                      ('candidate', 'candidate-bundle.json')):
        raw = zipped.read('paired-report-common/' + name)
        hashes[name] = hashlib.sha256(raw).hexdigest()
        values[key] = json.loads(raw)
report = pair.build_report(Path(r'D:\lcy\develop\_assessments\rwb-ci-paired-shadow-20260920\accepted-doc\snapshot'), **values)
assert report['pair_status'] == 'observed-matching-pair' and not report['blockers']
assert len(report['effective_execution_skips']) == 73
(out / 'report.json').write_bytes(pair.planner.canonical(report))
(out / 'sources.json').write_bytes(pair.planner.canonical({
    'source_commit': '387d18ebac7817b2a7492a60568b4ef194f557e3',
    'source_archive': archive_path,
    'source_archive_sha256': hashlib.sha256(archive).hexdigest(),
    'input_sha256': hashes,
    'fresh_execution': False,
    'scope': 'Re-evaluate original native evidence with the repaired offline protocol; preserve the original execution target.'
}))
print(json.dumps({'pair_status': report['pair_status'], 'target': report['binding']['target'],
                  'exclusions': len(report['effective_execution_skips']), 'new_execution': False}))
