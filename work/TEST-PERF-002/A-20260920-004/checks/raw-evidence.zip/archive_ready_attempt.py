import dataclasses
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

repo = Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow')
scratch = Path(__file__).parent
attempt = repo / 'work/TEST-PERF-002/A-20260920-004'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
base = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'origin/develop'], text=True).strip()
assert not (attempt / 'INDEX.yaml').exists(), 'A sealed attempt must not be rewritten'
results = (scratch / 'attempt-results.md').read_text(encoding='utf-8')
checks = attempt / 'checks'
checks.mkdir(parents=True, exist_ok=True)
metrics = json.loads((scratch / 'coverage-final.json').read_bytes())['files']
assert len(metrics) == 2
assert all(row['summary']['missing_lines'] == row['summary']['missing_branches'] == 0 for row in metrics.values())

members = []
excluded_directories = {'.git', '__pycache__', 'snapshot', 'tmp', '.venv', 'venv'}
for path in scratch.rglob('*'):
    relative = path.relative_to(scratch)
    if not path.is_file() or excluded_directories.intersection(relative.parts):
        continue
    if path.name in {'pr-body.md', 'issue-progress.md', 'attempt-results.md'}:
        continue
    members.append((path, relative.as_posix()))
inventory = []
with zipfile.ZipFile(checks / 'raw-evidence.zip', 'w', compression=zipfile.ZIP_DEFLATED) as zipped:
    for path, name in sorted(members):
        raw = path.read_bytes()
        zipped.writestr(name, raw)
        inventory.append({'path': name, 'bytes': len(raw), 'sha256': sha(raw)})
with zipfile.ZipFile(checks / 'raw-evidence.zip') as zipped:
    assert zipped.testzip() is None
    assert all(sha(zipped.read(row['path'])) == row['sha256'] for row in inventory)

for name, source in (
    ('protocol-review.md', 'review/final-protocol-review.md'),
    ('protocol-recheck.md', 'review/recheck.md'),
    ('fingerprint-debt.md', 'review/fingerprint-debt.md'),
    ('document-pair-recheck.json', 'document-pair-recheck/report.json'),
    ('real-pair-audit.md', 'review/real-pair-audit.md'),
    ('coverage-pair-handoff.md', 'coverage-pilot/HANDOFF.md'),
    ('coverage-pair-summary.json', 'coverage-pilot/provider-positive/short-temp-pair/summary.json'),
    ('hosted-baseline.md', 'hosted92/REPORT.md'),
):
    shutil.copyfile(scratch / source, checks / name)
summary = {
    'implementation': head, 'base': base, 'execution_authority': False,
    'validation': {'related_python311_passed': 52, 'related_seconds': 40.761,
                   'final_python311_passed': 11, 'final_seconds': 10.660,
                   'python313_passed': 11, 'python313_seconds': 8.412,
                   'modules': {name: row['summary'] for name, row in metrics.items()},
                   'exclusions_added': 0, 'independent_review_findings_closed': 3},
    'raw_archive_sha256': sha((checks / 'raw-evidence.zip').read_bytes()),
    'raw_members': inventory,
    'limitations': ['Offline provenance is not authentication',
                    'Historical narrow impact plans are not current-base performance evidence',
                    'Human cross-owner acceptance and dependency integration are separate from agent audits',
                    'No production exclusion activation or merge'],
}
dump(checks / 'validation.json', summary)
sys.path.insert(0, str(repo / 'src'))
from research_workbench.observability.trace import AgentTraceRecorder, validate_attempt_trace
recorder = AgentTraceRecorder(
    attempt, task_id='TEST-PERF-002', task_revision=42, attempt_id=attempt.name,
    task_snapshot={'task_id': 'TEST-PERF-002', 'revision': 42,
                   'request': 'Continue PR92 to an explicit ready-for-merge boundary',
                   'scope': 'CI-only paired protocol fixes, real coverage and smoke observations, readiness evidence',
                   'delegation': True, 'required_skills': []},
    accountable_owner='Chengyue-Lu', actor_id='main-agent', runtime_identity='Codex desktop', provider='OpenAI',
    read_allowlist=['AGENTS.md', '.github/**', 'tests/**', 'docs/workstreams/chengyue-lu/TEST-PERF-002/**',
                    'work/TEST-PERF-002/**', 'scoped historical CI consumer source and hosted PR92 artifacts'],
    write_scope=['.github/scripts/ci_shadow_pair.py', '.github/scripts/ci_consumer_shadow.py',
                 'tests/test_ci_shadow_pair.py', 'tests/test_ci_consumer_shadow.py',
                 'docs/workstreams/chengyue-lu/TEST-PERF-002/**', 'work/TEST-PERF-002/A-20260920-004/**'],
    tool_allowlist=['git', 'gh', 'python', 'shell', 'collaboration', 'goal'], baseline=base)
recorder.record_capture_gap('messages', 'Visible work is retained in task log, original reports and raw experiment evidence; the complete initial tool and inter-agent stream was not captured.')
recorder.record_capture_gap('external-actions', 'Final exact-head checks, push and PR/Issue updates occur after the archive is sealed and remain externally recorded.')
recorder.record_tool_call(operation_id='ci-readiness-evidence', tool_name='shell', status='succeeded',
    arguments={'operation': 'retain protocol fixes, real failed and positive coverage/smoke observations and inherited anchor debt'},
    result=summary, result_entered_context=True)
recorder.seal('safe-paused')
validated = validate_attempt_trace(repo, attempt)
dump(checks / 'trace-validation.json', {'blocked': validated.blocked,
     'risks': [dataclasses.asdict(risk) for risk in validated.risks]})
assert not validated.blocked
(attempt / '.gitattributes').write_text('* -text whitespace=cr-at-eol\n', encoding='utf-8')
(attempt / 'RESULTS.md').write_text(results.replace('IMPLEMENTATION_SHA', head).replace('BASE_SHA', base), encoding='utf-8')
files = [{'path': path.relative_to(attempt).as_posix(), 'sha256': sha(path.read_bytes())}
         for path in sorted(attempt.rglob('*')) if path.is_file()]
dump(checks / 'evidence-manifest.json', {'files': files})
print(json.dumps({'implementation': head, 'raw_members': len(inventory), 'archive_files': len(files),
                  'trace_blocked': validated.blocked}))
