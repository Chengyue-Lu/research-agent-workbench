按用户要求，已建立持续目标：将本 PR 推进到明确 ready-for-merge 点，并持续修复和更新证据。

本 PR 的闭合范围是 **2B 离线提案及真实配对观察协议**。接下来补齐真实 exact-Git impact coverage 对照、当前 HEAD hosted Gate/成本采集与独立协议审计；现有 selector/witness/worker/aggregate 和所有质量门槛保持。2C 的独立排除 authority、至少三次 hosted 配对及生产激活仍单独审查，不混入本 PR。

Ready 条件：#91 依赖接受后 rebase/revalidate；当前 HEAD 全部必需 CI 通过；材料性发现与 review conversation 闭合；具备规定的 cross-owner 审查结论；原始证据及 hash 可追溯。达到后可转 Ready，合并仍由用户决定。

当前 `387d18e` 的 plan、documentation、package、repository、governance 已通过，长测试继续运行。#91 已全绿，现已补齐 cross-owner review 请求。上述状态只针对当前读取，不将旧 HEAD CI 视为新 HEAD 证明。
