from pathlib import Path
import subprocess

out = Path(__file__).parent
repo = Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow')
head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
url = 'https://github.com/Chengyue-Lu/research-agent-workbench/blob/' + head + '/'
body = f'''## 治理元数据

- **PR 类型**: feature
- **任务 ID**: TEST-PERF-002
- **风险等级**: R2
- **责任人**: @Chengyue-Lu
- **工作流目录**: docs/workstreams/chengyue-lu/TEST-PERF-002

## Scope and non-goals

只比较测试集合无法证明减选保留了失败、coverage 和 fixture 生命周期。本 PR 实现 Issue #87 的 **2B 离线 consumer 提案与配对执行观察协议**：对照完整 canonical inventory 和原生结果，区分 B 排除、实际执行排除、移入 C−B 的案例，并分别检查两侧 coverage/smoke。所有报告保持 `execution_authority=false`；生产 worker/aggregate 不消费这些提案。

**依赖 Draft #91 的 2A**，起点 `09c6cb1c82680233c369014e0831874b6702d3b7`。按仓库拓扑规则仍指向 develop；依赖接受前 diff 包含其两个提交。2B 初始实现 `435dfb6`、配对扩展 `9239c2f`、本轮完整性修复 `35b5b28`；当前 HEAD `{head}`。#91 接受后需 rebase/revalidate。

当前 PR 的 Ready 条件见 [review boundary]({url}docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_SHADOW_READINESS.md)：精确当前 HEAD 的必需 CI、阻断意见闭合、依赖集成和规定的 cross-owner review。2C 独立排除 authority、三次 hosted 配对与生产减测激活另行审查。

## 契约与权威影响

- **共享契约**: yes
- **权威、权限或数据边界**: yes

R2 诊断协议；global90、critical95/90、changed100/100、正反证据、ordered B→C−B、固定 aggregate 与 integration fresh baseline 保持。未改变生产 selector、witness、worker、coverage policy 或业务实现。

配对结果绑定 exact plan/target、runner/checker来源、environment、driver、原生 receipt 和 coverage。相同 driver 下只允许唯一 `--role` 值变化；其他 argv 差异保持 inconclusive。smoke 绑定各自 run/receipt 与原 artifact hash。任何未解释 skip、失败、缺失、顺序或 fixture/checkpoint 异常均不能成为成功观察。

## TASKS transition

none；沿用 Audit ID TEST-PERF-002。

## Verification evidence

- 相关 3.11 回归 **52 PASS / 40.761s**；最终专项 3.11 **11 PASS / 10.660s**、3.13 **11 PASS / 8.412s**；文档 **10 PASS**。consumer comparator **205/205 statements、84/84 branches**；paired comparator **123/123、40/40**；零新增 exclusions。
- 独立审计发现的三项 P2 已闭合：未解释的 aggregate skip、同 SHA 下额外 argv、跨成员复制 smoke。独立复核四个 focused 方法和六个反例全部通过。
- 完整 workstream 文档对照：同 driver/target/environment，两次 fresh process **325 PASS / 323.008s → 252 PASS / 59.492s**。73 个 PlannerTests 受 19-pin 与 workstream scope 限制。仅一次本地观察，81.58% 不代表远端收益；原始证据通过修复后的协议复验，未重签名成新执行。
- 真实历史 provider 正对照：base `348d625`，target `51eb115`，两侧各 **B81/C34/C−B0，81 PASS、impact PASS、repository186/0/0、四种 package install probes PASS**。同 driver/env，原 raw coverage 未转换，smoke 独立运行并绑定。各约98.7s，**零减选，不宣称缩时**。这些 provider subjects 不在 critical inventory，此案例不宣称新的95/90或全仓coverage。
- 真实负对照：81个行为测试全过，但修改guard的line65/branch64→65未覆盖，原impact Gate正确失败。另一次正对照的长TEMP打包失败原样保留；相同target在两侧一致的短TEMP下完整重跑通过。49件旧失败材料hash不变；两个实验target具有thin Git bundle。
- 独立实测材料抽查：52件当前文件、49件保留文件hash及原生B/C、coverage、driver/env、smoke关联全部通过。
- 上一远端 HEAD `387d18e` 在run `35497858451` 全部Gate成功：tested merge `dc0bc58e...`，coverage **27m35s**，3.13 **14m43s / 1424 PASS**。这是修复前基线，**新 HEAD CI 以新运行结果为准**。

协议：[CONSUMER_SHADOW.md]({url}docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_SHADOW.md)。证据：[初始故障对照]({url}work/TEST-PERF-002/A-20260920-002/RESULTS.md)、[完整文档配对]({url}work/TEST-PERF-002/A-20260920-003/RESULTS.md)、[本轮修复与coverage/smoke]({url}work/TEST-PERF-002/A-20260920-004/RESULTS.md)。Trace 无 BLOCK，保留真实 capture-gap warning。

## Authority basis

用户授权持续更新本 PR 至明确 Ready 点，并同步 Issue #87；仅负责 CI，业务分支与主 develop 不在写入范围。Cross-owner review 已向 @let778750-cpu 请求，依赖 #91 也已请求审查。没有合并授权或自行合并。

## Adversarial evidence

保留真实 README/Markdown 相关故障、planner executable mutant、Git source/pin/membership/mode drift、foreign gitlink、空delta、工作区重写、重叠consumer、旧plan/target/Python、别名/重复ID、缺C、输出覆盖输入等反例。真实 subprocess 证明 coverage 全部覆盖仍可能因C−B fixture重启而行为失败；该失败继续阻断。Threshold与negative acceptance原检查器继续生效。

## Residual risk and follow-up

当前 accepted base `171d465` 继承了 production fingerprint-anchor 扩测问题：PR86/89 的 diagnostic pin-only edit 移动整份policy文件的历史anchor，但没有改变旧digest；新非leaf inventory导致失配，原reviewed leaf边界停用。已有当前/历史精确计划与Git record audit；不能盲目刷新fingerprint或将历史窄计划当当前收益。需要另行审查的anchor修复，当前PR仅如实披露。

另有 `domain-model.json` 尚未分类的FULL/repository fallback。输入/环境闭包与外部执行来源仍需独立证明；离线hash关联不等于认证。完整2C激活与跨提交证据复用不在本PR。保持Draft直到上述Ready条件成立。

Refs #87; depends on #91.
'''
(out / 'pr-body.md').write_text(body, encoding='utf-8')
issue = f'''持续目标已建立：更新 [PR #92](https://github.com/Chengyue-Lu/research-agent-workbench/pull/92) 至明确 ready-for-merge 点。当前 HEAD `{head}`；本轮实现 `35b5b28`。

**已完成的2B工作**：修复独立审计发现的三项误判（未解释skip、同driver下额外argv、跨成员复制smoke），并明确[Ready边界]({url}docs/workstreams/chengyue-lu/TEST-PERF-002/CONSUMER_SHADOW_READINESS.md)。相关回归52PASS，最终专项3.11/3.13各11PASS，两个模块line/branch100%，零exclusions；独立协议与实测材料复核均通过。

补齐真实impact/smoke配对：历史accepted base348d625、target51eb115，两侧各B81/C34/C−B0、81PASS、impactPASS、repository186/0/0和四种package installsPASS。各约98.7秒，零减选，无缩时声明。原始coverage未转换，smoke分别绑定各自run/receipt/artifact。保留了“81个行为测试全过但changed guard coverage失败”的负对照，以及长TEMP打包失败；同target统一短TEMP重跑通过，49件旧证据未改。此前325→252文档配对也通过新协议复验，仍仅一次本地观察。

**新增明确根因**：PR86/89只更新 `ci_impact_policy` 的diagnostic consumer pins，却移动了production planner选取的整文件Git anchor。保留的旧fingerprint与新anchor inventory不匹配，导致5个既有reviewed leaf边界停用；当前局部控制因此扩到B1412/C1386。精确11/13个inventory变更及语义diff已保存。不能直接刷新digest，否则会把新增opaque消费者当成已reviewed；应单独验证authority anchor与逐consumer drift。该修复属于既有生产选择权威的恢复，与2C新增排除激活分开，不混入本诊断PR。

上一远端head387d18e已经全绿，coverage27m35s、3.13 14m43s/1424PASS；新head等待自己的CI。#91依赖及规定的cross-owner review仍待接受，已请求 reviewer。下一步继续处理新CI/review，依赖接受后rebase/revalidate；达到明确Ready点才转Ready，合并留给用户。

完整证据：[A-20260920-004]({url}work/TEST-PERF-002/A-20260920-004/RESULTS.md)。
'''
(out / 'issue-progress.md').write_text(issue, encoding='utf-8')
print(head)
