import hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
HOME=Path(__file__).resolve().parent
OUT=HOME/'provider-positive';OUT.mkdir()
ROOT=OUT/'snapshot';BASE='348d6257ddd28637c9d06abe177fc685ac4368b6'
subprocess.run(['git','clone','--shared','--no-checkout',str(HOME/'snapshot'),str(ROOT)],check=True)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
git('checkout','-q','--detach',BASE)
git('config','user.name','Chengyue-Lu');git('config','user.email','local-ci-experiment@invalid.example')
path='src/research_workbench/adapters/models/openai.py';raw=(ROOT/path).read_bytes()
old=b'self.timeout_seconds = timeout_seconds';new=b'self.timeout_seconds = +timeout_seconds'
assert raw.count(old)==1
line=raw[:raw.index(old)].count(b'\n')+1
coverage=json.loads((HOME/'provider-pair/accepted-coverage.json').read_bytes())
file=next(value for name,value in coverage['files'].items() if name.replace('\\','/')==path)
assert line in file['executed_lines'] and line not in file['missing_lines']
sys.path[:0]=[str(ROOT/'.github/scripts'),str(ROOT),str(ROOT/'src'),str(ROOT/'tests')]
import ci_dependencies
modified=raw.replace(old,new)
assert ci_dependencies.function_body_only(raw,modified)
(ROOT/path).write_bytes(modified);git('add','--',path);git('commit','-q','-m','Isolated coverage positive control: preserve float timeout assignment')
target=git('rev-parse','HEAD')
import plan_ci
plan=plan_ci.make_plan(ROOT,base=BASE,head=target,target=target,repository='Chengyue-Lu/research-agent-workbench',body='- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no')
plan_ci.verify_plan(ROOT,plan)
assert plan['coverage_scope']=='impact' and plan['package_smoke'] and plan['repository_smoke']
(OUT/'historical-provider').mkdir();(OUT/'historical-provider/plan.json').write_bytes(plan_ci.canonical(plan))
(OUT/'change.diff').write_text(git('diff',BASE,target)+'\n',encoding='utf-8')
summary={'execution_authority':False,'base':BASE,'target':target,'plan_id':plan['plan_id'],'changed_line':line,'previous_raw_coverage_line_executed':True,'strict_function_body_only':True,'reason':'Unary plus preserves the annotated float timeout value; no provider calls, imports, bindings or resource inputs changed','failed_control_retained':str(HOME/'provider-pair')}
(OUT/'preparation.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ('setup_pair.py','provider_driver.py','run_provider_role.py'):
    text=(HOME/name).read_text(encoding='utf-8').replace('09361362c7d4d8fdf4599f066965ee092c05b939',target)
    (OUT/name).write_text(text,encoding='utf-8')
print(json.dumps(summary,indent=2))
