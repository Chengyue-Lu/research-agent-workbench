import json,subprocess,sys
from pathlib import Path
out=Path(r'D:\lcy\develop\_assessments\rwb-ci-ready-20260920\coverage-pilot');repo=out/'snapshot'
sys.path.insert(0,str(repo/'.github/scripts'))
import plan_ci
commits=['171d4654f88e926f239cdf25bc8168109b81f391','51dc3ab477f21f18ac3829bf553b5b779d49a4fe','348d6257ddd28637c9d06abe177fc685ac4368b6','75fbf97c001c7e399135c97e603124cc7a2b06b3','ab98caf25125e6567d8bb2c8afff02105b54c940','3a27f9a052dcb79bd29e56138f9e219385dd1f5f']
rows=[]
for commit in commits:
    policy=json.loads(subprocess.check_output(['git','show',f'{commit}:tests/ci_impact_policy.yaml'],cwd=repo))
    leaves={p for g in policy['groups'].values() for p in g['coverage']}
    computed=plan_ci.consumer_fingerprint(repo,commit,leaves)
    rows.append({'anchor':commit,'declared':policy['consumer_fingerprint'],'computed':computed,'match':computed==policy['consumer_fingerprint']})
(out/'fingerprint-anchor-audit.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows,indent=2))
