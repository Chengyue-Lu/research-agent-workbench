# Coverage pilot preparation and retained controls

Owner: Chengyue-Lu. Profile: CI experiment auditor. Required Skills: none.
All observations are diagnostic: `execution_authority=false`.
No source worktree, business branch, policy, thresholds, tests or original archive were modified.

## Current baseline diagnostic

Current audited baseline `387d18ebac7817b2a7492a60568b4ef194f557e3` could not yield the requested bounded execution under its existing policy. Two semantically local source controls produced impact plans with B=1412/C=1386. The planner retained opaque consumers because the newest reviewed closure fingerprint anchor was unavailable. `fingerprint-anchor-audit.json` records the exact declared/computed values: policy revisions PR86 and PR89 still declared the PR85 fingerprint, but their Git inventory no longer matched. Policy was not refreshed to manufacture a bounded plan.

The initial `_digest` expression split also exceeded the accepted `function_body_only` boundary because it introduced a binding/call-shape change. That distinct fallback is retained in the root `plan.json`, `summary.json`, and `change.diff`.

## Immutable historical positive preparation

PR85 base `348d6257ddd28637c9d06abe177fc685ac4368b6` has a matching accepted closure anchor. All source experiments use exact isolated commits on that baseline; none establishes readiness on the current baseline.

- `historical-claim/`: target `144c9e9060059f03873b6a0ea26d6d5c194cb8a8`, B=15/C=15, impact on the critical Claim module, no smoke required. Preparation/discovery only; tests were not executed.
- `historical-provider/`: target `09361362c7d4d8fdf4599f066965ee092c05b939`, plan `ba72b403769293830600ece8f6f09183572f8804cdabc77f493221be44c610e8`, B=81/C=34, three provider wire coverage modules, package and repository smoke required.
- `provider-positive/`: target `51eb115119d3ea7b9639fae86ba94e0f5f0be8ea`, plan `f8091e8ca27f552f3c30a9c99bf36a74bf614344999c816098294856a9885736`, same B/C and smoke requirements. Its straight-line timeout assignment uses unary plus, preserving the annotated float value. The original raw coverage showed this line executed and the unchanged dependency analyzer accepted the function-body boundary.

The provider coverage modules are not critical inventory members. These runs test the real changed-line/branch 100/100 requirement and the existing three positive plus three negative provider evidence mappings; they do not establish critical 95/90 evidence for the separate Claim scenario or repository-wide coverage.

## Native execution contract

The common driver collects B and C freshly in each process, then calls the unmodified `tests/run_unittest_suite.py` `coverage-execution` entry point. The native `OrderedCoverageExecution` runs the original B hierarchy before C minus B. Here C is a subset of B, so each process executes 81 unique cases and projects the original 34-case coverage receipt. Both roles retain identical B/C, source subjects, evidence and smoke requirements.

The exact runner, planner, impact checker and coverage-policy checker bytes match both the historical target and the current worktree; see `checker-compatibility.json`. Setup generates runtime resources only inside each verified isolated snapshot using its original build backend. The Python 3.11.16 venv remains read-only. Dependencies, runtime manifest/source pin, native runner, config, Git configuration and safe process environment are frozen per run. No test or policy is rewritten, no mock is introduced.

Native command families (full argv and exit/wall times are in each `*-steps.json`):

```text
python -m coverage run --rcfile=<frozen config> <common driver> --role accepted|candidate
python -m coverage json --rcfile=<frozen config> -o <raw coverage JSON>
python <target>/.github/scripts/ci_checks.py coverage --plan <plan> --coverage <raw JSON> --results <native C projection>
python -m research_workbench validate examples registry --root .
python <target>/.github/scripts/portable_package_smoke.py --python <Python 3.11 interpreter> --output <report>
```

Only the driver role value differs between the execution invocations. Coverage data files, raw JSON and native receipts are retained separately; paths inside raw coverage are not normalized in place. Smoke bindings retain run identity, exact receipt digest, raw artifact digest and conclusion.

## Retained failure controls

1. `provider-pair/` changes timeout guard `<= 0` to `<= 0.0`. All 81 tests passed, native runner wall 18.551923 s, but the real impact Gate rejected uncovered changed closure line 65 and the 64→65 branch. No candidate or smoke was run after this failure. This is an actual fail-closed coverage control, not a passing pair.
2. `provider-positive/provider-pair/` passes all 81 behavioral cases (18.465900 s), impact Gate and repository validation 186/0/0. Its package smoke failed while copying a runtime resource in a deeply nested build directory. The expected absolute path length, using the native temporary-name format, is 260 characters. The original random directory name was removed by native cleanup, so the historical absolute path is inferred, not observed. Candidate was not started. This remains a failed required smoke / experiment setup result.
3. The authorized repair uses the same positive source target and new `provider-positive/short-temp-pair/` outputs, with dedicated short TEMP/TMP `D:/lcy/develop/_tmp/ci92-20260920`. It reruns each entire role in a fresh process. Read-only directory observations retain actual build path and length. Results belong in the final handoff after completion.

## Diagnostic proposal boundary and replay

`frozen-existing-proposal.json` is the unchanged audited 73-PlannerTests/19-pin proposal. Its older docs baseline differs and both executable changes are outside the Markdown pilot. The actual shadow comparator returns zero behavioral/effective exclusions and retains all B/C. Each first accepted observation has an `accepted-shadow.json` and `observation-summary.json` with actual fallback and individual pin decisions.

`provider-pair/failed-scenario.bundle` and `provider-positive/provider-pair/positive-scenario.bundle` are verified thin Git bundles, each requiring the immutable PR85 base `348d6257ddd28637c9d06abe177fc685ac4368b6`. They preserve the two executed scenario commit/tree/blob objects. Original diffs and complete producing scripts are retained. `artifact-sha256.json` freezes the first two observations; new short-TEMP evidence receives a separate manifest.

One local pair, even if successful, is neither a hosted speed result nor production activation. This source control proposes no reduction and cannot prove savings. Production CI authority and the full Python matrix remain unchanged.
