import argparse,hashlib,importlib.util,json,os,platform,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=ROOT/'snapshot'
BASE='387d18ebac7817b2a7492a60568b4ef194f557e3'
parser=argparse.ArgumentParser();parser.add_argument('variant',choices=('claim-integer-boundary','provider-timeout-control','provider-zero-literal'));parser.add_argument('--base',default=BASE);parser.add_argument('--output-name');args=parser.parse_args()
BASE=args.base
OUT=ROOT/(args.output_name or args.variant);OUT.mkdir()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,text=True,encoding='utf-8').strip()
assert not git('status','--short')
git('checkout','-q','--detach',BASE)
if args.variant=='claim-integer-boundary':
    path='src/research_workbench/artifacts/claim_trace.py'
    old=b'or int(revision) < 1:';new=b'or int(revision) <= 0:'
else:
    path='src/research_workbench/adapters/models/openai.py'
    old=b'if timeout_seconds <= 0:';new=b'if timeout_seconds <= 0.0:' if args.variant=='provider-zero-literal' else b'if timeout_seconds < 0 or timeout_seconds == 0:'
original=(REPO/path).read_bytes();assert original.count(old)==1
changed=original.replace(old,new);(REPO/path).write_bytes(changed)
git('add','--',path);git('commit','-q','-m','Isolated coverage pilot: '+args.variant)
target=git('rev-parse','HEAD')
(OUT/'change.diff').write_text(git('diff',BASE,target,'--',path)+'\n',encoding='utf-8')
sys.path[:0]=[str(REPO/'.github/scripts'),str(REPO),str(REPO/'src'),str(REPO/'tests')]
import plan_ci
plan=plan_ci.make_plan(REPO,base=BASE,head=target,target=target,repository='Chengyue-Lu/research-agent-workbench',body='- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no')
plan_ci.verify_plan(REPO,plan);(OUT/'plan.json').write_bytes(plan_ci.canonical(plan))
spec=importlib.util.spec_from_file_location('native_runner',REPO/'tests/run_unittest_suite.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
native_args=argparse.Namespace(suite=plan['behavioral_scope'],plan=OUT/'plan.json',policy=REPO/'tests/coverage_policy.yaml')
b,c=runner._execution_suites(native_args,plan);bi,ci=runner._inventory(b),runner._inventory(c)
inventory={'version':1,'plan_id':plan['plan_id'],'target':target,'source':'fresh native discovery only; no execution','scope':'plan-collection','python_version':platform.python_version(),'behavioral_order':list(bi),'coverage_order':list(ci),'runtime_ids':{**bi,**ci}}
(OUT/'inventory.json').write_bytes(plan_ci.canonical(inventory))
summary={'execution_authority':False,'base':BASE,'target':target,'plan_id':plan['plan_id'],'behavioral_scope':plan['behavioral_scope'],'coverage_scope':plan['coverage_scope'],
 'B':len(bi),'C':len(ci),'intersection':len(bi.keys()&ci.keys()),'C_minus_B':len(ci.keys()-bi.keys()),'tests':plan['tests'],'coverage_tests':plan['coverage_tests'],
 'coverage_modules':plan['coverage_modules'],'changed_lines':plan['changed_lines'],'package_smoke':plan['package_smoke'],'repository_smoke':plan['repository_smoke'],
 'reasons':plan['reasons'],'obligation_reasons':plan.get('obligation_reasons'),'reviewed_boundary':plan['selection'].get('reviewed_opaque_boundary'),
 'original_sha256':hashlib.sha256(original).hexdigest(),'changed_sha256':hashlib.sha256(changed).hexdigest(),'tests_executed':False,'git_status':git('status','--short')}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('tests','coverage_tests')},indent=2))
