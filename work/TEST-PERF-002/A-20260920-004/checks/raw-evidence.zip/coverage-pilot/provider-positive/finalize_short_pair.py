import hashlib,json,subprocess,sys
from pathlib import Path
HOME=Path(__file__).resolve().parent;OUT=HOME/'short-temp-pair';REPO=HOME/'snapshot'
LIVE=Path('D:/lcy/develop/_worktrees/RWB/ci-consumer-shadow')
sys.path.insert(0,str(LIVE/'.github/scripts'))
import ci_shadow_pair,plan_ci
def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
plan=read(OUT/'plan.json');proposal=read(HOME.parent/'frozen-existing-proposal.json');inventory=read(OUT/'accepted-inventory.json')
accepted=read(OUT/'accepted-bundle.json');candidate=read(OUT/'candidate-bundle.json')
report=ci_shadow_pair.build_report(REPO,plan,proposal,inventory,accepted,candidate)
(OUT/'paired-report.json').write_bytes(plan_ci.canonical(report))
old=read(HOME.parent/'artifact-sha256.json')
verified={name:sha(HOME.parent/name)==signature for name,signature in old.items()}
assert all(verified.values())
(OUT/'prior-artifacts-unchanged.json').write_bytes(plan_ci.canonical(verified))
summary={'execution_authority':False,'target':plan['binding']['target'],'base':plan['binding']['base'],'plan_id':plan['plan_id'],'B':len(inventory['behavioral_order']),'C':len(inventory['coverage_order']),'C_minus_B':0,'pair_status':report['pair_status'],'blockers':report['blockers'],'execution_skips':report['effective_execution_skips'],'same_environment':accepted['environment']==candidate['environment'],'same_driver':accepted['driver']['sha256']==candidate['driver']['sha256'],'driver_sha256':accepted['driver']['sha256'],'timing':report['timing'],'steps':{role:read(OUT/(role+'-steps.json')) for role in ('accepted','candidate')},'actual_temp_paths':{role:read(OUT/(role+'-actual-temp-paths.json')) for role in ('accepted','candidate')},'native_results':{role:bundle['receipt']['outcomes'] for role,bundle in (('accepted',accepted),('candidate',candidate))},'coverage_results':report['coverage'],'smokes':report['smokes'],'git_status':subprocess.check_output(['git','status','--short'],cwd=REPO,text=True).strip(),'prior_artifacts_preserved':len(verified),'limitations':['one local Python 3.11 pair only','zero exclusions; no savings claim','historical PR85 baseline; current reviewed fingerprint diagnostic unresolved','provider modules are not critical inventory members; no separate Claim95/90 execution','global/repository coverage not proved','no production activation; no hosted pairs']}
(OUT/'summary.json').write_bytes(plan_ci.canonical(summary))
manifest={path.name:sha(path) for path in sorted(OUT.iterdir()) if path.is_file() and path.name!='artifact-sha256.json'}
(OUT/'artifact-sha256.json').write_bytes(plan_ci.canonical(manifest))
print(json.dumps({key:summary[key] for key in ('pair_status','blockers','target','B','C','same_environment','same_driver','timing','prior_artifacts_preserved','git_status')},indent=2))
