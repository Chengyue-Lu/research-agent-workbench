import hashlib,json
from pathlib import Path
HOME=Path(__file__).resolve().parent
OUT=HOME/'short-temp-pair';OUT.mkdir()
TEMP=Path('D:/lcy/develop/_tmp/ci92-20260920');TEMP.mkdir(parents=True,exist_ok=True)
assert TEMP.resolve()==Path('D:/lcy/develop/_tmp/ci92-20260920').resolve()
driver=(HOME/'provider_driver.py').read_text(encoding='utf-8').replace("OUT=Path(__file__).resolve().parent/'provider-pair'","OUT=Path(__file__).resolve().parent")
(OUT/'provider_driver.py').write_text(driver,encoding='utf-8')
run=(HOME/'run_provider_role.py').read_text(encoding='utf-8').replace("OUT=HOME/'provider-pair';ROOT=HOME/'snapshot';role=sys.argv[1]","OUT=HOME;ROOT=HOME.parent/'snapshot';role=sys.argv[1]")
run=run.replace("TEMP=str(OUT/'tmp'),TMP=str(OUT/'tmp')","TEMP='D:/lcy/develop/_tmp/ci92-20260920',TMP='D:/lcy/develop/_tmp/ci92-20260920'")
run=run.replace("result=subprocess.run([str(a) for a in args],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)","""process=subprocess.Popen([str(a) for a in args],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
        temp_observations={}
        while process.poll() is None:
            if name=='package_smoke':
                for folder in Path(env['TEMP']).glob('rwb-portable-install-*'):
                    probe=folder/'source/build/lib/research_workbench/_runtime_data/assets/registry/protocol-profiles/prisma-systematic-review-reporting-1.0.0.yaml'
                    previous=temp_observations.get(str(probe),{})
                    temp_observations[str(probe)]={'actual_temp_directory':str(folder),'build_target_path':str(probe),'path_length':len(str(probe)),'observed_file_exists':previous.get('observed_file_exists',False) or probe.is_file()}
            time.sleep(0.1)
        result=process
        if temp_observations:
            (OUT/(role+'-actual-temp-paths.json')).write_bytes(canonical(list(temp_observations.values())))""")
(OUT/'run_provider_role.py').write_text(run,encoding='utf-8')
for name in ('plan.json','coverage.ini','compatibility.json'):(OUT/name).write_bytes((HOME/'provider-pair'/name).read_bytes())
suffix='/rwb-portable-install-'+'x'*8+'/source/build/lib/research_workbench/_runtime_data/assets/registry/protocol-profiles/prisma-systematic-review-reporting-1.0.0.yaml'
diagnosis={'execution_authority':False,'original_failed_temp_root':str(HOME/'provider-pair/tmp'),'original_expected_build_target_length':len(str(HOME/'provider-pair/tmp')+suffix),'original_actual_random_temp_basename_retained':False,'original_attribution':'probable Windows path length setup; original temporary directory removed by native smoke cleanup','new_temp_root':str(TEMP),'new_expected_build_target_length':len(str(TEMP)+suffix),'target':'51eb115119d3ea7b9639fae86ba94e0f5f0be8ea','same_target_and_production_bytes':True}
(OUT/'setup-diagnosis.json').write_text(json.dumps(diagnosis,indent=2)+'\n')
print(json.dumps(diagnosis,indent=2))
