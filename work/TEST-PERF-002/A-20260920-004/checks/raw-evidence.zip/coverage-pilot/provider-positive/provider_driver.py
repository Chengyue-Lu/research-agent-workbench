"""One native ordered coverage driver, two fresh roles, zero proposed exclusions."""
import argparse,hashlib,importlib.metadata,importlib.util,json,os,platform,subprocess,sys,time
from pathlib import Path
STARTED=time.perf_counter()
ROOT=Path.cwd().resolve()
OUT=Path(__file__).resolve().parent/'provider-pair'
TARGET='51eb115119d3ea7b9639fae86ba94e0f5f0be8ea'
def canonical(value):return (json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()
def sha(data):return hashlib.sha256(data).hexdigest()
def write(name,value): (OUT/name).write_bytes(canonical(value))
p=argparse.ArgumentParser();p.add_argument('--role',choices=('accepted','candidate'),required=True);role=p.parse_args().role
assert ROOT==(OUT.parent/'snapshot').resolve()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==TARGET
assert not subprocess.check_output(['git','status','--short'],text=True).strip()
spec=importlib.util.spec_from_file_location('native_runner',ROOT/'tests/run_unittest_suite.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
plan=runner._verified_plan(OUT/'plan.json')
args=argparse.Namespace(suite='coverage-execution',plan=OUT/'plan.json',policy=ROOT/'tests/coverage_policy.yaml')
b,c=runner._execution_suites(args,plan);bi,ci=runner._inventory(b),runner._inventory(c)
assert len(bi)==81 and len(ci)==34 and set(ci)<=set(bi)
inventory={'version':1,'plan_id':plan['plan_id'],'target':TARGET,'source':'fresh preexecution native plan collection, '+role,'scope':'plan-collection','python_version':platform.python_version(),'behavioral_order':list(bi),'coverage_order':list(ci),'runtime_ids':{**bi,**ci}}
write(role+'-inventory.json',inventory)
deps=sorted((dist.metadata['Name'],dist.version) for dist in importlib.metadata.distributions())
context={'executable':sys.executable,'cwd':str(ROOT),'environment_allowlist':{key:os.environ.get(key) for key in ('PYTHONPATH','PYTHONHASHSEED','PYTHONUTF8','PYTHONDONTWRITEBYTECODE','LANG','LC_ALL','TZ','TEMP','TMP','COVERAGE_FILE')},'path_sha256':sha(os.environ.get('PATH','').encode()),'git_config_sha256':sha(subprocess.check_output(['git','config','--null','--list','--show-origin'])),'runtime_manifest_sha256':sha((ROOT/'src/research_workbench/_runtime_data/manifest.json').read_bytes()),'runtime_pin_source_sha256':sha((ROOT/'src/research_workbench/_runtime_pin.py').read_bytes())}
env={'python_version':platform.python_version(),'platform':platform.platform(),'machine':platform.machine(),'dependencies_sha256':sha(canonical(deps)),'runner_sha256':sha((ROOT/'tests/run_unittest_suite.py').read_bytes()),'coverage_config_sha256':sha((OUT/'coverage.ini').read_bytes()),'invocation_context_sha256':sha(canonical(context))}
write(role+'-environment.json',env);write(role+'-context.json',context);write(role+'-dependencies.json',deps)
driver={'sha256':sha(Path(__file__).read_bytes()),'invocation':[sys.executable,'-m','coverage','run','--rcfile='+str(OUT/'coverage.ini'),str(Path(__file__).resolve()),'--role',role]}
write(role+'-driver.json',driver)
write(role+'-expected.json',{'execution_authority':False,'behavioral_order':list(bi),'coverage_order':list(ci),'execution_order':list(bi),'excluded_ids':[],'coverage_obligations':plan['coverage_obligations'],'reason':'source modification is outside Markdown-only pilot; unchanged B/C'})
print(json.dumps({'role':role,'B':len(bi),'C':len(ci),'C_minus_B':0,'excluded':0}),flush=True)
code=runner.main(['--suite','coverage-execution','--plan',str(OUT/'plan.json'),'--policy',str(ROOT/'tests/coverage_policy.yaml'),'--json-output',str(OUT/(role+'-receipt.json')),'--coverage-results',str(OUT/(role+'-coverage-receipt.json')),'--verbosity','1'])
write(role+'-driver-result.json',{'returncode':code,'driver_wall_seconds':time.perf_counter()-STARTED,'execution_authority':False})
raise SystemExit(code)
