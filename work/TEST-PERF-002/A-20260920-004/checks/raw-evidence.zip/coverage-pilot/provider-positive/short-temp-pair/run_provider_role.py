import hashlib,json,os,shutil,subprocess,sys,time,uuid
from pathlib import Path
HOME=Path(__file__).resolve().parent
OUT=HOME;ROOT=HOME.parent/'snapshot';role=sys.argv[1]
assert role in ('accepted','candidate')
def canonical(v):return (json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
env=dict(os.environ);env.update(PYTHONPATH=os.pathsep.join([str(ROOT/'src'),str(ROOT),str(ROOT/'tests'),str(ROOT/'.github/scripts')]),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',TEMP='D:/lcy/develop/_tmp/ci92-20260920',TMP='D:/lcy/develop/_tmp/ci92-20260920',COVERAGE_FILE=str(OUT/'.coverage-current'))
steps=[]
def run(name,args):
    started=time.perf_counter()
    with (OUT/(role+'-'+name+'.log')).open('wb') as log:
        process=subprocess.Popen([str(a) for a in args],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
        temp_observations={}
        while process.poll() is None:
            if name=='package_smoke':
                for folder in Path(env['TEMP']).glob('rwb-portable-install-*'):
                    probe=folder/'source/build/lib/research_workbench/_runtime_data/assets/registry/protocol-profiles/prisma-systematic-review-reporting-1.0.0.yaml'
                    previous=temp_observations.get(str(probe),{})
                    temp_observations[str(probe)]={'actual_temp_directory':str(folder),'build_target_path':str(probe),'path_length':len(str(probe)),'observed_file_exists':previous.get('observed_file_exists',False) or probe.is_file()}
            time.sleep(0.1)
        result=process
        if temp_observations:
            (OUT/(role+'-actual-temp-paths.json')).write_bytes(canonical(list(temp_observations.values())))
    step={'name':name,'command':[str(a) for a in args],'returncode':result.returncode,'wall_seconds':time.perf_counter()-started,'log_sha256':sha((OUT/(role+'-'+name+'.log')).read_bytes())};steps.append(step)
    (OUT/(role+'-steps.json')).write_bytes(canonical(steps));print(json.dumps(step),flush=True)
    return result.returncode
code=run('execution',[sys.executable,'-m','coverage','run','--rcfile='+str(OUT/'coverage.ini'),HOME/'provider_driver.py','--role',role])
if (OUT/'.coverage-current').exists():shutil.copyfile(OUT/'.coverage-current',OUT/(role+'.coverage'))
if code:raise SystemExit(code)
if run('coverage-json',[sys.executable,'-m','coverage','json','--rcfile='+str(OUT/'coverage.ini'),'-o',OUT/(role+'-coverage.json')]):raise SystemExit(2)
if run('coverage-check',[sys.executable,ROOT/'.github/scripts/ci_checks.py','coverage','--plan',OUT/'plan.json','--coverage',OUT/(role+'-coverage.json'),'--results',OUT/(role+'-coverage-receipt.json')]):raise SystemExit(3)
plan=json.loads((OUT/'plan.json').read_bytes());receipt=json.loads((OUT/(role+'-receipt.json')).read_bytes());run_id='coverage-provider-'+role+'-'+str(uuid.uuid4());smokes={}
for name,argv,artifact in (
    ('repository_smoke',[sys.executable,'-m','research_workbench','validate','examples','registry','--root','.'],OUT/(role+'-repository_smoke.log')),
    ('package_smoke',[sys.executable,ROOT/'.github/scripts/portable_package_smoke.py','--python',sys.executable,'--output',OUT/(role+'-package-results.json')],OUT/(role+'-package-results.json'))):
    code=run(name,argv)
    if not artifact.exists():artifact=OUT/(role+'-'+name+'.log')
    smokes[name]={'plan_id':plan['plan_id'],'target':plan['binding']['target'],'run_id':run_id,'execution_receipt_sha256':sha(canonical(receipt)),'artifact_sha256':sha(artifact.read_bytes()),'conclusion':'success' if code==0 else 'failure','source':str(artifact)}
    (OUT/(role+'-smokes.json')).write_bytes(canonical(smokes))
    if code:raise SystemExit(4)
coverage=json.loads((OUT/(role+'-coverage.json')).read_bytes())
bundle={'version':1,'role':role,'run_id':run_id,'environment':json.loads((OUT/(role+'-environment.json')).read_bytes()),'driver':json.loads((OUT/(role+'-driver.json')).read_bytes()),'receipt':receipt,'coverage':coverage,'coverage_binding':{'plan_id':plan['plan_id'],'target':plan['binding']['target'],'run_id':run_id,'receipt_sha256':sha(canonical(receipt)),'coverage_sha256':sha(canonical(coverage))},'smokes':smokes}
(OUT/(role+'-bundle.json')).write_bytes(canonical(bundle))
print('COMPLETE '+role,flush=True)
