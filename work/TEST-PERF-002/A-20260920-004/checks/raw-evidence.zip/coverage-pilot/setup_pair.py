import hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT/'snapshot'
LIVE=Path('D:/lcy/develop/_worktrees/RWB/ci-consumer-shadow')
TARGET='09361362c7d4d8fdf4599f066965ee092c05b939'
def sha(data): return hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==TARGET
assert not subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True).strip()
rows=[]
for name in ('tests/run_unittest_suite.py','.github/scripts/plan_ci.py','.github/scripts/ci_checks.py','.github/scripts/check_coverage_policy.py'):
    expected=subprocess.check_output(['git','show',TARGET+':'+name],cwd=ROOT)
    rows.append({'path':name,'target_sha256':sha(expected),'snapshot_sha256':sha((ROOT/name).read_bytes()),'current_sha256':sha((LIVE/name).read_bytes()),'snapshot_matches_target':expected==(ROOT/name).read_bytes(),'current_matches_target':expected==(LIVE/name).read_bytes()})
(OUT/'checker-compatibility.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(row['snapshot_matches_target'] for row in rows)
pair=OUT/'provider-pair';pair.mkdir();(pair/'tmp').mkdir()
sys.path[:0]=[str(ROOT),str(ROOT/'src'),str(ROOT/'.github/scripts')]
import build_backend
assert build_backend.ROOT.resolve()==ROOT.resolve()
print('runtime_manifest_pin',build_backend.generate(ROOT))
import ci_checks,plan_ci
plan=json.loads((OUT/'historical-provider/plan.json').read_bytes())
plan_ci.verify_plan(ROOT,plan)
(pair/'coverage.ini').write_text(ci_checks.coverage_config(plan,ROOT),encoding='utf-8')
(pair/'plan.json').write_bytes((OUT/'historical-provider/plan.json').read_bytes())
(pair/'compatibility.json').write_bytes((OUT/'checker-compatibility.json').read_bytes())
print(json.dumps(rows,indent=2))
