import hashlib,json,shutil,subprocess,sys,uuid
from pathlib import Path
import yaml
HOME=Path(__file__).resolve().parent
LIVE=Path('D:/lcy/develop/_worktrees/RWB/ci-consumer-shadow')
sys.path.insert(0,str(LIVE/'.github/scripts'))
import ci_consumer_shadow as shadow
import plan_ci
source=Path('D:/lcy/develop/_assessments/rwb-ci-paired-shadow-20260920/planner-consumer/proposal.json')
shutil.copyfile(source,HOME/'frozen-existing-proposal.json')
proposal=json.loads(source.read_bytes())
def sha(data):return hashlib.sha256(data).hexdigest()
def dump(path,value):path.write_bytes(plan_ci.canonical(value))
summaries=[]
for label,root in (('timeout-guard-failed',HOME),('timeout-assignment-positive',HOME/'provider-positive')):
    out=root/'provider-pair';repo=root/'snapshot'
    plan=json.loads((out/'plan.json').read_bytes());receipt=json.loads((out/'accepted-receipt.json').read_bytes());coverage=json.loads((out/'accepted-coverage.json').read_bytes());inventory=json.loads((out/'accepted-inventory.json').read_bytes())
    report=shadow.build_report(repo,plan,proposal,inventory,receipt)
    dump(out/'accepted-shadow.json',report)
    smokes=json.loads((out/'accepted-smokes.json').read_bytes()) if (out/'accepted-smokes.json').exists() else {}
    run_id=next(iter(smokes.values()))['run_id'] if smokes else 'coverage-provider-failed-'+str(uuid.uuid4())
    bundle={'version':1,'role':'accepted','run_id':run_id,'environment':json.loads((out/'accepted-environment.json').read_bytes()),'driver':json.loads((out/'accepted-driver.json').read_bytes()),'receipt':receipt,'coverage':coverage,'coverage_binding':{'plan_id':plan['plan_id'],'target':plan['binding']['target'],'run_id':run_id,'receipt_sha256':plan_ci.digest(receipt),'coverage_sha256':plan_ci.digest(coverage)},'smokes':smokes}
    dump(out/'accepted-bundle.json',bundle)
    policy=yaml.safe_load((repo/'tests/coverage_policy.yaml').read_bytes())
    files={key.replace('\\','/'):value for key,value in coverage['files'].items()}
    rows={row['id']:row['outcome'] for row in receipt['tests']}
    record={'scenario':label,'execution_authority':False,'target':plan['binding']['target'],'base':plan['binding']['base'],'plan_id':plan['plan_id'],'B':len(inventory['behavioral_order']),'C':len(inventory['coverage_order']),'C_minus_B':len(set(inventory['coverage_order'])-set(inventory['behavioral_order'])),'runner_wall_seconds':receipt['wall_seconds'],'outcomes':receipt['outcomes'],'raw_coverage_sha256':sha((out/'accepted-coverage.json').read_bytes()),'receipt_file_sha256':sha((out/'accepted-receipt.json').read_bytes()),'coverage_modules':{key:{'summary':files[key]['summary'],'changed_or_affected_lines':plan['coverage_lines'].get(key,[]),'missing_affected_lines':sorted(set(plan['coverage_lines'].get(key,[]))&set(files[key]['missing_lines'])),'missing_affected_branches':[edge for edge in files[key]['missing_branches'] if edge[0] in plan['coverage_lines'].get(key,[])],'is_critical':key in policy['critical_modules']} for key in plan['coverage_modules']},'acceptance_evidence':{kind:{test:rows.get(test,'missing') for test in tests} for kind,tests in plan['impact_evidence'].items()},'proposal_fallback':report['candidate']['fallback'],'consumer_decisions':report['candidate']['consumers'],'behavioral_skips':report['behavioral_skips'],'effective_execution_skips':report['effective_execution_skips'],'candidate_run':'not-started after failed required Gate','smokes':smokes,'steps':json.loads((out/'accepted-steps.json').read_bytes()),'git_status':subprocess.check_output(['git','status','--short'],cwd=repo,text=True).strip()}
    dump(out/'observation-summary.json',record);summaries.append(record)
dump(HOME/'observations.json',summaries)
manifest={}
for root in (HOME/'provider-pair',HOME/'provider-positive/provider-pair'):
    for path in sorted(root.iterdir()):
        if path.is_file():manifest[path.relative_to(HOME).as_posix()]=sha(path.read_bytes())
dump(HOME/'artifact-sha256.json',manifest)
print(json.dumps([{k:r[k] for k in ('scenario','target','runner_wall_seconds','B','C','behavioral_skips','proposal_fallback','git_status')} for r in summaries],indent=2))
