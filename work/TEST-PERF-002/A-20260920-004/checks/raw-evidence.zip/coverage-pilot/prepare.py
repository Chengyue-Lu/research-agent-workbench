"""Freeze one existing-policy impact pilot without running its tests."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

OUT=Path(__file__).resolve().parent
SOURCE=Path(r'D:\lcy\develop\_worktrees\RWB\ci-consumer-shadow')
REPO=OUT/'snapshot'
BASE='387d18ebac7817b2a7492a60568b4ef194f557e3'
PATH='src/research_workbench/artifacts/claim_trace.py'
assert not REPO.exists()
OUT.mkdir(parents=True,exist_ok=True)
def git(*args,cwd=REPO):
    process=subprocess.run(['git',*args],cwd=cwd,text=True,encoding='utf-8',errors='replace',capture_output=True)
    if process.returncode:
        raise RuntimeError((args,process.returncode,process.stdout,process.stderr))
    return process.stdout.strip()
git('-c','core.autocrlf=false','clone','-q','--shared','--no-checkout',str(SOURCE),str(REPO),cwd=OUT)
git('config','core.autocrlf','false')
git('config','user.name','Isolated coverage pilot')
git('config','user.email','pilot@example.invalid')
git('checkout','-q','--detach',BASE)
source=REPO/PATH
original=source.read_bytes()
old=b'def _digest(value: str) -> str:\n    return value.lower().removeprefix("sha256:")\n'
new=b'def _digest(value: str) -> str:\n    normalized = value.lower()\n    return normalized.removeprefix("sha256:")\n'
assert original.count(old)==1
changed=original.replace(old,new)
source.write_bytes(changed)
git('add','--',PATH)
git('commit','-q','-m','Isolated coverage pilot: split Claim digest normalization expression')
target=git('rev-parse','HEAD')
(OUT/'change.diff').write_text(git('diff',BASE,target,'--',PATH)+'\n',encoding='utf-8')
sys.path[:0]=[str(REPO/'.github/scripts'),str(REPO),str(REPO/'src'),str(REPO/'tests')]
import plan_ci
plan=plan_ci.make_plan(REPO,base=BASE,head=target,target=target,repository='Chengyue-Lu/research-agent-workbench',
    body='- **Risk tier**: R2\n- **Shared contract**: no\n- **Authority impact**: no')
plan_ci.verify_plan(REPO,plan)
(OUT/'plan.json').write_bytes(plan_ci.canonical(plan))
spec=importlib.util.spec_from_file_location('native_runner',REPO/'tests/run_unittest_suite.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
args=argparse.Namespace(suite=plan['behavioral_scope'],plan=OUT/'plan.json',policy=REPO/'tests/coverage_policy.yaml')
b,c=runner._execution_suites(args,plan)
bi,ci=runner._inventory(b),runner._inventory(c)
inventory={'version':1,'plan_id':plan['plan_id'],'target':target,'source':'fresh native discovery only; no execution',
           'scope':'plan-collection','python_version':platform.python_version(),'behavioral_order':list(bi),
           'coverage_order':list(ci),'runtime_ids':{**bi,**ci}}
(OUT/'inventory.json').write_bytes(plan_ci.canonical(inventory))
summary={'execution_authority':False,'base':BASE,'target':target,'plan_id':plan['plan_id'],
 'behavioral_scope':plan['behavioral_scope'],'coverage_scope':plan['coverage_scope'],
 'coverage_obligations':plan['coverage_obligations'],'tests':plan['tests'],'coverage_tests':plan['coverage_tests'],
 'coverage_modules':plan['coverage_modules'],'changed_lines':plan['changed_lines'],
 'package_smoke':plan['package_smoke'],'repository_smoke':plan['repository_smoke'],
 'B':len(bi),'C':len(ci),'intersection':len(bi.keys()&ci.keys()),'C_minus_B':len(ci.keys()-bi.keys()),
 'reasons':plan['reasons'],'obligation_reasons':plan.get('obligation_reasons'),
 'original_sha256':hashlib.sha256(original).hexdigest(),'changed_sha256':hashlib.sha256(changed).hexdigest(),
 'runner_sha256':hashlib.sha256((REPO/'tests/run_unittest_suite.py').read_bytes()).hexdigest(),
 'policy_sha256':hashlib.sha256((REPO/'tests/ci_impact_policy.yaml').read_bytes()).hexdigest(),
 'coverage_policy_sha256':hashlib.sha256((REPO/'tests/coverage_policy.yaml').read_bytes()).hexdigest(),
 'git_status':git('status','--short'),'tests_executed':False}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
