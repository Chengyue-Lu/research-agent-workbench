"""Bounded offline protocol counterexamples. Does not run tests or mutate the repo."""
import copy, json, sys
from pathlib import Path
repo = Path(sys.argv[1])
sys.path[:0] = [str(repo), str(repo / ".github/scripts")]
from tests.test_ci_shadow_pair import example
import ci_shadow_pair as pair
observations = []
for case in ("unexplained_fixture_skip", "driver_extra_mode", "same_smoke_replayed"):
    plan, inventory, policy, proposal_report, accepted, candidate = example(False)
    if case == "unexplained_fixture_skip":
        candidate["receipt"]["events"]["skips"] = 1
    elif case == "driver_extra_mode":
        candidate["driver"]["invocation"] += ["--fixtures", "cached-success"]
    else:
        plan["package_smoke"] = True
        accepted["smokes"]["package_smoke"] = {"plan_id": plan["plan_id"], "target": plan["binding"]["target"],
            "conclusion": "success", "source": "accepted-run-A/package.log"}
        candidate["smokes"] = copy.deepcopy(accepted["smokes"])
    result = pair.compare_pair(plan, proposal_report, inventory, policy, accepted, candidate)
    observations.append({"case": case, "status": result["pair_status"], "blockers": result["blockers"]})
print(json.dumps(observations, indent=2))
