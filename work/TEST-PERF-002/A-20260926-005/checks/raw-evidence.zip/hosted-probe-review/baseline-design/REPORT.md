# Baseline design review for the diagnostic-contract paired probe

Profile: CI experiment design reviewer. Required Skills: []. Read-only, bounded source review; no tests, CI or external calls. Original hosted-probe-review/REPORT.md is unchanged. Final source HEAD inspected: 333dafffdbc87694f65e3e38330d42a69560089a.

Source hashes: paired_probe.py 7dd613aee2b4bb7bf3142de84909fa3b7c53f9001cf7d3b88fc6eb7e0e4d35f3; test_ci_plan.py 3fc65ae85709e4f24b7c205321fbb20d6f77ad44de558ad9ccB7d94b5fe5336f; test_ci_domain_audit.py 3fbf1bb6f1bfa28c5902d6fe82ee0ae759a4d5f5ce0b1660d552a2273be390ce; plan_ci.py 9cf11cd330493c8ac4955075dfd88a209521b104ae2796604eb59f3a5132276b.

## Confirmed source-level conflicts in the current baseline design

1. Removing the three groups/surfaces from the baseline's repository policy breaks the three new `test_real_diagnostic_contracts_*` regressions. PlannerTests.setUpClass loads that exact policy from ROOT. `_diagnostic_contracts()` then indexes each `policy['groups'][identity]` unconditionally before constructing its own accepted/unaccepted fixture epochs. Missing baseline groups therefore cause KeyError. These regressions cannot remain unchanged and pass against that altered root policy.
2. Preserving the groups alone is insufficient. The current synthetic change replaces the only `if identity not in seen]` occurrence in the real consumer-shadow source. `_diagnostic_contracts()` reads that ROOT source and asserts the original mutation anchor occurs exactly once. A broad arm that selects test_ci_plan therefore fails the anchor assertion even when its groups are restored. The reduced family arm does not select this module, which explains why reduced-only harness acceptance did not exercise this defect.
3. The new domain-audit self-input test validates the real default domain model. It does not directly index the three policy groups; removing those groups is not, by itself, a demonstrated cause of that test failing. Its model and input bytes must remain intact. Runtime failures require the separate raw-log diagnosis; this source review does not relabel all failures as policy conflicts.

## Recommended minimum replacement: unavailable-anchor vs valid-anchor pair

Preserve the identical final implementation/tests and all three proposed groups/surfaces in both disposable arm roots. Use a synthetic baseline policy whose consumer_fingerprint is a legal but intentionally nonmatching 64-hex value (for example all zeroes); use the correctly recomputed fingerprint in the reduced arm. Existing make_plan/verify_plan then naturally restore ordinary opaque-consumer closure in the baseline and use the explicitly valid synthetic anchor in the reduced arm. Do not modify or resign plan fields to decrease obligations.

This is a controlled missing-review-anchor comparison, not a claim to reproduce the exact historical policy with its groups deleted. It retains the new self-policy regressions. PlannerTests reconstructs its own seed fingerprints and the diagnostic helper constructs its own policy epochs, so the external arm's intentionally absent anchor does not remove those tests' prerequisite group definitions.

Use an equivalent function-body change that preserves all three `_diagnostic_contracts` source anchors. One concrete candidate is inside consumer-shadow build_report: replace the unique `if i not in set(behavioral)]` with `if not i in set(behavioral)]`. Python gives these expressions the same membership meaning; call identities and initialization stay unchanged. Require exact one-occurrence matching and preserve `if identity not in seen]` unchanged. This is a proposed candidate for preflight, not an executed acceptance claim.

Executable preparation sequence:

1. Make two new independent ordinary clones at exact source 333daff. Keep all source/test/model/coverage-policy bytes identical and record their Git trees and source hashes.
2. Retain all three groups and surfaces. Baseline commits only the deliberately unmatchable fingerprint; reduced commits the actual fingerprint computed from its staged tree. Declare both as synthetic, not production-accepted.
3. Apply the same new equivalent predicate change to both arm HEADs. Verify every tracked tree record except the impact-policy file is identical across arms and that the three regression mutation anchors still occur once.
4. Generate fresh plans with the same actual make_plan entry point and BODY. Require no blocked_reasons, then run existing verify_plan/configure on each plan. Require baseline reviewed_contract_anchor empty/reviewed_opaque_boundary empty and reduced the expected valid synthetic anchor/subject. Record actual scopes, subjects, B/C requirements and reasons; do not assume counts or smoke scopes in advance.
5. Before an expensive pair, run only necessary preparation acceptance: the three new real-diagnostic-contract regression methods plus the named domain-model validator in the prepared broad arm, and the changed expression's focused proof. These are proposed new checks of a new experimental target, not a request to rerun already completed official CI. Preserve results and exact identities. If broader policy self-tests still fail, diagnose rather than removing them from the baseline.
6. Execute both complete planned producers and native B/C projections serially on the same hosted runner; alternate order across fresh pairs. Require successful native receipts, exact identity/order checks, retained quality floors and reduced U as a strict subset of baseline U. Report actual raw producer times only after both arms succeed.

Do not silently equate missing-anchor broad selection with the exact old no-group policy. If needed, compute the old no-group plan in a separate planning-only fixture to compare B/C obligations and explain any difference; never run current self-policy tests against an input that violates their declared prerequisites and then count that failed arm as performance evidence.

## Fresh Runtime resources are a prerequisite in each arm

An editable install in the outer checkout does not populate the two cloned roots. Before any reader/test acceptance, invoke that arm's existing build_backend.generate in a fresh process with cwd at the arm root and module origin asserted inside that same root. Pass the arm root explicitly; do not call an outer imported helper whose ROOT still points elsewhere.

Capture the generator command, return code, duration, build_backend/resources source origins and hashes, returned manifest pin, `_runtime_pin.py` bytes/hash, `_runtime_data/manifest.json` hash, and a complete generated resource path/size/hash inventory. Require both arms' generated pin and inventories equal, and source resources unchanged. Generate from each clone's tracked source inputs; do not copy old generated data or re-label an outer install as a clone generation result. This setup is outside the producer timing and should be reported separately.

## Alternative: an explicit force_full expansion

Keeping one valid policy in both roots and using make_plan(..., force_full=True) for the broad arm is a valid monotonic expansion. Existing code adds FULL behavioral, repository coverage and both smoke requirements. It is useful if the question is full-policy cost versus selective cost, but is not a pure consumer-boundary comparison: it changes the coverage obligation and may add substantial coverage-suite work. Preserve impact obligations too if generated, and run their real quality checks. If smoke execution remains outside the measured experiment, label it unexecuted and do not call the result a complete CI gate proof.

Do not hand-edit coverage_scope, remove repository obligations, or alter a signed force_full plan to make the cost comparison narrower. Report force_full results separately from the missing-anchor pair and from historical old-policy runs.

## Acceptance limits

The recommendation is a design, not a successful new execution. The failed three historical pairs remain failures with their original logs and identities. Fixing Runtime generation alone will not close the two source-level self-test conflicts above. No claim of hosted time savings, complete compatibility, production acceptance, cross-commit reuse or independent exclusion authority follows until the new, accurately labelled pair succeeds.

## Coordinator decision after source review

The coordinator accepted the missing-anchor vs valid-anchor design and retained all groups/surfaces, with that exact interpretation rather than historical old-policy equivalence. The coordinator also assigned a separate bounded repair of the new test_ci_plan fixture's hardcoded source-literal coupling. Consequently the proposed alternate predicate above is NOT the selected experiment mutation: the original union condition probe (`if identity not in seen]` to `if not identity in seen]`) remains unchanged.

This is the stronger development outcome: repair the self-test's accidental coupling so an equivalent small function change can pass the complete suite, instead of selecting a different probe that evades the discovered coupling. Keep the original failing evidence. After the fixture repair, bind both arms to the same new exact source/test commit, fresh-generate Runtime data in each clone and compare hashes, then perform the targeted three diagnostic-contract methods before starting another long hosted pair. Final patched source and its actual targeted results were not yet available in this read-only design review and are not claimed verified here.
