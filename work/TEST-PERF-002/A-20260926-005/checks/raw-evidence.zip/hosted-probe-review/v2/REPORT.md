# V2 paired-harness independent light verification

Profile: experiment verifier. Required Skills: []. Write scope: this v2 assessment directory only. The real production worktree and remote state were not modified. Existing historical reviews and failed pair records remain unchanged.

Result: **PASS for preparation, runtime generation, import origins, plans/configuration, collection and bundles at fixed source 333dafffdbc87694f65e3e38330d42a69560089a.** No producer or test method was executed. This source still predates the independently assigned fixture-coupling repair; this result does not certify that future source HEAD or a full baseline execution.

## Bound identities

- Reviewed/exercised harness SHA-256: d967afc0e9733afa7f9540c0de6427170f37e584c160129228f32dc1dfb6eef3.
- Local light driver verify_light.py SHA-256: fda1aec4070689d344e6761c172facecc841c3b8fb02c020b14b83b5dc10a347.
- light-333daff/summary.json SHA-256: 9ab57407974c463f38008768eb226af68b38078e18d4b22bd7e203ec2575d900.
- Interpreter: the existing Python3.11 assessment venv, recorded verbatim in each command JSON. This is local acceptance, not hosted runner evidence.

The driver calls the actual harness prepare() and execute() implementations. It delegates every imports/runtime/plan/configure command to the real harness command runner, but deliberately intercepts the first producer command before execution. `STOPPED-BEFORE-PRODUCER.json` records its unexecuted argv; no producer.log exists. It then invokes the actual native runner's inventory collection functions without running the collected suite.

## Synthetic inputs and preparation

Both independent ordinary clones retain all three diagnostic groups/surfaces. A direct JSON comparison after removing consumer_fingerprint proves that their policies are otherwise identical. Baseline uses exactly 64 zeroes; reduced uses a nonzero recomputed fingerprint. No signed plan fields were edited to lower obligations.

Both clones contain exactly the intended equivalent union-condition change and share identical complete tracked tree records outside the policy file (SHA-256 d5e8faad9b9d898fd86e60d68b5411a981db054937791fbef320dcd45127e8b0). Each base parent is the fixed source commit; each head parent is its synthetic base. Git bundle verify succeeds for both incremental bundles, and their advertised HEAD matches the actual prepared HEAD. The bundles retain the fixed source prerequisite rather than claiming standalone repository closure.

| Arm | Synthetic base | Synthetic head/target | Plan ID |
| --- | --- | --- | --- |
| baseline, missing anchor | badd4c3060b4e378e61f9da46b0ee7074552034d | 57c23c36d44c834d524dafc0fb75978dea6ded68 | 4617b778db48f22978eab017fb603c0d10097d32a3b363cd2ba4e86c5b405556 |
| reduced, matching anchor | be7db4d5cc4dce16d56faedaf130bfb9eb2db755 | 91f20dcdc0e45d5a920aaf51f9c3ef48de53b25e | 7a9d2638a7609b854a9f4b3605f5eca3f6053005cc1bb24fb28558070acabfde |

## Fresh Runtime resources and isolation

The harness requires each generated target to be untracked, absent, non-symlink and contained in its own clone before calling build_backend.generate. Thus the existing build helper's recursive deletion branch cannot remove a pre-existing Runtime directory in this preparation. The helper's __file__ and ROOT are asserted to belong to the current clone before generation. It reads that clone's tracked resources and writes fresh _runtime_data and _runtime_pin.py; no outer generated outputs were copied.

Both runtime generation commands returned zero, in 0.421075s and 0.411140s respectively. Complete runtime identity JSON bytes match, including generated file paths/hashes and manifest pin. Identity SHA-256: b3a91c2c88ac9c6f0b83b3fc45bf672c271713ef5fcd0b84c67fa3974c5f14ec. Both tracked worktrees remained clean after generation/configuration/collection.

Fresh import records confirm plan_ci and research_workbench load from the corresponding clone. yaml and coverage resolve to the same caller-provided venv in both arms. The harness strips inherited GITHUB event variables for these synthetic plans and records outer hosted provenance separately when used by its main entry point. Runtime setup has its own command timing and is excluded from producer time.

## Actual plans and collected inventories

Both plans/configurations passed their real native verification. Neither plan has blocked reasons. Baseline has an empty reviewed anchor/boundary; reduced has its own synthetic base as anchor and exactly ci_consumer_shadow.py as reviewed boundary.

| Arm | Behavioral | Coverage | Package/repository smoke required | B collected | C collected | U union collected |
| --- | --- | --- | --- | ---: | ---: | ---: |
| baseline | focused | impact | true / true | 1530 | 1504 | 1530 |
| reduced | focused | impact | false / false | 20 | 20 | 20 |

The reduced U identities form a strict subset of baseline U. These are freshly collected identities, not successful test results. In particular, the broad arm is focused by scope but broad by actual selected inventory; it must not be inaccurately labelled FULL. Smokes were neither executed nor presented as successful.

## Remaining acceptance boundary

No full suite, coverage producer, quality result, behavioral receipt or hosted pair ran in this review. The existing fixed-source test fixture coupling remains a known blocker until the separately assigned repair is validated; collection does not exercise setUpClass or those assertions. Before a new long pair, bind both arms to the same repaired exact source and perform the targeted three diagnostic-contract methods, keeping the original equivalent union probe.

The v2 comparison measures ordinary missing-anchor closure versus matching-anchor contraction. It is not an exact replay of the deleted-group historical policy, not a force_full/repository-coverage comparison, and not production acceptance. A valid performance conclusion still requires both actual producers/quality checks/native projections to pass at the new target, with equal generated inputs and comparable runtime environments. The harness preserves failure logs and writes pair PASS only after those conditions and inventory checks.

No material blocker was found in the reviewed v2 preparation/plan mechanics. All raw command logs, origins, generated inventories, policies, plans, configuration, collection IDs, bundle checks and untouched repositories are retained under light-333daff/ for audit.
