from __future__ import annotations
import argparse, hashlib, importlib.util, json, subprocess, sys, traceback
from pathlib import Path

SOURCE_HEAD = '333dafffdbc87694f65e3e38330d42a69560089a'
SOURCE = Path(r'D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
HARNESS = Path(r'D:/lcy/develop/_assessments/rwb-ci-reduction-20260926/hosted-probe-v2/paired_probe.py')
ROOT = Path(__file__).resolve().parent
OUT = ROOT/'light-333daff'

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value):
    with path.open('x', encoding='utf-8') as stream: json.dump(value, stream, indent=2)
class BeforeProducer(Exception): pass

def main():
    OUT.mkdir()
    workspace = OUT/'repositories'; workspace.mkdir()
    summary = {'status':'FAIL','source':SOURCE_HEAD,'harness_sha256':sha(HARNESS),
               'scope':'prepare/runtime/origins/plans/configure/collection only; no producer or test execution',
               'arms':{}, 'failures':[]}
    save(OUT/'inputs.json', {k:v for k,v in summary.items() if k not in ('arms','failures')})
    try:
        spec=importlib.util.spec_from_file_location('paired_probe_v2_review',HARNESS)
        probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
        prepared={label:probe.prepare(SOURCE,SOURCE_HEAD,workspace,label) for label in ('baseline','reduced')}
        assert prepared['baseline'][1]['tree_without_policy_sha256']==prepared['reduced'][1]['tree_without_policy_sha256']
        policies={label:json.loads((repo/probe.POLICY).read_bytes()) for label,(repo,b) in prepared.items()}
        assert policies['baseline']['consumer_fingerprint']=='0'*64
        assert policies['reduced']['consumer_fingerprint']!='0'*64
        normalized={label:{k:v for k,v in p.items() if k!='consumer_fingerprint'} for label,p in policies.items()}
        assert normalized['baseline']==normalized['reduced']
        original_command=probe.command
        def command(repo,out,name,args):
            if name=='producer':
                save(out/'STOPPED-BEFORE-PRODUCER.json',{'argv_not_executed':args})
                raise BeforeProducer()
            return original_command(repo,out,name,args)
        probe.command=command
        collector=r'''import argparse,json,sys
from pathlib import Path
import tests.run_unittest_suite as runner
root=Path.cwd().resolve(); plan_path=Path(sys.argv[1]); plan=runner._verified_plan(plan_path)
args=argparse.Namespace(plan=plan_path,policy=root/'tests/coverage_policy.yaml')
b,c=runner._execution_suites(args,plan)
bids=runner._inventory(b);cids=runner._inventory(c)
rows={'B':list(bids),'C':list(cids),'U':list(dict.fromkeys([*bids,*cids]))}
assert len(rows['B'])==len(set(rows['B'])) and len(rows['C'])==len(set(rows['C']))
Path(sys.argv[2]).write_text(json.dumps({'counts':{k:len(v) for k,v in rows.items()},'ids':rows,'executed':False}),encoding='utf-8')
'''
        for label,(repo,binding) in prepared.items():
            armout=OUT/label
            try: probe.execute(repo,binding,armout)
            except BeforeProducer: pass
            else: raise AssertionError('producer stop was not reached')
            plan=json.loads((armout/'plan.json').read_bytes())
            original_command(repo,armout,'collect-only',[sys.executable,'-c',collector,str(armout/'plan.json'),str(armout/'inventory.json')])
            inventory=json.loads((armout/'inventory.json').read_bytes())
            bundle=OUT/(label+'.bundle')
            verify=subprocess.run(['git','-C',str(repo),'bundle','verify',str(bundle)],env=probe.environment(repo),capture_output=True,text=True)
            save(armout/'bundle-verify.json',{'returncode':verify.returncode,'stdout':verify.stdout,'stderr':verify.stderr})
            assert verify.returncode==0
            heads=probe.git(repo,'bundle','list-heads',str(bundle)).splitlines()
            assert heads==[binding['head']+' HEAD']
            assert probe.git(repo,'show','-s','--format=%P',binding['base'])==SOURCE_HEAD
            assert probe.git(repo,'show','-s','--format=%P',binding['head'])==binding['base']
            assert not probe.git(repo,'status','--porcelain','--untracked-files=no')
            assert not (armout/'producer.log').exists()
            summary['arms'][label]={'binding':binding,'plan_id':plan['plan_id'],
                'behavioral_scope':plan['behavioral_scope'],'coverage_scope':plan['coverage_scope'],
                'package_smoke':plan['package_smoke'],'repository_smoke':plan['repository_smoke'],
                'reviewed_anchor':plan['selection']['reviewed_contract_anchor'],
                'reviewed_boundary':plan['selection']['reviewed_opaque_boundary'],
                'counts':inventory['counts'],'bundle_sha256':sha(bundle),
                'runtime_identity_sha256':sha(armout/'runtime-identity.json'),
                'source_tree_without_policy_sha256':binding['tree_without_policy_sha256']}
        assert (OUT/'baseline/runtime-identity.json').read_bytes()==(OUT/'reduced/runtime-identity.json').read_bytes()
        bi=json.loads((OUT/'baseline/inventory.json').read_bytes())
        ri=json.loads((OUT/'reduced/inventory.json').read_bytes())
        assert set(ri['ids']['U'])<set(bi['ids']['U'])
        assert ri['counts']=={'B':20,'C':20,'U':20}
        assert summary['harness_sha256']==sha(HARNESS)
        summary['status']='PASS-light-only'
    except Exception as error:
        summary['failures'].append(type(error).__name__+': '+str(error))
        (OUT/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8')
    save(OUT/'summary.json',summary)
    print(json.dumps(summary,indent=2))
    return 0 if summary['status']=='PASS-light-only' else 1
if __name__=='__main__': raise SystemExit(main())
