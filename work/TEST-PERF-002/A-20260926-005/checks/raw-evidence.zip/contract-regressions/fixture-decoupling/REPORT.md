# Diagnostic fixture decoupling

Status: PASS. Owned change: `tests/test_ci_plan.py` only. No production or policy edits, commit, push, or remote CI operations. Existing local config dirt is preserved.

Final source SHA256: `29d4eb756aca073be27d2ec19a975e6c65f722ba48e0aa803e9ddf410dffcbce`.

## Fix and retained controls

The real-source fixture no longer searches for a particular union spelling, percentage expression, or domain count statement. It locates an explicitly named function by AST and inserts a `pass` statement into the original text. It asserts that the semantic representation changed and that the actual `function_body_only` classifier accepts the edit. Existing statements, docstrings, comments, coverage pragmas, imports, and module initialization are retained. The call-boundary counterexample adds an explicit new call through the same helper and asserts the classifier rejects that boundary change.

The three existing parameterized regression methods retain all 27 real Git scenarios: three candidate-only policy attempts, three accepted-base exact proof controls, eighteen import/call/initialization/new-function/proof-drift/missing-anchor counterexamples, and three new direct plus opaque consumer scenarios. Their actual Git bases, source modules, copied proof suites, policy fingerprints, selected B/C, opaque fallbacks and blocking assertions remain in use. The harmless local statement is a fixture input to the planner, not a replacement for behavioral correctness tests. Genuine source faults remain the responsibility of the complete consumer proof suites and the separately recorded paired experiment.

The new `test_diagnostic_fixture_accepts_equivalent_negated_membership_source` pins the historical `not identity in seen` function as an explicit static AST fixture, substituted for the same named function in the real module. It does not search today's implementation for a comprehension, `NotIn`, or `Not(In)` pattern. It checks the pinned pure function on an overlap/order example, then performs real Git fixture construction and the accepted-base B/C proof selection. This is a historical compatibility fixture; it does not assert that the current production implementation must use that algorithm form. Default fixtures retain the current real source byte text except the deliberately inserted statement.

## Verification identity

- `final-python-311/` and `final-python-313/`: four related methods PASS, including the three original methods and their 27 scenarios. Source SHA `0622e9b60fee043994ac29be36ec10dcfabbe57c358355b683b02581e91132c1`; wall 29.371s / 29.308s.
- The subsequent root-reviewed adjustment changed only the new regression to the explicit fixed historical function. As requested, unchanged methods were not rerun.
- `historical-python-311/` and `historical-python-313/`: the changed new regression PASS on final SHA `29d4eb75...`; wall 2.574s / 2.579s.
- Scoped `git diff --check -- tests/test_ci_plan.py`: PASS.
- Root reported independent final-source review PASS for `29d4eb75`.

Raw stdout, stderr, argv, cwd, exit status, timings and hashes are retained per stage. Earlier `python-311/` and `python-313/` results belong to the first helper revision and are preserved without relabeling. This is local fixture validation; no full-suite or hosted performance claim is made. `owned.diff` is the final scoped patch; `summary.json` binds the final source and each distinct executed stage.

## Handoff

Root owns policy fingerprint refresh, final archive/commit, the two fresh experimental arms, and their hosted verification. This subtask has no outstanding implementation work. No current source expression spelling is used as the fixture acceptance contract; named public helper identity and an existing multiline function remain explicit fixture assumptions.
