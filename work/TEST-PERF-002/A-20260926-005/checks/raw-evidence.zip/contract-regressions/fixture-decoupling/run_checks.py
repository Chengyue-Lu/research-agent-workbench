import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(r'D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
OUT = Path(__file__).parent / ('historical-python-' + sys.argv[1])
OUT.mkdir(exist_ok=False)
python = Path(r'D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917') / ('venv' + sys.argv[1]) / 'Scripts/python.exe'
names = ['tests.test_ci_plan.PlannerTests.' + name for name in (
    'test_diagnostic_fixture_accepts_equivalent_negated_membership_source',
)]
argv = [str(python), '-B', '-m', 'unittest', '-v', *names]
started = time.perf_counter()
result = subprocess.run(argv, cwd=ROOT, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'},
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(OUT / 'stdout.txt').write_bytes(result.stdout)
(OUT / 'stderr.txt').write_bytes(result.stderr)
summary = {'argv': argv, 'cwd': str(ROOT), 'returncode': result.returncode,
           'wall_seconds': time.perf_counter() - started,
           'test_source_sha256': hashlib.sha256((ROOT / 'tests/test_ci_plan.py').read_bytes()).hexdigest()}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))
print(result.stderr.decode('utf-8', errors='replace'))
raise SystemExit(result.returncode)
