# Diagnostic fixture decoupling — independent source review

**Disposition: PASS, no blocking finding in the reviewed diff.** This is a bounded read-only source review, not an execution or timing result and not a human cross-owner approval.

Profile: CI regression reviewer. Required Skills: none. Reviewed `tests/test_ci_plan.py` against `333dafffdbc87694f65e3e38330d42a69560089a`, the existing `ci_dependencies.function_body_only` implementation, the narrowly referenced pure `ci_consumer_shadow.ordered_union` function, and the failed experiment diagnosis. No tests, Git mutations, production edits, or metadata publication were performed.

## Exact source binding

- Prior `tests/test_ci_plan.py` at `333daff`: SHA256 `3fc65ae85709e4f24b7c205321fbb20d6f77ad44de558ad9ccb7d94b5fe5336f`.
- Final reviewed working file: SHA256 **`29d4eb756aca073be27d2ec19a975e6c65f722ba48e0aa803e9ddf410dffcbce`**.
- Earlier intermediate files beginning `f363df48` and `0622e9b6` were replaced during review. The generic helper now uses AST location plus original-source insertion rather than whole-module unparsing. The final regression also uses an explicit historical function fixture rather than inspecting the current implementation for a unique membership-comprehension shape. The disposition applies only to final `29d4eb75`.
- No diff against `333daff` was present in `ci_dependencies.py`, `ci_consumer_shadow.py`, `ci_shadow_pair.py`, or `ci_domain_audit.py`.

## Findings

The former fixture required exact production expression spellings in three different functions. The failed experiment intentionally used one of those equivalent expression changes, so the fixture could fail before examining any planner result. The replacement locates an explicitly named real function by AST, requires that it exist uniquely and span multiple lines, and inserts either a no-op `pass` or a new call at a statement boundary. It retains the existing executable statements, a genuine leading docstring, original source comments, and coverage pragmas. It does not require the old membership, arithmetic, or increment expression to retain a particular spelling.

The ordinary fixture edit changes the AST while keeping the imports, calls, names, attributes, resource strings, definitions, and initialization inspected by `function_body_only` intact. The helper asserts both an actual semantic-AST difference and the expected admission result. The invalid-call fixture adds a real `fixture_new_call()` AST node and asserts that this changes the protected call/name boundary. The function is deliberately not executed in that invalidation test: the subject is the planner's admission/fallback decision over Git source, rather than the runtime result of an intentionally invalid candidate.

All original test methods remain. Static AST inventory reports **87 prior and 88 current test methods**, with zero removals. Only `_diagnostic_contracts` and the existing boundary/proof-drift method changed among prior functions; the base-acceptance method and new-consumer method retain identical ASTs. The added functions are the source-edit helper and one equivalent-membership regression.

The original **27 scenarios remain intact** across all three diagnostic members:

| Scenario per member | Count across three members | Required evidence retained |
| --- | ---: | --- |
| Candidate-only policy declaration | 3 | No reviewed opaque boundary; independent runtime reader remains in both behavioral and coverage selections |
| Accepted-base declaration | 3 | Exact risk/scope/smoke tuple, full declared proof family, coverage subject, accepted anchor, impact evidence, no blocked reasons, and ordinary plan verification |
| Import, call, initialization, new-function, proof-byte drift, missing-anchor invalidation | 18 | Leaf leaves reviewed boundary; independent runtime reader and all family proof tests remain; impact obligation and nonblocked planning remain |
| Added direct and opaque consumers together | 3 | Both new readers and family proofs remain; test-membership evidence invalidation restores the independent reader and records the reason |

The final union regression is meaningful: it preserves the previously problematic `not (identity in seen)` form as a fixed historical function fixture and substitutes that function node into the otherwise real current module. It locates the function by its contract name, without requiring today's body to contain a particular comprehension or membership expression. It executes that historical pure function with an order-sensitive overlapping input and checks the result, then commits the variant into real Git fixture history and verifies the accepted contract still yields its exact behavioral/coverage proof families and reviewed boundary. It neither mocks the consumer result nor substitutes a fake planner. This regression would expose the former literal-marker assumption when constructing its fixture.

This final adjustment resolves an additional fragility identified during coordination: the intermediate AST regression still required exactly one current `NotIn` or negated-`In` comprehension. That could reject a future valid body rewrite before testing the planner. The final version preserves the historical reproducer without scanning the current algorithm shape. The original three scenario methods continue to use the actual current production functions, so the fixed historical function does not replace current consumer behavior or contract coverage.

## Limits and remaining verification

The inserted `pass` is a boundary/admission probe, not evidence of a functional business change or a performance improvement. The additional historical function's observed output is not presented as certification of today's production function; the complete consumer proof suite retains that responsibility. This review does not generalize the contract to call changes or other protected boundary changes; those retain explicit negative cases. The fixture intentionally still depends on the named contract functions and the actual current policy groups, so a genuine removal/rename of those contract surfaces requires an explicit test update rather than silent acceptance.

The previously failed hosted run remains a failed experiment without a valid timing pair. This fixture repair addresses the production-expression coupling described in diagnosis item 3; it does not by itself prove clone runtime generation, policy-arm preparation, native inventory, or a reduced-versus-baseline timing result. Those require the root task's separate implementation checks and fresh experimental identity. The implementation agent is responsible for actual test execution; no execution results were borrowed for this source-review disposition.
