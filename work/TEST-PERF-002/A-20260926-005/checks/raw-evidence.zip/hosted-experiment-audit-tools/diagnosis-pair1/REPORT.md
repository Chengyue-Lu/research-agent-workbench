# Hosted experiment failure diagnosis

The three jobs of run **36251614855**, attempt **1**, experiment head **e91675f95f1c6da05ab478636b8925151972b896**, source **333dafffdbc87694f65e3e38330d42a69560089a**, all failed. This is an experimental harness failure, and **no valid baseline/reduced timing pair exists**.

All three completed artifacts were authenticated against current API SHA256 and compressed size, then checked for ZIP CRC, duplicate/unsafe paths and symlinks before extraction. `artifacts.json`, `jobs.json`, `run.json`, each `official.zip`, `members.json`, the three job logs, and raw JSON/logs retain the original failed identities. No test or workflow was rerun.

| Pair | Baseline native test_count | Native row count | PASS / error / fail rows | Fixture errors / failures | Reduced |
|---|---:|---:|---|---|---|
| 1 | 1418 | 1428 | 951 / 473 / 4 | 596 / 4 | not reached |
| 2 | 1418 | 1428 | 951 / 473 / 4 | 596 / 4 | 20 PASS, zero errors/failures/skips |
| 3 | 1418 | 1428 | 951 / 473 / 4 | 596 / 4 | not reached |

The 1428 rows include fixture-error records; they must not be presented as 1428 attempted successful cases or as the expected full inventory. `failure-classification.json` preserves the distinct counts.

## Confirmed root causes

1. **Generated runtime inputs are absent in the new clones.** Each baseline has 595 problem records mentioning `_runtime_pin` or `_runtime_data`. The workflow installs the outer checkout, but the fresh clone source import correctly comes from the clone. Git does not copy ignored generated inputs. `build_backend.py:30` defines `generate()`, line 83 writes `_runtime_pin.py`, and `build_editable()` calls `generate()`; `.gitignore:13-14` excludes these generated paths. The experiment never invokes generation for its clones. This causes missing schemas/resources across otherwise unrelated business tests. Three of the four failure tracebacks directly show this missing-runtime error; the stale-evidence assertion lacks its expected CLI output and is consistent with that startup failure. The separate phase-C missing `output.json` is retained as an observed downstream symptom, not independently proven to have no additional cause.

2. **Removing current policy contracts breaks tests that inspect current policy.** Three `test_ci_plan.PlannerTests.test_real_diagnostic_contracts_*` cases fail at `tests/test_ci_plan.py:1219`: `group = policy['groups'][identity]`, with `KeyError: 'diagnostic-consumer-shadow-local-function'`. `self.policy` is read from the running candidate tree. The baseline preparation deletes the three contracts in both its synthetic base and its executed candidate, so the new proof fixtures cannot even be constructed.

3. **A second fixture conflict is statically certain once the KeyError is corrected.** `_diagnostic_contracts()` requires the original exact string `if identity not in seen]` to occur once in current consumer source; the experiment replaces that same marker. Its `self.assertEqual(1, source.count(before))` will then see zero. This assertion was not reached in the failed run because cause 2 occurred first. It is a predicted next failure from the exact current source, not a claimed observed execution failure.

## Minimum repair proposal

- Generate runtime resources in each newly prepared clone before timed execution, through a fresh process loading that clone's `build_backend.generate()`. Record the resource manifest/pin and the full generated-file hash inventory, and require both arms to agree. Keep generation outside producer timing. Preserve the separate outer dependency installation and both clone import-origin assertions.
- Use a **different equivalent body change** which leaves the test fixtures' source markers intact. For this module, `seen = set(behavioral)` → `seen = set(iter(behavioral))` is a candidate under its list/iterable input contract. Confirm function-body admission and necessary selected proof before scheduling another expensive baseline.
- Prefer identical final candidate policy/source/tests for both arms. Construct the baseline synthetic **base** without the three contracts, but restore the complete candidate policy in its **head**. Keep the reduced synthetic base and head with the contracts. The baseline cannot borrow candidate-only selection authority, while full regression can inspect the actual current policy. This matches the existing new tests' own candidate-only authority scenario. First verify the new plans and inventories, not just their declared `tests` field; the full worker discovers the full suite.
- Do not delete, skip or change the failing tests, and do not import generated inputs from the outer checkout to disguise missing clone preparation. Do not use these failed baseline durations for a performance ratio. A corrected experiment requires a new head/run and fresh output identity.

The above repair has **not** been implemented or executed by this independent reviewer. The initial auditor tools are being held pending the revised harness contract so they do not silently accept a different experiment structure.

## Coordinator decision after diagnosis

The coordinator prepared `hosted-probe-v2` with a narrower intervention: both arms retain all current groups/surfaces, the baseline base uses the syntactically valid but nonmatching fingerprint `0` repeated 64 times, and the reduced base recomputes its correct fingerprint. Its claim is explicitly **ordinary closure with no matching accepted anchor versus matching-anchor contract**, not a replay of historical policy. Both clone resource manifests and full generated-file hashes must match. The original union-condition edit is retained.

The proposed `set(iter(behavioral))` replacement was **not adopted**: it changes a Call/Name, which the function-body boundary intentionally rejects. The earlier proposal was not experimentally verified and should not be treated as an admissible change. Another bounded worker is addressing the new `test_ci_plan` fixtures' coupling to production literal spelling while preserving their 27 scenarios; production consumer code remains unchanged. The earlier failed run and the three original diagnostic findings remain intact. The auditor is being adapted to the explicit v2 comparison contract, pending its final source/run identities.
