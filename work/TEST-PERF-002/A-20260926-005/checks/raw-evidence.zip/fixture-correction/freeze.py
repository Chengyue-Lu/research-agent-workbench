"""Freeze the distinct failed experiment and its bounded fixture/harness repairs."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

R = Path(__file__).resolve().parent.parent
F = R/'fixture-correction'
W = Path('D:/lcy/develop/_worktrees/RWB/ci-attribute-consumer-probe')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
implementation = json.loads((F/'implementation.json').read_bytes())
head = subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'], text=True).strip()
assert head == implementation['head']
assert sha(W/'tests/test_ci_plan.py') == implementation['test_sha256']
tests = json.loads((R/'contract-regressions/fixture-decoupling/summary.json').read_bytes())
assert tests['status'] == 'PASS' and tests['final_sha256'] == implementation['test_sha256']
preflight = F/('preflight-'+head[:7])
proof = json.loads((preflight/'fixture-summary.json').read_bytes())
assert proof['status'] == 'PASS' and proof['source'] == head and not proof['producer_executed']
light = json.loads((preflight/'summary.json').read_bytes())
assert light['status'] == 'PASS-light-only' and light['arms']['reduced']['counts'] == {'B':20,'C':20,'U':20}
A = W/'work/TEST-PERF-002/A-20260926-005'
C = A/'checks'
C.mkdir(parents=True,exist_ok=False)
files = [F/'scope.json',F/'implementation.json',F/'implementation.diff',F/'freeze.py',F/'preflight.py',
         F/'initial-minified-unpublished.diff',F/'policy-before.json']
for relative in ('contract-regressions/fixture-decoupling','contract-regressions/fixture-decoupling-review',
                 'hosted-probe-v2','hosted-probe-review/baseline-design','hosted-probe-review/v2',
                 'fixture-correction/'+preflight.name):
    root = R/relative
    files += [p for p in root.rglob('*') if p.is_file()
              and not any(part in {'repositories','__pycache__','.git'} for part in p.relative_to(root).parts)]
diagnosis = R/'hosted-experiment-audit-tools/diagnosis-pair1'
files += [p for p in diagnosis.iterdir() if p.is_file()]
files += list(diagnosis.glob('fresh-pair-*/official.zip'))
files += list(diagnosis.glob('fresh-pair-*/members.json'))
files = sorted(set(files))
assert sum(p.stat().st_size for p in files) < 40*1024*1024
with zipfile.ZipFile(C/'raw-evidence.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p,p.relative_to(R).as_posix())
(C/'manifest.json').write_text(json.dumps({p.relative_to(R).as_posix():sha(p) for p in files},indent=2)+'\n',encoding='utf-8')
summary = dict(status='PASS-local-repair; hosted-v1-failure-retained', implementation=implementation,
    fixture_checks=tests, new_source_preflight=proof,
    collected_counts={label:v['counts'] for label,v in light['arms'].items()},
    failed_experiment={'run':36251614855,'head':'e91675f95f1c6da05ab478636b8925151972b896',
        'source':'333dafffdbc87694f65e3e38330d42a69560089a','valid_timing_pairs':0},
    review_sha256=sha(R/'contract-regressions/fixture-decoupling-review/REPORT.md'),
    harness_sha256=sha(R/'hosted-probe-v2/paired_probe.py'),
    raw_evidence_sha256=sha(C/'raw-evidence.zip'),
    new_hosted_execution_proved=False, hosted_speedup_proved=False, production_reduction_activated=False)
(C/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
(A/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
(A/'RESULTS.md').write_text(f'''# Diagnostic fixture and paired-experiment correction

Owner Chengyue-Lu; TEST-PERF-002; R2; Skills []. Base `{implementation['base']}`;
implementation `{head}`. This record supplements A004; previous archives remain
unchanged. It does not replace their source, execution or acceptance identities.

Experimental run36251614855 failed on all three pairs. Fresh clones lacked the
ignored Runtime build outputs, and removing the new policy groups prevented three
current-policy fixtures from being constructed. One reduced arm passed20 tests,
but there were zero valid timing pairs. The original API-bound artifacts, logs,
counts and diagnosis remain. A further exact-source-spelling dependency was found
behind the earlier KeyError; it is distinguished from an observed hosted failure.

The permanent fixture now uses AST locations to insert controlled statements while
preserving actual function bodies, comments and coverage pragmas. All27 real Git
authority/dependency scenarios and all87 previous test methods remain. The new
regression substitutes the fixed historical negated-membership function into a
real module and verifies its independent Git planning boundary; it does not require
today's implementation to keep that expression shape. Current business behavior
remains the responsibility of the complete consumer suites. Independent source
review passes on the final test hash. Dual-Python checks retain their original
source identities, including the separately rerun final historical regression.

The corrected experiment keeps all current groups and varies only a legitimate
missing-versus-matching anchor fingerprint. Both clones freshly generate and hash
identical Runtime inputs outside producer timing. The original equivalent union
probe is retained. On the new implementation commit, actual preparation, imports,
runtime generation, plan/configuration and collection pass; each actual probe arm
also passes the three relevant fixture methods and their27 scenarios. Collection
is B/C/U {light['arms']['baseline']['counts']} versus20/20/20; no full producer was
executed in that local preflight. This compares ordinary missing-anchor closure
against a matching-anchor contract, not historical policy replay.

New exact-head official CI and three fresh complete hosted pairs are still required
to establish their own native quality and timing facts. No failed duration or old
receipt is reused as a valid speedup result. Global90, critical95/90, changed100/100,
all negative controls and independent authority bootstrap remain. Policy changes
in this correction are limited to the consumer fingerprint for the changed tests.

[Summary](checks/summary.json), [manifest](checks/manifest.json) and
[raw evidence](checks/raw-evidence.zip) preserve the bounded results and failures.
The unpublished formatting-only intermediate commit was corrected before any
remote push; its original diff and identity remain in this record. Trace begins
at freeze and declares earlier capture gaps. No Ready, merge or production
activation is claimed.
''',encoding='utf-8',newline='\n')
sys.path.insert(0,str(W/'src'))
from research_workbench.observability.trace import AgentTraceRecorder,validate_attempt_trace
t = AgentTraceRecorder(A,task_id='TEST-PERF-002',task_revision=49,attempt_id=A.name,
    task_snapshot={'task_id':'TEST-PERF-002','revision':49,'request':'Continue until actual test reduction',
        'profile':'CI boundary engineer','required_skills':[], 'delegation':True,
        'scope':'diagnostic fixture decoupling and corrected fresh paired experiment',
        'budget':'only failed fixture/harness causes and relevant preflight',
        'stop_condition':'reviewable real execution evidence; actual-base acceptance remains external'},
    accountable_owner='Chengyue-Lu',actor_id='main-agent',runtime_identity='Codex desktop',provider='OpenAI',
    read_allowlist=['AGENTS.md','README.md','PROJECT_MEMORY.md','.github/scripts/**','tests/**',
        'build_backend.py','runtime-resources.json','work/TEST-PERF-002/**'],
    write_scope=['tests/test_ci_plan.py','tests/ci_impact_policy.yaml','work/TEST-PERF-002/A-20260926-005/**'],
    tool_allowlist=['collaboration','shell','git','gh','python'],baseline=implementation['base'])
t.record_capture_gap('messages','Raw diagnosis, reviews and checks retained; prior tool/inter-agent events are not a continuous complete capture.')
t.record_capture_gap('external-actions','Final committed-head checks, publication and new hosted execution occur after this sealed local record.')
t.record_tool_call(operation_id='freeze-fixture-correction',tool_name='python',status='succeeded',
    arguments={'operation':'preserve failed hosted identity and exact local correction'},
    result={'implementation':head,'summary_sha256':sha(C/'summary.json')},result_entered_context=True)
t.seal('safe-paused')
v=validate_attempt_trace(W,A)
(C/'trace-validation.json').write_text(json.dumps({'blocked':v.blocked,'risks':[asdict(x) for x in v.risks]},indent=2)+'\n',encoding='utf-8')
assert not v.blocked
print(json.dumps({'archive':str(A.relative_to(W)),'files':len(files),'zip_bytes':(C/'raw-evidence.zip').stat().st_size,'blocked':v.blocked}))
