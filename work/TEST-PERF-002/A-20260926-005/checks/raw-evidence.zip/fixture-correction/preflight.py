"""Fresh v2 preparation plus the three fixtures that failed on the real probe."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

R = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('--head', required=True)
args = parser.parse_args()
implementation = json.loads((R/'fixture-correction/implementation.json').read_bytes())
assert args.head == implementation['head']
path = R/'hosted-probe-review/v2/verify_light.py'
spec = importlib.util.spec_from_file_location('light_review', path)
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)
review.SOURCE_HEAD = args.head
review.OUT = R/'fixture-correction'/('preflight-'+args.head[:7])
assert review.main() == 0
spec = importlib.util.spec_from_file_location('fresh_probe', review.HARNESS)
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)
names = [
 'test_real_diagnostic_contracts_require_base_acceptance_and_complete_family_proof',
 'test_real_diagnostic_contracts_restore_scope_for_boundary_and_proof_drift',
 'test_real_diagnostic_contracts_keep_new_direct_and_opaque_consumers',
]
def verify(label):
    repo = review.OUT/'repositories'/label
    assert hashlib.sha256((repo/'tests/test_ci_plan.py').read_bytes()).hexdigest() == implementation['test_sha256']
    record = probe.command(repo, review.OUT/label, 'fixture-preflight',
        [sys.executable, '-B', '-m', 'unittest', '-v',
         *['tests.test_ci_plan.PlannerTests.'+name for name in names]])
    assert 'if not identity in seen]' in (repo/probe.SUBJECT).read_text(encoding='utf-8')
    return label, record
with ThreadPoolExecutor(max_workers=2) as pool:
    results = dict(pool.map(verify, ('baseline','reduced')))
summary = dict(status='PASS', source=args.head, fixtures_per_arm=3,
    scenarios_per_arm=27, producer_executed=False, results=results,
    light_summary_sha256=review.sha(review.OUT/'summary.json'))
probe.save(review.OUT/'fixture-summary.json', summary)
print(json.dumps(summary, indent=2))
