# Independent exclusions / component selection review

**REQUEST_CHANGES：1个P2组件选择问题。** Coverage policy精确修复与真实源码短guard通过静态复核；新增policy-path direct map缩减了旧组件选集，需修正后再冻结候选。读取snapshot为c80基线工作区；未读取正在修改的provider源码，也未重复任何测试。三组静态核验及一次最终policy旧工件重放到此停止。

## [P2] policy YAML 的 direct map 抑制旧 ci_tooling fallback

位置：tests/ci_components.json:354新增 `tests/coverage_policy.yaml: [test_coverage_policy]`；tests/test_ci_components.py:156新增测试仅验证guard存在。

直接读取test所调用的classifier `plan`窄段用于验证实际选择关系：.github/scripts/ci_components.py:110–122先计算exact/prefix组件命中，再应用direct map；只有两者都没有命中时才使用nearest fallback。coverage_policy.yaml没有原组件exact/prefix命中，原来由nearest ci_tooling选择 `test_ci_components`、`test_ci_component_execution`、`test_ci_component_smoke`。新direct map使fallback分支不再执行，三个原检查被移除；旧fallback smoke flag也不再建立。新增测试的 `assertIn(guard)` / `assertNotIn('full', report)` 无法发现这项缩减。

最小修复：该policy-path的direct list保留原三个CI控制模块并新增test_coverage_policy；三个源路径仍只增加guard，因为它们保留原adapters/execution组件命中。强化新增测试对policy路径断言原三项仍selected，及原smoke语义是否需保留；既有classifier、full规则均不改。源路径session.py/session_policy.py/host.py的原组件组在当前classifier中先choose再union direct，没有缩减。

四条direct map没有引入FULL。问题来自已有fallback被新direct-hit旁路，不能仅凭JSON结构“只新增四条”声称所有旧选集不变。静态逐路径关系保存在review.json的path_selection_static_proof。

## 已通过的边界

- policy只包含2.3.6→2.3.7、session.py90–93→97–100、增加session_policy.py35–38；与覆盖原实际排除集合对齐，其余14排除行保留。policy解析后与预期精确对象全等，没有更宽路径或自动排除。
- global90 / critical line95 branch90 / impact100/100逐值相同；critical inventory、negative_acceptance、coverage suite modules / exact IDs均不变。
- test_coverage_policy既有21方法与test_ci_components既有15方法的AST函数体、断言全部不变，各只新增1方法。
- 新guard读取真实POLICY，逐个调用公开`Coverage(data_file=None, config_file=False).analysis2(str(ROOT / declaration['path']))`，与已登记行集合比较。它不使用合成coverage() helper，不patch分析器，不执行Provider/Host，不采集全局覆盖。它检查已声明文件位置，未声明新文件/配置变化仍由full双向对账发现。
- 两份docs明确旧ede2055测试PASS / enforcementFAIL、候选重放的新evaluation、双Python局部及latestfull分别绑定，没有把旧工件冒充新head全量/净提速。Provider修复描述只复核文字边界，未核实现正确性。

## 已有测试证据与一次最终evaluation

读取root local-checks原回执：旧policy位置guard1FAIL；3.11/3.13各22PASS，覆盖相关source_hashes与本次snapshot相符；组件16PASS。未重跑这些测试。

组件16PASS summary的source_hashes没有tests/ci_components.json和tests/test_ci_components.py，故其same_inputs_after仅覆盖记录中列出的coverage相关文件，不能据此单独证明两个组件文件的exact bytes。当后续修正P2并验证时，应采这两文件的实际hash；不回写旧回执来补造历史绑定。本次独立静态review记录它们当前hash。

一次获授权checker重放使用最终实际2.3.7 policy和原ede coverage/results：evaluation `coverage-review-final237-old-ede-20261004`，exit0 / coverage-policy PASS。没有suite/collection、receipt修改或新coverage；不是候选全仓证明。参数、旧输入hash及logSHA存review.json；日志为final-237-old-ede.evaluation.log。policy SHA `05a47de90603c30db301232a8828971cbaeb003b7381dd293d3a464260c8f6fc`。

## Snapshot source hashes

| Source | SHA256 |
|---|---|
| tests/coverage_policy.yaml | 05a47de90603c30db301232a8828971cbaeb003b7381dd293d3a464260c8f6fc |
| tests/test_coverage_policy.py | 248ac0eec5ad1e80f6dc62911477213689d565b9401177489ae4bc0ded8a8e93 |
| tests/ci_components.json | c6f22d0ed77717aecadd75edcf34263765f13f2725dad130e8fef509c90d20ab |
| tests/test_ci_components.py | 712a98829c3281afcd000ffe1b03ae9bba3a7cfb0c69e84dd12de7be3e95d3f0 |
| FULL-CI-REPAIR-001/README.md | 5696490aaa48132dfcc1dd4eca9f2ac5944992a786c9f83dffdf97145ab155e6 |
| FULL-CI-REPAIR-001/RISK_LEDGER.md | 1b62dc896a1110b1aec51fd5a507e30797a46da35bc49084a100c0623c4636e0 |

上述六文件在最终重放前后hash相同。本代理没有stage/commit/push/source mutation；此snapshot发现及原evaluation保持，不等待root新补丁或主动再跑。
