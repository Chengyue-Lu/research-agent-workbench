# Corrected exclusions / selection final review

**PASS：原P2已修正，本复核范围无剩余阻断。** 原coverage-review/REPORT.md与review.json的失败snapshot保持不变。本文件绑定修正后的工作区；不审核provider实现，不宣称候选full/coverage通过。

policy YAML现显式命中ci_tooling.paths，四个direct map仍各只添加test_coverage_policy。用同一纯planner、同一Git inventory对accepted c80 policy与修正policy逐路径比较：

| 变更路径 | 旧模块数 | 修正模块数 | 旧selected⊆新selected | flags / Python versions |
|---|---:|---:|---|---|
| tests/coverage_policy.yaml | 3 | 4 | true | 全部相同 |
| adapters/models/session.py | 31 | 32 | true | 全部相同 |
| adapters/models/session_policy.py | 31 | 32 | true | 全部相同 |
| execution/host.py | 15 | 16 | true | 全部相同 |

四路径唯一新增模块均为test_coverage_policy；smoke/install/contracts/docs/python_versions逐值相同。policy YAML由旧unknown/nearest-ci_tooling变成明确ci_tooling命中，原三模块与smoke保留；没有FULL。classifier本身不改。完整old/new plan及hash保存comparison.json；这只是planner求值，没有测试suite/collection/CI。

新增组件guard已对policy路径断言ci_tooling、原三个检查与smoke，另保留guard存在及无FULL断言。root仅重跑修正后的新方法1/1 PASS，原回执component-policy-guard-corrected的两个组件文件SHA与本次snapshot完全相符，补足原16PASS回执未记录这两个文件hash的边界。没有重新运行16方法，本代理没有执行测试。

覆盖policy仍为2.3.7；policy/test_coverage_policy SHA与上一轮静态及最终旧ede重放相同。因此已核的真实源码analysis2、90/95/90/100阈值、critical/negative/coverage选集保留和一次最终2.3.7旧工件PASS继续适用于这些相同bytes。旧工件仍是ede身份，最终候选full/3.13正确性由其独立验证决定。

| Snapshot source | SHA256 |
|---|---|
| tests/coverage_policy.yaml | 05a47de90603c30db301232a8828971cbaeb003b7381dd293d3a464260c8f6fc |
| tests/test_coverage_policy.py | 248ac0eec5ad1e80f6dc62911477213689d565b9401177489ae4bc0ded8a8e93 |
| tests/ci_components.json | 1922926c7816d71d6894c2beff23741128e834c1195d1d3bb45dbf6f58ea53c2 |
| tests/test_ci_components.py | 9569400021c5532e77eb84f152265dfcf623c559b387d0d1e6014492583e51d8 |
| FULL-CI-REPAIR-001/README.md | 5696490aaa48132dfcc1dd4eca9f2ac5944992a786c9f83dffdf97145ab155e6 |
| FULL-CI-REPAIR-001/RISK_LEDGER.md | 1b62dc896a1110b1aec51fd5a507e30797a46da35bc49084a100c0623c4636e0 |

本轮compare脚本第一次把新增paths位置假定为末尾，静态对象顺序断言失败，尚未调用planner；保留compare-first-failure.log后按实际插入位置修正。随后比较通过。这是审查脚本假设错误，不是测试或CI失败。没有修改source、stage、commit、push或refs；已停止。
