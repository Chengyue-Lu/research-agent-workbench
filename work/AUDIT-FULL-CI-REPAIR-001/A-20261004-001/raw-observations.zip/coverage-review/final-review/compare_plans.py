import ast
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
WT=Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004")
BASE="c80ec014925f0cbbbaef5486bce8422a5b4f73fb"
PATHS=["tests/coverage_policy.yaml","src/research_workbench/adapters/models/session.py",
       "src/research_workbench/adapters/models/session_policy.py","src/research_workbench/execution/host.py"]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(["git",*args],cwd=WT)
old_bytes=git("show",BASE+":tests/ci_components.json")
old=json.loads(old_bytes)
new=json.loads((WT/"tests/ci_components.json").read_text(encoding="utf-8"))
expected=json.loads(json.dumps(old))
expected["components"]["ci_tooling"]["paths"].insert(1,"tests/coverage_policy.yaml")
for path in PATHS: expected["direct_tests"][path]=["test_coverage_policy"]
assert new==expected
inventory=set(git("ls-files","-z").decode().split("\0")[:-1])
spec=importlib.util.spec_from_file_location("review_classifier",WT/".github/scripts/ci_components.py")
classifier=importlib.util.module_from_spec(spec)
spec.loader.exec_module(classifier)
rows=[]
for path in PATHS:
    changes=[{"status":"M","path":path}]
    before=classifier.plan(changes,inventory,old)
    after=classifier.plan(changes,inventory,new)
    assert set(before["selected_tests"])<=set(after["selected_tests"])
    assert set(after["selected_tests"])-set(before["selected_tests"])=={"test_coverage_policy"}
    assert all(before[key]==after[key] for key in ["smoke","install","contracts","docs","python_versions"])
    assert "full" not in before and "full" not in after
    if path==PATHS[0]:
        assert after["components"]==["ci_tooling"]
        assert after["unknown_paths"]==[]
    rows.append({"path":path,"old":before,"corrected":after,"old_selected_subset_corrected":True,
                 "added_tests":["test_coverage_policy"],"flags_and_python_versions_unchanged":True})
summary_file=OUT.parents[1]/"local-checks/component-policy-guard-corrected/summary.json"
receipt=json.loads(summary_file.read_text(encoding="utf-8"))
assert receipt["exit_code"]==0 and receipt["same_inputs_after"]
hash_files=["tests/coverage_policy.yaml","tests/test_coverage_policy.py","tests/ci_components.json","tests/test_ci_components.py",
            "docs/workstreams/chengyue-lu/FULL-CI-REPAIR-001/README.md","docs/workstreams/chengyue-lu/FULL-CI-REPAIR-001/RISK_LEDGER.md"]
source_hashes={p:sha(WT/p) for p in hash_files}
assert all(source_hashes[p]==receipt["source_hashes"][p] for p in ["tests/ci_components.json","tests/test_ci_components.py"])
prior=json.loads((OUT.parent/"review.json").read_text(encoding="utf-8"))
assert all(source_hashes[p]==prior["source_hashes"][p] for p in ["tests/coverage_policy.yaml","tests/test_coverage_policy.py"])
tree=ast.parse((WT/"tests/test_ci_components.py").read_text(encoding="utf-8"))
guard=next(f for c in tree.body if isinstance(c,ast.ClassDef) for f in c.body if isinstance(f,ast.FunctionDef)
           and f.name=="test_protocol_and_exclusion_policy_changes_select_position_guard")
guard_source=ast.get_source_segment((WT/"tests/test_ci_components.py").read_text(encoding="utf-8"),guard)
assert all(value in guard_source for value in ["ci_tooling","test_ci_components","test_ci_component_execution","test_ci_component_smoke","smoke"])
record={"status":"PASS","at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"base":BASE,
        "source_hashes":source_hashes,"source_classifier_sha256":sha(WT/".github/scripts/ci_components.py"),
        "base_component_policy_sha256":hashlib.sha256(old_bytes).hexdigest(),
        "only_mapping_delta":"coverage YAML gains explicit ci_tooling path + four guard-only direct additions",
        "planner_only_new_test_executions":0,"comparison":rows,
        "corrected_guard_receipt":{"path":str(summary_file),"sha256":sha(summary_file),"exit_code":0,
                                   "same_inputs_after":True,"component_files_hash_match":True},
        "previous_policy_replay_still_same_policy_sha":True,
        "limits":["No suite or CI rerun; pure planner evaluation and saved one-method PASS receipt only.",
                  "Prior P2 report and prior evaluation preserved.","Provider implementation not read or reviewed.",
                  "Old ede replay PASS does not prove candidate full coverage or compatibility."]}
(OUT/"comparison.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"status":record["status"],"source_hashes":source_hashes,"paths":[{"path":r["path"],
    "old_count":len(r["old"]["selected_tests"]),"corrected_count":len(r["corrected"]["selected_tests"]),
    "old_selected_subset_corrected":True,"flags_unchanged":True} for r in rows]},ensure_ascii=False,indent=2))
