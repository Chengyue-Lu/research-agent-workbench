import ast
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import yaml

OUT=Path(__file__).resolve().parent
WT=Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004")
OLD=Path("D:/lcy/develop/_assessments/rwb-full-ci-accounting-20261004/last-complete")
DIAG=OUT.parent/"coverage-diagnosis"
BASE="c80ec014925f0cbbbaef5486bce8422a5b4f73fb"
FILES=["tests/coverage_policy.yaml","tests/test_coverage_policy.py","tests/ci_components.json",
       "tests/test_ci_components.py","docs/workstreams/chengyue-lu/FULL-CI-REPAIR-001/README.md",
       "docs/workstreams/chengyue-lu/FULL-CI-REPAIR-001/RISK_LEDGER.md"]

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(["git",*args],cwd=WT)
def before(path): return git("show",BASE+":"+path).decode("utf-8")

assert git("rev-parse","HEAD").decode().strip()==BASE
policy=yaml.safe_load((WT/FILES[0]).read_text(encoding="utf-8"))
base_policy=yaml.safe_load(before(FILES[0]))
assert policy["version"]=="2.3.7"
allowed=dict(base_policy)
allowed["version"]="2.3.7"
allowed["justified_exclusions"]=json.loads(json.dumps(base_policy["justified_exclusions"]))
allowed["justified_exclusions"][0]["lines"]=[97,98,99,100]
allowed["justified_exclusions"].insert(1,{"path":"src/research_workbench/adapters/models/session_policy.py",
    "lines":[35,36,37,38],"reason":"Protocol method declaration has no executable implementation body.",
    "owner":"Chengyue-Lu"})
assert policy==allowed
assert policy["thresholds"]=={"impact":{"line":100,"branch":100},"global":{"line":90},"critical":{"line":95,"branch":90}}
component=json.loads((WT/FILES[2]).read_text(encoding="utf-8"))
base_component=json.loads(before(FILES[2]))
paths=["tests/coverage_policy.yaml","src/research_workbench/adapters/models/session.py",
       "src/research_workbench/adapters/models/session_policy.py","src/research_workbench/execution/host.py"]
allowed_component=json.loads(json.dumps(base_component))
for path in paths:
    assert path not in base_component["direct_tests"]
    allowed_component["direct_tests"][path]=["test_coverage_policy"]
assert component==allowed_component
path_rows=[]
for path in paths:
    hits=[(len(key),name) for name,rule in component["components"].items() for key in rule.get("paths",[]) if path==key]
    hits += [(len(prefix.rstrip('/'))+1,name) for name,rule in component["components"].items()
             for prefix in rule.get("prefixes",[]) if path.startswith(prefix.rstrip('/')+'/')]
    if hits:
        longest=max(v[0] for v in hits)
        comps={name for length,name in hits if length==longest}
    else:
        fallbacks=[(len(k.rstrip('/')),v) for k,v in component.get("nearest_components",{}).items() if path.startswith(k.rstrip('/')+'/')]
        comps={max(fallbacks)[1]} if fallbacks else set()
    original={test for name in comps for test in component["components"][name]["tests"]}
    # In the actual classifier, an existing exact/prefix hit is retained;
    # a direct-only hit suppresses fallback, which must be assessed explicitly.
    after_set=(original if hits else set())|{"test_coverage_policy"}
    row={"path":path,"existing_component_hits":sorted(comps) if hits else [],
         "prior_fallback_components":sorted(comps) if not hits else [],
         "retained_previous_component_tests":original <= after_set,
         "removed_previous_component_tests":sorted(original-after_set)}
    path_rows.append(row)

def methods(source):
    tree=ast.parse(source)
    return {(c.name,f.name):ast.dump(f,include_attributes=False) for c in tree.body if isinstance(c,ast.ClassDef)
            for f in c.body if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)) and f.name.startswith("test_")}
test_delta=[]
for path in [FILES[1],FILES[3]]:
    old_methods=methods(before(path)); new_methods=methods((WT/path).read_text(encoding="utf-8"))
    assert old_methods.keys() <= new_methods.keys()
    assert all(new_methods[k]==v for k,v in old_methods.items())
    test_delta.append({"path":path,"old_methods":len(old_methods),"new_methods":len(new_methods),
                       "new_methods_added":[".".join(k) for k in new_methods.keys()-old_methods.keys()],
                       "old_method_bodies_assertions_unchanged":True})
tree=ast.parse((WT/FILES[1]).read_text(encoding="utf-8"))
guard=next(f for c in tree.body if isinstance(c,ast.ClassDef) for f in c.body
           if isinstance(f,ast.FunctionDef) and f.name=="test_checked_in_exclusions_match_static_coverage_analysis")
assert any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="analysis2" for n in ast.walk(guard))
assert "ROOT / declaration[\"path\"]" in ast.get_source_segment((WT/FILES[1]).read_text(encoding="utf-8"),guard)
checks={}
for label in ["exclusion-red","coverage-311","coverage-313","component-policy-311"]:
    folder=OUT.parent/"local-checks"/label
    summary=json.loads((folder/"summary.json").read_text(encoding="utf-8"))
    output=(folder/"output.log").read_text(encoding="utf-8")
    terminal=[line for line in output.splitlines() if line.startswith("Ran ") or line=="OK" or line.startswith("FAILED (")]
    checks[label]={"summary":str(folder/"summary.json"),"summary_sha256":digest(folder/"summary.json"),
                   "terminal":terminal,"exit_code":summary["exit_code"],
                   "same_inputs_after":summary["same_inputs_after"],
                   "source_hashes_match_current":all(digest(WT/p)==h for p,h in summary["source_hashes"].items())
                       if label!="exclusion-red" else None,
                   "component_files_captured":all(p in summary["source_hashes"] for p in [FILES[2],FILES[3]])}

# One authorized final-policy evaluation of old evidence, no suite or collection.
source_hashes={p:digest(WT/p) for p in FILES}
argv=[sys.executable,"-B",str(WT/".github/scripts/check_coverage_policy.py"),
      "--policy",str(WT/FILES[0]),"--coverage",str(DIAG/"coverage-ede.json"),
      "--test-results",str(OLD/"coverage-test-results.json")]
result=subprocess.run(argv,cwd=WT,capture_output=True)
(OUT/"final-237-old-ede.evaluation.log").write_bytes(result.stdout+result.stderr)
assert result.returncode==0
assert source_hashes=={p:digest(WT/p) for p in FILES}
review={"at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"base_head":BASE,
        "source_hashes":source_hashes,"policy_exact_change_only":True,"thresholds_unchanged":True,
        "suite_selection_critical_and_evidence_mapping_unchanged":True,
        "component_policy_only_four_guard_additions":True,"path_selection_static_proof":path_rows,
        "test_delta":test_delta,"guard_uses_real_source_analysis2":True,
        "existing_test_evidence":checks,
        "final_evaluation":{"id":"coverage-review-final237-old-ede-20261004","argv":argv,"exit_code":result.returncode,
                            "log_sha256":digest(OUT/"final-237-old-ede.evaluation.log"),
                            "policy_sha256":source_hashes[FILES[0]],"coverage_head":"ede2bc1d5e3496b4e4c72abb1f39f0a3ce00aedf",
                            "coverage_sha256":digest(DIAG/"coverage-ede.json"),
                            "results_sha256":digest(OLD/"coverage-test-results.json"),"new_test_executions":0}}
(OUT/"review.json").write_text(json.dumps(review,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps(review,ensure_ascii=False,indent=2))
