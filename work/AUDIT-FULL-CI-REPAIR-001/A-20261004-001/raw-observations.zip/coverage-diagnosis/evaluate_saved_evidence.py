import ast
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

import yaml

OUT = Path(__file__).resolve().parent
WT = Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004")
OLD = Path("D:/lcy/develop/_assessments/rwb-full-ci-accounting-20261004/last-complete")
EDE = "ede2bc1d5e3496b4e4c72abb1f39f0a3ce00aedf"
C80 = "c80ec014925f0cbbbaef5486bce8422a5b4f73fb"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=WT)

assert git("rev-parse", "HEAD").decode().strip() == C80
original_bytes = git("show", EDE+":tests/coverage_policy.yaml")
checker_original = git("show", EDE+":.github/scripts/check_coverage_policy.py")
checker = WT/".github/scripts/check_coverage_policy.py"
assert checker_original == checker.read_bytes()
(OUT/"policy-ede-original.yaml").write_bytes(original_bytes)
original = yaml.safe_load(original_bytes)
current = yaml.safe_load((WT/"tests/coverage_policy.yaml").read_text(encoding="utf-8"))
candidate = yaml.safe_load((WT/"tests/coverage_policy.yaml").read_text(encoding="utf-8"))
candidate["justified_exclusions"][0]["lines"] = [97,98,99,100]
candidate["justified_exclusions"].insert(1, {
    "path": "src/research_workbench/adapters/models/session_policy.py",
    "lines": [35,36,37,38],
    "reason": "Protocol method declaration has no executable implementation body.",
    "owner": "Chengyue-Lu",
})
(OUT/"policy-c80-exact-pins-candidate.yaml").write_text(yaml.safe_dump(candidate, allow_unicode=True, sort_keys=False),encoding="utf-8")
z = zipfile.ZipFile(OLD/"coverage-quality-evidence.zip")
coverage_bytes = z.read("coverage.json")
(OUT/"coverage-ede.json").write_bytes(coverage_bytes)
coverage = json.loads(coverage_bytes)
results = json.loads((OLD/"coverage-test-results.json").read_text(encoding="utf-8"))
assert results["target"] == EDE
passed = {v["id"] for v in results["tests"] if v["outcome"] == "passed"}
negative_ids = [(v["surface"], kind, test) for v in current["negative_acceptance"]
                for kind in ["positive_tests", "negative_tests"] for test in v[kind]]
absent = [v for v in negative_ids if v[2] not in passed]
assert not absent
selected_modules=set(current["suites"]["coverage-quality"]["modules"])
selected_exact=set(current["suites"]["coverage-quality"].get("test_ids",[]))
selection_missing=[v[2] for v in negative_ids if v[2].split(".")[0] not in selected_modules and v[2] not in selected_exact]
assert not selection_missing
current_ast_missing = []
for module in sorted({v[2].split(".")[0] for v in negative_ids}):
    file = WT/"tests"/(module+".py")
    tree = ast.parse(file.read_text(encoding="utf-8"))
    methods = {module+"."+c.name+"."+f.name for c in tree.body if isinstance(c,ast.ClassDef)
               for f in c.body if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef))}
    current_ast_missing += [v[2] for v in negative_ids if v[2].split(".")[0]==module and v[2] not in methods]
assert not current_ast_missing
policy_diff = git("diff", EDE,C80,"--","tests/coverage_policy.yaml").decode("utf-8")
(OUT/"policy-ede-to-c80.diff").write_text(policy_diff,encoding="utf-8")
loglines=(OUT/"coverage-job.log").read_text(encoding="utf-8-sig").splitlines()
fail_index=max(i for i,line in enumerate(loglines) if "coverage-policy: FAIL" in line)
start=max(i for i,line in enumerate(loglines[:fail_index]) if "##[group]" in line)
end=next(i for i,line in enumerate(loglines[fail_index:],fail_index) if "##[error]Process completed" in line)
excerpt=[{"line":i+1,"text":loglines[i]} for i in range(start,end+1)
         if any(marker in loglines[i] for marker in ["##[group]", "global line=", "critical ", "coverage-policy:", "- coverage contains", "- policy declares", "CalledProcessError:", "##[error]"])]
(OUT/"enforce-excerpt-focused.json").write_text(json.dumps(excerpt,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
evaluations=[]
for label,file,expected in [("ede-original","policy-ede-original.yaml",1),
                            ("c80-exact-pins-candidate","policy-c80-exact-pins-candidate.yaml",0)]:
    args=[sys.executable,"-B",str(checker),"--policy",str(OUT/file),"--coverage",str(OUT/"coverage-ede.json"),
          "--test-results",str(OLD/"coverage-test-results.json")]
    result=subprocess.run(args,cwd=WT,capture_output=True)
    log=OUT/(label+".evaluation.log")
    log.write_bytes(result.stdout+result.stderr)
    evaluations.append({"evaluation_id":"coverage-replay-20261004-"+label,
                        "at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        "args":args,"exit_code":result.returncode,"expected_exit_code":expected,
                        "policy_sha256":sha(OUT/file),"log":str(log),"log_sha256":sha(log),
                        "coverage_source_head":EDE,"checker_source_head":C80,
                        "new_test_executions":0,"original_receipts_modified":False})
    assert result.returncode==expected
canonical={p:v for p,v in coverage["files"].items() if p.startswith("src/research_workbench/")}
global_line=sum(v["summary"]["covered_lines"] for v in canonical.values())*100/sum(v["summary"]["num_statements"] for v in canonical.values())
critical=[]
for p in current["critical_modules"]:
    s=coverage["files"][p]["summary"]
    critical.append({"path":p,"line":100*s["covered_lines"]/s["num_statements"] if s["num_statements"] else 100,
                     "branch":100*s["covered_branches"]/s["num_branches"] if s["num_branches"] else 100})
assert all(v["line"]>=95 and v["branch"]>=90 for v in critical)
record={"old_run_id":37168512882,"old_job_id":111336470266,"old_head":EDE,"current_head":C80,
        "coverage_version":coverage["meta"]["version"],"global_source_line_percent":global_line,
        "critical_count":len(critical),"critical_thresholds":current["thresholds"],
        "critical_lowest_line":min(critical,key=lambda v:v["line"]),
        "critical_lowest_branch":min(critical,key=lambda v:v["branch"]),
        "negative_acceptance_surfaces":len(current["negative_acceptance"]),
        "positive_negative_id_references":len(negative_ids),"unique_evidence_ids":len({v[2] for v in negative_ids}),
        "missing_native_passed_evidence":absent,"missing_current_ast_evidence":current_ast_missing,
        "missing_current_policy_selection":selection_missing,
        "135_policy_delta":{"old_version":original["version"],"current_version":current["version"],
                             "removed_coverage_module":"test_m5_trace_export",
                             "negative_acceptance_unchanged":original["negative_acceptance"]==current["negative_acceptance"],
                             "critical_modules_unchanged":original["critical_modules"]==current["critical_modules"],
                             "thresholds_unchanged":original["thresholds"]==current["thresholds"],
                             "justified_exclusions_unchanged":original["justified_exclusions"]==current["justified_exclusions"]},
        "actual_failure_lines":[v for v in excerpt if "- coverage contains" in v["text"] or "- policy declares" in v["text"]],
        "evaluations":evaluations,
        "input_sha256":{"checker_c80":sha(checker),"current_policy":sha(WT/"tests/coverage_policy.yaml"),
                        "coverage_ede":sha(OUT/"coverage-ede.json"),"results_ede":sha(OLD/"coverage-test-results.json"),
                        "artifact_zip":sha(OLD/"coverage-quality-evidence.zip"),"job_log":sha(OUT/"coverage-job.log")},
        "limits":["Old ede coverage/data remains old identity; candidate replay is policy evaluation, not new coverage or test suite.",
                  "Current source method existence is static AST evidence; it does not prove current full execution or current coverage.",
                  "No source/test mutation, new native download, collection, suite, refs or rerun.",
                  "One same-run job log API request; original native receipts remain byte unchanged."]}
(OUT/"diagnosis.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({k:v for k,v in record.items() if k not in ["evaluations","input_sha256","actual_failure_lines"]},ensure_ascii=False,indent=2))
print("failures",len(record["actual_failure_lines"]),"evaluations",[(v["evaluation_id"],v["exit_code"]) for v in evaluations])
