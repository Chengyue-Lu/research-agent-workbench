import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
OLD = Path("D:/lcy/develop/_assessments/rwb-full-ci-accounting-20261004/last-complete")
RUN = 37168512882
JOB = 111336470266
HEAD = "ede2bc1d5e3496b4e4c72abb1f39f0a3ce00aedf"
run = json.loads((OLD/"run.json").read_text(encoding="utf-8"))
job = next(j for j in json.loads((OLD/"jobs.json").read_text(encoding="utf-8"))["jobs"] if j["id"] == JOB)
assert run["id"] == RUN and run["head_sha"] == job["head_sha"] == HEAD
assert job["conclusion"] == "failure" and job["name"] == "coverage-quality (3.11)"
endpoint = f"repos/Chengyue-Lu/research-agent-workbench/actions/jobs/{JOB}/logs"
env = {k:v for k,v in os.environ.items() if k.upper() not in ["HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY"]}
result = subprocess.run(["C:/Program Files/GitHub CLI/gh.exe", "api", endpoint], env=env, capture_output=True)
(OUT/"coverage-job.log").write_bytes(result.stdout)
(OUT/"job-log-receipt.json").write_text(json.dumps({
    "run_id": RUN, "job_id": JOB, "head_sha": HEAD, "run_conclusion": run["conclusion"],
    "job_conclusion": job["conclusion"], "endpoint": endpoint, "api_calls": 1,
    "download_attempts": 1, "at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "exit_code": result.returncode, "bytes": len(result.stdout),
    "sha256": hashlib.sha256(result.stdout).hexdigest(),
    "stderr": result.stderr.decode("utf-8", errors="replace"),
    "identity_evidence": str(OLD/"jobs.json"), "digest_authority": "local SHA256; API job log publishes no digest",
}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
if result.returncode:
    raise SystemExit(result.returncode)
lines = result.stdout.decode("utf-8-sig").splitlines()
anchors = [i for i,line in enumerate(lines) if "coverage-policy: FAIL" in line or "##[group]Run python .github/scripts/check_coverage_policy.py" in line]
selected = set()
for i in anchors:
    for n in range(max(0, i-2), min(len(lines), i+100)):
        selected.add(n)
        if n > i and "##[endgroup]" in lines[n]:
            break
excerpt = [{"line": i+1, "text": lines[i]} for i in sorted(selected)]
(OUT/"enforce-excerpt.json").write_text(json.dumps(excerpt,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps(excerpt, ensure_ascii=False, indent=2))
