# Coverage obligations failure diagnosis

**确切原因是 Protocol 占位排除行与 policy 精确行号失配。** 对象为 completed failure CI37168512882 / job111336470266 / head `ede2bc1d5e3496b4e4c72abb1f39f0a3ce00aedf`，不是当前 c80 的新结果。现有两 ZIP 未重复下载；仅补取该 job log 一次，505862 bytes / SHA256 `5f05c769f064b037ce580b98f16ccb2c5ed0cb7b0e23ea4793ff316cd15675d5`。身份来自已核 jobs.json；job log 没有 API digest，SHA 为本地保存值。

Enforce 原日志 3019–3031 行列出全部 12 条错误：

| 类型 | 路径 | 精确行 |
|---|---|---|
| actual excluded 未声明 | src/research_workbench/adapters/models/session.py | 97, 98, 99, 100 |
| actual excluded 未声明 | src/research_workbench/adapters/models/session_policy.py | 35, 36, 37, 38 |
| policy 声明但 actual excluded 中不存在 | src/research_workbench/adapters/models/session.py | 90, 91, 92, 93 |

没有阈值不足、缺失关键模块、缺少 passing negative acceptance 或非 successful test receipt 的失败项。旧工件由 coverage7.16.2 产生，branch_coverage=true；canonical src 全局行覆盖 94.387942%，高于90%。68个 critical 模块分别通过95% line /90% branch；最低 line 为 execution_view.py 95.636364%，最低 branch 为 relationships.py 90%。session.py / session_policy.py 本身不在 critical list，不能把它们的低于95/90数值误报成失败。

读取范围为 checker / policy / 直接测试与精确 Protocol 窄段。当前 c80 与 ede 的两段声明相同：session.py:95–98 的 `SessionEventSink(Protocol).record`，session_policy.py:23–36 的 `ConformanceSessionSummarySink(Protocol).record`，均只有 `...`，没有实现体。actual excluded 的四行分别围绕这两个声明，含空行；policy旧90–93落在 ClientTool 数据字段附近，已经不是排除位置。当前 checker `_actual_exclusions` 取覆盖 JSON 的 excluded_lines；`check_policy` 在151–154行对两个集合做双向差集，按设计 fail closed。该 checker 与 ede 文件 byte 相同。

PR135 不构成本次 ede 失败的原因。ede→c80 的 policy 只有2.3.5→2.3.6及删除 `test_m5_trace_export` 一个 coverage module；critical_modules、thresholds、justified_exclusions、50组 negative_acceptance 均逐值相同。322个唯一正负 evidence ID 都在旧 coverage 投影中 passed，当前 AST 方法仍存在，并由当前 coverage modules / exact test IDs 选中；没有静态证据 ID 漏项。此检查不证明删除21内部记录方法之后的实际当前全局覆盖率，最新全量结果仍需其自身验证。

建议最小修复是精确修改 policy 两条排除 pin：session.py 改为97–100；增加 session_policy.py35–38，沿用“Protocol declaration no executable body”理由和 Chengyue-Lu owner。其余14个已声明实际排除行保留。源码、checker、阈值90/95/90、critical / selection / positive-negative tests 不变。可审 patch 为 `exact-pins-proposal.patch`；它只写 assessment，本代理未应用到仓库。候选保持读取时c80的2.3.6作语义验证，root可按仓库版本约定单独递增policy版本。

不建议在这次修复自动生成更宽的 Protocol/AST 排除集合。长期可增加静态声明位置核对以早发现漂移；它应验证具名 Protocol 的纯 `...` 声明，而非自动扩大 exclusions。自动排除所有 Protocol/不可达代码会改变质量定义，超出本修复。

获 root 授权后，仅运行现有 checker 对**同一旧 coverage/results**的两份 policy 重放，没有 suite/collection/Host/provider 执行：

| 新 evaluation 身份 | checker | policy | 旧输入身份 | 结果 |
|---|---|---|---|---|
| coverage-replay-20261004-ede-original | c80（byte同ede） | 原ede2.3.5 | ede coverage/results | exit1，完全相同12项 |
| coverage-replay-20261004-c80-exact-pins-candidate | c80 | c80精确pin候选 | 同ede coverage/results | exit0，coverage-policy PASS |

参数、时间、policy/checker/input/log SHA 保存 diagnosis.json；原 receipt 未改、未重签。两条命令等价于给定311 Python `-B .github/scripts/check_coverage_policy.py --policy <assessment-policy> --coverage coverage-ede.json --test-results <旧原生coverage-test-results.json>`。重放 PASS 只确认候选policy可接受旧完整工件，不是新head全仓测试/coverage PASS。

有意义的局部回归建议：运行 `python -m unittest tests.test_coverage_policy`，保留 existing `test_declared_exclusions_exactly_match_coverage_json`、`test_undeclared_actual_and_nonexistent_declared_exclusions_fail`、`test_exclusion_line_shape_and_duplicates_are_fail_closed`。可补一个两文件专用回归，用 coverage 的公开 analysis2 解析真实源文件，核对声明 excluded_lines 与具名 Protocol占位；不执行provider/Host，不制造合成“当前正确行号”来镜像实现。再用保存旧工件重放 checker 作实质阳性证明，并保留原policy FAIL作负证据。实际最新 c80 / 修复head 的 full native与全局coverage必须保持独立身份，不能由这些局部回归替代。

本阶段没有源码/tests/ref mutation，没有 suite或 CI rerun。原日志、较宽初始自动摘录及 focused enforce 摘录均保留；最终判断只采 `enforce-excerpt-focused.json` 的真实末尾enforce组，避免把测试内部故意输出的 coverage-policy FAIL 当CI终态。诊断已完成，停止由root整合。
