from pathlib import Path
import datetime
import hashlib
import json

OUT = Path(__file__).parent
ROOT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
DIAG = OUT.parent / 'repr-diagnosis'
expected = {'src/research_workbench/adapters/models/provider_source_closure.py': '2d18c1c6f9288bd38124b6ba10ac45a74c971894b8450b408119937393390957', 'tests/test_provider_source_closure.py': '9b261e14e28e4a3fabb822e4b0f1d2f2500957b13ac573fcbcfc96e7c4e803e1'}
def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
identities = [identity(ROOT / name) for name in expected]
assert all(item['sha256'] == expected[str(Path(item['path']).relative_to(ROOT)).replace('\\', '/')] for item in identities)
probes = [json.loads((OUT / name).read_text(encoding='utf-8')) for name in ('field-flag-311.json', 'field-flag-313.json')]
review = dict(status='BLOCKED_P1_GENERATED_REFERENCE_FLAG_EXECUTION', profile='independent generated-callable reviewer', required_skills=[], created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_identity=identities, findings=[dict(priority='P1', source='provider_source_closure.py:702', introduced_by_reference_path=True, evidence='Both declared Python interpreters executed injected Field.kw_only.__bool__ twice and accepted layout.', gate='Validate exact field metadata types before passing to stdlib generator; negative regression must reject without invoking injected callable.'), dict(priority='P2_existing_trusted_boundary', source='provider_source_closure.py:724', evidence='Other dataclasses/enum/typing filename blanket trust and other <string> generated slots remain; filename is forgeable.', adoption_blocker_for_this_patch=False, scope='Report only, no implementation expansion.'), dict(priority='P3_report_precision', evidence='code_state omits co_filename already; all remaining CodeType fields is broader than actual comparison.')], attack_probes=probes, repeated_test_cases=0, actual_graph_reexecution=0, provider_executions=0, network_reads=0, source_mutations=0, no_full_ci_speedup_claim=True, final_receipt_limit='Corrected native proves only its 3 selected methods on final hashes, not all19 freshly rerun.', capture_gap='Only current visible parent contract and transmissions captured; prior mailbox context may have been summarized.')
with (OUT / 'review.json').open('x', encoding='utf-8') as handle:
    json.dump(review, handle, ensure_ascii=False, indent=2)
with (OUT / 'messages.jsonl').open('x', encoding='utf-8') as handle:
    handle.write(json.dumps({'kind': 'review_contract', 'scope': 'Static generated-callable security review; max2 narrow probes; no source/test/CI changes.', 'capture_gap': review['capture_gap']}) + '\n')
inputs = identities + [identity(DIAG / name) for name in ('REPORT.md', 'final.patch', 'commands.json', 'corrected311/native.json', 'corrected313/native.json', 'python311.json', 'python313.json', 'prototype313.json', 'reference-first-failure.json', 'validate.py')]
manifest = dict(status=review['status'], inputs=inputs, files=[identity(path) for path in sorted(OUT.rglob('*')) if path.is_file() and path.name != 'manifest.json'])
with (OUT / 'manifest.json').open('x', encoding='utf-8') as handle:
    json.dump(manifest, handle, ensure_ascii=False, indent=2)
print(json.dumps(dict(status=review['status'], source_hashes_match=True, probes=len(probes), files=len(manifest['files']))))
