"""Narrow independent layout attack probe; no archived code or Provider execution."""
import ast
import dataclasses
import hashlib
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'src'))
from research_workbench.adapters.models import provider_source_closure as closure

@dataclasses.dataclass
class ProbeRecord:
    value: int

item = {'raw': b'from dataclasses import dataclass\n@dataclass\nclass ProbeRecord:\n    value: int\n', 'aliases': {'dataclass': ('dataclasses', 'dataclass')}}
calls = []
class Flag:
    def __bool__(self):
        calls.append('injected Flag.__bool__ executed')
        return False

source_path = ROOT / 'src/research_workbench/adapters/models/provider_source_closure.py'
before = hashlib.sha256(source_path.read_bytes()).hexdigest()
started = time.perf_counter()
baseline = None
baseline_error = None
try:
    closure._verify_class_layout(sys.modules[__name__], 'ProbeRecord', ProbeRecord, item)
    baseline = 'accepted'
except Exception as error:
    baseline_error = f'{type(error).__name__}: {error}'
field = dataclasses.fields(ProbeRecord)[0]
old = field.kw_only
field.kw_only = Flag()
attack = None
attack_error = None
try:
    closure._verify_class_layout(sys.modules[__name__], 'ProbeRecord', ProbeRecord, item)
    attack = 'accepted'
except Exception as error:
    attack_error = f'{type(error).__name__}: {error}'
finally:
    field.kw_only = old
result = dict(python=sys.version, executable=sys.executable, source_sha256=before, source_sha256_after=hashlib.sha256(source_path.read_bytes()).hexdigest(), baseline=baseline, baseline_error=baseline_error, attack=attack, attack_error=attack_error, injected_calls=calls, elapsed_seconds=time.perf_counter()-started, zero_test_cases=True, zero_original_constructors=True, zero_archived_source_execution=True, zero_provider_execution=True)
with (OUT / ('field-flag-' + sys.argv[1] + '.json')).open('x', encoding='utf-8') as handle:
    json.dump(result, handle, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False))
