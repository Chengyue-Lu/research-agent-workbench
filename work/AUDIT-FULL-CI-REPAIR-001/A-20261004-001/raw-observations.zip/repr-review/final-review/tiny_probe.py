"""Independent tiny metadata/layout probe; no unittest, archive, or Provider execution."""
from pathlib import Path
import dataclasses
import hashlib
import json
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'src'))
from research_workbench.adapters.models import provider_source_closure as closure

@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Record:
    value: int
    hidden: str = dataclasses.field(repr=False, default='hidden')

class Plain:
    def declared(self):
        return 'never called'

CALLS = []
class Flag:
    def __bool__(self):
        CALLS.append('flag bool')
        return True
class Label(str):
    def isidentifier(self):
        CALLS.append('name isidentifier')
        return True
class FieldSubclass(dataclasses.Field):
    __slots__ = ()
    def __getattribute__(self, name):
        CALLS.append('field read:' + name)
        return super().__getattribute__(name)
class ParamsSubclass(dataclasses._DataclassParams):
    __slots__ = ()
    def __getattribute__(self, name):
        CALLS.append('params read:' + name)
        return super().__getattribute__(name)

ITEM = {'raw': b'from dataclasses import dataclass\n@dataclass(frozen=True, slots=True, kw_only=True)\nclass Record:\n    value: int\n    hidden: str\nclass Plain:\n    def declared(self):\n        return 0\n', 'aliases': {'dataclass': ('dataclasses', 'dataclass')}}
def identities():
    names = ('src/research_workbench/adapters/models/provider_source_closure.py', 'tests/test_provider_source_closure.py')
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names}
def attempt(function):
    try:
        function()
        return {'rejected': False, 'error': None}
    except closure.SourceClosureError as error:
        return {'rejected': True, 'error': str(error)}
def control(label):
    CALLS.clear()
    field = Record.__dataclass_fields__['value']
    if label == 'Flag':
        target, attribute, replacement = field, 'kw_only', Flag()
    elif label == 'name':
        target, attribute, replacement = field, 'name', Label('value')
    elif label == 'Field':
        replacement_field = FieldSubclass(dataclasses.MISSING, dataclasses.MISSING, True, True, None, True, None, True)
        target, attribute, replacement = Record, '__dataclass_fields__', {**Record.__dataclass_fields__, 'value': replacement_field}
    else:
        target, attribute, replacement = Record, '__dataclass_params__', object.__new__(ParamsSubclass)
    original = object.__getattribute__(target, attribute) if type(target) is dataclasses.Field else vars(target)[attribute]
    setattr(target, attribute, replacement)
    try:
        scan = attempt(lambda: closure.runtime_functions(sys.modules[__name__]))
        scan_calls = list(CALLS)
        layout = attempt(lambda: closure._verify_class_layout(sys.modules[__name__], 'Record', Record, ITEM))
        all_calls = list(CALLS)
    finally:
        setattr(target, attribute, original)
    return dict(label=label, runtime_scan=scan, callbacks_after_scan=scan_calls, layout=layout, all_callbacks=all_calls, pass_reject_zero_callback=layout['rejected'] and not all_calls and (label not in ('Field', 'params') or scan['rejected']))

before = identities()
started = time.perf_counter()
normal = attempt(lambda: closure._verify_class_layout(sys.modules[__name__], 'Record', Record, ITEM))
plain = attempt(lambda: closure._verify_class_layout(sys.modules[__name__], 'Plain', Plain, ITEM))
rows = [control(label) for label in ('Flag', 'name', 'Field', 'params')]
after = identities()
result = dict(python=sys.version, executable=sys.executable, hashes_before=before, hashes_after=after, normal_dataclass=normal, ordinary_non_dataclass=plain, controls=rows, elapsed_seconds=time.perf_counter()-started, pass_all=before == after and not normal['rejected'] and not plain['rejected'] and all(row['pass_reject_zero_callback'] for row in rows), zero_unittest_execution=True, zero_actual_graph_execution=True, zero_provider_execution=True, zero_original_constructor_or_factory=True, zero_archive_execution=True)
with (OUT / ('probe-' + sys.argv[1] + '.json')).open('x', encoding='utf-8') as handle:
    json.dump(result, handle, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(0 if result['pass_all'] else 1)
