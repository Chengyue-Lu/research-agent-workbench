from pathlib import Path
import datetime
import hashlib
import json

OUT = Path(__file__).parent
BASE = OUT.parents[1]
ROOT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
EXPECTED = {'src/research_workbench/adapters/models/provider_source_closure.py': 'f0f63804d0b80625f57cd25e6805958ac44e3c3f044fdd2b38d5858184b9490e', 'tests/test_provider_source_closure.py': '8a53751c7f4862b21cb423e1691d20e9b44bbd2ff5029d76d722a737f005d4a1'}
def read(path):
    return json.loads(path.read_text(encoding='utf-8'))
def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def save(name, value):
    with (OUT / name).open('x', encoding='utf-8') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
sources = [identity(ROOT / name) for name in EXPECTED]
assert all(item['sha256'] == EXPECTED[str(Path(item['path']).relative_to(ROOT)).replace('\\', '/')] for item in sources)
probes = [read(OUT / name) for name in ('probe-311.json', 'probe-313.json')]
assert all(probe['pass_all'] and probe['hashes_before'] == EXPECTED and probe['hashes_after'] == EXPECTED for probe in probes)
summary = dict(status='PASS_P1_CORRECTED_NEW_HASH_IDENTITY', profile='independent generated-callable security reviewer', required_skills=[], created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_identity=sources, independent_probes=probes, gates=dict(class_local_exact_metadata_precedes_both_member_scans=True, reference_names_and_flags_exact_primitives=True, ordinary_non_dataclass_layout_preserved=True, normal_generated_layout_supported=True, flag_name_field_params_injections_rejected=True, zero_custom_callbacks=True, normal_forged_slot_guards_not_relaxed=True), prior_p1_preserved=True, constraints=dict(tiny_processes=2, unittest_runs=0, full_runs=0, actual_graph_runs=0, provider_execution=0, archive_execution=0, source_edits=0, remote_reads=0, ci_mutations=0), limits=['Only current scoped metadata/reference fix reviewed; not full CI or coverage approval.', 'code_state retains existing compared fields, excludes co_filename; not equality of all CodeType fields.', 'Pre-existing other stdlib filename and <string> generated-slot trust is unchanged, not eliminated.', 'Final saved native verifies only its2 selected methods; prior repr runs retain their original source identity.'], capture_gap='Current visible parent contract captured; earlier conversation may have been summarized, no hidden mailbox replay.')
save('summary.json', summary)
with (OUT / 'messages.jsonl').open('x', encoding='utf-8') as handle:
    handle.write(json.dumps(dict(kind='contract', scope='Read final primitive-repair and own oldP1; atmost one tiny probe perPython; no suite/actualgraph/Provider/archiveexec/remote/source mutation.', capture_gap=summary['capture_gap']), ensure_ascii=False) + '\n')
inputs = sources + [identity(BASE / name) for name in ('repr-review/REPORT.md', 'repr-review/review.json', 'repr-review/field-flag-311.json', 'repr-review/field-flag-313.json', 'repr-diagnosis/primitive-repair/REPORT.md', 'repr-diagnosis/primitive-repair/final.patch', 'repr-diagnosis/primitive-repair/commands.json', 'repr-diagnosis/primitive-scan-fixed311/native.json', 'repr-diagnosis/primitive-scan-fixed313/native.json')]
save('manifest.json', dict(status=summary['status'], inputs=inputs, files=[identity(path) for path in sorted(OUT.rglob('*')) if path.is_file() and path.name != 'manifest.json']))
print(json.dumps(dict(status=summary['status'], final_source_hash=EXPECTED['src/research_workbench/adapters/models/provider_source_closure.py'], final_test_hash=EXPECTED['tests/test_provider_source_closure.py'], independent_probes=2, all_callbacks_zero=True)))
