# Generated dataclass callable 修正后独立复核

结论：**PASS — 原 P1 的注入回调路径已在本次新身份关闭；未发现新的采纳阻断。** 绑定 product SHA256 `f0f63804d0b80625f57cd25e6805958ac44e3c3f044fdd2b38d5858184b9490e`、test SHA256 `8a53751c7f4862b21cb423e1691d20e9b44bbd2ff5029d76d722a737f005d4a1`。当前文件、最终原生回执、独立 probe 前后hash一致。原 P1 和中间失败保留原目录/身份，未覆盖或重签。

`_check_dataclass_metadata:444–451` 使用 class-local `vars(cls)`；仅存在本地 dataclass metadata 时，先验证 params 为 exact stdlib _DataclassParams、fields 为 exact dict、所有值为 exact dataclasses.Field。该检查在 `runtime_functions:462` 的 member扫描前和 `_verify_class_layout:737` 的 member扫描前均执行，避免 forged参数/Field子类的 `__class__`/属性访问先行。普通无dataclass metadata的类沿用原路径。

`_generated_dataclass_repr:685–724` 在 params读取前再次验证结构类型；进入 stdlib reference生成器前，field为exact Field、name为exact str、repr/kw_only为exact bool。这关闭原kw_only求值回调及 name子类 isidentifier 路径；Field/params子类在读取其属性前拒绝。标准库仍是当前解释器可信实现，没有调用原类 constructor/default/factory。

两个独立 probe各只执行一次（Python3.11.16 / 3.13.15），使用 assessment 自有小类，直接调用 runtime_functions/layout helper，没有 unittest、case body或实际 Provider 图。

| 控制 | runtime member扫描 | repr/layout | 自定义回调数（两版） |
|---|---|---|---:|
| 正常dataclass | 正常路径 | 接受 | 0 |
| 普通非dataclass | 原路径 | 接受 | 0 |
| kw_only Flag | 不提前求值 | 拒绝 | 0 |
| name str子类 | 不提前调用方法 | 拒绝 | 0 |
| Field子类 | 扫描前拒绝 | 扫描前拒绝 | 0 |
| params子类 | 扫描前拒绝 | 扫描前拒绝 | 0 |

原始结果为 probe-311.json / probe-313.json；所有四注入均 rejected 且 callbacks=[]。布局/metadata段总计4.854ms / 3.802ms；此混合小诊断时间不用于估计full CI成本或提速。

正常3.11 dataclasses wrapper和3.13 reprlib wrapper的code object identity、stdlib globals、源码dataclass decorator、repr slot/enabled、closure集合/fillvalue、同一wrapped inner、inner namespace及空defaults/closure检查均保持。普通wrapper、伪造marker/inner与wrong-slot guards未放松，也没有新增reprlib整文件信任。只有 generated inner 的co_firstlineno被归一化；比较仍仅限现有code_state字段集合，不包含co_filename，不称为所有CodeType字段等值或依赖实现证明。显式源callable attestation未改。

已保存的最终 primitive-scan-fixed311/313 原生回执各2/2 PASS，绑定新hash，涵盖新零回调方法与actual graph；本审查仅读其结果，未重复运行。此前两个repr方法的通过仍属于此前source身份，不改写成全部最终源码新执行。

既有其他 dataclasses/enum/typing filename blanket trust及其他 `<string>` generated slots的许可没有扩大，也未在本次消除；stdlib runtime、native references及这些声明的generated/dependency信任边界仍存在。不将本次PASS外推为全部未知callable闭合、full CI、生产覆盖门槛或发布接纳。

交付后停止：2个tiny进程，零 full/unit/actualgraph/Provider/归档执行/远端/源码改动。manifest记录输入、脚本、原始probe和报告hash；可见契约及capture-gap保存到messages.jsonl。root负责后续正式CI/整合。
