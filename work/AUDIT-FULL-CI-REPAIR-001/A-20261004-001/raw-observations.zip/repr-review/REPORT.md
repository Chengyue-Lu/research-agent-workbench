# Generated dataclass callable 独立审查

结论：**BLOCKED — P1，参考 repr 生成路径会执行注入的字段 flag callable，并接受该漂移。** 本审查绑定最终 product SHA256 `2d18c1c6f9288bd38124b6ba10ac45a74c971894b8450b408119937393390957`、test SHA256 `9b261e14e28e4a3fabb822e4b0f1d2f2500957b13ac573fcbcfc96e7c4e803e1`；两者与当前 worktree 和 corrected311/313 原生回执一致。没有修改源码或复跑19项/actual graph。

## 必须先修复的 P1

`provider_source_closure.py:702–708` 对 `field.repr` 要求 exact bool，却把未验证的 `field.kw_only` 传给 `dataclasses.field` / `make_dataclass`。stdlib `_fields_in_init_order` 会对它求布尔值，即使参考类 `init=False`。独立 probe 只创建 assessment 自有小 dataclass、调用布局校验；将该真实 Field 的 `kw_only` 换成有记录副作用的 Flag 后，**Python3.11.16 和3.13.15 都调用 `Flag.__bool__` 两次且继续 accepted**。详见 field-flag-311.json / field-flag-313.json。布局段分别0.0024813s / 0.0021421s；没有测试、Provider、归档源码执行或原类 constructor/default/factory。

这属于新参考生成器接收未声明 runtime callable 的输入，不能以标准库执行为由豁免。最小采纳门槛：进入参考生成器前验证 `kw_only` 为 exact bool，并增加“拒绝且 injected __bool__ 调用数为零”的回归。应一并把引用元数据收敛到 exact `dataclasses.Field`、exact str field.name 和 exact bool field.repr；先检查 Field 类型再读取其属性。后两项是静态建议，未另做攻击执行：stdlib make_dataclass 对 str 子类允许调用可重载的 `isidentifier()`；当前代码未验证 name exact str。禁止通过放松 wrapper/code/namespace guard 消除失败。

## 已保留的安全检查与可信边界

- 3.11 legacy dataclasses wrapper 和3.13 reprlib wrapper 都用当前 stdlib wrapper **code object identity** 识别；仅 generated `__repr__` slot、源码 dataclass decorator、repr enabled 才进入许可。没有把整个 reprlib filename 加入 trusted_files。legacy wrapper 的原 filename blanket 许可被取消，因此原 wrong-slot 注入也拒绝。
- wrapper namespace、closure freevar集合、exact set、reprlib fillvalue exact `'...'`、真实同一 `__wrapped__` inner、inner module globals/module metadata、空defaults/kwdefaults/closure 均检查；inner code 比较保留 bytecode/constants/names/参数/flags/linetable/exceptiontable 等。只将该 generated inner 的 co_firstlineno 归一化；现有显式源码 callable attestation 未改。注意 code_state 比较的是其已有字段集合，**原本就不含 co_filename**，不能把报告中“all other code fields”理解为全部 CodeType 字段。
- 原归档源仍仅 AST/compile 提取，不执行；新路径仅从字段元数据生成 stdlib reference，没有调用原类 constructor/default/factory。上述 P1 说明“没有调用原factory”并不足以证明新路径没有执行未知 callable。
- 已有最终回执分别3/3 PASS，绑定最终hash，涵盖正常generated/custom repr、普通wrapper/伪造marker/伪造inner、wrong-slot以及actual graph。首次3.11新反例失败和co_firstlineno不等失败保留。其余旧方法不是最终源码上的新执行，不重签为19/19。

## 既有问题，未扩大本次实现范围

`_verify_class_layout:724–733` 对其他 dataclasses/enum/typing filename 仍作 blanket trust；FunctionType 的 co_filename 可伪造，因而仍可能让非canonical stdlib代码/未知slot过关。其他 dataclass generated slots 也仍仅按 `<string>` filename 许可。它们属于已有 generated/dependency trusted boundary，**本补丁未新增这些许可，也没有全面解决它们**；不应把这次兼容修复描述为通用依赖实现或全部 generated callable 的安全证明。本审查仅标出，不扩大源修改。

当前 stdlib实现/模块 namespace 及 dataclass metadata 完整性仍是可信前提；没有针对 stdlib monkeypatch 的普遍证明。25次原布局均值约2ms是本地小样本成本，未添加缓存，也不是full CI提速或仓库覆盖通过。latest c80 full状态不属于本任务，未轮询。

交付后停止：2次极窄 attack probe；0 suite/test/Provider/网络/CI/ref/source修改。root负责修复门槛后的定向回归与正式采纳。manifest和review.json保留输入/脚本/输出hash及可见消息capture-gap。
