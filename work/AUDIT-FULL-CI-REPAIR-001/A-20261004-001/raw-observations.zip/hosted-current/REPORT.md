# 最新 full CI 只读交接

快照 2026-10-04T04:48:21.592949+00:00。旧 run37171230339/6fa：completed/cancelled，取消终态验证：True。最新 run37176315620/c80：in_progress/None，attempt1、ci.yml、develop push 身份匹配：True。

全仓 producer 当前正在实际执行：True。本次仅一次轻量快照，完整结果与失败原因尚待终态；未将旧证据重签为c80。

| job | status | conclusion | active step |
|---|---|---|---|
| plan | completed | success | [] |
| governance | completed | success | [] |
| repository_smoke | completed | success | [] |
| CI contract shadow (diagnostic) | completed | success | [] |
| documentation | completed | success | [] |
| coverage-quality (3.11) | in_progress | None | [{"name": "Run ordered behavior and coverage-only cases once", "started_at": "2026-10-04T04:48:20Z"}] |
| package-smoke (3.11) | completed | success | [] |
| package-smoke (3.13) | in_progress | None | [{"name": "Validate both distribution routes outside checkout", "started_at": "2026-10-04T04:47:42Z"}] |
| compatibility (3.13) | in_progress | None | [{"name": "Run selected compatibility suite", "started_at": "2026-10-04T04:47:46Z"}] |

自身正式plan：已取得并认证。API SHA/size、ZIP CRC/安全路径以及run/head/plan binding保留在official-plan-checks.json；实际义务以official-ci-plan.json为准。

4次metadata读取，至多1次自身完整plan工件下载。零测试、dispatch/rerun/cancel、源码/ref/远端修改；没有等候长producer或重复下载。root继续修复与后续运行跟进。
