from pathlib import Path, PurePosixPath
import concurrent.futures
import datetime
import hashlib
import io
import json
import os
import subprocess
import zipfile

OUT = Path(__file__).parent
REPO = 'Chengyue-Lu/research-agent-workbench'
OLD = 37171230339
LATEST = 37176315620
HEAD = 'c80ec014925f0cbbbaef5486bce8422a5b4f73fb'
env = dict(os.environ)
for key in list(env):
    if key.upper() in ('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY'):
        env.pop(key)
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name, data):
    with (OUT / name).open('x', encoding='utf-8') as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
def api(item):
    name, endpoint = item
    started = now()
    result = subprocess.run(['gh', 'api', f'repos/{REPO}/{endpoint}'], capture_output=True, env=env)
    request = dict(endpoint=endpoint, started_at=started, completed_at=now(), exit_code=result.returncode, stderr=result.stderr.decode('utf-8', 'replace'))
    save(name + '-request.json', request)
    if result.returncode:
        return name, dict(request_failed=True, request=request)
    with (OUT / (name + '.json')).open('xb') as handle:
        handle.write(result.stdout)
    return name, json.loads(result.stdout)
calls = [('old-run', f'actions/runs/{OLD}'), ('latest-run', f'actions/runs/{LATEST}'), ('latest-jobs', f'actions/runs/{LATEST}/attempts/1/jobs?per_page=100'), ('latest-artifacts', f'actions/runs/{LATEST}/artifacts?per_page=100')]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = dict(pool.map(api, calls))
snapshot = now()
old = results['old-run']
latest = results['latest-run']
jobs = results['latest-jobs'].get('jobs', [])
artifacts = results['latest-artifacts'].get('artifacts', [])
identity = latest.get('id') == LATEST and latest.get('head_sha') == HEAD and latest.get('run_attempt') == 1 and latest.get('path') == '.github/workflows/ci.yml' and latest.get('event') == 'push'
plans = [item for item in artifacts if item['name'] == 'ci-plan' and not item['expired']]
checks = None
plan = None
if identity and len(plans) == 1:
    artifact = plans[0]
    result = subprocess.run(['gh', 'api', f"repos/{REPO}/actions/artifacts/{artifact['id']}/zip"], capture_output=True, env=env)
    save('plan-download-request.json', dict(artifact_id=artifact['id'], exit_code=result.returncode, stderr=result.stderr.decode('utf-8', 'replace'), completed_at=now()))
    if result.returncode == 0:
        payload = result.stdout
        with (OUT / 'official-ci-plan.zip').open('xb') as handle:
            handle.write(payload)
        digest = hashlib.sha256(payload).hexdigest()
        checks = dict(artifact_id=artifact['id'], name=artifact['name'], api_size=artifact['size_in_bytes'], bytes=len(payload), api_digest=artifact['digest'], sha256=digest, size_matches=len(payload) == artifact['size_in_bytes'], sha_matches=artifact['digest'] == 'sha256:' + digest, workflow_run=artifact['workflow_run'])
        if checks['size_matches'] and checks['sha_matches']:
            archive = zipfile.ZipFile(io.BytesIO(payload))
            seen = set()
            members = []
            for item in archive.infolist():
                path = PurePosixPath(item.filename)
                assert not path.is_absolute() and '..' not in path.parts and '\\' not in item.filename and ':' not in item.filename and item.filename not in seen
                assert ((item.external_attr >> 16) & 0o170000) != 0o120000
                seen.add(item.filename)
                members.append(dict(path=item.filename, bytes=item.file_size, crc32=f'{item.CRC:08x}'))
            assert sum(item.file_size for item in archive.infolist()) < 5000000
            checks['safe_paths'] = True
            checks['zip_crc_pass'] = archive.testzip() is None
            checks['members'] = members
            assert checks['zip_crc_pass']
            assert seen == {'ci-plan.json'}
            contents = archive.read('ci-plan.json')
            with (OUT / 'official-ci-plan.json').open('xb') as handle:
                handle.write(contents)
            plan = json.loads(contents)
            checks['plan_binding_matches'] = all(plan['binding'][key] == HEAD for key in ('base', 'head', 'merge_base', 'target')) and plan['binding']['repository'] == REPO
            checks['artifact_run_identity_matches'] = artifact['workflow_run']['id'] == LATEST and artifact['workflow_run']['head_sha'] == HEAD
        save('official-plan-checks.json', checks)
rows = []
for job in jobs:
    rows.append({**{key: job.get(key) for key in ('id', 'name', 'status', 'conclusion', 'created_at', 'started_at', 'completed_at')}, 'active_steps': [{key: step.get(key) for key in ('name', 'started_at')} for step in job['steps'] if step['status'] == 'in_progress'], 'failed_steps': [{key: step.get(key) for key in ('name', 'started_at', 'completed_at')} for step in job['steps'] if step.get('conclusion') == 'failure']})
summary = dict(status='LIVE_HANDOFF_STOP', snapshot_at=snapshot, old_run={key: old.get(key) for key in ('id', 'head_sha', 'run_attempt', 'status', 'conclusion', 'updated_at')}, old_cancelled_terminal=old.get('status') == 'completed' and old.get('conclusion') == 'cancelled', latest_run={key: latest.get(key) for key in ('id', 'head_sha', 'run_attempt', 'path', 'event', 'status', 'conclusion', 'created_at', 'updated_at')}, latest_identity_matches=identity, jobs=rows, producer_actually_running=any('Run ordered behavior and coverage-only cases once' == step['name'] for row in rows for step in row['active_steps']), artifacts=[{key: item.get(key) for key in ('id', 'name', 'size_in_bytes', 'digest', 'created_at', 'expired')} for item in artifacts], official_plan=plan, official_plan_checks=checks, metadata_reads=4, artifact_downloads=int(bool(plans) and identity), zero_tests_executed=True, no_ci_mutations=True, handoff='One current snapshot; root follows latest run after meaningful local progress. No ongoing polling or native audit of active producer.', capture_gap='Visible parent contract captured; no replay of earlier hidden mailbox history.')
save('summary.json', summary)
lines = ['# 最新 full CI 只读交接', '', f"快照 {snapshot}。旧 run{OLD}/6fa：{old.get('status')}/{old.get('conclusion')}，取消终态验证：{summary['old_cancelled_terminal']}。最新 run{LATEST}/c80：{latest.get('status')}/{latest.get('conclusion')}，attempt1、ci.yml、develop push 身份匹配：{identity}。", '', f"全仓 producer 当前正在实际执行：{summary['producer_actually_running']}。本次仅一次轻量快照，完整结果与失败原因尚待终态；未将旧证据重签为c80。", '', '| job | status | conclusion | active step |', '|---|---|---|---|']
for row in rows:
    lines.append(f"| {row['name']} | {row['status']} | {row['conclusion']} | {json.dumps(row['active_steps'], ensure_ascii=False)} |")
lines += ['', f"自身正式plan：{'已取得并认证' if checks and checks.get('plan_binding_matches') and checks.get('artifact_run_identity_matches') else '尚未取得完整认证'}。API SHA/size、ZIP CRC/安全路径以及run/head/plan binding保留在official-plan-checks.json；实际义务以official-ci-plan.json为准。", '', '4次metadata读取，至多1次自身完整plan工件下载。零测试、dispatch/rerun/cancel、源码/ref/远端修改；没有等候长producer或重复下载。root继续修复与后续运行跟进。']
with (OUT / 'REPORT.md').open('x', encoding='utf-8') as handle:
    handle.write('\n'.join(lines) + '\n')
def identity_file(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
inputs = [identity_file(OUT.parent / 'PLAN.md'), identity_file(OUT.parent / 'cancel-old/request.json'), identity_file(OUT.parent / 'cancel-old/after.json')]
save('manifest.json', dict(snapshot_at=snapshot, run_id=LATEST, head=HEAD, files=[identity_file(path) for path in sorted(OUT.rglob('*')) if path.is_file() and path.name != 'manifest.json'], inputs=inputs))
print(json.dumps({key: summary[key] for key in ('snapshot_at', 'old_run', 'old_cancelled_terminal', 'latest_run', 'latest_identity_matches', 'producer_actually_running', 'jobs', 'official_plan', 'official_plan_checks')}, ensure_ascii=False))
