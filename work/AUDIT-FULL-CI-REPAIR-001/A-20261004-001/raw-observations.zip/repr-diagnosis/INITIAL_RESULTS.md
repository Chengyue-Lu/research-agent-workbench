# Scoped diagnosis and first implementation verification

Base: c80ec014925f0cbbbaef5486bce8422a5b4f73fb; isolated working tree only.

- Original unchanged layout reproductions: Python 3.13.15 ERROR `undeclared runtime class callable: ProviderAdapterConfig.__repr__`; Python 3.11.16 PASS. Standard 3.13 repr wrapper code is exactly the current `reprlib.recursive_repr` wrapper code; 3.11 wrapper comes from `dataclasses`.
- First reference-code attempt failed before any unit test started: 3.13 batches generated methods, so actual synthetic `co_firstlineno=12` versus isolated reference `2`. The sole difference is saved in `reference-first-failure.json`. Only this synthetic starting-line offset is normalized; explicit source callable attestation is unchanged.
- Initial full affected module runs: 3.13 19/19 PASS in 17.1279 seconds; 3.11 18/19 PASS in 19.1429 seconds. Both original outputs are retained under `validation313-final` and `validation311-final`; these names do not imply both passed.
- The one 3.11 failed adversarial control reuses its genuine generated repr wrapper in an unrelated injected class slot. Existing broad `dataclasses.py` trust accepts it. This pre-existing recursive-wrapper boundary gap is reported to the coordinator; it is not silently discarded or described as a green module result.
- Current product source hash after the first implementation is `016da56ef6516a56680f3c2385c0725d21433949228f84b6afa3d93f5816898c`; test hash is `9b261e14e28e4a3fabb822e4b0f1d2f2500957b13ac573fcbcfc96e7c4e803e1`.
- Proposed follow-up is bounded to the same recursive repr wrapper: recognize the canonical legacy dataclasses wrapper by code identity too, require the repr slot and genuine generated inner code for both interpreters, preserving all other existing generated-method trust boundaries. Run only the changed adversarial method and normal repr method after this correction, preserving the original module runs.
- Discovery-only `rg -Encoding` syntax and two nonexistent runner-directory lookups failed harmlessly; no tests, files, refs, network execution or credentials were changed by those commands. Validation uses an assessment-local timed unittest runner.

No archive source execution, original Provider constructor, default factory, remote API, credential action, full suite, stage, commit or push occurred in this delegated task.
