"""One bounded affected-module test execution per local interpreter."""
from pathlib import Path
import hashlib
import importlib
import io
import json
import statistics
import sys
import time
import unittest

root = Path(sys.argv[1])
output = Path(sys.argv[2])
output.mkdir(parents=True, exist_ok=False)
sys.path[:0] = [str(root / "src"), str(root), str(root / "tests")]
from research_workbench.adapters.models import configuration
from research_workbench.adapters.models import provider_source_closure as closure

def hashes():
    paths = ("src/research_workbench/adapters/models/provider_source_closure.py", "tests/test_provider_source_closure.py")
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in paths}

raw = Path(configuration.__file__).read_bytes()
_, aliases = closure._imports(configuration.__name__, raw, is_package=False, namespace={"research_workbench"})
item = {"raw": raw, "aliases": aliases}
measurements = []
for _ in range(25):
    started = time.perf_counter()
    closure._verify_class_layout(configuration, "ProviderAdapterConfig", configuration.ProviderAdapterConfig, item)
    measurements.append(time.perf_counter() - started)

class Result(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []
    def startTest(self, test):
        super().startTest(test)
        self.started = time.perf_counter()
    def stopTest(self, test):
        self.records.append({"id": test.id(), "elapsed_seconds": time.perf_counter() - self.started})
        super().stopTest(test)

before = hashes()
module = importlib.import_module("test_provider_source_closure")
suite = (unittest.defaultTestLoader.loadTestsFromNames(sys.argv[3:]) if len(sys.argv) > 3
         else unittest.defaultTestLoader.loadTestsFromModule(module))
stream = io.StringIO()
started = time.perf_counter()
result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=Result).run(suite)
summary = {
    "python": sys.version, "executable": sys.executable, "root": str(root),
    "test_count": result.testsRun, "successful": result.wasSuccessful(),
    "failures": [{"id": test.id(), "traceback": detail} for test, detail in result.failures],
    "errors": [{"id": test.id(), "traceback": detail} for test, detail in result.errors],
    "skipped": [{"id": test.id(), "reason": detail} for test, detail in result.skipped],
    "elapsed_seconds": time.perf_counter() - started,
    "records": result.records, "source_hashes_before": before, "source_hashes_after": hashes(),
    "layout_microbenchmark": {"samples": len(measurements), "seconds_sum": sum(measurements),
                              "mean_seconds": statistics.mean(measurements),
                              "median_seconds": statistics.median(measurements)},
}
(output / "native.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
(output / "unittest.txt").write_text(stream.getvalue(), encoding="utf-8")
print(json.dumps({key: summary[key] for key in ("python", "test_count", "successful", "elapsed_seconds", "layout_microbenchmark")}))
assert before == summary["source_hashes_after"]
raise SystemExit(not result.wasSuccessful())
