"""In-memory proposal predicates; never patches repository source or checker."""
from pathlib import Path
import ast
import dataclasses
import functools
import json
import reprlib
import sys
from types import FunctionType

source_root = Path(sys.argv[1])
sys.path[:0] = [str(source_root / "src"), str(source_root)]
from research_workbench.adapters.models import configuration
from research_workbench.adapters.models import provider_source_closure as closure

def probe(self):
    return "probe"

canonical_code = reprlib.recursive_repr()(probe).__code__

def source_declares_dataclass(item, node):
    for decorator in node.decorator_list:
        target = decorator.func if isinstance(decorator, ast.Call) else decorator
        if isinstance(target, ast.Name) and item["aliases"].get(target.id) == ("dataclasses", "dataclass"):
            return True
        if isinstance(target, ast.Attribute) and target.attr == "dataclass" and isinstance(target.value, ast.Name) and item["aliases"].get(target.value.id) == ("dataclasses", None):
            return True
    return False

def accepted(cls, member, attribute, item, node):
    if not (attribute == "__repr__" and isinstance(member, FunctionType)
            and member.__code__ is canonical_code and member.__globals__ is vars(reprlib)
            and dataclasses.is_dataclass(cls) and source_declares_dataclass(item, node)
            and cls.__dataclass_params__.repr):
        return False
    if not member.__closure__ or len(member.__closure__) != len(member.__code__.co_freevars):
        return False
    cells = dict(zip(member.__code__.co_freevars, (cell.cell_contents for cell in member.__closure__)))
    inner = cells.get("user_function")
    return (set(cells) == {"fillvalue", "repr_running", "user_function"}
            and cells["fillvalue"] == "..." and type(cells["repr_running"]) is set
            and isinstance(inner, FunctionType) and inner.__code__.co_filename == "<string>"
            and inner.__code__.co_name == "__repr__" and inner.__module__ == cls.__module__
            and getattr(member, "__wrapped__", None) is inner)

raw = Path(configuration.__file__).read_bytes()
_, aliases = closure._imports(configuration.__name__, raw, is_package=False, namespace={"research_workbench"})
item = {"raw": raw, "aliases": aliases}
node = closure._class_node(item, "ProviderAdapterConfig")
cls = configuration.ProviderAdapterConfig
real = vars(cls)["__repr__"]

@reprlib.recursive_repr()
def arbitrary(self):
    return "injected"

@functools.wraps(real)
def forged_outer(self):
    return "injected"

fake_real = FunctionType(real.__code__, {}, name=real.__name__, closure=real.__closure__)
fake_real.__wrapped__ = real.__wrapped__

source_without_decorator = dict(item, aliases=aliases)
ordinary_node = ast.parse("class Ordinary:\n    pass\n").body[0]

@dataclasses.dataclass(frozen=True, slots=True)
class OtherRecord:
    value: int

other_raw = b"from dataclasses import dataclass\n@dataclass(frozen=True, slots=True)\nclass OtherRecord:\n    value: int\n"
other_node = ast.parse(other_raw).body[1]
other_item = {"raw": other_raw, "aliases": {"dataclass": ("dataclasses", "dataclass")}}
cases = {
    "real_generated_record": accepted(cls, real, "__repr__", item, node),
    "unrelated_generated_record": accepted(OtherRecord, OtherRecord.__repr__, "__repr__", other_item, other_node),
    "ordinary_injected_reprlib_wrapper": accepted(cls, arbitrary, "__repr__", item, node),
    "forged_wrapped_marker_outer": accepted(cls, forged_outer, "__repr__", item, node),
    "wrong_slot_injected": accepted(cls, real, "injected", item, node),
    "source_lacks_dataclass": accepted(cls, real, "__repr__", item, ordinary_node),
    "canonical_code_wrong_globals": accepted(cls, fake_real, "__repr__", item, node),
}
expected = {name: name in {"real_generated_record", "unrelated_generated_record"} for name in cases}
result = {"python": sys.version, "cases": cases, "expected": expected, "pass": cases == expected}
Path(sys.argv[2]).write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result))
assert result["pass"]
