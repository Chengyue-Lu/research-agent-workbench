"""Narrow read-only runtime dataclass layout reproduction."""
from pathlib import Path
import json
import reprlib
import sys
import types

source_root = Path(sys.argv[1])
sys.path[:0] = [str(source_root / "src"), str(source_root)]
from research_workbench.adapters.models import configuration
from research_workbench.adapters.models import provider_source_closure as closure

method = vars(configuration.ProviderAdapterConfig)["__repr__"]

def metadata(function):
    return {
        "module": function.__module__, "qualname": function.__qualname__,
        "filename": function.__code__.co_filename,
        "code_name": function.__code__.co_name,
        "code_qualname": function.__code__.co_qualname,
        "freevars": list(function.__code__.co_freevars),
        "closure": [
            {"type": type(cell.cell_contents).__name__,
             "function": metadata(cell.cell_contents) if isinstance(cell.cell_contents, types.FunctionType) else None,
             "literal": cell.cell_contents if type(cell.cell_contents) in (str, int, bool) else None}
            for cell in function.__closure__ or ()
        ],
    }

def canonical_probe(self):
    return "probe"

wrapped_probe = reprlib.recursive_repr()(canonical_probe)
result = {
    "python": sys.version, "executable": sys.executable,
    "source_module": str(Path(configuration.__file__).resolve()),
    "dataclass_repr": metadata(method),
    "canonical_reprlib_wrapper": metadata(wrapped_probe),
    "wrapper_code_identity": method.__code__ is wrapped_probe.__code__,
    "wrapped": metadata(method.__wrapped__) if hasattr(method, "__wrapped__") else None,
}
try:
    closure._verify_class_layout(configuration, "ProviderAdapterConfig", configuration.ProviderAdapterConfig,
                                 {"raw": Path(configuration.__file__).read_bytes()})
except closure.SourceClosureError as error:
    result["layout_result"] = "ERROR"
    result["layout_error"] = str(error)
else:
    result["layout_result"] = "PASS"
Path(sys.argv[2]).write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps({key: result[key] for key in ("python", "layout_result", "wrapper_code_identity")}))
