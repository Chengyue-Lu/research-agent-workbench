from pathlib import Path
import dataclasses
import json
import sys

root = Path(sys.argv[1])
sys.path[:0] = [str(root / "src"), str(root)]
from research_workbench.adapters.models import configuration
from research_workbench.adapters.models import provider_source_closure as closure
cls = configuration.ProviderAdapterConfig
inner = cls.__repr__.__wrapped__
reference = dataclasses.make_dataclass("_ClosureRepr", [(field.name, object, dataclasses.field(repr=field.repr, kw_only=field.kw_only)) for field in dataclasses.fields(cls)], init=False, eq=False)
left = closure.code_state(inner.__code__)
right = closure.code_state(reference.__repr__.__wrapped__.__code__)
result = {"diff": {key: {"actual": left[key], "reference": right[key]} for key in left if left[key] != right[key]}}
Path(sys.argv[2]).write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result))
