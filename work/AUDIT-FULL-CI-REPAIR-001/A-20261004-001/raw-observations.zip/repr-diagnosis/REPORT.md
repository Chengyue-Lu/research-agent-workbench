# Provider dataclass repr closure repair

Task boundary: latest accepted c80ec014925f0cbbbaef5486bce8422a5b4f73fb, isolated `fix/full-ci-post-optimization-20261004`. Only `provider_source_closure.py` and `test_provider_source_closure.py` changed by this delegated task. No stage, commit, push, full suite, installation, Provider construction, credentials, archive-source execution or remote API operation.

## Cause

The same real `ProviderAdapterConfig` passes its unchanged class layout check on local Python 3.11.16 but fails on 3.13.15. Python 3.13 dataclasses produce an outer recursion wrapper in `reprlib.py`; its inner generated repr is still compiler-generated code. The old checker trusts only files belonging to dataclasses, enum and typing, so it rejects the legitimate 3.13 wrapper. Native metadata and the exact repro scripts/results are in `python311.json`, `python313.json`, and `repro.py`.

## Repair

The checker now recognizes the current standard library recursive repr wrapper by exact code-object identity and namespace. It supports both the legacy dataclasses wrapper and the reprlib wrapper, only in the `__repr__` class slot, on a source-declared dataclass with repr enabled. It validates the actual wrapper closure, the same wrapped inner function, and the inner function's current source module namespace and metadata. It independently generates a standard-library reference repr from the dataclass's field names and repr/kw-only flags, with no original class constructor or default/factory execution, and compares inner code state. Synthetic starting-line offset is normalized because Python 3.13 compiles several generated methods together; all other code fields still compare. Explicit source callable attestation is unchanged.

No entire reprlib file was added to trusted files. Ordinary unknown-callable rejection is retained. The same strict wrapper check closes the related pre-existing 3.11 wrong-slot reuse loophole; other existing generated dataclass/Enum/typing methods retain their previous declared trust boundary. This is not general dependent-library implementation attestation.

## Verification and preserved failures

1. Initial narrow reproduction: original 3.13 ERROR / 3.11 PASS, each under 0.6 seconds.
2. Assessment-local prototype: two positive unrelated generated records accepted; ordinary wrapper, forged wrapped marker, wrong slot, missing source declaration and wrong namespace controls rejected.
3. First implementation reference comparison failed before any unit test started. The sole difference was synthetic `co_firstlineno` 12 versus 2; `reference-first-failure.json` preserves it.
4. Initial affected-module executions: Python 3.13 19/19 PASS in 17.127913 seconds; Python 3.11 18/19 PASS in 19.142900 seconds. The one failing new control exposed legacy generated repr reuse in an unrelated class slot. Both native receipts and initial implementation hashes remain in `validation313-final/` and `validation311-final/`; names do not overwrite the first 3.11 failure.
5. After the bounded legacy-wrapper correction, only the two repr methods and the affected actual runtime graph method were executed again on each interpreter. Python 3.11 3/3 PASS in 15.805984 seconds; Python 3.13 3/3 PASS in 16.035874 seconds; 0 failure/error/skip. Source/test hashes are stable before/after each run. The untouched original methods are not re-signed as fresh final-source executions.

The final actual graph method is `ProviderSourceClosureTests.test_actual_provider_graph_named_closed_registries_and_outside_seven_helper`. It verifies the real declared provider/conformance graph and its existing helper and policy drift controls. Own method elapsed: Python 3.11 15.736180 seconds; Python 3.13 15.977404 seconds. Do not repeat this run at the coordinator.

Final layout-only measurements on 25 samples: Python 3.11 mean 2.365220 ms / median 2.138600 ms; Python 3.13 mean 2.055608 ms / median 1.940900 ms. These are local small-layout cost observations, not a full CI speedup claim. No cache mechanism was added.

## Identity and handoff

- Final product SHA256: `2d18c1c6f9288bd38124b6ba10ac45a74c971894b8450b408119937393390957`.
- Final test SHA256: `9b261e14e28e4a3fabb822e4b0f1d2f2500957b13ac573fcbcfc96e7c4e803e1`.
- Final native: `corrected311/native.json`, `corrected313/native.json` and matching `unittest.txt`.
- Exact diff: `final.patch`; scoped `git diff --check` PASS.
- Commands: `commands.json`; timed local runner: `validate.py`.
- Initial failures: `INITIAL_RESULTS.md`, `reference-first-failure.json` and `validation311-final/native.json` retained.

Root still owns independent review, repository coverage/negative acceptance, integration testing, CI metadata, archive, publication and merge decisions. A focused local correctness repair is not latest-head full CI approval or release acceptance. No fixtures or other-owner business files were changed.
