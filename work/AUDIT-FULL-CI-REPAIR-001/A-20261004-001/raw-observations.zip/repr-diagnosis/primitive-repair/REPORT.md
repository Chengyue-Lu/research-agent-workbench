# Primitive dataclass metadata boundary correction

This supersedes the initial repr candidate only at its new source identity. Previous reports, source hashes, first failures and independent P1 reproductions remain unchanged.

The independent review found that a custom `Field.kw_only` value could execute `Flag.__bool__` twice during trusted reference class generation and still be accepted. Both original 3.11/3.13 reproductions are preserved in `repr-review/field-flag-311.json` and `field-flag-313.json`.

The correction validates local `__dataclass_params__` as exactly the standard-library parameter type and local `__dataclass_fields__` as exactly a dict with exact `dataclasses.Field` values, before accessing field metadata. After obtaining normal dataclass fields, field names must be exact str and repr/kw-only flags exact bool before the values enter the trusted standard-library generator. No class constructor or default factory executes.

The first corrected four-method run exposed an additional early-read path: existing `isinstance` class-member scans invoked a forged parameter subclass's `__class__` getter eight times before eventual rejection. Those runs are preserved in `primitive-fixed311/` and `primitive-fixed313/` (three methods passed, the new zero-callback method failed). The same exact metadata precheck now runs before those two scans. Ordinary classes without dataclass metadata retain their existing path; no generic third-party metadata system was introduced.

New controls assert rejection with zero custom callbacks for kw-only truth objects, str-subclass field names, Field-subclass metadata and parameter-subclass metadata. Existing canonical wrapper, namespace, declaration, repr-slot and independent inner-code checks remain.

Only the new zero-callback method and the affected actual provider graph method were repeated after the scan correction, on each interpreter. Final receipts: `../primitive-scan-fixed311/native.json` and `../primitive-scan-fixed313/native.json`; both 2/2 PASS, zero failure/error/skip and stable source hashes. The prior two repr methods had already passed at the primitive-guard source, so they were not redundantly executed again or relabeled as fresh final-source runs. The graph method includes real declared dataclasses and existing helper/policy drift controls.

Final product SHA256: `f0f63804d0b80625f57cd25e6805958ac44e3c3f044fdd2b38d5858184b9490e`; final test SHA256: `8a53751c7f4862b21cb423e1691d20e9b44bbd2ff5029d76d722a737f005d4a1`. Scoped `git diff --check` PASS; `final.patch` is the new final two-file diff.

The comparison is exactly the existing named `code_state` policy: `co_names`, `co_varnames`, `co_freevars`, `co_cellvars`, `co_argcount`, `co_posonlyargcount`, `co_kwonlyargcount`, `co_nlocals`, `co_stacksize`, `co_flags`, `co_name`, `co_qualname`, `co_firstlineno`, bytecode (`co_code`), recursively serialized constants (`co_consts`), line table (`co_linetable`) and exception table (`co_exceptiontable`). For this generated-reference comparison only, `co_firstlineno` is normalized to 1. `co_filename` is not a compared policy field. This does not claim equality of all CodeType attributes or dependency implementation attestation; the original explicit source callable policy remains unchanged.

Final local execution times: Python 3.11 15.617622 seconds (actual graph 15.582805); Python 3.13 15.979526 seconds (actual graph 15.947069). Layout-only 25-sample means are 2.356668 ms and 1.951760 ms respectively; these are local cost observations, not full CI speedup evidence.

Root owns independent re-review and final integration. Only the two originally owned source/test files were edited. No stage, commit, push, installation, full suite or remote API operation occurred.
