"""Run named, original unittest cases once with source-bound local receipts."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import os
import platform
import subprocess
import sys
import time
import unittest

parser = argparse.ArgumentParser()
parser.add_argument("--root", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("names", nargs="+")
args = parser.parse_args()
root, output = Path(args.root).resolve(), Path(args.output).resolve()
output.mkdir(parents=True, exist_ok=False)
sys.path[:0] = [str(root / "src"), str(root), str(root / "tests")]
os.chdir(root)
from tests.run_unittest_suite import TimedTextResult

paths = ["src/research_workbench/adapters/models/provider_source_closure.py",
         "src/research_workbench/adapters/models/provider_binding.py",
         "src/research_workbench/adapters/models/configured.py",
         "tests/test_provider_source_closure.py", "tests/test_provider_binding_graph.py",
         "tests/run_unittest_suite.py"]
def hashes():
    return {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths}

before = hashes()
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
suite = unittest.defaultTestLoader.loadTestsFromNames(args.names)
# inventory is collected independently of outcomes below, without importing a
# second copy of test or product modules.
def ids(suite):
    result = []
    for test in suite:
        result.extend(ids(test) if isinstance(test, unittest.TestSuite) else [test.id()])
    return result
selected = ids(suite)
stream = io.StringIO()
start = time.perf_counter()
result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=TimedTextResult).run(suite)
elapsed = time.perf_counter() - start
data = dict(schema="source-facts-local-regression-v1", root=str(root), head=head,
            python=sys.version, executable=sys.executable, platform=platform.platform(),
            names=args.names, selected=selected, tests_run=result.testsRun,
            successful=result.wasSuccessful(), wall_seconds=elapsed,
            records=list(result.records.values()), execution_order=result.execution_order,
            failures=[dict(id=test.id(), traceback=detail) for test, detail in result.failures],
            errors=[dict(id=test.id(), traceback=detail) for test, detail in result.errors],
            skipped=[dict(id=test.id(), reason=reason) for test, reason in result.skipped],
            source_before=before, source_after=hashes())
(output / "native.json").write_text(json.dumps(data, indent=2)+"\n", encoding="utf-8")
(output / "unittest.txt").write_text(stream.getvalue(), encoding="utf-8")
assert before == data["source_after"], "source changed during execution"
print(json.dumps({k:data[k] for k in ("tests_run", "successful", "wall_seconds", "python", "output") if k in data}))
raise SystemExit(not result.wasSuccessful())
