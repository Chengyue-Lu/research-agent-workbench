"""Freeze scoped local evidence for an R2 source-parse optimization candidate."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent
WT=Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
OLD='d7c13791b8ade226a7448cacac3a05fdfe7f71c2'
BASE='c80ec014925f0cbbbaef5486bce8422a5b4f73fb'
OWNED=['src/research_workbench/adapters/models/provider_source_closure.py',
       'tests/test_provider_source_closure.py',
       'docs/workstreams/chengyue-lu/FULL-CI-REPAIR-001/README.md',
       'docs/workstreams/chengyue-lu/FULL-CI-REPAIR-001/RISK_LEDGER.md']
def git(*args): return subprocess.check_output(['git','-C',str(WT),*args])
def sha(raw): return hashlib.sha256(raw).hexdigest()
def save(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert git('rev-parse','HEAD').decode().strip()==OLD
independent=json.loads((ROOT/'independent/summary.json').read_bytes())
assert independent['status']=='PASS'
# Root must first verify all final summaries listed in evidence-selection.json.
selection=json.loads((ROOT/'evidence-selection.json').read_bytes())
assert selection['ready_to_freeze'] is True
for row in selection['bindings']:
    assert sha((ROOT/row['path']).read_bytes())==row['sha256']
for row in selection['source']:
    assert sha((WT/row['path']).read_bytes())==row['sha256']
archive=WT/'work/AUDIT-FULL-CI-REPAIR-001/A-20261004-003'
archive.mkdir(parents=True,exist_ok=False)
index=[]
with zipfile.ZipFile(archive/'raw-observations.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for relative in selection['files']:
        p=ROOT/relative;raw=p.read_bytes()
        z.writestr(relative,raw);index.append(dict(path=relative,bytes=len(raw),sha256=sha(raw)))
    diff=git('diff','--',*OWNED)
    z.writestr('candidate.diff',diff);index.append(dict(path='candidate.diff',bytes=len(diff),sha256=sha(diff)))
save(archive/'RAW_INDEX.json',dict(kind='source_parse_scoped_evidence',files=index))
save(archive/'CAPTURE.json',dict(kind='compact_delegated_followup_record',
    at=datetime.now(timezone.utc).isoformat(),base=BASE,parent=OLD,skills=[],
    accountable_owner='Chengyue-Lu',provider_review_owner='let778750-cpu',
    source=selection['source'],complete_agent_trace=False,
    warnings=['capture-gap: complete transport/event trace unavailable; scoped raw checks, tool failures, messages and reviews retained'],
    test_budget_seconds=120,quality='global90/critical95-90/changed100-100 unchanged',
    global_cache=False,cached_acceptance=False,ready=False,merged=False,
    historical_archives_preserved=['A-20261004-001','A-20261004-002']))
(archive/'README.md').write_text('''# FULL-CI-REPAIR-001 / A-20261004-003

责任人Chengyue-Lu，Provider/source-closure跨owner接受let778750-cpu；R2。
本候选在每次私有归档构建中仅解析一次当前模块源码，保留两遍fresh reads/hash、
独立claims/compile与全部loaded-runtime控制。没有跨调用或通过资格缓存。
原两项graph baseline预算120秒不变；原用例、攻击及cold控制保留。

原始配对、coverage局部结果、源码identity、独立复核和准备工具失败分身份保存。
RAW_INDEX/ZIP/MANIFEST认证原始字节；局部成功不等于新鲜全仓checkpoint。
A001/A002及原c80/d7 hosted证据保持原身份。本轮无Ready/merge。
CAPTURE如实保留capture-gap，不声明完整Agent Trace；原始脚本中的机器路径仅为
本地原始执行事实，产品导航使用相对路径。
''',encoding='utf-8')
save(archive/'MANIFEST.json',dict(kind='compact_evidence_index',files=[dict(path=p.name,bytes=p.stat().st_size,
    sha256=sha(p.read_bytes())) for p in sorted(archive.iterdir())]))
with zipfile.ZipFile(archive/'raw-observations.zip') as z: assert z.testzip() is None
print(json.dumps(dict(archive=str(archive),files=len(index),zip_bytes=(archive/'raw-observations.zip').stat().st_size)))
