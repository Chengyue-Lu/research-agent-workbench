"""Read-only immutable starting-source capture; no source imports or execution."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
WT = Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004")
START = "d7c13791b8ade226a7448cacac3a05fdfe7f71c2"
SOURCES = (
    "src/research_workbench/adapters/models/provider_source_closure.py",
    "src/research_workbench/adapters/models/provider_binding.py",
    "src/research_workbench/adapters/models/configured.py",
)
environment = dict(os.environ, GIT_NO_REPLACE_OBJECTS="1", GIT_OPTIONAL_LOCKS="0")
inputs = ROOT / "inputs"
inputs.mkdir(exist_ok=False)
rows = []
for relative in SOURCES:
    command = ["git", "-C", str(WT), "show", START + ":" + relative]
    result = subprocess.run(command, capture_output=True, check=True, env=environment)
    raw = result.stdout
    current = (WT / relative).read_bytes()
    snapshot = inputs / Path(relative).name
    with snapshot.open("xb") as stream:
        stream.write(raw)
    rows.append(dict(
        source=relative, starting_commit=START,
        starting_blob_bytes=len(raw), starting_blob_sha256=hashlib.sha256(raw).hexdigest(),
        snapshot=str(snapshot),
        current_bytes=len(current), current_sha256=hashlib.sha256(current).hexdigest(),
        byte_equal=raw == current,
        newline_normalized_equal=raw.replace(b"\r\n", b"\n") == current.replace(b"\r\n", b"\n"),
        git_show_exit_code=result.returncode,
    ))
summary = dict(
    captured_at=datetime.now(timezone.utc).isoformat(),
    agent_profile="source-derivation reviewer", required_skills=[],
    starting_commit=START, source_files_read=3, source_budget=6,
    analysis_source="immutable Git blobs; current bytes captured only for identity comparison",
    source_mutations=0, tests=0, test_imports=0, api_reads=0, profiler_runs=0,
    sources=rows,
    capture_gap="Visible tool reads/messages are in Codex task history; this bounded capture records immutable inputs and events, not a complete Agent Trace or transport transcript.",
)
with (ROOT / "SOURCE_IDENTITIES.json").open("x", encoding="utf-8") as stream:
    json.dump(summary, stream, ensure_ascii=False, indent=2)
print(json.dumps(summary, ensure_ascii=False))
