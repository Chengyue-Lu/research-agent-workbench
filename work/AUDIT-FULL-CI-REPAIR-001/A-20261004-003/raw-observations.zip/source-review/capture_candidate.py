"""Static candidate diff/source audit only; no test/product module imports."""
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
wt = Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004")
relative = "src/research_workbench/adapters/models/provider_source_closure.py"
raw = (wt / relative).read_bytes()
baseline = (here / "inputs/provider_source_closure.py").read_bytes()
environment = dict(os.environ, GIT_NO_REPLACE_OBJECTS="1", GIT_OPTIONAL_LOCKS="0")
result = subprocess.run(
    ["git","-C",str(wt),"diff","--no-ext-diff","--no-textconv","--",relative],
    capture_output=True, check=True, env=environment,
)
with (here / "candidate-closure.diff").open("xb") as stream:
    stream.write(result.stdout)
with (here / "inputs/candidate_provider_source_closure.py").open("xb") as stream:
    stream.write(raw)
def functions(payload):
    return {node.name:node for node in ast.parse(payload).body if isinstance(node,ast.FunctionDef)}
old, new = functions(baseline), functions(raw)
preserved = (
    "verify_source_closure","read_source_closure","verify_loaded_source_closure",
    "_verify_loaded","_runtime","_read_ref","compiled_functions","code_state",
)
checks = {name:ast.dump(old[name],include_attributes=False) == ast.dump(new[name],include_attributes=False)
          for name in preserved}
summary = dict(
    status="STATIC_AST_REUSE_DIFF_REVIEW_NO_BLOCKER_FOUND",
    captured_at=datetime.now(timezone.utc).isoformat(),
    starting_commit="d7c13791b8ade226a7448cacac3a05fdfe7f71c2",
    candidate_source=relative, candidate_sha256=hashlib.sha256(raw).hexdigest(),
    candidate_bytes=len(raw), diff_sha256=hashlib.sha256(result.stdout).hexdigest(),
    syntax_ast_parse_passed=True, preserved_function_ast_equal=checks,
    public_declarations_raw_retained=True,
    two_archive_passes_and_fresh_claim_compile_checks_retained=True,
    current_design="One tree per module per private archive; no cross-pass claims/compile/result cache.",
    future_only="Cross-pass pure facts reuse; requires separate equivalence/threat checks.",
    tests=0, product_module_imports=0, api_reads=0, source_mutations=0,
    limits=["Static diff review only; no runtime/performance acceptance.",
            "Only three named product source files reviewed; all-repository private consumers not certified.",
            "Root owns necessary tiny/adversarial tests, original failing graph pair and checkpoint."],
)
with (here / "CANDIDATE_STATIC_REVIEW.json").open("x",encoding="utf-8") as stream:
    json.dump(summary,stream,ensure_ascii=False,indent=2)
print(json.dumps(summary,ensure_ascii=False))
