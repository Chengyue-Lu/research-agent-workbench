# Source facts 复用：d7 静态评审

结论：本轮采用每次 private archive 内一份 AST/module。Root 已选保守实现：loaded 的两个 archive pass、每 pass 当前 FileRef/bytes/hash、闭图、claims/compile 派生与 equality、错误/receipt 路径全部保留。当前 diff 静态未发现阻断；两 pass 间纯编译/claims 复用仅留作未来候选。没有 runtime acceptance 或净提速结论；root 负责测试及配对验收。

当前候选 diff 单独保存为 [candidate-closure.diff](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/candidate-closure.diff)，hash/静态核对见 [CANDIDATE_STATIC_REVIEW.json](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/CANDIDATE_STATIC_REVIEW.json)。verify_source/read_source/verify_loaded/_verify_loaded/_runtime/_read_ref/compiled_functions/code_state 的 AST 与 d7 逐项一致；declarations(raw) 保留，新增私有 _declarations(tree)，所有现有 body scan 顺序保留。Builders 在原 _imports parse 位置建树并存私有 archive；调用方不接收可重用事实。直接手工 raw-only archive 的内部调用契约变为含 tree，须由 tiny/相关回归覆盖；本次未认证全仓私有消费者。root 告知初次删第二 pass 的 23 tests PASS 仅为历史中间结果，本报告不以其认证保守候选。

Profile=source-derivation reviewer；Skills=[]。只读源码 3/6，绑定起始 d7c13791b8ade226a7448cacac3a05fdfe7f71c2 的不可变 Git blobs；07:19:02Z 捕获时三个当前文件逐字节一致。0 产品 edits / tests / test imports / API / profiler。写域仅本 source-review。入口：本任务 PLAN、FACT_REUSE_ACCEPTANCE、旧 fixture REPORT、AGENTS/README/docs导航/DEVELOPMENT，以及 primary PROJECT_MEMORY 的 PR139/P234 条目。未读其他 owner 的原始日志。文中行号指向本目录 d7 快照，避免与 root 同时修改源码造成混身份。

## 可证机会及最小设计

1. ClosedSource.lookup 未命中 value 时重新 parse 同一模块（[closure:165](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:165)）；类 attribute、TypeVar、record fields、declarations、class lookup/policies 和 globals 又各有 parse（216、312、330、440、507、542、555）。本文件有 9 个显式 ast.parse call sites。建议给同一私有 archive 提供 lazy tree(name)，所有调用读取同一个 tree；不修改 AST、不将节点或事实暴露为公共对象，validation 结束即释放。先保留原 body scan 和 first-match：lookup 选首个匹配声明，而 declarations 的同名记录可能后覆盖，直接建立 name->last-node index 会改变现有语义。保留 local 优先、active recursion guard、values 的原有缓存规则；本次不扩展 memo 到失败结果或 runtime 值。

2. 未来候选：verify_loaded_source_closure 先经 verify_source_closure 派生 archive，再直接第二次完整派生（[closure:853](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:853)、[closure:855](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:855)）。后续可评估拆“当前输入检查”与“纯 facts 派生”，第二 pass 重读当前 refs/bytes 并逐项确认完整闭图与 document claims；本轮不实施这层复用。_document_archive 的模块数量、总字节、package/path、namespace、dependencies、reached==archive 和全部 claims equality 不减（[closure:583](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:583)）。若改为仅一次读取，原两次读取之间 source drift/reader 副作用的拒绝能力可能改变；须先具名证明等价，不能把后续 inputs.recheck 当作所有直接调用方均有的保障。

3. 当前 AST 的最小生命周期是该次完整 archive 上下文，只依赖已检查的精确 raw 和同进程 parser，不需要跨 pass cache key。未来 compiled_callables 复用还依赖 Python implementation/version/optimization、dont_inherit、固定编译 filename 与 code_state policy（[closure:134](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:134)）。claims/defaults/globals 的 ClosedSource 可沿 alias 读取其他 archive 模块；所以未来 claims 复用不能只以单文件 hash 为键，须核对完整 module->raw、module name/is_package、roots/namespace、dependencies/aliases、compiler/runtime 与 closure/grammar/code policy/trusted-boundaries 身份。本轮不建立这些缓存，更不接受调用方 supplied “validated facts” token。

当前 callers 本身仍有独立入口：_checked_source_closure(actual=True) 先 read，再 loaded verify；observe 的 manifest reader 与 actual graph 检查分别执行；ConfiguredProvider generate 前重新进入实现闭包（[binding:488](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_binding.py:488)、[binding:578](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_binding.py:578)、[configured:230](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/configured.py:230)）。本次建议只优化私有派生；不在这些入口之间传递旧 graph PASS、Provider 实例、receipt 或权限/凭据/journal/freshness 状态。

## 评审必须守住的边界

- _verify_loaded 每次读取 canonical loaded source bytes，并核对 source-root/path、runtime callable 当前 code、descriptor、globals、builtins、closure/defaults、registry globals、aliases、class layout；这些不是可记忆化 facts（[closure:789](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:789)、[closure:811](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:811)、[closure:825](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:825)）。P1 repr outer/inner 的 canonical captured builtins、wrapped identity、field primitive types 和零恶意 callback 继续逐 use 核查（[closure:681](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:681)）。
- 不信任 public document 的 claims 即为 derived facts。必须保持独立派生相等检查；私有 facts 不引用可由 caller 改写的 claims mapping。AST/derived mappings 可变时只由当前 stack 持有、只读使用，不能跨入口或公开返回；保持 source_refs/receipt/checked counters 和 serialized claims 不变。
- 保持异常归一化：verify_source 捕获 SyntaxError/OverflowError，loaded 层额外有 OSError 且消息不同；production 捕获两类集合（[closure:632](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:632)、[closure:859](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:859)、[closure:909](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:909)）。拆 helper 后不得让原 SourceClosureError 变为裸 SyntaxError 或改变先拒绝的错误类别。lazy parsing 有助于维持首次触发顺序。
- 校验器属于一等闭包源码：新 helper/class/method 的真实 code/default/global/class 状态须由新 target 源码独立派生并比较，不得从 attest 集剔除缓存实现或相信其“已安全”标志。优先复用现有 imports/简单 private structures，避免新 dataclass/closure/default grammar 引入额外自校验问题。旧 d7 archive 不能自动认证已改 loaded helper；root 需新 source archive 与独立 cold 重建。produce_source_closure 的 _verify_loaded 仍执行（[closure:896](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/inputs/provider_source_closure.py:896)）。

## root 的必要验收

1. 同一完整 archive 的 old/new tiny：全部 claims、compiled hashes、receipt 和 checked counters 逐项等值；parse/compile/claims 次数降低。保留重复声明顺序、recursive values、TypeVar annotation-only、record/class/default grammar 和错误类别的具名控制。
2. warm facts 后改本模块/依赖模块 bytes、coherent 重签 false claims/defaults、roots/package/alias/dependency/extra node，以及两次读取间 drift；仍 fresh 拒绝。相同 raw 下篡改当前 code/defaults/global alias/descriptor/class/wrapper/outer-inner builtins 仍拒绝，恶意 metadata callback=0。
3. 私有数据不逃逸、不允许 cached-object mutation 或并发上下文共用旧事实；cold 新解释器不携带 warm facts，不执行归档源码/Provider/credential/network。保留现有正例、负例、missing/extra use refs 和全部原断言。
4. 配对测同 source 集/Python/resources/env 的原失败 graph cases，不插桩；producer/setup/validator/cold 分开。旧 e939 instrumented 32 archive / 2706 claims / 30k AST 只说明候选，不能作为 d7 未插桩 baseline、理论可省时间或全 CI 减幅。新 target 组件结果、跨 owner 审查和新鲜完整 checkpoint 分别验收，budget/coverage/选择不降。

## 身份、预算及 capture gap

| d7 source | SHA-256 |
|---|---|
| provider_source_closure.py | 441bb66b2ab2f69cb721950e54e15690ce6aafd8bcfbbe2dd4162bbe2786ee96 |
| provider_binding.py | 45ae1480039e7bc13c7a5e988a70bd6773ec9e4e6b1e7530be9867ae05ac349e |
| configured.py | 616d6b0d33c68fb1a8222ad22a9e719fbe748a99cb8148a2f78f65aabbccf043 |

详见 [SOURCE_IDENTITIES.json](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/source-review/SOURCE_IDENTITIES.json) 及三个 inputs 快照。预算 15 min，已读源码 3/6，无新增执行观察；后续候选实际安全/速度均待 root 验证。本报告是输入评审，不是候选实现 acceptance。

可见消息/工具输出保留于 Codex 当前任务历史；本目录记录 immutable 输入、事件摘要和正式结论，无法声称完整 transport transcript / Agent Trace。输出截断范围已由必要窄行重读补齐；无隐藏推理/参数/凭据捕获。未写共享 PROJECT_MEMORY，root 可按本报告更新该任务摘要。
