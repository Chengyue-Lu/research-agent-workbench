"""Prepare remaining original controls; no test execution."""
from pathlib import Path
import ast, hashlib, json

ROOT = Path(__file__).resolve().parent
WT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
PY311 = 'D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917/venv311/Scripts/python.exe'
PY313 = 'D:/lcy/develop/_assessments/rwb-ci-schema-parse-20260917/venv313/Scripts/python.exe'
path = WT / 'tests/test_provider_binding_graph.py'
tree = ast.parse(path.read_bytes())
cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'ProviderBindingGraphTests')
names = sorted('tests.test_provider_binding_graph.ProviderBindingGraphTests.' + n.name
               for n in cls.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_'))
paired = {'tests.test_provider_binding_graph.ProviderBindingGraphTests.test_v12_cold_replay_rejects_helper_source_drift_without_provider_reuse',
          'tests.test_provider_binding_graph.ProviderBindingGraphTests.test_v12_rehashed_use_facts_require_exact_source_closure_per_invocation'}
remaining = [n for n in names if n not in paired]
assert len(names) == 11 and len(remaining) == 9
cold = next(n for n in remaining if n.endswith('.test_v12_baseline_consumes_graph_sources_at_each_use_and_replays_cold'))
rows = [dict(python='3.11', scope='nine remaining original graph controls',
             argv=[PY311, '-B', '-X', 'utf8', str(ROOT / 'run_local.py'), '--root', str(WT), '--output', str(ROOT / 'remaining-graph311'), *remaining]),
        dict(python='3.13', scope='original genuine cold-replay positive',
             argv=[PY313, '-B', '-X', 'utf8', str(ROOT / 'run_local.py'), '--root', str(WT), '--output', str(ROOT / 'cold-graph313'), cold])]
(ROOT / 'graph-control-invocations.json').write_text(json.dumps(dict(status='PREPARED_NOT_EXECUTED',
    tests_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), invocations=rows), indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status='PREPARED_NOT_EXECUTED', original_methods=len(names), remaining=len(remaining))))
