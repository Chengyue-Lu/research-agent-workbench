from datetime import datetime, timezone
import argparse, hashlib, io, json, os, re, stat, subprocess, sys, zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
WT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
parser = argparse.ArgumentParser()
parser.add_argument('--run', type=int, required=True)
parser.add_argument('--head', required=True)
parser.add_argument('--base', required=True)
args = parser.parse_args()
RUN, HEAD, BASE = args.run, args.head, args.base
assert RUN > 0 and re.fullmatch('[0-9a-f]{40}', HEAD) and re.fullmatch('[0-9a-f]{40}', BASE)
ENV = {k: v for k, v in os.environ.items() if k.upper() not in {'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY'}}

def rawapi(path):
    return subprocess.check_output(['gh', 'api', 'repos/Chengyue-Lu/research-agent-workbench/' + path], env=ENV)

def api(path):
    return json.loads(rawapi(path))

local_summary = json.loads((ROOT / 'committed-validation/summary.json').read_bytes())
assert local_summary['status'] == 'PASS' and local_summary['head'] == HEAD and local_summary['base'] == BASE
run = api('actions/runs/' + str(RUN))
assert run['head_sha'] == HEAD and run['run_attempt'] == 1 and run['event'] == 'pull_request'
assert run['head_branch'] == 'fix/full-ci-post-optimization-20261004'
assert run['path'].split('@')[0] == '.github/workflows/ci_components.yml'
artifacts = api('actions/runs/' + str(RUN) + '/artifacts?per_page=100')
matches = [row for row in artifacts['artifacts'] if row['name'] == 'component-plan' and not row['expired']]
assert len(matches) == 1, 'Plan not ready or ambiguous; do not download automatically'
OUT = ROOT / 'hosted-plan'
OUT.mkdir(exist_ok=False)

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

save('run.json', run)
save('artifacts.json', artifacts)
artifact = matches[0]
save('artifact.json', artifact)
assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD
raw = rawapi('actions/artifacts/' + str(artifact['id']) + '/zip')
(OUT / 'official-plan.zip').write_bytes(raw)
assert len(raw) == artifact['size_in_bytes'] and artifact['digest'] == 'sha256:' + hashlib.sha256(raw).hexdigest()
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    names = z.namelist()
    assert len(names) == len(set(names)) == 1 and names[0] == 'plan.json' and z.testzip() is None
    for item in z.infolist():
        p = PurePosixPath(item.filename)
        assert not p.is_absolute() and '..' not in p.parts and ':' not in item.filename and '\\' not in item.filename
        assert not stat.S_ISLNK(item.external_attr >> 16)
    plan_raw = z.read('plan.json')
(OUT / 'official-plan.json').write_bytes(plan_raw)
plan = json.loads(plan_raw)
sys.path.insert(0, str(WT / '.github/scripts'))
import run_component_ci as runner
unsigned = dict(plan)
supplied = unsigned.pop('plan_sha256')
assert hashlib.sha256(runner.canonical(unsigned)).hexdigest() == supplied
TARGET = plan['head_sha']
assert plan['base_sha'] == BASE and plan['profile'] == 'component'

def git(*argv):
    return subprocess.check_output(['git', '-C', str(WT), *argv], env=ENV)

available = subprocess.run(['git', '-C', str(WT), 'cat-file', '-e', TARGET + '^{commit}'], env=ENV,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if available.returncode:
    done = subprocess.run(['git', '-C', str(WT), 'fetch', '--no-tags', '--no-write-fetch-head', 'origin', TARGET],
                          env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT / 'fetch.log').write_bytes(done.stdout)
    assert done.returncode == 0
assert git('rev-list', '--parents', '-n', '1', TARGET).decode().split() == [TARGET, BASE, HEAD]
tree = git('rev-parse', TARGET + '^{tree}').decode().strip()
assert tree == git('rev-parse', HEAD + '^{tree}').decode().strip()
actual = runner.make_plan(WT, BASE, TARGET, 'component')
assert runner.canonical(actual) == runner.canonical(plan)
local = json.loads((ROOT / 'committed-validation/component-plan.json').read_bytes())
assert local['selected_tests'] == plan['selected_tests'] and len(plan['selected_tests']) == 36
for key in ('python_versions', 'smoke', 'install', 'docs', 'contracts'):
    assert local[key] == plan[key]
summary = dict(status='PASS_OFFICIAL_COMPONENT_PLAN_GIT_BINDING', at=datetime.now(timezone.utc).isoformat(),
    run=RUN, head=HEAD, base=BASE, target=TARGET, tree=tree, plan_sha256=supplied,
    artifact=artifact['id'], modules=36, python_versions=plan['python_versions'], smoke=plan['smoke'],
    install=plan['install'], zip_api_sha_size_crc_safepath=True,
    git_parents_tree_and_canonical_plan=True, tests_executed=0, native_proof=False, download_count=1)
save('summary.json', summary)
print(json.dumps(summary))
