"""Execute the prepared remaining controls once, after timed pairs finish."""
from pathlib import Path
import hashlib, json, os, subprocess, time

ROOT = Path(__file__).resolve().parent
WT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
plan = json.loads((ROOT / 'graph-control-invocations.json').read_bytes())
assert plan['status'] == 'PREPARED_NOT_EXECUTED'
assert hashlib.sha256((WT / 'tests/test_provider_binding_graph.py').read_bytes()).hexdigest() == plan['tests_sha256']
source = WT / 'src/research_workbench/adapters/models/provider_source_closure.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == 'c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3'
covered = json.loads((ROOT / 'baseline/coverage-candidate/execution.json').read_bytes())
assert covered['measurement_capture_valid'] and covered['source_runtime_unchanged']
assert len(covered['records']) == 2 and all(row['returncode'] == 0 for row in covered['records'])
OUT = ROOT / 'graph-control-execution'
OUT.mkdir(exist_ok=False)
rows = []
for row in plan['invocations']:
    start = time.perf_counter()
    done = subprocess.run(row['argv'], cwd=WT, capture_output=True, timeout=480)
    label = row['python']
    (OUT / (label + '.stdout.txt')).write_bytes(done.stdout)
    (OUT / (label + '.stderr.txt')).write_bytes(done.stderr)
    rows.append(dict(scope=row['scope'], argv=row['argv'], returncode=done.returncode,
                     wall_seconds=time.perf_counter() - start))
    (OUT / 'execution.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(python=label, returncode=done.returncode, scope=row['scope'])), flush=True)
    assert done.returncode == 0
assert hashlib.sha256(source.read_bytes()).hexdigest() == 'c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3'
