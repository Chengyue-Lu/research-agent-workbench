# Provider source-closure repeated-parse optimization

2026-10-04. Owner Chengyue-Lu; Provider cross-owner acceptance let778750-cpu.
Draft PR139, accepted base c80ec014925f0cbbbaef5486bce8422a5b4f73fb;
starting candidate d7c13791b8ade226a7448cacac3a05fdfe7f71c2.

## Problem and change

Actual c80 full run37176315620 failed two Python3.11 graph baseline cases on the
original 120-second post-call budget. Its Python3.13 repr failure and missing
coverage execution projection are separate failures. Original raw receipts retain
their identities. Old global94.387942% is diagnostic, not a passed quality gate.

Each private archive pass now parses each just-read, hash-checked module once and
shares that tree for its pure syntax consumers. Both original fresh archive passes,
FileRef/source bytes/hash, closed-set, claims/compile and current loaded runtime
checks remain. No acceptance result, module or cross-call cache is retained. Public
document/receipt contain no tree; declarations(raw) remains a fresh public entry.
The private AST is mutable, with read-only consumers, not an immutable trust token.
CI selection/workflows/budgets/quality thresholds and every old test remain.

Final source SHA256 c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3;
test SHA256 52c10a34efbf80fce3829eec77a950f43e73e9a9f97826d2ff5c7d9e01bce96a.

## Verified local results

The same frozen normal runner executes the two original methods in fresh Python3.11
children, serially, with identical original fixtures, Runtime178, generated pin,
interpreter, class setup and budgets. Both old and new arms passed. No profiler or
trace was enabled. Credential resolution and transport request counts each remain1.

| Original method | Old seconds | Candidate seconds | Local decrease |
| --- | ---: | ---: | ---: |
| cold replay/helper source drift | 77.9420941 | 28.5015591 | 63.43% |
| rehashed use facts/missing and extra refs | 79.8769100 | 29.9345113 | 62.52% |

This is one local matched normal pair, not a whole-CI or coverage budget result.
PAIR_SUMMARY and its manifest bind all source/runtime/environment bytes and native
results. These method intervals include setup/cleanup; class/import/runner overhead
is recorded separately and is not attributed to the method or its production call.

A separate tiny four-module equivalence check reduced direct parses54→8 while
keeping fresh reads8 and compile calls8, with equal public documents and receipts.
Two independent Python versions each passed45 safety checks, with zero attack
callbacks: successful verification did not authorize later same-path/size/mtime
source drift, claims/compiler/runtime/defaults/alias/code/captured-builtins changes.
Source identities remained unchanged. Two preparatory probe harness failures are
preserved; they were not product failures or successful performance evidence.

Source-closure23 tests passed on both Python versions; the two final strengthened
methods then passed on each. The current exact23 methods also passed under a
source-only branch collector on3.11. Its local diagnostic694/748 lines and357/428
branches (92.78/83.41) are a diagnostic without repository or critical policy
evaluation, and are not reported as a gate verdict. Existing mapped graph cases and a fresh checkpoint retain
their separate obligations; no test is added merely to echo implementation.

## Coverage-style paired result

The coverage-style original-method pair used the unchanged CI helper's
actual path-source, branch=True and complementary-omit configuration. Its old/new
rcfiles are byte-identical. This uses historical c80 plan only as filter data;
it is not signed as candidate authority or accepted as a full-suite result.
All four old/new method executions PASS, each with one credential resolution and
one request. Actual trace is coverage.CTracer, profile is absent, captured data and
source/runtime before-after checks pass, and each saved SQLite records branch arcs.

| Original method | Old covered seconds | Candidate covered seconds | Local decrease |
| --- | ---: | ---: | ---: |
| cold replay/helper source drift | 97.7203480 | 45.2635309 | 53.68% |
| rehashed use facts/missing and extra refs | 98.9596414 | 47.4082571 | 52.09% |

This second pair is local and uses the same installed coverage7.16.1 and Python,
not the original hosted environment. The old arm also PASS: hosted budget failure
was not reproduced locally. The original120-second production guard remains and
the candidate completes its legal baseline and adversarial assertions; method
intervals are not the production budget intervals, so no numeric guard margin is
claimed. There is no repository coverage threshold or policy gate evaluation.
COVERED_SUMMARY/REPORT/MANIFEST retain all source/config/runtime/data identities.

All11 original graph methods now have native3.11 PASS evidence, including both
paired cases and the remaining controls. The first remaining-nine invocation had
8PASS plus one cold-child import failure because the local runner did not pass
src to the subprocess; its actual failure is preserved. Corrected only the child
PYTHONPATH and reran only that affected method, which PASS. No successful method
was repeated. The original isolated (-I) genuine cold-replay positive also PASS on
3.13, with original no-Provider-reexecution/credential/network assertions.

local-final-summary.json indexes these native receipts without normalizing their
historical outcomes. Exact committed validation, current hosted component proof
and cross-owner/checkpoint acceptance remain pending. Measured production/test
bytes stay equal to the final candidate; later workstream navigation and A003
freeze are outside the timed windows and retain their separate identities.

## Evidence and limits

Normal pair: baseline/PAIR_REPORT.md, baseline/PAIR_SUMMARY.json and manifests.
Independent safety: independent/REPORT.md and summary.json. Static source review:
source-review/REPORT.md. Source-only collector: source-coverage/summary.json.
Preparation tool/import failures and superseded local source/test hashes remain in
WORKLOG and their original directories. Complete event transport capture is
unavailable; the compact archive must retain capture-gap and scoped raw evidence.
No Ready, merge, release, tag, main or other-owner branch operation is authorized
by this follow-up. Main checkout and user config/AGENTS are preserved.
