from dataclasses import dataclass
from time import monotonic
from .helper import helper as source_alias

POLICY_VERSION="safe"

def typed(value=3,*,clock=monotonic):
    return source_alias(value)

@dataclass(init=False,eq=False)
class Record:
    value: object
