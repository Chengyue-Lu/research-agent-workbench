PREFIX="ok:"

def helper(value,suffix=":end"):
    return PREFIX+str(value)+suffix
