# committed validation v1：历史 BLOCK

工具 SHA256 3f57fdb6c177529d750159cf3a478a0575eaa80a7400b89aa2ec95786a8ed242。第49行从 WT 读取 ZIP，而43–45行的 MANIFEST 哈希验证 HEAD Git blobs；ZIP校验对象没有绑定到被声明的 committed container。只重新压缩 WT ZIP、保持 member names/content 不变时，这一段 CRC/index/member hashes 仍可通过。其余 preflight 若成立，摘要将声明 committed_archive_bytes=True，但该 ZIP 的 CRC 校验并非针对 committed blob。

要求读取 HEAD ZIP blob 或先断言 WT ZIP 与 HEAD bytes 完全相同。root 已保存 committed_validation.v1.py 原 bytes 并在 v2 采用 BytesIO(HEAD blob)；本目录保留原 BLOCK，不改工具、不执行任何 tool/API/tests/producer。
