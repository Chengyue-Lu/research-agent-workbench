# committed validation v2：静态复核

PASS，blockers=[]。当前工具 SHA256 4a98f0e5097a4a4a84198b391f2ccafe627b7f05c080e1815ee115e4ea31410b，原 v1 SHA 3f57fdb6c177529d750159cf3a478a0575eaa80a7400b89aa2ec95786a8ed242 与已保留 committed_validation.v1.py 相同。只审查准备中的脚本，不运行。未来 commit/head、pending body template 和 committed-validation 输出尚未形成，不将这些预期输入记为已有验收结果。

精确文本比较证明 v2 仅增加 io、review source 的 WT/hash 检查、HEAD ZIP 的 BytesIO 读取，以及 runner/governance 导入文件的 WT==HEAD 断言；其他控制原样保留。

- 23–30行绑定新 HEAD 的父提交 OLD=d7、merge-base BASE=c80、独立 review PASS/blockers[]；四个 reviewed source 的 HEAD blob 与当前 WT bytes 均须匹配独立 source hashes。
- 32–41行保留 policy/selectors/workflows/graph caller 等 unchanged bytes 与 A001/A002 diff-empty 控制；42–58行对 A003 manifest 的 committed bytes/size/hash、capture source hash、HEAD ZIP CRC、完整 member/index列表与各member hash/size进行检查。ZIP现在从 HEAD blob打开，历史 COMMITTED_ZIP_OBJECT_MISMATCH 已修复。
- 60–77行静态检查 test methods 21→23，旧methods key/body AST全部保留；verify_source_closure/read_source_closure/verify_loaded_source_closure/_verify_loaded/_runtime/_read_ref/compiled_functions/code_state八项 AST完全相同。它们是未来运行时对真实 Git blobs 的断言，此审查没有运行 AST checker。
- 79–90行在导入前绑定 runner/governance WT源码到 HEAD，生成并重读组件plan，再与OLD的36项 selected_tests及python_versions/smoke/install/docs/contracts比较。仅plan生成，没有执行组件suite。
- 91–93行仅一次固定PR139只读API，必须draft、远端head仍OLD、base仍c80。API位于commit/archive/source/AST/plan门禁后。94–115行要求真实pendingtemplate，构造未发布body与本地governance event/report，metadata_published=False，governance errors不能得PASS。没有PR写操作、push或CI rerun。

执行 scope 仅未来新commit形成、相应A003和pendingtemplate准备好后的单次root-authorized checker；当前为STATIC_PREPARATION。script在最前新建专属输出目录exist_ok=False，失败部分保留，不能当作已完成receipt重复覆盖。不得使用-O关闭assert。未验证实时PR状态、未生成commit/head/template、未执行plan/governance/API；没有candidate/full CI PASS。完整Agent Trace不可得，capture gap保留。历史BLOCK保存在v1/。
