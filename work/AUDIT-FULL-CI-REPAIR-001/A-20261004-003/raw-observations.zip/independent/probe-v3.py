"""Independent tiny synthetic probes, no actual provider graph or author tests."""
import ast,builtins,copy,dataclasses,hashlib,importlib,importlib.util,json,os,reprlib,sys,time,traceback
from pathlib import Path
from types import FunctionType
from unittest.mock import patch
WT=Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004")
SOURCE=WT/"src/research_workbench/adapters/models/provider_source_closure.py"
EXPECTED="c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3"
ROOT=Path(__file__).resolve().parent/("runtime-"+str(sys.version_info.major)+str(sys.version_info.minor))
ROOT=ROOT.with_name(ROOT.name+"-v3")
ROOT.mkdir(exist_ok=False)
CLOCK=time.monotonic
start=CLOCK()
result={"status":"RUNNING","python":sys.version,"checks":[],"attack_callbacks":[],"scope":"3 synthetic modules; no actual provider graph"}
def check(name,ok,detail=None):
    if CLOCK()-start>58:raise AssertionError("58-second budget")
    result["checks"].append({"name":name,"pass":bool(ok),"detail":detail})
    if not ok:raise AssertionError(name)
def reject(name,run,text):
    try:run()
    except closure.SourceClosureError as exc:check(name,text in str(exc),str(exc))
    else:check(name,False,"unexpected acceptance")
def attack(*a,**k):
    result["attack_callbacks"].append("attack");raise AssertionError("attack callback ran")
class TrapDict(dict):
    def __getitem__(self,name):
        result["attack_callbacks"].append("dict getter");return super().__getitem__(name)
class TrapMapping:
    def __getitem__(self,name):
        result["attack_callbacks"].append("mapping getter");return vars(builtins)[name]
class MetadataTrap:
    def __getattribute__(self,name):
        result["attack_callbacks"].append("metadata getter");raise AssertionError(name)
def clone(fn,mapping):
    g=fn.__globals__;before=g["__builtins__"];g["__builtins__"]=mapping
    try:new=FunctionType(fn.__code__,g,fn.__name__,fn.__defaults__,fn.__closure__)
    finally:g["__builtins__"]=before
    new.__dict__.update(fn.__dict__);new.__module__=fn.__module__;new.__qualname__=fn.__qualname__
    return new
def plain_only(v):
    if type(v) is dict:return all(type(k) is str and k not in {"tree","raw","archive"} and plain_only(x) for k,x in v.items())
    if type(v) is list:return all(plain_only(x) for x in v)
    return type(v) in {str,int,bool,float,type(None)}
try:
    result["source_hash_before"]=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    check("frozen source",result["source_hash_before"]==EXPECTED)
    spec=importlib.util.spec_from_file_location("independent_closure_review",SOURCE)
    closure=importlib.util.module_from_spec(spec);sys.modules[spec.name]=closure;spec.loader.exec_module(closure)
    src=ROOT/"source";pkg=src/"rwb_independent_facts";pkg.mkdir(parents=True)
    texts={"__init__.py":"","helper.py":'PREFIX="ok:"\n\ndef helper(value,suffix=":end"):\n    return PREFIX+str(value)+suffix\n',"provider.py":'from dataclasses import dataclass\nfrom time import monotonic\nfrom .helper import helper as source_alias\n\nPOLICY_VERSION="safe"\n\ndef typed(value=3,*,clock=monotonic):\n    return source_alias(value)\n\n@dataclass(init=False,eq=False)\nclass Record:\n    value: object\n'}
    for name,txt in texts.items():(pkg/name).write_text(txt,encoding="utf-8",newline="\n")
    sys.path.insert(0,str(src));provider=importlib.import_module("rwb_independent_facts.provider");helper=sys.modules["rwb_independent_facts.helper"]
    doc=closure.produce_source_closure((provider.__name__,),source_root=src,project_root=ROOT,archive_prefix="archive")
    class Reader:
        def read_bytes(self,ref):return ROOT.joinpath(*ref["path"].split("/")).read_bytes()
    reader=Reader()
    def verify(document=doc,read_bytes=None):return closure.verify_loaded_source_closure(document,read_bytes=reader.read_bytes if read_bytes is None else read_bytes,source_root=src)
    warm=verify();check("warm success",warm["actual_verified"] and warm["module_count"]==3)
    check("returned document receipt no private AST facts",plain_only(doc) and plain_only(warm))
    check("document JSON roundtrip",json.loads(json.dumps(doc))==doc)
    counts={"archive":0,"parse":0,"private_parse":0,"compile":0};observed=[];parse_callers=[]
    orig_a=closure._document_archive;orig_p=closure.ast.parse;orig_c=closure.compiled_functions
    def observe_parse(*a,**k):
        counts["parse"]+=1
        caller=traceback.extract_stack(limit=2)[0]
        parse_callers.append({"filename":caller.filename,"name":caller.name,"line":caller.lineno})
        if Path(caller.filename)==SOURCE and caller.name=="_document_archive":counts["private_parse"]+=1
        return orig_p(*a,**k)
    def observe_compile(*a,**k):counts["compile"]+=1;return orig_c(*a,**k)
    def observe_archive(*a,**k):
        counts["archive"]+=1;archive=orig_a(*a,**k);observed.append((archive,{n:ast.dump(v["tree"],include_attributes=True) for n,v in archive.items()}));return archive
    with patch.object(closure.ast,"parse",observe_parse),patch.object(closure,"compiled_functions",observe_compile),patch.object(closure,"_document_archive",observe_archive):repeated=verify()
    check("repeated receipt equivalent",repeated==warm)
    check("two fresh full passes",counts["archive"]==2 and counts["private_parse"]==6 and counts["compile"]==6,{"counts":counts,"parse_callers":parse_callers})
    check("each pass private trees distinct",all(observed[0][0][n]["tree"] is not observed[1][0][n]["tree"] for n in doc["modules"]))
    check("consumers leave private trees unchanged",all(ast.dump(v["tree"],include_attributes=True)==snap[n] for archive,snap in observed for n,v in archive.items()))
    declarations=closure.declarations(texts["provider.py"].encode());declarations["typed"].name="external_mutation"
    check("public declarations raw preserved isolated",set(closure.declarations(texts["provider.py"].encode()))=={"typed"} and verify()==warm)
    raw=json.dumps(doc,sort_keys=True).encode();(ROOT/"document.json").write_bytes(raw);outer={"path":"document.json","sha256":hashlib.sha256(raw).hexdigest()}
    returned=closure.read_source_closure(reader,outer);check("read returns plain original document",returned==doc and plain_only(returned))
    reject("warm wrong outer hash",lambda:closure.read_source_closure(reader,dict(outer,sha256="0"*64)),"FileRef hash differs")
    ref=doc["modules"][helper.__name__]["source_ref"];ap=ROOT.joinpath(*ref["path"].split("/"));old=ap.read_bytes();mtime=ap.stat().st_mtime_ns
    try:
        altered=old.replace(b"ok:",b"zz:",1)
        check("same source length and different bytes",len(altered)==len(old) and altered!=old)
        ap.write_bytes(altered);os.utime(ap,ns=(mtime,mtime));reject("warm same path mtime source drift",verify,"FileRef hash differs")
    finally:ap.write_bytes(old)
    reads={}
    def drift_reader(r):
        key=r["path"];reads[key]=reads.get(key,0)+1;value=reader.read_bytes(r)
        return value+b"# second pass\n" if key==ref["path"] and reads[key]==2 else value
    reject("first to second pass archive drift",lambda:verify(read_bytes=drift_reader),"FileRef hash differs")
    check("second helper read happened",reads.get(ref["path"])==2,reads)
    bad=copy.deepcopy(doc);bad["compiler"]["optimization"]+=1;reject("warm compiler flag drift",lambda:verify(bad),"compiler/runtime differs")
    bad=copy.deepcopy(doc);bad["modules"][provider.__name__]["claims"]["compiled_callables"]["typed"]="0"*64
    reject("coherent false code claims",lambda:verify(bad),"source-derived claims differ")
    bad_raw=json.dumps(bad,sort_keys=True).encode();(ROOT/"false-claims.json").write_bytes(bad_raw)
    bad_ref={"path":"false-claims.json","sha256":hashlib.sha256(bad_raw).hexdigest()}
    reject("coherently pinned false claims independent read",lambda:closure.read_source_closure(reader,bad_ref),"source-derived claims differ")
    bad=copy.deepcopy(doc);bad["modules"][provider.__name__]["claims"]["defaults"]["typed"]["positional"]=[9]
    with patch.object(provider.typed,"__defaults__",(9,)):
        reject("coherent false runtime defaults claims",lambda:verify(bad),"source-derived claims differ");reject("warm runtime defaults drift",verify,"defaults differ")
    with patch.object(provider.typed,"__kwdefaults__",{"clock":attack}):reject("warm native default drift",verify,"defaults differ")
    with patch.object(helper,"PREFIX","changed"):reject("warm global policy drift",verify,"global policy differs")
    with patch.object(provider,"source_alias",attack):reject("warm alias drift",verify,"import alias differs")
    during_read_counts={}
    def runtime_drift_reader(r):
        key=r["path"];during_read_counts[key]=during_read_counts.get(key,0)+1
        if key==ref["path"] and during_read_counts[key]==2:helper.PREFIX="during-validation"
        return reader.read_bytes(r)
    old_prefix=helper.PREFIX
    try:reject("same invocation runtime drift in trusted reader",lambda:verify(read_bytes=runtime_drift_reader),"global policy differs")
    finally:helper.PREFIX=old_prefix
    original_code=provider.typed.__code__
    try:
        provider.typed.__code__=original_code.replace(co_firstlineno=original_code.co_firstlineno+1)
        reject("warm code fingerprint drift",verify,"code differs")
    finally:provider.typed.__code__=original_code
    fn=clone(helper.helper,{**vars(builtins),"str":attack})
    with patch.object(helper,"helper",fn),patch.object(provider,"source_alias",fn):reject("warm ordinary builtins drift",verify,"builtin reference differs")
    with patch.object(closure.time,"monotonic",attack):reject("warm native identity drift",verify,"native clock reference differs")
    lp=pkg/"helper.py";old=lp.read_bytes()
    try:lp.write_bytes(old+b"# live drift\n");reject("warm live source bytes drift",verify,"loaded source bytes differ")
    finally:lp.write_bytes(old)
    bad=copy.deepcopy(doc);bad["modules"]["rwb_independent_facts.extra"]=copy.deepcopy(bad["modules"][helper.__name__])
    reject("extra closed-set module",lambda:verify(bad),"module location differs")
    normal=object.__new__(provider.Record);object.__setattr__(normal,"value",1)
    recursive=object.__new__(provider.Record);object.__setattr__(recursive,"value",recursive)
    check("normal trusted generated repr",repr(normal)=="Record(value=1)")
    check("recursive trusted generated repr",repr(recursive)=="Record(value=...)")
    wrapper=vars(provider.Record)["__repr__"]
    with patch.object(provider.Record,"injected",wrapper,create=True):reject("warm P1 wrong slot",verify,"undeclared runtime class callable")
    for name,mapping in [("poison dict",{**vars(builtins),"id":attack}),("canonical copied dict",dict(vars(builtins))),("dict subclass",TrapDict(vars(builtins))),("custom mapping",TrapMapping())]:
        replacement=clone(wrapper,mapping)
        check("P1 clone identity "+name,replacement.__code__ is wrapper.__code__ and replacement.__globals__ is wrapper.__globals__ and replacement.__closure__ is wrapper.__closure__ and replacement.__wrapped__ is wrapper.__wrapped__)
        with patch.object(provider.Record,"__repr__",replacement):reject("warm P1 captured "+name,verify,"undeclared runtime class callable")
    inner=clone(wrapper.__wrapped__,{**vars(builtins),"id":attack});namespace=closure._recursive_repr_namespace(wrapper)
    replacement=reprlib.recursive_repr()(inner) if namespace is reprlib else dataclasses._recursive_repr(inner)
    with patch.object(provider.Record,"__repr__",replacement):reject("warm P1 inner captured builtins",verify,"undeclared runtime class callable")
    with patch.object(provider.Record,"__dataclass_fields__",{"value":MetadataTrap()}):reject("P1 metadata callback trap",verify,"runtime dataclass metadata differs")
    check("restored fresh verification",verify()==warm);check("zero custom callbacks",result["attack_callbacks"]==[])
    result["source_hash_after"]=hashlib.sha256(SOURCE.read_bytes()).hexdigest();check("unchanged source hash",result["source_hash_before"]==result["source_hash_after"])
    result["status"]="PASS"
except BaseException as exc:
    result["status"]="FAIL";result["error"]={"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()}
finally:
    result["source_hash_after"]=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    result["elapsed_seconds"]=CLOCK()-start;result["actual_graph_executions"]=0
    (ROOT/"raw.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");print(json.dumps(result,ensure_ascii=False))
sys.exit(0 if result["status"]=="PASS" else 1)
