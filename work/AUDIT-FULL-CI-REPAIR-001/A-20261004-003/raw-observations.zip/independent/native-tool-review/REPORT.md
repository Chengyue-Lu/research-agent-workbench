# 新 native 审核工具静态复核

结论：PASS，blockers=[]。工具 SHA-256 为 a90d7577f5ad4b16524af7f51490520cbddb7ee92b9d4293ee579fc54e0bffd1。本结论覆盖未绑定身份的准备工具；未执行 auditor、API、下载、tests、case 或 producer。新 run/head/target/tree/plan/governance 仍未绑定，当前 argv 是占位模板。

## 完整库存和顺序

仅读取八个工具/准备输入，前后哈希全部一致。独立按列表重算：538 个 selected 方法、7 个不相交的精确 short 方法、545 个唯一有序预期 ID、36 个完整模块，规范库存 digest=77a6366bb2905f54b2c23f87afc77ca81879dec53d8ad9541f956c2271699f7b。按排序模块 ordinal modulo 4 独立重算四片，分别 145/137/140/123，逐 ID、逐位置与 expected-native-inventory.json 和 preparation.json 完全一致。accepted530 和 d7的536方法 ID 均完整包含；新增 accepted→candidate 8 个、d7→candidate 2 个具名方法与准备列表一致。数据检查及完整输入哈希保存在 STATIC_CHECKS.json 与 summary.json。

工具 audit_native.py:96–307 在终态从绑定 TARGET 的真实源码建立 exact inventory，支持的 direct TestCase 形态及 imported helper 形态有明确静态证明，不导入测试或运行 TestLoader；未支持的继承、动态生成、collection hook 等 fail closed。:533–553 从 base/d7/target 逐模块检查530→538、536→538和旧方法完整 AST 相同，随后建立完整源码预期。此次只静态核该逻辑及已冻结准备列表，尚未获得未来 TARGET 的动态执行回执。

:660、:666–667、:690–703 强制每片 native inventory 与完整 expected list 相等，记录顺序与源码所有权顺序相等，最终收到记录为唯一完整不相交并集。旧反例仍必拒：删去 test_undeclared_builtin_shadow_is_rejected 并换入同 owner 的虚构 ID，可保留545个及同 owner 分片数量，却不满足:660；保持同一分片 ID 集合但交换两项不满足:666。旧543库存及22-check本地回执不满足545/45门禁。这些是静态谓词反例，不是执行 auditor 或测试。

## 身份及证据门禁

七个 adaptation.diff hunk 的新段均与当前工具逐行相等；反向重构精确得到先前已审 v2 helper 的原始 SHA 1ffd6f9244887805b415eae1b5c2c08ad5a341c566834fe2f202143f07afec6c，确认未在变化外缩小原门禁。准备 MD 哈希 bb31151c2ff7a638c2958aeac3fed632e2962ccc6fed9ed8f353df5e46d80091，单次 prepare 回执绑定当前 helper，记载0 API/download/tests/module imports/producer；所有最终身份为 null。

:759–787 要求真实新 run/attempt/head/base/target/tree/plan/A003/governance/tool-review 全字段，base=c80，head≠d7；本次 PASS summary 文件哈希和 helper 哈希必须匹配。:492–567 在首次 API 前检查实际 committed-validation PASS 的身份/23方法/旧档案/source c309及test52/治理检查、官方缓存 plan 的完整身份/规范 digest、缓存 zip API SHA/size/CRC，Git HEAD、merge parents、head/merge同tree及接受的 producer 源码。:623–630 再要求真实 component 与同 head governance run completed/success，成功后才读取 native zip。

:369–421 对 A003 MANIFEST 加四个 payload（共五件）核 committed bytes、schema、当前 source/hash、RAW_INDEX、ZIP 唯一成员/CRC/大小/SHA/路径；各 WT payload 已先断言等于 HEAD blob，没有旧 committed-helper v1 打开未绑定 WT zip 的空隙。:346–367 绑定此前本次候选 c309/52 的两 Python 各45 checks/0 callbacks，且终态 TARGET bytes一致；该本地回执不会被宣称为 hosted额外subtests。

SOURCE_BINDINGS 的 input_identities 保留准备时 committed_validation.py 的3f57历史哈希；其用途是历史来源记录。当前独立复核过的修正工具为4a98f0e5097a4a4a84198b391f2ccafe627b7f05c080e1815ee115e4ea31410b。未来须由该修正工具生成实际 committed-validation/summary.json PASS，再进入 native gate；历史3f57记录不能代替当前工具身份或实际receipt。

## 原约束和权限边界

:579–609 对五个 native zip 保留唯一下载、API digest/size、CRC、完整成员集合及安全路径检查；exclusive写入、输出目录必须不存在，旧 raw 不会被覆盖。:647–649 将接受的 validator projection 与官方 result 完全比较；:675–684 保留八项 installed smoke×四片及原 exit/schema规则；官方 raw install flag与实际由 selected/smoke 派生的 workflow 安装是两个字段，不把 raw false 当无安装。:699–720 保留全 record/checkpoint PASS、captured-builtins 三个真实 hosted labels、无label inner控制和 normal/recursive repr 原方法 PASS，没有新增第四 hosted label。

这是 component Python3.11/profile-result-only、coverage=not-collected 的静态工具可执行性结论，不是新 run的native PASS、全仓 coverage/checkpoint、merge或全CI提速结论。可在根协调者绑定全部实际身份、当前committed回执与官方plan并确认两run终态SUCCESS后使用本工具；当前模板仍不可直接执行。完整transport trace不可得，capture gap保留。已封存，停止。
