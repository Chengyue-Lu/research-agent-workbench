from datetime import datetime, timezone
from contextlib import redirect_stdout
import ast, hashlib, json, os, subprocess, sys, zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
WT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
BASE = 'c80ec014925f0cbbbaef5486bce8422a5b4f73fb'
OLD = 'd7c13791b8ade226a7448cacac3a05fdfe7f71c2'
ENV = {k: v for k, v in os.environ.items() if k.upper() not in {'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY'}}

def git(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args])

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

OUT = ROOT / 'committed-validation'
OUT.mkdir(exist_ok=False)
HEAD = git('rev-parse', 'HEAD').decode().strip()
assert git('show', '-s', '--format=%P', HEAD).decode().strip() == OLD
assert git('merge-base', BASE, HEAD).decode().strip() == BASE
review = json.loads((ROOT / 'independent/summary.json').read_bytes())
assert review['status'] == 'PASS' and not review['blockers']
for row in review['sources']:
    assert sha(git('show', HEAD + ':' + row['path'])) == row['sha256']

unchanged = ['tests/coverage_policy.yaml', 'tests/ci_components.json',
             'tests/ci_impact_policy.yaml', '.github/scripts/run_component_ci.py',
             '.github/workflows/ci_components.yml', '.github/workflows/ci.yml',
             'tests/test_provider_binding_graph.py',
             'src/research_workbench/adapters/models/provider_binding.py',
             'src/research_workbench/adapters/models/configured.py']
for path in unchanged:
    assert git('show', HEAD + ':' + path) == git('show', OLD + ':' + path), path
for arc in ('A-20261004-001', 'A-20261004-002'):
    assert git('diff', '--name-only', OLD, HEAD, '--', 'work/AUDIT-FULL-CI-REPAIR-001/' + arc) == b''
ARC = 'work/AUDIT-FULL-CI-REPAIR-001/A-20261004-003'
manifest = json.loads(git('show', HEAD + ':' + ARC + '/MANIFEST.json'))
for row in manifest['files']:
    raw = git('show', HEAD + ':' + ARC + '/' + row['path'])
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
capture = json.loads(git('show', HEAD + ':' + ARC + '/CAPTURE.json'))
for row in capture['source']:
    assert sha(git('show', HEAD + ':' + row['path'])) == row['sha256']
with zipfile.ZipFile(WT / ARC / 'raw-observations.zip') as z:
    assert z.testzip() is None
    index = json.loads(git('show', HEAD + ':' + ARC + '/RAW_INDEX.json'))
    assert sorted(z.namelist()) == sorted(row['path'] for row in index['files'])
    for row in index['files']:
        p = PurePosixPath(row['path'])
        assert not p.is_absolute() and '..' not in p.parts
        raw = z.read(row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']

def methods(raw):
    t = ast.parse(raw)
    return {c.name + '.' + m.name: m for c in t.body if isinstance(c, ast.ClassDef)
            for m in c.body if isinstance(m, ast.FunctionDef) and m.name.startswith('test_')}

path = 'tests/test_provider_source_closure.py'
previous, current = methods(git('show', OLD + ':' + path)), methods(git('show', HEAD + ':' + path))
assert len(previous) == 21 and len(current) == 23 and set(previous) < set(current)
for name, method in previous.items():
    assert ast.dump(method) == ast.dump(current[name]), name
source_path = 'src/research_workbench/adapters/models/provider_source_closure.py'
old_ast, new_ast = ast.parse(git('show', OLD + ':' + source_path)), ast.parse(git('show', HEAD + ':' + source_path))
old_f = {n.name: n for n in old_ast.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
new_f = {n.name: n for n in new_ast.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
fresh_controls = ('verify_source_closure', 'read_source_closure', 'verify_loaded_source_closure',
                  '_verify_loaded', '_runtime', '_read_ref', 'compiled_functions', 'code_state')
for name in fresh_controls:
    assert ast.dump(old_f[name]) == ast.dump(new_f[name]), name

sys.path.insert(0, str(WT / '.github/scripts'))
import run_component_ci as runner
import check_pr_governance as governance
plan = runner.make_plan(WT, BASE, HEAD)
runner.save(OUT / 'component-plan.json', plan)
assert runner.load_plan(OUT / 'component-plan.json', WT) == plan
old_plan = runner.make_plan(WT, BASE, OLD)
assert plan['selected_tests'] == old_plan['selected_tests'] and len(plan['selected_tests']) == 36
for key in ('python_versions', 'smoke', 'install', 'docs', 'contracts'):
    assert plan[key] == old_plan[key], key
pr = json.loads(subprocess.check_output(['gh', 'api', 'repos/Chengyue-Lu/research-agent-workbench/pulls/139'], env=ENV))
assert pr['draft'] and pr['head']['sha'] == OLD and pr['base']['sha'] == BASE
save(OUT / 'pr-before.json', pr)
body = (ROOT / 'pr-body.pending.template.md').read_text(encoding='utf-8').replace('{HEAD}', HEAD)
(OUT / 'pr-body.pending.md').write_text(body, encoding='utf-8')
event = {'pull_request': {'body': body,
    'base': {'ref': 'develop', 'sha': BASE, 'repo': {'full_name': 'Chengyue-Lu/research-agent-workbench'}},
    'head': {'ref': 'fix/full-ci-post-optimization-20261004', 'sha': HEAD, 'repo': {'full_name': 'Chengyue-Lu/research-agent-workbench'}},
    'mergeable': True}}
runner.save(OUT / 'event.json', event)
report = governance.check_pull_request(event)
with (OUT / 'governance.log').open('w', encoding='utf-8') as stream, redirect_stdout(stream):
    report.emit()
summary = dict(status='PASS' if not report.has_errors else 'FAIL', at=datetime.now(timezone.utc).isoformat(),
    head=HEAD, parent=OLD, base=BASE, tree=git('rev-parse', HEAD + '^{tree}').decode().strip(),
    plan_sha256=plan['plan_sha256'], modules=len(plan['selected_tests']),
    old_test_methods=len(previous), current_test_methods=len(current), old_methods_preserved=True,
    fresh_controls_unchanged=list(fresh_controls), selection_and_flags_unchanged=True,
    committed_archive_bytes=True, old_archives_preserved=True,
    source_sha256=sha(git('show', HEAD + ':' + source_path)),
    test_sha256=sha(git('show', HEAD + ':' + path)),
    governance_errors=report.has_errors, metadata_published=False, body_sha256=sha(body.encode()))
save(OUT / 'summary.json', summary)
print(json.dumps(summary))
assert not report.has_errors
