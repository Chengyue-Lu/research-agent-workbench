# Work log

- Read project guidance, shared current entries, prior P234 facts and acceptance
  boundaries. Remote develop c80 and candidate d7 match. Only user config/AGENTS
  are dirty; preserved. First filename assumption was wrong (modules live under
  adapters/models), corrected by scoped filename discovery before source reads.
- Current graph test failures are post-call baseline budget checks, separate from
  the fixed captured-builtins P1. Budget and all original adversarial cases remain.
- Initial runner lacked root/src import paths, producing one import-only loader
  error; no case body ran. Corrected runner keeps explicit scoped sys.path. Initial
  intermediate candidate 23 source-closure cases passed on 3.11 (5.16s).
- Source reviewer flagged that deleting the second fresh archive read would change
  the existing drift-detection boundary. Restored both complete archive passes and
  original receipts/error normalization; final change only shares a private tree
  per module within each archive construction. Compiler/claims, FileRef reads,
  bytes/hash and every loaded runtime check still run on every pass. Initial PASS
  is superseded, not rebound to the final revision. declarations(raw) retained.
- Final-source suites: Python3.11 and 3.13 each 23 cases passed; new regression
  then strengthened to same-path/same-size/same-mtime drift and preserved public
  declarations(raw) compatibility. Only these two changed methods require follow-up
  execution; the earlier suite retains its exact test hash and original identity.
- Internal-consumer filename discovery across src/tests found ClosedSource only in
  its own two builders, no raw-only archive callers. Source review of three direct
  modules found no blocker in the final AST-only diff. Independent tiny probe
  harness errors (parse-count scope and __code__ mock cleanup) and baseline
  preparation tuple/list normalization failure are retained separately, not product
  failures or successful business timing. No actual pair has been repeated.
- Received PR136 owner-reported 70289d12 native421/4smoke and new22-case timings
  (162.145s, longest40.915s); these remain unverified external input for future
  cost work, not evidence for this candidate or an expansion of the present tests.
- First same-runner normal pair passed old/new original methods:77.942→28.502s
  and79.877→29.935s; original budgets/assertions/fixtures, Runtime178, pin and
  interpreter remain equal. No trace/profile. These one-pair local reductions
  (63.43/62.52%) are not whole-CI or coverage-budget success claims.
- Exact current23 source tests under a separate source-only branch collector PASS;
  source diagnostic92.78/83.41 is not a policy gate. Final independent3.11/3.13
  tiny probes45each/zero callback PASS, old probe harness failures preserved.
- For directly relevant coverage-budget validation, inspected unchanged ci_checks
  coverage_config/impact_coverage definitions and policy filename matches. The
  changed closure has no pragma/exclusion registration to migrate. No quality or
  selector edit. Historicalc80 plan is filter input only, not new signed authority.
- Independent static review approved the frozen coverage-only helper/config;
  root authorized one serial old-two/candidate-two execution, with no competing
  tests and unchanged120-second production/300-second external bounds. Failures
  keep their original identities, and are never successful timing controls.
- One matched coverage pair finished old/new allPASS, actualCTracer/branch data
  capture valid and source/runtime unchanged:97.720→45.264s and98.960→47.408s
  (53.68/52.09%). Old alsoPASS, so hosted budget failure was not reproduced locally;
  no numeric production-budget margin or whole-CI/full-gate success claim.
- Committed-validation tool v1 had an independent static BLOCK for mixing Git
  manifest binding with a working-copy ZIP object. Original tool preserved;
  minimal v2 now checks ZIP Git blob via BytesIO and binds actual imported/source
  bytes. Static reviewPASS is a preparation result, not a committed receipt.
- Timed children fully exited before root started the nine remaining original
  graph controls and the3.13 genuine cold-replay positive. No repeated normal pair.
- Remaining-nine actual result was8PASS+1cold-child importFAIL, not a product
  assertion failure: local run_local sys.path did not propagate to plain subprocess
  python -c. Passed explicit childPYTHONPATH, reran only that method, PASS; genuine
  isolated3.13 cold positive alsoPASS. Source/test bytes unchanged; original failure
  and8successful results preserved, not overwritten or counted as allPASS.
- Read-only local-final-summary proves all11 distinct original graph methods now
  have3.11 nativePASS references; exactcurrent23 source suite3.11 and strengthened
  3.13 methods pass, with earlier3.13 suite kept at its actual prior test hash.
  Independent final helper checks (coverage, committed v2, native unbound) PASS;
  static preparations are not hosted/committed execution proofs.
