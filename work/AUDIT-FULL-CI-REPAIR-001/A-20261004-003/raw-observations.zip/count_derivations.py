"""Tiny fixture equivalence/count check, separate from unprofiled timing pairs."""
from pathlib import Path
import hashlib
import importlib
import importlib.util
import json
import subprocess
import sys
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
WT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
BASELINE = 'd7c13791b8ade226a7448cacac3a05fdfe7f71c2'
PATH = 'src/research_workbench/adapters/models/provider_source_closure.py'
OUT = ROOT / 'derivation-counts'
OUT.mkdir(exist_ok=False)
old = subprocess.check_output(['git','-C',str(WT),'show',BASELINE+':'+PATH])
(OUT/'baseline_source.py').write_bytes(old)
sys.path[:0] = [str(WT/'src'),str(WT/'tests/fixtures/provider_source_closure_v1')]
importlib.import_module('rwb_source_fixture.provider')
real_parse = importlib.import_module('ast').parse
rows = []
for label, source in [('baseline',OUT/'baseline_source.py'),('candidate',WT/PATH)]:
    spec = importlib.util.spec_from_file_location('facts_count_'+label,source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        doc = module.produce_source_closure(('rwb_source_fixture.provider',),
                source_root=WT/'tests/fixtures/provider_source_closure_v1',
                project_root=root, archive_prefix='archive')
        read_order = []
        def read(ref):
            read_order.append(ref['path'])
            return root.joinpath(*ref['path'].split('/')).read_bytes()
        count = {'direct_ast_parse_calls':0,'compiled_function_calls':0}
        compiled = module.compiled_functions
        def parse(*args,**kwargs):
            if sys._getframe(1).f_code.co_filename == str(source):
                count['direct_ast_parse_calls'] += 1
            return real_parse(*args,**kwargs)
        def compile_functions(raw):
            count['compiled_function_calls'] += 1
            return compiled(raw)
        with patch.object(module.ast,'parse',parse), patch.object(module,'compiled_functions',compile_functions):
            receipt=module.verify_loaded_source_closure(doc,read_bytes=read,
                source_root=WT/'tests/fixtures/provider_source_closure_v1')
        rows.append(dict(label=label,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                         document=doc,receipt=receipt,read_order=read_order,counts=count))
assert rows[0]['document'] == rows[1]['document']
assert rows[0]['receipt'] == rows[1]['receipt']
assert rows[0]['read_order'] == rows[1]['read_order']
assert rows[0]['counts']['compiled_function_calls'] == rows[1]['counts']['compiled_function_calls']
assert rows[1]['counts']['direct_ast_parse_calls'] == 2*len(rows[1]['document']['modules'])
data=dict(status='PASS',python=sys.version,rows=rows,document_receipt_and_fresh_reads_equal=True,
          timing_claim=False,scope='Four-module fixture only; both archive passes retained')
(OUT/'summary.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='PASS',counts=[dict(label=r['label'],**r['counts'],fresh_reads=len(r['read_order'])) for r in rows])))
