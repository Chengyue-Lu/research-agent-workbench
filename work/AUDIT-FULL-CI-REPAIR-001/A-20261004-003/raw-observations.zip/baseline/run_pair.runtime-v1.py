"""One-shot unprofiled original graph-method run in a frozen snapshot."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

CASES = (
    "tests.test_provider_binding_graph.ProviderBindingGraphTests."
    "test_v12_cold_replay_rejects_helper_source_drift_without_provider_reuse",
    "tests.test_provider_binding_graph.ProviderBindingGraphTests."
    "test_v12_rehashed_use_facts_require_exact_source_closure_per_invocation",
)
TIMEOUT_SECONDS = 300


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def git(snapshot, *args):
    done = subprocess.run(["git", "-C", str(snapshot), *args], capture_output=True, check=True)
    return done.stdout


def identity(snapshot):
    files = [p.decode("utf-8") for p in git(snapshot, "ls-files", "-z").split(b"\0") if p]
    tracked = {name: sha(snapshot / name) for name in sorted(files)}
    runtime = snapshot / "src/research_workbench/_runtime_data"
    rows = [[p.relative_to(runtime).as_posix(), sha(p)]
            for p in sorted(runtime.rglob("*")) if p.is_file()]
    raw = json.dumps(rows, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return {
        "head": git(snapshot, "rev-parse", "HEAD").decode().strip(),
        "tracked_status": git(snapshot, "status", "--porcelain=v1", "--untracked-files=no").decode().strip(),
        "tracked_files": tracked,
        "runtime": {"file_count": len(rows), "manifest_sha256": hashlib.sha256(raw).hexdigest(), "files": rows},
    }


def child(snapshot, case, directory):
    # Only runner metadata and normal unittest result hooks. No test/product
    # method, callable, clock, global, budget, credential, or transport changes.
    import platform
    import tempfile
    import unittest
    import traceback

    directory.mkdir(parents=True, exist_ok=False)
    temporary = directory / "temp"
    temporary.mkdir()
    tempfile.tempdir = str(temporary)
    started_wall, started_cpu = time.perf_counter(), time.process_time()
    sys.path.insert(0, str(snapshot / "tests"))
    sys.path.insert(0, str(snapshot))
    sys.path.insert(0, str(snapshot / "src"))
    record = {
        "schema": "original-graph-case-normal-v1", "case": case,
        "interpreter": sys.executable, "python": sys.version,
        "platform": platform.platform(), "profile_enabled": sys.getprofile() is not None,
        "trace_enabled": sys.gettrace() is not None,
        "temp_root": temporary.as_posix(), "source_snapshot": snapshot.as_posix(),
        "timing_scope": "startTest-stopTest includes setUp, method, tearDown and cleanup; pre-test includes original setUpClass and runner overhead",
    }
    events = []

    class Result(unittest.TextTestResult):
        def startTest(self, test):
            self.case_wall, self.case_cpu = time.perf_counter(), time.process_time()
            events.append({"event": "startTest", "id": test.id()})
            super().startTest(test)

        def stopTest(self, test):
            record["test_interval_seconds"] = time.perf_counter() - self.case_wall
            record["test_interval_cpu_seconds"] = time.process_time() - self.case_cpu
            record["suite_before_startTest_seconds"] = self.case_wall - suite_started_wall
            # Counts only, never arguments, requests, headers, credentials or values.
            provider = getattr(test, "provider", None)
            credential = getattr(provider, "credential", None)
            transport = getattr(provider, "transport", None)
            resolutions = getattr(credential, "resolutions", None)
            requests = getattr(transport, "requests", None)
            record["credential_resolutions"] = resolutions if isinstance(resolutions, int) else None
            record["transport_request_count"] = len(requests) if isinstance(requests, list) else None
            events.append({"event": "stopTest", "id": test.id()})
            super().stopTest(test)

        def addSubTest(self, test, subtest, err):
            events.append({"event": "subTest", "id": subtest.id(), "outcome": "PASS" if err is None else "FAIL"})
            super().addSubTest(test, subtest, err)

    result = None
    try:
        suite = unittest.defaultTestLoader.loadTestsFromName(case)
        record["import_and_load_seconds"] = time.perf_counter() - started_wall
        suite_started_wall, suite_started_cpu = time.perf_counter(), time.process_time()
        result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
        suite_ended = time.perf_counter()
        record.update({
            "outcome": "PASS" if result.wasSuccessful() else "FAIL", "tests_run": result.testsRun,
            "failures": [{"id": t.id(), "native_detail": detail} for t, detail in result.failures],
            "errors": [{"id": t.id(), "native_detail": detail} for t, detail in result.errors],
            "skips": [{"id": t.id(), "reason": detail} for t, detail in result.skipped],
            "suite_wall_seconds": suite_ended - suite_started_wall,
            "suite_cpu_seconds": time.process_time() - suite_started_cpu,
        })
        if "test_interval_seconds" in record:
            record["suite_after_stopTest_seconds"] = record["suite_wall_seconds"] - record["suite_before_startTest_seconds"] - record["test_interval_seconds"]
    except BaseException:
        record["outcome"] = "RUNNER_ERROR"
        record["runner_error"] = traceback.format_exc()
        traceback.print_exc()
    record["child_wall_seconds"] = time.perf_counter() - started_wall
    record["child_cpu_seconds"] = time.process_time() - started_cpu
    record["native_events"] = events
    record["loaded_snapshot_modules"] = {
        name: {"file": str(Path(module.__file__).resolve()), "sha256": sha(module.__file__)}
        for name, module in sorted(sys.modules.items())
        if getattr(module, "__file__", None) and Path(module.__file__).is_file()
        and Path(module.__file__).resolve().is_relative_to(snapshot)
    }
    save(directory / "result.json", record)
    return 0 if record["outcome"] == "PASS" else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--prepared-manifest", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--execute-approved", action="store_true")
    parser.add_argument("--child-case", choices=CASES)
    args = parser.parse_args()
    snapshot = args.snapshot.resolve()
    output = args.output_dir.resolve()
    assessment = Path(__file__).resolve().parent
    if not output.is_relative_to(assessment) or output == assessment:
        raise SystemExit("output must be a new directory under the baseline assessment")
    if not args.execute_approved:
        raise SystemExit("explicit root execution approval required")
    if args.child_case:
        return child(snapshot, args.child_case, output)
    prepared = json.loads(args.prepared_manifest.read_text(encoding="utf-8"))
    if snapshot.as_posix() != prepared["snapshot_path"]:
        raise SystemExit("snapshot path differs from prepared binding")
    if sha(__file__) != prepared["runner_sha256"]:
        raise SystemExit("runner bytes differ from prepared binding")
    before = identity(snapshot)
    if before != prepared["snapshot_identity"]:
        raise SystemExit("snapshot bytes/runtime/status differ from prepared binding")
    output.mkdir(parents=True, exist_ok=False)
    save(output / "identity-before.json", before)
    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join((str(snapshot / "src"), str(snapshot)))
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    records = []
    for index, case in enumerate(CASES, 1):
        case_dir = output / f"case-{index}"
        command = [sys.executable, "-B", "-X", "utf8", str(Path(__file__).resolve()),
                   "--snapshot", str(snapshot), "--output-dir", str(case_dir),
                   "--execute-approved", "--child-case", case]
        start = time.perf_counter()
        timed_out = False
        try:
            done = subprocess.run(command, cwd=snapshot, env=env, capture_output=True, timeout=TIMEOUT_SECONDS)
            stdout, stderr, returncode = done.stdout, done.stderr, done.returncode
        except subprocess.TimeoutExpired as exc:
            stdout, stderr, returncode = exc.stdout or b"", exc.stderr or b"", None
            timed_out = True
        subprocess_wall = time.perf_counter() - start
        (output / f"case-{index}.stdout.txt").write_bytes(stdout)
        (output / f"case-{index}.stderr.txt").write_bytes(stderr)
        after_case = identity(snapshot)
        save(output / f"identity-after-case-{index}.json", after_case)
        record = {"case": case, "command": command, "attempt": 1, "timeout_seconds": TIMEOUT_SECONDS,
                  "timed_out": timed_out, "returncode": returncode,
                  "subprocess_wall_seconds": subprocess_wall,
                  "source_runtime_unchanged": after_case == before}
        if (case_dir / "result.json").is_file():
            record["native_result"] = json.loads((case_dir / "result.json").read_text(encoding="utf-8"))
        records.append(record)
        save(output / "execution.json", {"schema": "original-graph-pair-normal-v1", "serial": True, "records": records})
        if after_case != before:
            raise SystemExit("snapshot changed; second method not executed")
    final = identity(snapshot)
    save(output / "identity-after.json", final)
    receipt = {"schema": "original-graph-pair-normal-v1", "serial": True, "records": records,
               "source_runtime_unchanged": final == before,
               "interpretation": "Local normal runs; not coverage/hosted reproduction or evidence of resolved full-CI budget failure"}
    save(output / "execution.json", receipt)
    return 0 if all(r.get("native_result", {}).get("outcome") == "PASS" and not r["timed_out"] for r in records) else 1


if __name__ == "__main__":
    raise SystemExit(main())
