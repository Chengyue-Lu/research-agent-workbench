# Covered original-method old/new pair

Candidate original-method result: **PASS**. Measurement capture valid: **True**; source/Runtime unchanged: **True**; branch SQLite metadata valid: **True**. Exactly one covered old/new pair, two original methods each, baseline then candidate serially; no retry. Root and other agents kept timing windows free of other tests/producers.

| Original method | d7/candidate outcome | d7 test interval s | Candidate test interval s | Successful-run reduction |
|---|---:|---:|---:|---:|
| `test_v12_cold_replay_rejects_helper_source_drift_without_provider_reuse` | PASS/PASS | 97.72034799994435 | 45.26353090000339 | 52.456817s (53.68%) |
| `test_v12_rehashed_use_facts_require_exact_source_closure_per_invocation` | PASS/PASS | 98.95964140002616 | 47.40825710003264 | 51.551384s (52.09%) |

Native producer/test failures are retained exactly below and in original stderr/results. If baseline failed, its elapsed interval includes the native failed outcome and is not used to claim successful-run savings. Candidate PASS means all original completed/replay_valid, helper archive drift rejection, credential/request and rehashed missing/extra assertions executed successfully. Whole testcase wall time is not the product's measured 120-second interval; no external 200-second threshold is inferred. The native producer elapsed field was not captured separately, so no numerical guard margin is reported and120 is never reduced by method/test wall time.

Both versions used unchanged coverage helper `52f41276847b45f1225f6c66d5f7042b0609c018f22270400b56e64094e96a53`, config `91b3a8541cf97e4df056b0221b6db90977892002fbf0cacdf7034f57f39cae9d`, installed local coverage7.16.1 (identity `8f48bce87ed9cce94764fe47a672b9963295eb0bad95096881254956518e06f3`), existing Python3.11 interpreter and user files, Runtime178 and generated pin. Actual profile/trace flags and tracer types are recorded per case in `COVERED_SUMMARY.json`; new data files are independently hashed and read only for SQLite has_arcs/file/arc metadata. Credential/request counts refer to the original case's self.provider; separate original class-stage/conformance objects are not aggregated. Source/pin/Runtime identities are frozen before/after each version. Root's frozen candidate is dirty worktree sourcec309/test52 at Git HEAD d7; no new commit execution is implied.

The rcfile is byte-identical old/new, produced by unchanged actual CI coverage_config using cached historical c80 plan filter data. It measures branch/path sources src/research_workbench, .github/scripts, . with complementary omit. No verify_plan, re-sign, native full-result projection, policy checker or full-suite runner was invoked. Local two-method results do not establish hosted/full311 success, policy threshold GatePASS or repository coverage obligations. The earlier c80 full overall failure remains separate evidence.

Normal old/new pair is retained independently in `PAIR_REPORT.md`/`PAIR_SUMMARY.json`. Covered timing is one serial sample with no uncertainty estimate; interpreter/environment are bound, but background variation and ordering effects remain. Original methods/fixture seeds, real monotonic clock, UTC fixture, class stage, setup, fresh provider/credential/transport, journal/replay paths, every-use refs/bytes/current runtime/defaults/aliases/closed sets and both original negative assertions are unchanged. No producer or verification PASS was cached or substituted, no budget/source edit occurred during runs, and no test was deleted.

Preparation's tuple/list rejection and missing pin errors remain separately preserved as zero-test preparation failures. Output paths `coverage-d7` and `coverage-candidate` contain original raw stdout/stderr, native JSON and data files. This report/SUMMARY/MANIFEST are newly written without rewriting prior normal/helper/preparation evidence. Source-content reads7; external API/install/workflow/full-suite/retries0. Root handles shared Issue/project records; this agent made no shared writes.

## Retained native failure details

No native unittest failures/errors in either version.
