"""Prepare actual CI path-source coverage configuration, no testcase execution."""
from pathlib import Path
import hashlib
import importlib.util
import importlib.metadata
import json
import sys
import datetime

BASE = Path(__file__).resolve().parent
OLD = BASE / "snapshot-d7"
NEW = Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004")
PLAN = Path("D:/lcy/develop/_assessments/rwb-full-ci-repair-20261004/hosted-current/official-ci-plan.json")
PREP = BASE / "coverage-preparation"
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

assert sha(PLAN) == "ad2bc08469881411550813c84f2b3fbcf22f444eecac6f96a6d8514a52a883ba"
plan = json.loads(PLAN.read_text(encoding="utf-8"))
assert plan["binding"]["target"] == "c80ec014925f0cbbbaef5486bce8422a5b4f73fb"
helper_name = ".github/scripts/ci_checks.py"
assert sha(OLD / helper_name) == sha(NEW / helper_name)
assert not PREP.exists()
PREP.mkdir()
sys.path.insert(0, str(OLD / ".github/scripts"))
spec = importlib.util.spec_from_file_location("coverage_config_preparation_only", OLD / helper_name)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
old_config = helper.coverage_config(plan, OLD)
new_config = helper.coverage_config(plan, NEW)
(PREP / "ci-coverage-d7.ini").write_text(old_config, encoding="utf-8")
(PREP / "ci-coverage-candidate.ini").write_text(new_config, encoding="utf-8")
old_lines, new_lines = set(old_config.splitlines()), set(new_config.splitlines())
distribution = importlib.metadata.distribution("coverage")
files = {str(name): {"bytes": distribution.locate_file(name).stat().st_size,
                     "sha256": sha(distribution.locate_file(name))}
         for name in distribution.files if distribution.locate_file(name).is_file()}
identity = {"version": distribution.version, "files": files}
save(PREP / "installed-coverage-identity.json", identity)
record = {
    "schema": "ci-style-coverage-pair-preparation-v1", "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "tests": 0, "producer_runs": 0, "API": 0, "coverage_case_execution": 0,
    "config_generator": helper_name, "config_generator_sha256": sha(OLD / helper_name),
    "cached_c80_plan": {"path": PLAN.as_posix(), "sha256": sha(PLAN), "plan_id": plan["plan_id"],
        "target": plan["binding"]["target"], "purpose": "coverage filter data only; no verify_plan/re-sign/candidate execution authority"},
    "old_root": OLD.as_posix(), "candidate_root": NEW.as_posix(),
    "coverage_version": distribution.version,
    "coverage_identity_sha256": sha(PREP / "installed-coverage-identity.json"),
    "old_config_sha256": sha(PREP / "ci-coverage-d7.ini"), "candidate_config_sha256": sha(PREP / "ci-coverage-candidate.ini"),
    "config_bytes_equal": old_config == new_config,
    "only_old_config_lines": sorted(old_lines - new_lines), "only_candidate_config_lines": sorted(new_lines - old_lines),
    "coverage_flags": "coverage run --rcfile=...; [run] branch=True with path sources src/research_workbench, .github/scripts, . and complementary omitted paths",
    "execution_approval": "NOT_APPROVED_YET; preparation only",
    "python_source_content_read_count": 7,
}
save(PREP / "preparation.json", record)
print(json.dumps(record, ensure_ascii=False))
