"""Offline packaging of already captured native results; no product imports."""
from pathlib import Path
import hashlib
import json
import datetime

BASE = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

execution_path = BASE / "normal-d7-v2/execution.json"
execution = json.loads(execution_path.read_text(encoding="utf-8"))
assert len(execution["records"]) == 2
prepared = json.loads((BASE / "preparation.json").read_text(encoding="utf-8"))
records = []
for index, row in enumerate(execution["records"], 1):
    native = row.get("native_result", {})
    records.append({
        "case": row["case"], "outcome": native.get("outcome", "TIMEOUT_OR_CAPTURE_GAP"),
        "tests_run": native.get("tests_run", 0), "attempt": row["attempt"],
        "timed_out": row["timed_out"], "timeout_seconds": row["timeout_seconds"],
        "subprocess_wall_seconds": row["subprocess_wall_seconds"],
        "suite_wall_seconds": native.get("suite_wall_seconds"),
        "suite_cpu_seconds": native.get("suite_cpu_seconds"),
        "test_interval_seconds": native.get("test_interval_seconds"),
        "test_interval_cpu_seconds": native.get("test_interval_cpu_seconds"),
        "import_and_load_seconds": native.get("import_and_load_seconds"),
        "class_stage_and_runner_before_test_seconds": native.get("suite_before_startTest_seconds"),
        "class_cleanup_and_runner_after_test_seconds": native.get("suite_after_stopTest_seconds"),
        "credential_resolutions": native.get("credential_resolutions"),
        "transport_request_count": native.get("transport_request_count"),
        "profile_enabled": native.get("profile_enabled"), "trace_enabled": native.get("trace_enabled"),
        "native_events": native.get("native_events", []),
        "failures": native.get("failures", []), "errors": native.get("errors", []),
        "source_runtime_unchanged": row["source_runtime_unchanged"],
        "stdout_sha256": sha(BASE / f"normal-d7-v2/case-{index}.stdout.txt"),
        "stderr_sha256": sha(BASE / f"normal-d7-v2/case-{index}.stderr.txt"),
        "native_result_sha256": sha(BASE / f"normal-d7-v2/case-{index}/result.json") if native else None,
    })
summary = {
    "schema": "d7-original-graph-pair-baseline-v1", "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "head": prepared["snapshot_identity"]["head"], "snapshot_path": prepared["snapshot_path"],
    "runner_sha256": prepared["runner_sha256"], "interpreter": prepared["interpreter"],
    "interpreter_sha256": prepared["interpreter_sha256"], "python": prepared["python"],
    "runtime_file_count": 178, "runtime_manifest_sha256": prepared["runtime_copy"]["manifest_sha256"],
    "runtime_pin_sha256": prepared["runtime_pin_copy"]["snapshot_sha256"],
    "outcome": "PASS" if all(r["outcome"] == "PASS" and r["tests_run"] == 1 and not r["timed_out"] for r in records) else "FAIL_OR_INCOMPLETE",
    "serial": True, "source_runtime_unchanged": execution["source_runtime_unchanged"],
    "frozen_budget": prepared["frozen_budget"], "records": records,
    "execution_sha256": sha(execution_path),
    "prior_preparation_failures": {
        "tuple_list_preflight": {"tests": 0, "detail_path": "PREFLIGHT_EVENT.json"},
        "missing_generated_pin": {"tests": 0, "original_class_stages": 2,
            "detail_path": "normal-d7/execution.json", "sha256": sha(BASE / "normal-d7/execution.json"),
            "performance_sample": False},
    },
    "verification_boundary": "Normal local original-method assertions only; not coverage/hosted reproduction, root candidate execution, gate, full-suite or proof of eliminated budget failure",
    "producer_clock_interval": "Not separately instrumented; full testcase interval is not frozen max_seconds elapsed",
    "setup_timing": "Original setUp remains within startTest-stopTest; class stage reported with pre-test runner overhead, no invasive isolated timing",
    "next_optional_design": "Same interpreter/config/Runtime and fixed old/new snapshots; coverage run --branch --source=research_workbench on each serial original child, isolated data paths, after separate approval; not executed here",
    "budget": {"static_python_source_reads": 6, "API": 0, "installs": 0, "workflow_changes": 0, "full_suites": 0, "normal_original_methods": sum(r["tests_run"] for r in records), "coverage_pairs": 0},
}
save(BASE / "summary.json", summary)
lines = []
for row in records:
    lines.append(f"| `{row['case'].split('.')[-1]}` | {row['outcome']} | {row['tests_run']} | {row['suite_wall_seconds']} | {row['test_interval_seconds']} | {row['test_interval_cpu_seconds']} | {row['class_stage_and_runner_before_test_seconds']} | {row['credential_resolutions']}/{row['transport_request_count']} |")
table = "\n".join(lines)
report = f"""# d7 original graph pair baseline

Outcome: **{summary['outcome']}**. Original two methods ran serially on fixed detached `{summary['head']}`, snapshot `{summary['snapshot_path']}`. No root candidate source entered this run. Raw `normal-d7-v2` stdout/stderr, result JSON, interpreter/source/runtime identities and native event order are retained. Source, generated pin and Runtime hashes were unchanged before/after both cases. Original 120-second budget and monotonic clock remained active.

| Original method | Outcome | Tests | Suite wall s | Test interval s | Test CPU s | Class stage + runner before test s | Credential/request counts |
|---|---:|---:|---:|---:|---:|---:|---:|
{table}

Each case used a fresh interpreter and original unittest class stage once, original setUp, method, cleanup and assertions. The two listed case order is native alphabetical order. startTest-stopTest includes setUp and cleanup; the class stage value includes pre-test runner overhead. setUp and the product's measured budget interval were not separately instrumented. No profiling, coverage, product callable/clock/global replacement, mocked producer or shared producer result was introduced. The original test's own synthetic transport and attack guard remain exactly as written.

Runtime178 manifest SHA-256 `{summary['runtime_manifest_sha256']}` matches the existing generated directory and prior P234 identity. Existing generated `_runtime_pin.py` was copied (not imported/generated in preparation), SHA-256 `{summary['runtime_pin_sha256']}`. Runner SHA-256 `{summary['runner_sha256']}`; interpreter SHA-256 `{summary['interpreter_sha256']}`. Complete tracked source hashes and the six static read source hashes are frozen in `preparation.json`.

Two preparation failures are kept separately: an initial tuple/list JSON identity rejection before output/tests, and two original class-stage errors because the first snapshot lacked generated `_runtime_pin.py` (`normal-d7`, 0 tests). Root approved the serialization fix and pin byte-copy; these failed preparations are not budget/performance samples. No other missing resource was found in a scoped ignored-file inventory. No original method was automatically rerun after the retained real pair.

The original assertions cover completed/replay_valid before attack, fresh archive source refs/bytes/current runtime/defaults/aliases/closed sets, one fresh credential resolution and one injected transport request, helper archive drift rejection without provider reuse, and both rehashed missing/extra use-ref rejections. Native failure/error details, if any, are in `summary.json` and the original stderr. The original helper-drift negative replay is same-process; its method name does not establish a new-process replay here.

This is a local **normal** measurement. The earlier c80 full311 failures happened under coverage; normal PASS does not prove the full-CI budget cause disappeared. These results are not root's new candidate execution or an authority/policy/coverage gate. Whole test wall time is not the producer's 120-second measured budget interval; no fixed external 200-second failure threshold is inferred.

A later coverage pair remains only a design: bind the installed coverage version/hash first, then use identical `coverage run --branch --source=research_workbench` in each original child on fixed old/new source snapshots, with the same interpreter/config/Runtime, isolated coverage data paths and serial ordering. No coverage pair ran, no coverage version was discovered, and no hosted/full-CI equivalence or optimization savings is claimed here. Root must confirm any additional execution budget.

Reads: 6 Python source files. API/install/workflow/full-suite/coverage executions: 0. Writes stayed under this baseline assessment; product files and shared progress/memory were not edited. See `PREPARATION_REPORT.md` for exact budget derivation, fixture semantics and authorized command.
"""
(BASE / "REPORT.md").write_text(report, encoding="utf-8")
files = [path for path in BASE.rglob("*") if path.is_file()
         and not path.is_relative_to(BASE / "snapshot-d7") and path.name != "manifest.json"]
manifest = {"schema": "d7-original-graph-baseline-manifest-v1", "files": {
    path.relative_to(BASE).as_posix(): {"bytes": path.stat().st_size, "sha256": sha(path)} for path in sorted(files)}}
save(BASE / "manifest.json", manifest)
print(json.dumps({"outcome": summary["outcome"], "records": records,
                  "summary_sha256": sha(BASE / "summary.json"), "report_sha256": sha(BASE / "REPORT.md"),
                  "manifest_sha256": sha(BASE / "manifest.json")}, ensure_ascii=False))
