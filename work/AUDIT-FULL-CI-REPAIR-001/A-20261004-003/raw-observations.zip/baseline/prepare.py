"""Static-only freeze: no business import/test/producer invocation."""
from pathlib import Path
import datetime
import importlib.util
import json
import platform
import subprocess
import sys

BASE = Path(__file__).resolve().parent
SNAPSHOT = BASE / "snapshot-d7"
MUTABLE = Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004")
EXPECTED_HEAD = "d7c13791b8ade226a7448cacac3a05fdfe7f71c2"
runner = BASE / "run_pair.py"
compile(runner.read_bytes(), str(runner), "exec")
spec = importlib.util.spec_from_file_location("graph_pair_runner_metadata", runner)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
snapshot_identity = module.identity(SNAPSHOT)
assert snapshot_identity["head"] == EXPECTED_HEAD
assert set(snapshot_identity["tracked_status"].splitlines()) == {"M .codex/config.toml", " M AGENTS.md"}
detached = subprocess.run(["git", "-C", str(SNAPSHOT), "symbolic-ref", "-q", "HEAD"], capture_output=True)
assert detached.returncode == 1 and not detached.stdout
source_runtime = MUTABLE / "src/research_workbench/_runtime_data"
pin = "src/research_workbench/_runtime_pin.py"
assert (MUTABLE / pin).is_file() and (SNAPSHOT / pin).is_file()
assert module.sha(MUTABLE / pin) == module.sha(SNAPSHOT / pin)
assert module.sha(SNAPSHOT / pin) == "b867750c4b5de4f3e6fdbe8aff394f1dfb1f9498db38d4d0fe0b4eae1ce4b5e3"
source_rows = [(p.relative_to(source_runtime).as_posix(), module.sha(p))
               for p in sorted(source_runtime.rglob("*")) if p.is_file()]
assert source_rows == [tuple(row) for row in snapshot_identity["runtime"]["files"]]
prior_identity_path = Path("D:/lcy/develop/_assessments/rwb-ci-p234-p1-20261004/fixture/SOURCE_IDENTITIES_BEFORE.json")
prior_runtime = json.loads(prior_identity_path.read_text(encoding="utf-8"))["runtime"]
assert snapshot_identity["runtime"]["file_count"] == prior_runtime["file_count"] == 178
assert snapshot_identity["runtime"]["manifest_sha256"] == prior_runtime["manifest_sha256"]
copied = {name: {"source_sha256": module.sha(MUTABLE / name), "snapshot_sha256": module.sha(SNAPSHOT / name)}
          for name in ("AGENTS.md", ".codex/config.toml")}
assert all(row["source_sha256"] == row["snapshot_sha256"] for row in copied.values())
config = (SNAPSHOT / ".codex/config.toml").read_text(encoding="utf-8")
assert "generate_memories = false" in config and "use_memories = true" in config
sources = (
    "tests/test_provider_binding_graph.py", "tests/test_provider_binding.py",
    "tests/baseline_fixtures.py", "tests/system_evaluation_fixtures.py",
    "src/research_workbench/execution/baseline.py", "src/research_workbench/execution/baseline_envelope.py",
)
record = {
    "schema": "original-graph-pair-preparation-v1",
    "prepared_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "snapshot_path": SNAPSHOT.as_posix(), "snapshot_identity": snapshot_identity,
    "interpreter": sys.executable, "interpreter_sha256": module.sha(sys.executable),
    "python": sys.version, "platform": platform.platform(),
    "runner_path": runner.as_posix(), "runner_sha256": module.sha(runner),
    "copied_user_files": copied,
    "runtime_copy": {"source_path": source_runtime.as_posix(), "copied_not_generated": True,
        "source_and_snapshot_rows_equal_at_preparation": True,
        "file_count": 178, "manifest_sha256": prior_runtime["manifest_sha256"],
        "prior_identity_path": prior_identity_path.as_posix(), "prior_identity_sha256": module.sha(prior_identity_path)},
    "runtime_pin_copy": {"source_sha256": module.sha(MUTABLE / pin),
        "snapshot_sha256": module.sha(SNAPSHOT / pin), "copied_not_generated": True,
        "source_path": (MUTABLE / pin).as_posix()},
    "static_read_source_hashes": {name: module.sha(SNAPSHOT / name) for name in sources},
    "static_source_read_count": 6, "cases": module.CASES, "each_timeout_seconds": 300,
    "frozen_budget": {"max_seconds": 120, "max_turns": 4, "max_output_tokens": 64, "max_parallel": 1},
    "approval": {"root_approved_snapshot_path": True,
        "scope": "original two methods once normal serial, continue second after first failure; no coverage run yet"},
    "preparation_execution": {"static_syntax": "PASS", "business_imports": 0, "tests": 0, "producer_runs": 0, "API": 0},
    "execution_output_path": (BASE / "normal-d7-v2").as_posix(),
}
assert not (BASE / "normal-d7-v2").exists()
assert json.loads(json.dumps(snapshot_identity)) == snapshot_identity
module.save(BASE / "preparation.json", record)
source_table = "\n".join(f"- `{name}`: `{digest}`" for name, digest in record["static_read_source_hashes"].items())
report = f"""# Fixed d7 baseline pair preparation

Snapshot: `{SNAPSHOT.as_posix()}`; detached HEAD `{EXPECTED_HEAD}`. The source worktree can change concurrently; tests will run only in this frozen snapshot. Root explicitly approved this path and one normal serial pair on 2026-10-04. Original `normal-d7` stopped in both original setUpClass stages because the snapshot lacked generated `_runtime_pin.py` (zero methods/tests, no budget performance sample); raw outcomes are preserved. Root approved copying the existing 85-byte pin and new `normal-d7-v2` original pair, with no generation/import during preparation. Pin SHA-256 is `{module.sha(SNAPSHOT / pin)}`. No further run is allowed if another resource is missing.

`AGENTS.md` and `.codex/config.toml` were copied byte-for-byte from the existing worktree. Only these two tracked files differ from d7; memory generation is disabled. Runtime was copied from the existing generated directory, without building or installing: 178 files, SHA-256 `{prior_runtime['manifest_sha256']}` using the prior P234 sorted path/hash tuple algorithm. Copied/source rows match at preparation and match the P234 178-file identity. The snapshot's complete tracked-file and Runtime hashes are frozen in `preparation.json`.

The runner `{runner.name}` SHA-256 is `{record['runner_sha256']}`. Interpreter `{sys.executable}`, {sys.version.split()[0]}, SHA-256 `{record['interpreter_sha256']}`. Static syntax and metadata binding checks passed; business imports/tests/producer/API count during preparation is zero. Initial tuple/list serialization preflight rejection is separately retained in `PREFLIGHT_EVENT.json` and old tool/preparation/report bytes.

## Original methods and timing

1. `{module.CASES[0]}`
2. `{module.CASES[1]}`

Each original method runs once in a fresh interpreter and original unittest suite, serially in the native alphabetical order of these two methods. The original class stage runs once per child, then the original setUp/method/cleanup; no test or product callable is replaced. Every original assertion remains. Each child is externally bounded at 300 seconds; first failure is retained and the second still runs. There is no retry. Raw stdout/stderr and native unittest failures/subtests are retained. Counts only are captured for credential resolution and transport requests; parameters and credential values are not inspected.

The default `run_baseline_session` clock is real `time.monotonic`; the graph test supplies only its original frozen UTC clock. `SystemEvaluationFixture.build` creates Protocol `execution_time_budget_seconds=120` (line 569); `compile_baseline_envelope` transfers this to `budget.max_seconds` (line 222). BaselineFixture sets max_parallel=1; configured binding fixture lowers max_output_tokens to64. Effective budget is 120 seconds, 4 turns, 64 output tokens, max_parallel1. No threshold changes are made.

The budget starts at baseline.py line314, after envelope validation/request preparation, and covers the active session, fresh use-boundary reads and observation, response-side facts, and end-clock check. The post-call guard is detective, with no hard preemption. Whole testcase wall time is not the measured budget interval and cannot establish a fixed external failure threshold.

Normal unittest Result.startTest/stopTest gives the test interval, including original setUp and cleanup. Import/load, class-stage plus pre-test runner overhead, and post-test runner/class-cleanup overhead are reported separately where naturally exposed. setUp is not separately isolated, and the product elapsed interval is not instrumented. The runner uses neither coverage nor sys.setprofile/sys.settrace.

## Fixture and attack boundaries

The class stage creates a complete graph binding with source_closure and conformance; each setUp creates fresh configured profile/provider/credential/transport and copies the stage archive. Source references and bytes/current runtime/defaults/aliases/closed sets are checked by original product code; no validation PASS or producer output is shared. The synthetic injected transport has original no-retry/no-redirect configuration and timeout10, response bound65536. A1 original synthetic task/public input, request payload, journal, closure and replay construction remain intact.

Both methods require the baseline completed/replay_valid assertions first. The helper-drift method then changes an archived pins source, retains its original Provider.generate guard, requires closure failure and exactly one credential resolution/request. Despite its name, this method's negative replay is in the same process. The missing/extra method restores original bytes between its two subtests, re-signs retained facts, requires use.boundary rejection, and retains exactly one resolution/request. A normal PASS means those original guards executed; it is not a hosted coverage reproduction.

## Optional later coverage pairing (not executed)

The c80 full failures occurred under coverage. A normal old/new PASS cannot show their cause disappeared. A separately approved pair would reuse these same frozen source snapshots/interpreter/config/Runtime and original serial cases, adding `python -B -X utf8 -m coverage run --branch --source=research_workbench` to each child invocation and isolated coverage data paths. It must first bind the installed coverage identity and use identical coverage settings for old/new; no tests, budgets or source semantics change. Do not claim equivalence to the hosted run or subtract normal from covered timing as a source-change gain.

## Static source read boundary

Six Python source files were read; additional snapshot files were hashed as metadata only.

{source_table}

## Authorized invocation

`{sys.executable} -B -X utf8 {runner.as_posix()} --snapshot {SNAPSHOT.as_posix()} --prepared-manifest {(BASE / 'preparation.json').as_posix()} --output-dir {(BASE / 'normal-d7-v2').as_posix()} --execute-approved`

The runner refuses changed snapshot/Runtime/runner bytes or an existing output directory. Environment PYTHONPATH is snapshot/src;snapshot; test fixture temporary files remain under the assessment. No product edits, API, install, CI/workflow/full-suite execution or shared-memory updates are authorized by this report.
"""
(BASE / "PREPARATION_REPORT.md").write_text(report, encoding="utf-8")
print(json.dumps({"preparation": "PASS", "runner_sha256": record["runner_sha256"],
                  "snapshot": record["snapshot_path"], "runtime": record["runtime_copy"],
                  "report_sha256": module.sha(BASE / "PREPARATION_REPORT.md"),
                  "preparation_sha256": module.sha(BASE / "preparation.json")}, ensure_ascii=False))
