"""Offline packaging of one retained covered old/new pair, no product imports."""
from pathlib import Path
import hashlib
import json
import datetime
import sqlite3

BASE = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
def data_metadata(path):
    if not path.is_file():
        return {"exists": False}
    result = {"exists": True, "bytes": path.stat().st_size, "sha256": sha(path),
              "sqlite_header": path.read_bytes()[:16] == b"SQLite format 3\x00"}
    try:
        connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
        result["meta"] = dict(connection.execute("SELECT key, value FROM meta WHERE key IN ('has_arcs', 'version')"))
        result["measured_file_count"] = connection.execute("SELECT COUNT(*) FROM file").fetchone()[0]
        result["arc_row_count"] = connection.execute("SELECT COUNT(*) FROM arc").fetchone()[0]
        connection.close()
    except sqlite3.Error as exc:
        result["read_error"] = str(exc)
    return result

paths = {name: BASE / ("coverage-" + name) / "execution.json" for name in ("d7", "candidate")}
executions = {name: json.loads(path.read_text(encoding="utf-8")) for name, path in paths.items()}
assert all(len(execution["records"]) == 2 for execution in executions.values())
freeze = json.loads((BASE / "coverage-preparation/FREEZE.json").read_text(encoding="utf-8"))
rows = []
for index, (before, after) in enumerate(zip(executions["d7"]["records"], executions["candidate"]["records"]), 1):
    assert before["case"] == after["case"]
    native_before, native_after = before.get("native_result", {}), after.get("native_result", {})
    success_pair = native_before.get("outcome") == native_after.get("outcome") == "PASS"
    metrics = {}
    for metric in ("subprocess_wall_seconds", "suite_wall_seconds", "suite_cpu_seconds", "test_interval_seconds", "test_interval_cpu_seconds", "import_and_load_seconds", "suite_before_startTest_seconds", "suite_after_stopTest_seconds"):
        old = before.get(metric, native_before.get(metric))
        new = after.get(metric, native_after.get(metric))
        metrics[metric] = {"baseline": old, "candidate": new,
            "success_to_success_saved_seconds": old - new if success_pair and old is not None and new is not None else None,
            "success_to_success_saved_percent": 100 * (old - new) / old if success_pair and old and new is not None else None}
    versions = {}
    for name, record, native in (("d7", before, native_before), ("candidate", after, native_after)):
        detail = "\n".join(item["native_detail"] for item in native.get("failures", []) + native.get("errors", []))
        versions[name] = {"outcome": native.get("outcome", "TIMEOUT_OR_CAPTURE_GAP"), "tests_run": native.get("tests_run", 0),
            "timed_out": record["timed_out"], "timeout_seconds": record["timeout_seconds"],
            "profile_enabled": native.get("profile_enabled"), "trace_enabled": native.get("trace_enabled"),
            "tracer_type": native.get("tracer_type"), "coverage_version": native.get("coverage_version"),
            "coverage_config_path": native.get("coverage_config_path"), "coverage_data_path": record["coverage_data_path"],
            "coverage_data": data_metadata(Path(record["coverage_data_path"])),
            "credential_resolutions": native.get("credential_resolutions"), "request_count": native.get("transport_request_count"),
            "native_events": native.get("native_events", []), "failures": native.get("failures", []), "errors": native.get("errors", []),
            "native_post_call_budget_failure": "post-call time budget" in detail,
            "source_runtime_unchanged": record["source_runtime_unchanged"],
            "stdout_sha256": sha(BASE / f"coverage-{name}/case-{index}.stdout.txt"),
            "stderr_sha256": sha(BASE / f"coverage-{name}/case-{index}.stderr.txt"),
            "native_result_sha256": sha(BASE / f"coverage-{name}/case-{index}/result.json") if native else None,
        }
    rows.append({"case": before["case"], "versions": versions, "metrics": metrics,
        "success_pair": success_pair, "comparison_rule": "success savings only for PASS/PASS; failed producer elapsed is retained separately"})
capture_valid = all(execution.get("measurement_capture_valid") is True for execution in executions.values())
source_unchanged = all(execution.get("source_runtime_unchanged") is True for execution in executions.values())
arc_valid = all(version["coverage_data"].get("sqlite_header") is True and version["coverage_data"].get("meta", {}).get("has_arcs") == "1" for row in rows for version in row["versions"].values())
candidate_pass = all(row["versions"]["candidate"]["outcome"] == "PASS" and row["versions"]["candidate"]["tests_run"] == 1 and not row["versions"]["candidate"]["timed_out"] for row in rows)
summary = {"schema": "source-facts-covered-original-pair-v1", "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "candidate_original_methods": "PASS" if candidate_pass else "FAIL_OR_INCOMPLETE",
    "measurement_capture_valid": capture_valid, "source_runtime_unchanged": source_unchanged,
    "branch_data_metadata_valid": arc_valid, "serial_baseline_then_candidate": True,
    "pairs": 1, "methods_per_version": 2, "cases": rows,
    "helper_sha256": freeze["helper_sha256"], "config_sha256": freeze["config_sha256"],
    "coverage_version": freeze["coverage_version"], "coverage_identity_sha256": freeze["coverage_identity_sha256"],
    "coverage_environment": freeze["coverage_environment"],
    "execution_sha256": {name: sha(path) for name, path in paths.items()},
    "native_execution_flags": {name: {"measurement_capture_valid": execution.get("measurement_capture_valid"), "source_runtime_unchanged": execution.get("source_runtime_unchanged")} for name, execution in executions.items()},
    "product_budget_seconds": 120, "external_timeout_seconds": 300,
    "budget_margin": "Not quantified: no separate native producer elapsed field captured; method interval includes work outside the guard's clock interval; never subtract method wall time from120",
    "normal_pair_reference": {"path": "PAIR_SUMMARY.json", "sha256": sha(BASE / "PAIR_SUMMARY.json")},
    "scope": "One local original two-method CI-style branch/path-source covered pair; no hosted/full-suite/policy GatePASS or candidate commit authority",
    "source_binding": "Fixed d7 tracked baseline versus explicitly frozen dirty d7 worktree candidate sourcec309/test52, same original cases/fixtures/runtime178/pin/interpreter/userfiles",
    "count_scope": "Credential/request counts are original test self.provider after cleanup; separate original class-stage/conformance provider objects are not aggregated",
    "sampling_limit": "Single old-then-new serial covered pair; no uncertainty estimate; detective product clock interval not separately instrumented; failed producer time is not successful savings",
    "execution_budget": {"selected_original_methods_per_version": 2,
        "actual_tests_run": {name: sum(record.get("native_result", {}).get("tests_run", 0) for record in execution["records"]) for name, execution in executions.items()},
        "retries": 0, "full_suites": 0, "API": 0, "source_content_reads": 7},
}
save(BASE / "COVERED_SUMMARY.json", summary)
lines = []
for row in rows:
    wall = row["metrics"]["test_interval_seconds"]
    status = row["versions"]["d7"]["outcome"] + "/" + row["versions"]["candidate"]["outcome"]
    savings = f"{wall['success_to_success_saved_seconds']:.6f}s ({wall['success_to_success_saved_percent']:.2f}%)" if row["success_pair"] else "not success-to-success"
    old, new = wall["baseline"], wall["candidate"]
    lines.append(f"| `{row['case'].split('.')[-1]}` | {status} | {old} | {new} | {savings} |")
failures = []
for row in rows:
    for name, version in row["versions"].items():
        for error in version["failures"] + version["errors"]:
            failures.append(f"### {name}: {error['id']}\n\n```text\n{error['native_detail']}\n```\n")
report = f"""# Covered original-method old/new pair

Candidate original-method result: **{summary['candidate_original_methods']}**. Measurement capture valid: **{capture_valid}**; source/Runtime unchanged: **{source_unchanged}**; branch SQLite metadata valid: **{arc_valid}**. Exactly one covered old/new pair, two original methods each, baseline then candidate serially; no retry. Root and other agents kept timing windows free of other tests/producers.

| Original method | d7/candidate outcome | d7 test interval s | Candidate test interval s | Successful-run reduction |
|---|---:|---:|---:|---:|
{chr(10).join(lines)}

Native producer/test failures are retained exactly below and in original stderr/results. If baseline failed, its elapsed interval includes the native failed outcome and is not used to claim successful-run savings. Candidate PASS means all original completed/replay_valid, helper archive drift rejection, credential/request and rehashed missing/extra assertions executed successfully. Whole testcase wall time is not the product's measured 120-second interval; no external 200-second threshold is inferred. The native producer elapsed field was not captured separately, so no numerical guard margin is reported and120 is never reduced by method/test wall time.

Both versions used unchanged coverage helper `{summary['helper_sha256']}`, config `{summary['config_sha256']}`, installed local coverage{summary['coverage_version']} (identity `{summary['coverage_identity_sha256']}`), existing Python3.11 interpreter and user files, Runtime178 and generated pin. Actual profile/trace flags and tracer types are recorded per case in `COVERED_SUMMARY.json`; new data files are independently hashed and read only for SQLite has_arcs/file/arc metadata. Credential/request counts refer to the original case's self.provider; separate original class-stage/conformance objects are not aggregated. Source/pin/Runtime identities are frozen before/after each version. Root's frozen candidate is dirty worktree sourcec309/test52 at Git HEAD d7; no new commit execution is implied.

The rcfile is byte-identical old/new, produced by unchanged actual CI coverage_config using cached historical c80 plan filter data. It measures branch/path sources src/research_workbench, .github/scripts, . with complementary omit. No verify_plan, re-sign, native full-result projection, policy checker or full-suite runner was invoked. Local two-method results do not establish hosted/full311 success, policy threshold GatePASS or repository coverage obligations. The earlier c80 full overall failure remains separate evidence.

Normal old/new pair is retained independently in `PAIR_REPORT.md`/`PAIR_SUMMARY.json`. Covered timing is one serial sample with no uncertainty estimate; interpreter/environment are bound, but background variation and ordering effects remain. Original methods/fixture seeds, real monotonic clock, UTC fixture, class stage, setup, fresh provider/credential/transport, journal/replay paths, every-use refs/bytes/current runtime/defaults/aliases/closed sets and both original negative assertions are unchanged. No producer or verification PASS was cached or substituted, no budget/source edit occurred during runs, and no test was deleted.

Preparation's tuple/list rejection and missing pin errors remain separately preserved as zero-test preparation failures. Output paths `coverage-d7` and `coverage-candidate` contain original raw stdout/stderr, native JSON and data files. This report/SUMMARY/MANIFEST are newly written without rewriting prior normal/helper/preparation evidence. Source-content reads7; external API/install/workflow/full-suite/retries0. Root handles shared Issue/project records; this agent made no shared writes.

## Retained native failure details

{chr(10).join(failures) if failures else 'No native unittest failures/errors in either version.'}
"""
(BASE / "COVERED_REPORT.md").write_text(report, encoding="utf-8")
files = [path for path in BASE.rglob("*") if path.is_file() and not path.is_relative_to(BASE / "snapshot-d7") and path.name != "COVERED_MANIFEST.json"]
save(BASE / "COVERED_MANIFEST.json", {"schema": "covered-original-pair-manifest-v1", "files": {
    path.relative_to(BASE).as_posix(): {"bytes": path.stat().st_size, "sha256": sha(path)} for path in sorted(files)}})
print(json.dumps({"candidate_original_methods": summary["candidate_original_methods"], "measurement_capture_valid": capture_valid,
                  "branch_data_metadata_valid": arc_valid, "cases": rows,
                  "summary_sha256": sha(BASE / "COVERED_SUMMARY.json"), "report_sha256": sha(BASE / "COVERED_REPORT.md"),
                  "manifest_sha256": sha(BASE / "COVERED_MANIFEST.json")}, ensure_ascii=False))
