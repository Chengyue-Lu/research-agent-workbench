"""Artifact-only manifest, preserving all previous manifests."""
from pathlib import Path
import json
import hashlib

BASE = Path(__file__).resolve().parent
PREP = BASE / "coverage-preparation"
files = [path for path in PREP.rglob("*") if path.is_file() and path.name != "MANIFEST.json"]
files.extend(BASE / name for name in ("run_pair_coverage.py", "prepare_coverage.py", "freeze_coverage.py", "CONTINUATION_VISIBLE_EVENTS.md", "manifest_coverage_preparation.py"))
data = {"schema": "coverage-preparation-artifacts-v2", "files": {
    path.relative_to(BASE).as_posix(): {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    for path in sorted(files)}}
target = PREP / "MANIFEST.json"
target.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"path": target.as_posix(), "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}))
