"""Static freeze of the explicit coverage helper/config; never runs cases."""
from pathlib import Path
import importlib.util
import json
import datetime
import difflib
import os

BASE = Path(__file__).resolve().parent
PREP = BASE / "coverage-preparation"
normal = BASE / "run_pair.py"
runner = BASE / "run_pair_coverage.py"
compile(runner.read_bytes(), str(runner), "exec")
spec = importlib.util.spec_from_file_location("coverage_pair_static_only", runner)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
config = json.loads((PREP / "preparation.json").read_text(encoding="utf-8"))
assert config["config_bytes_equal"] is True
assert module.sha(normal) == "c793a6778e8b30f5401bc5f2f05c9bcacad1d0045d9a598eca3c33676c5231a4"
environment = {name: os.environ.get(name) for name in ("COVERAGE_CORE", "COVERAGE_TEST_TRACER", "COVERAGE_DEBUG", "COVERAGE_PROCESS_START")}
assert environment["COVERAGE_PROCESS_START"] is None
records = {}
for name, original_manifest, rcfile in (
    ("d7", BASE / "preparation.json", PREP / "ci-coverage-d7.ini"),
    ("candidate", BASE / "preparation-candidate.json", PREP / "ci-coverage-candidate.ini"),
):
    prepared = json.loads(original_manifest.read_text(encoding="utf-8"))
    identity = module.identity(Path(prepared["snapshot_path"]))
    assert identity == prepared["snapshot_identity"]
    prepared.update({
        "schema": "original-graph-pair-coverage-preparation-v2",
        "prepared_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "runner_path": runner.as_posix(), "runner_sha256": module.sha(runner),
        "measurement_mode": "coverage",
        "coverage_binding": {"config_path": rcfile.as_posix(), "config_sha256": module.sha(rcfile),
            "installed_identity_path": (PREP / "installed-coverage-identity.json").as_posix(),
            "installed_identity_sha256": module.sha(PREP / "installed-coverage-identity.json"),
            "version": config["coverage_version"], "environment": environment},
        "execution_output_path": (BASE / ("coverage-" + name)).as_posix(),
        "approval": "PREPARATION_ONLY; root must approve coverage execution after static review/normal pair",
    })
    assert not Path(prepared["execution_output_path"]).exists()
    target = PREP / ("preparation-" + name + ".json")
    module.save(target, prepared)
    records[name] = {"path": target.as_posix(), "sha256": module.sha(target), "output": prepared["execution_output_path"]}
patch = "".join(difflib.unified_diff(normal.read_text(encoding="utf-8").splitlines(True),
                                   runner.read_text(encoding="utf-8").splitlines(True),
                                   fromfile="run_pair.py@c793", tofile="run_pair_coverage.py"))
(PREP / "COVERAGE_HELPER_DIFF.patch").write_text(patch, encoding="utf-8")
summary = {"schema": "coverage-helper-freeze-v2", "static_syntax": "PASS", "source_bindings_unchanged": True,
    "helper_sha256": module.sha(runner), "normal_helper_sha256": module.sha(normal),
    "helper_diff_sha256": module.sha(PREP / "COVERAGE_HELPER_DIFF.patch"), "manifests": records,
    "config_sha256": config["old_config_sha256"], "config_bytes_equal": True,
    "coverage_version": config["coverage_version"], "coverage_identity_sha256": config["coverage_identity_sha256"],
    "coverage_environment": environment, "each_case_timeout_seconds": 300,
    "original_product_budget_seconds": 120, "cases": module.CASES,
    "coverage_case_execution": 0, "tests": 0, "business_imports": 0, "API": 0,
    "read_boundary": "six prior Python fixture/budget sources plus explicit root-authorized seventh ci_checks config source; no additional business content reads",
    "tracer_observer": "sys.gettrace presence/type and sys.getprofile presence recorded inside coverage child; no tracer type predicted as actual before execution",
    "authority_boundary": "cached c80 plan coverage filter data only; no verify_plan/re-sign/new run binding or policy evaluation",
    "approval": "PREPARATION_ONLY; coverage pair not executed",
}
module.save(PREP / "FREEZE.json", summary)
report = f"""# CI-style coverage pair preparation v2

Preparation **PASS**; zero coverage case/test/producer/API executions. Normal runner stays unchanged at `{summary['normal_helper_sha256']}` and its old/new reports remain preserved. New explicit coverage helper `{runner.as_posix()}` SHA-256 `{summary['helper_sha256']}`; exact diff SHA-256 `{summary['helper_diff_sha256']}`. Original methods, native unittest order/assertions, class stage, setUp/cleanup, source/current-runtime checks, one fresh provider/credential/transport and the 120-second product budget are unchanged. Each child remains externally bounded at300 seconds with no retry.

The actual CI `.github/scripts/ci_checks.py.coverage_config` generated both rcfiles directly from the same cached c80 plan (rawSHA `{config['cached_c80_plan']['sha256']}`), without calling CLI main, verify_plan or any policy checker. Generator source SHA-256 `{config['config_generator_sha256']}` is identical old/new. Old/new rcfile bytes are identical, SHA-256 `{summary['config_sha256']}`. Config uses branch=True and **path** sources `src/research_workbench`, `.github/scripts`, `.` with complementary omitted paths. This follows root's inspected CI path-source command; it is not a module-only `--source=research_workbench` measurement.

Installed local coverage version is `{summary['coverage_version']}`; full installed-file identity SHA-256 `{summary['coverage_identity_sha256']}`. Same interpreter, config, source bindings, Runtime178 and generated pin are frozen for each version. Coverage-specific environment is `{environment}`; process auto-start is absent. Each future child invokes `python -B -X utf8 -m coverage run --rcfile=... run_pair_coverage.py ... --coverage-mode`, with its own new absolute COVERAGE_FILE under the assessment. No config/data file is written into either repository. Installed coverage/config/interpreter/source/pin/Runtime bytes and selected coverage environment are rechecked before execution.

Child records are explicitly labeled coverage, with actual sys.gettrace presence/type, sys.getprofile presence, local coverage version, rcfile/data paths and file hashes. No tracer is guessed during preparation. The collector's presence and saved data determine a separate measurement_capture_valid field; native original-test PASS/FAIL stays distinct. Source and Runtime identities are checked before/after each original case. No product function/code/global/clock or producer output is substituted.

Cached plan target remains c80 and is used only as historical filter data. It is not verified/re-signed as current candidate authority, not a new native result projection, and not a full hosted run. These local two-case covered measurements cannot establish repository coverage thresholds, policy gate PASS or hosted/full-suite equivalence. Source-content reads total7 because root explicitly extended the six-file budget for the CI config helper. No additional business source was read.

Frozen manifests:

- d7: `{records['d7']['path']}`, SHA-256 `{records['d7']['sha256']}`, new output `{records['d7']['output']}`.
- candidate: `{records['candidate']['path']}`, SHA-256 `{records['candidate']['sha256']}`, new output `{records['candidate']['output']}`.

Execution requires root's later explicit approval after static review and the normal-pair results. The helper refuses missing --coverage-mode, changed bindings or existing output directories. All old normal/helper/preparation-failure evidence remains retained.
"""
(PREP / "REPORT.md").write_text(report, encoding="utf-8")
print(json.dumps({**summary, "freeze_sha256": module.sha(PREP / "FREEZE.json"),
                  "report_sha256": module.sha(PREP / "REPORT.md")}, ensure_ascii=False))
