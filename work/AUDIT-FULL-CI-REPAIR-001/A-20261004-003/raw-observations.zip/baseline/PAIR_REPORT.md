# Normal original-method old/new pair

**PASS** for both original graph methods, baseline then candidate serially using exactly the same runner `c793a6778e8b30f5401bc5f2f05c9bcacad1d0045d9a598eca3c33676c5231a4`. One original-method pair per version; no repeat for performance. Candidate is the explicit frozen dirty worktree at Git HEAD d7, source SHA `c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3`; it is not a new candidate commit execution claim.

| Original method | Old/new | Old test interval s | New test interval s | Measured reduction | Old/new test CPU s |
|---|---:|---:|---:|---:|---:|
| `test_v12_cold_replay_rejects_helper_source_drift_without_provider_reuse` | PASS/PASS | 77.942094 | 28.501559 | 49.440535 (63.43%) | 76.453125/27.859375 |
| `test_v12_rehashed_use_facts_require_exact_source_closure_per_invocation` | PASS/PASS | 79.876910 | 29.934511 | 49.942399 (62.52%) | 78.171875/29.062500 |

The existing interpreter, user AGENTS/config, Runtime178 and generated pin, original graph test/fixture/budget source bytes and runner bytes were identical. Candidate tracked bytes differ only in root's provider_source_closure source, its own regression test, and two workstream documents; exact old/new hashes are in `CANDIDATE_BINDING.json`. Both versions retain original class-stage/setUp/assertions, real monotonic clock, Protocol120-second budget, source archive validation, credential/request checks and both missing/extra subtests. Each method has a fresh interpreter/class stage and fresh provider/credential/transport. Source/pin/Runtime identities remained unchanged throughout each version.

These are observed differences in one **local normal** unprofiled old/new pair. Root paused competing tests and performed sub-second probes between versions. Test interval includes setUp/method/cleanup; class-stage plus runner and import overhead remain separate fields in `PAIR_SUMMARY.json`. No setUp or producer elapsed timing was isolated. Background variation and ordering effects have no uncertainty estimate. Normal PASS and lower normal elapsed do not establish that the earlier c80 coverage-run budget failures are fixed. No 200-second external failure threshold is inferred; the original in-session budget is120 seconds.

Baseline preparation failures and all raw bytes remain in their original paths and are excluded from performance samples. This report preserves `REPORT.md`, `summary.json` and original `manifest.json` baseline artifacts. New candidate raw evidence is in `normal-candidate`; native failures/errors and exact chronological unittest events are captured without request/credential parameter logging. Coverage pairing is preparation only until root separately approves execution; no hosted/full-suite/gate claim is made.
