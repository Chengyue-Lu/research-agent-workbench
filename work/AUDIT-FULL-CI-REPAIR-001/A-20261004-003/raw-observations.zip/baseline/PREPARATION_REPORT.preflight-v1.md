# Fixed d7 baseline pair preparation

Snapshot: `D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/baseline/snapshot-d7`; detached HEAD `d7c13791b8ade226a7448cacac3a05fdfe7f71c2`. The source worktree can change concurrently; tests will run only in this frozen snapshot. Root explicitly approved this path and one normal serial pair on 2026-10-04. No tests or producers ran during preparation.

`AGENTS.md` and `.codex/config.toml` were copied byte-for-byte from the existing worktree. Only these two tracked files differ from d7; memory generation is disabled. Runtime was copied from the existing generated directory, without building or installing: 178 files, SHA-256 `5c6d97f52d607c4dacf61cb8e97bae427b8fdca3d6085f39b945497d79a0106d` using the prior P234 sorted path/hash tuple algorithm. Copied/source rows match at preparation and match the P234 178-file identity. The snapshot's complete tracked-file and Runtime hashes are frozen in `preparation.json`.

The runner `run_pair.py` SHA-256 is `e9d6b1a71afa89eec1315de707e551633d949a8baccc6c77290514692e067e5b`. Interpreter `D:\lcy\develop\_assessments\rwb-ci-schema-parse-20260917\venv311\Scripts\python.exe`, 3.11.16, SHA-256 `1e2031f6e427a86cdef7ba777e58d5a6fa01bc225f3d6e065fbb4f9e58d5685f`. One static syntax compile and metadata binding check passed; business imports/tests/producer/API count is zero.

## Original methods and timing

1. `tests.test_provider_binding_graph.ProviderBindingGraphTests.test_v12_cold_replay_rejects_helper_source_drift_without_provider_reuse`
2. `tests.test_provider_binding_graph.ProviderBindingGraphTests.test_v12_rehashed_use_facts_require_exact_source_closure_per_invocation`

Each original method runs once in a fresh interpreter and original unittest suite, serially in the native alphabetical order of these two methods. The original class stage runs once per child, then the original setUp/method/cleanup; no test or product callable is replaced. Every original assertion remains. Each child is externally bounded at 300 seconds; first failure is retained and the second still runs. There is no retry. Raw stdout/stderr and native unittest failures/subtests are retained. Counts only are captured for credential resolution and transport requests; parameters and credential values are not inspected.

The default `run_baseline_session` clock is real `time.monotonic`; the graph test supplies only its original frozen UTC clock. `SystemEvaluationFixture.build` creates Protocol `execution_time_budget_seconds=120` (line 569); `compile_baseline_envelope` transfers this to `budget.max_seconds` (line 222). BaselineFixture sets max_parallel=1; configured binding fixture lowers max_output_tokens to64. Effective budget is 120 seconds, 4 turns, 64 output tokens, max_parallel1. No threshold changes are made.

The budget starts at baseline.py line314, after envelope validation/request preparation, and covers the active session, fresh use-boundary reads and observation, response-side facts, and end-clock check. The post-call guard is detective, with no hard preemption. Whole testcase wall time is not the measured budget interval and cannot establish a fixed external failure threshold.

Normal unittest Result.startTest/stopTest gives the test interval, including original setUp and cleanup. Import/load, class-stage plus pre-test runner overhead, and post-test runner/class-cleanup overhead are reported separately where naturally exposed. setUp is not separately isolated, and the product elapsed interval is not instrumented. The runner uses neither coverage nor sys.setprofile/sys.settrace.

## Fixture and attack boundaries

The class stage creates a complete graph binding with source_closure and conformance; each setUp creates fresh configured profile/provider/credential/transport and copies the stage archive. Source references and bytes/current runtime/defaults/aliases/closed sets are checked by original product code; no validation PASS or producer output is shared. The synthetic injected transport has original no-retry/no-redirect configuration and timeout10, response bound65536. A1 original synthetic task/public input, request payload, journal, closure and replay construction remain intact.

Both methods require the baseline completed/replay_valid assertions first. The helper-drift method then changes an archived pins source, retains its original Provider.generate guard, requires closure failure and exactly one credential resolution/request. Despite its name, this method's negative replay is in the same process. The missing/extra method restores original bytes between its two subtests, re-signs retained facts, requires use.boundary rejection, and retains exactly one resolution/request. A normal PASS means those original guards executed; it is not a hosted coverage reproduction.

## Optional later coverage pairing (not executed)

The c80 full failures occurred under coverage. A normal old/new PASS cannot show their cause disappeared. A separately approved pair would reuse these same frozen source snapshots/interpreter/config/Runtime and original serial cases, adding `python -B -X utf8 -m coverage run --branch --source=research_workbench` to each child invocation and isolated coverage data paths. It must first bind the installed coverage identity and use identical coverage settings for old/new; no tests, budgets or source semantics change. Do not claim equivalence to the hosted run or subtract normal from covered timing as a source-change gain.

## Static source read boundary

Six Python source files were read; additional snapshot files were hashed as metadata only.

- `tests/test_provider_binding_graph.py`: `a4f95668a695442790a9e34d17a4419da6e14fec470fddbbfb68345ee6724307`
- `tests/test_provider_binding.py`: `764651413ce67a3e32c8efa1fe2f1d54209dab90fba57884618dbd6dc1f0f90e`
- `tests/baseline_fixtures.py`: `32d02a88e832f98b3542cf59a50f6ee9eddb4f59a7cf0c0c605667916e8c5d26`
- `tests/system_evaluation_fixtures.py`: `53cc629f96db11d25490b1515a87d0aff5d6fb461ac95b0c52636ae83a9bae53`
- `src/research_workbench/execution/baseline.py`: `e9184fb6d536120853f256e2f45dd05d65f1184b5d64a4b6ac58b119063c1406`
- `src/research_workbench/execution/baseline_envelope.py`: `1916423789a7502fc20dc628f13ac4e8df4339f5b4271636f5eeee7a1808e84f`

## Authorized invocation

`D:\lcy\develop\_assessments\rwb-ci-schema-parse-20260917\venv311\Scripts\python.exe -B -X utf8 D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/baseline/run_pair.py --snapshot D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/baseline/snapshot-d7 --prepared-manifest D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/baseline/preparation.json --output-dir D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/baseline/normal-d7 --execute-approved`

The runner refuses changed snapshot/Runtime/runner bytes or an existing output directory. Environment PYTHONPATH is snapshot/src;snapshot; test fixture temporary files remain under the assessment. No product edits, API, install, CI/workflow/full-suite execution or shared-memory updates are authorized by this report.
