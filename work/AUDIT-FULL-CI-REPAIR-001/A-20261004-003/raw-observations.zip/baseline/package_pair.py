"""Offline same-runner normal old/new comparison, preserving baseline reports."""
from pathlib import Path
import hashlib
import json
import datetime

BASE = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

old_path = BASE / "normal-d7-v2/execution.json"
new_path = BASE / "normal-candidate/execution.json"
old = json.loads(old_path.read_text(encoding="utf-8"))
new = json.loads(new_path.read_text(encoding="utf-8"))
candidate_binding = json.loads((BASE / "CANDIDATE_BINDING.json").read_text(encoding="utf-8"))
assert len(old["records"]) == len(new["records"]) == 2
rows = []
for index, (before, after) in enumerate(zip(old["records"], new["records"]), 1):
    assert before["case"] == after["case"]
    b, a = before.get("native_result", {}), after.get("native_result", {})
    metrics = {}
    for name in ("subprocess_wall_seconds", "suite_wall_seconds", "suite_cpu_seconds", "test_interval_seconds", "test_interval_cpu_seconds", "import_and_load_seconds", "suite_before_startTest_seconds", "suite_after_stopTest_seconds"):
        bv = before.get(name, b.get(name))
        av = after.get(name, a.get(name))
        metrics[name] = {"baseline": bv, "candidate": av,
            "saved_seconds": bv - av if bv is not None and av is not None else None,
            "saved_percent": 100 * (bv - av) / bv if bv and av is not None else None}
    rows.append({"case": before["case"], "baseline_outcome": b.get("outcome"),
        "candidate_outcome": a.get("outcome"), "baseline_tests": b.get("tests_run", 0),
        "candidate_tests": a.get("tests_run", 0), "candidate_timeout": after["timed_out"],
        "metrics": metrics, "credential_resolutions": {"baseline": b.get("credential_resolutions"), "candidate": a.get("credential_resolutions")},
        "request_counts": {"baseline": b.get("transport_request_count"), "candidate": a.get("transport_request_count")},
        "candidate_profile_enabled": a.get("profile_enabled"), "candidate_trace_enabled": a.get("trace_enabled"),
        "baseline_native_events": b.get("native_events", []), "candidate_native_events": a.get("native_events", []),
        "candidate_failures": a.get("failures", []), "candidate_errors": a.get("errors", []),
        "candidate_source_runtime_unchanged": after["source_runtime_unchanged"],
        "candidate_stdout_sha256": sha(BASE / f"normal-candidate/case-{index}.stdout.txt"),
        "candidate_stderr_sha256": sha(BASE / f"normal-candidate/case-{index}.stderr.txt"),
    })
summary = {"schema": "source-facts-normal-original-pair-v1", "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "outcome": "PASS" if all(r["baseline_outcome"] == r["candidate_outcome"] == "PASS" and r["baseline_tests"] == r["candidate_tests"] == 1 and not r["candidate_timeout"] for r in rows) else "FAIL_OR_INCOMPLETE",
    "serial_baseline_then_candidate": True, "pairs": 1, "cases": rows,
    "runner_sha256": candidate_binding["runner_sha256"], "candidate_binding": candidate_binding,
    "baseline_execution_sha256": sha(old_path), "candidate_execution_sha256": sha(new_path),
    "baseline_source_runtime_unchanged": old["source_runtime_unchanged"],
    "candidate_source_runtime_unchanged": new["source_runtime_unchanged"],
    "scope": "Local normal unprofiled same-runner original methods once old/new; not covered/hosted/full-suite validation or proof full-CI budget issue resolved",
    "environment": "Same existing Python3.11 interpreter/userfiles/Runtime178/pin, original graph/fixture/budget source bytes; root paused other tests and ran short probes only between version pairs",
    "sampling_limit": "Single serial old-then-new pair, no uncertainty estimate; machine/background variation not controlled; stopwatch intervals include setup/cleanup and no invasive producer elapsed instrumentation",
    "coverage_pair": "Prepared only after this comparison, requires root approval to execute",
}
save(BASE / "PAIR_SUMMARY.json", summary)
lines = []
for row in rows:
    wall = row["metrics"]["test_interval_seconds"]
    cpu = row["metrics"]["test_interval_cpu_seconds"]
    lines.append(f"| `{row['case'].split('.')[-1]}` | {row['baseline_outcome']}/{row['candidate_outcome']} | {wall['baseline']:.6f} | {wall['candidate']:.6f} | {wall['saved_seconds']:.6f} ({wall['saved_percent']:.2f}%) | {cpu['baseline']:.6f}/{cpu['candidate']:.6f} |")
report = f"""# Normal original-method old/new pair

**{summary['outcome']}** for both original graph methods, baseline then candidate serially using exactly the same runner `{summary['runner_sha256']}`. One original-method pair per version; no repeat for performance. Candidate is the explicit frozen dirty worktree at Git HEAD d7, source SHA `c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3`; it is not a new candidate commit execution claim.

| Original method | Old/new | Old test interval s | New test interval s | Measured reduction | Old/new test CPU s |
|---|---:|---:|---:|---:|---:|
{chr(10).join(lines)}

The existing interpreter, user AGENTS/config, Runtime178 and generated pin, original graph test/fixture/budget source bytes and runner bytes were identical. Candidate tracked bytes differ only in root's provider_source_closure source, its own regression test, and two workstream documents; exact old/new hashes are in `CANDIDATE_BINDING.json`. Both versions retain original class-stage/setUp/assertions, real monotonic clock, Protocol120-second budget, source archive validation, credential/request checks and both missing/extra subtests. Each method has a fresh interpreter/class stage and fresh provider/credential/transport. Source/pin/Runtime identities remained unchanged throughout each version.

These are observed differences in one **local normal** unprofiled old/new pair. Root paused competing tests and performed sub-second probes between versions. Test interval includes setUp/method/cleanup; class-stage plus runner and import overhead remain separate fields in `PAIR_SUMMARY.json`. No setUp or producer elapsed timing was isolated. Background variation and ordering effects have no uncertainty estimate. Normal PASS and lower normal elapsed do not establish that the earlier c80 coverage-run budget failures are fixed. No 200-second external failure threshold is inferred; the original in-session budget is120 seconds.

Baseline preparation failures and all raw bytes remain in their original paths and are excluded from performance samples. This report preserves `REPORT.md`, `summary.json` and original `manifest.json` baseline artifacts. New candidate raw evidence is in `normal-candidate`; native failures/errors and exact chronological unittest events are captured without request/credential parameter logging. Coverage pairing is preparation only until root separately approves execution; no hosted/full-suite/gate claim is made.
"""
(BASE / "PAIR_REPORT.md").write_text(report, encoding="utf-8")
files = [path for path in BASE.rglob("*") if path.is_file() and not path.is_relative_to(BASE / "snapshot-d7") and path.name != "PAIR_MANIFEST.json"]
save(BASE / "PAIR_MANIFEST.json", {"schema": "normal-original-pair-manifest-v1", "files": {
    path.relative_to(BASE).as_posix(): {"bytes": path.stat().st_size, "sha256": sha(path)} for path in sorted(files)}})
print(json.dumps({"outcome": summary["outcome"], "cases": rows,
                  "summary_sha256": sha(BASE / "PAIR_SUMMARY.json"), "report_sha256": sha(BASE / "PAIR_REPORT.md"),
                  "manifest_sha256": sha(BASE / "PAIR_MANIFEST.json")}, ensure_ascii=False))
