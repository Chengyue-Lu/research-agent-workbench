"""Metadata-only binding of root's explicitly frozen candidate worktree."""
from pathlib import Path
import importlib.util
import datetime
import json
import sys

BASE = Path(__file__).resolve().parent
WT = Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004")
runner = BASE / "run_pair.py"
spec = importlib.util.spec_from_file_location("graph_pair_candidate_metadata", runner)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert module.sha(runner) == "c793a6778e8b30f5401bc5f2f05c9bcacad1d0045d9a598eca3c33676c5231a4"
old = json.loads((BASE / "preparation.json").read_text(encoding="utf-8"))
current = module.identity(WT)
assert current["head"] == old["snapshot_identity"]["head"]
assert current["runtime"] == old["snapshot_identity"]["runtime"]
assert current["runtime_pin"] == old["snapshot_identity"]["runtime_pin"]
assert module.sha(sys.executable) == old["interpreter_sha256"]
before_files = old["snapshot_identity"]["tracked_files"]
after_files = current["tracked_files"]
assert set(before_files) == set(after_files)
differences = {name: {"baseline_sha256": before_files[name], "candidate_sha256": after_files[name]}
               for name in before_files if before_files[name] != after_files[name]}
required = {"src/research_workbench/adapters/models/provider_source_closure.py", "tests/test_provider_source_closure.py"}
assert required.issubset(differences)
assert all(name in required or name.startswith("docs/workstreams/") for name in differences)
assert len(differences) == 4
assert differences["src/research_workbench/adapters/models/provider_source_closure.py"]["candidate_sha256"].startswith("c309208f")
assert differences["tests/test_provider_source_closure.py"]["candidate_sha256"].startswith("52c10a34")
for name in old["static_read_source_hashes"]:
    assert after_files[name] == before_files[name]
assert after_files["AGENTS.md"] == before_files["AGENTS.md"]
assert after_files[".codex/config.toml"] == before_files[".codex/config.toml"]
candidate = dict(old)
candidate.update({
    "schema": "original-graph-pair-candidate-preparation-v1",
    "prepared_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "snapshot_path": WT.as_posix(), "snapshot_identity": current,
    "execution_output_path": (BASE / "normal-candidate").as_posix(),
    "root_freeze": "Explicit root freeze for dirty candidate source c309208f/test52c10a34 and two workdocs; root will not edit during serial pair",
    "tracked_differences_from_fixed_d7": differences,
    "approval": {"root_approved_snapshot_path": True,
        "scope": "same unchanged c793 runner, original two methods once normal serial after root short probes finish; coverage preparation only"},
})
assert not (BASE / "normal-candidate").exists()
assert json.loads(json.dumps(current)) == current
module.save(BASE / "preparation-candidate.json", candidate)
report = {
    "schema": "candidate-metadata-binding-v1", "runner_sha256": module.sha(runner),
    "preparation_sha256": module.sha(BASE / "preparation-candidate.json"),
    "candidate_path": WT.as_posix(), "head": current["head"], "tracked_status": current["tracked_status"],
    "differences": differences, "six_original_read_source_hashes_equal": True,
    "runtime178_and_pin_equal": True, "interpreter_and_user_files_equal": True,
    "business_imports": 0, "tests": 0, "API": 0,
    "normal_d7_summary_sha256": module.sha(BASE / "summary.json"),
}
module.save(BASE / "CANDIDATE_BINDING.json", report)
print(json.dumps(report, ensure_ascii=False))
