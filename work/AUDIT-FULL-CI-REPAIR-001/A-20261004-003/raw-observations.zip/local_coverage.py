"""Local diagnostic of the changed critical source, not repository authority."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
WT=Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
OUT=ROOT/'source-coverage';OUT.mkdir(exist_ok=False)
PY=sys.executable
env=dict(os.environ)
env['PYTHONPATH']=str(WT/'src')+os.pathsep+str(WT)+os.pathsep+str(WT/'tests')
env['COVERAGE_FILE']=str(OUT/'.coverage')
env['PYTHONDONTWRITEBYTECODE']='1'
commands=[]
def run(command,label):
    start=time.perf_counter()
    done=subprocess.run(command,cwd=WT,env=env,capture_output=True,timeout=240)
    (OUT/(label+'.stdout.txt')).write_bytes(done.stdout)
    (OUT/(label+'.stderr.txt')).write_bytes(done.stderr)
    commands.append(dict(command=command,returncode=done.returncode,wall_seconds=time.perf_counter()-start))
    (OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf-8')
    assert done.returncode==0,label
source='src/research_workbench/adapters/models/provider_source_closure.py'
before=hashlib.sha256((WT/source).read_bytes()).hexdigest()
run([PY,'-B','-X','utf8','-m','coverage','run','--branch',
     '--source=research_workbench.adapters.models.provider_source_closure',
     str(ROOT/'run_local.py'),'--root',str(WT),'--output',str(OUT/'native'),
     'tests.test_provider_source_closure'],'tests')
run([PY,'-B','-X','utf8','-m','coverage','json','-o',str(OUT/'coverage.json')],'export')
data=json.loads((OUT/'coverage.json').read_bytes())
files={k:v for k,v in data['files'].items() if k.replace('\\','/').endswith(source)}
assert len(files)==1
record=next(iter(files.values()));summary=record['summary']
after=hashlib.sha256((WT/source).read_bytes()).hexdigest();assert before==after
result=dict(status='PASS_LOCAL_DIAGNOSTIC',python=sys.version,source_sha256=before,
    statements=summary['num_statements'],covered_lines=summary['covered_lines'],
    line_percent=100*summary['covered_lines']/summary['num_statements'],
    branches=summary['num_branches'],covered_branches=summary['covered_branches'],
    branch_percent=100*summary['covered_branches']/summary['num_branches'],
    repository_coverage_proven=False,quality_gate=False,
    scope='23 relevant source-closure cases; branch tracing limited to changed source; separate from full-config timing pair',
    coverage_sha256=hashlib.sha256((OUT/'coverage.json').read_bytes()).hexdigest())
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
