"""Correct only child import environment; rerun only affected cold case."""
from pathlib import Path
import hashlib, json, os, subprocess, time

ROOT = Path(__file__).resolve().parent
WT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
native = json.loads((ROOT / 'remaining-graph311/native.json').read_bytes())
failed_id = 'tests.test_provider_binding_graph.ProviderBindingGraphTests.test_cold_manifest_read_does_not_import_synthetic_component'
assert native['tests_run'] == 9 and not native['errors'] and not native['skipped']
assert [row['id'] for row in native['failures']] == [failed_id]
assert "ModuleNotFoundError: No module named 'research_workbench'" in native['failures'][0]['traceback']
env = dict(os.environ)
env['PYTHONPATH'] = os.pathsep.join((str(WT / 'src'), str(WT), str(WT / 'tests')))
env['PYTHONDONTWRITEBYTECODE'] = '1'
plan = json.loads((ROOT / 'graph-control-invocations.json').read_bytes())
first = list(plan['invocations'][0]['argv'])
first = first[:first.index('--output')] + ['--output', str(ROOT / 'remaining-cold311'), failed_id]
commands = [dict(python='3.11', argv=first, scope='only earlier child-import affected method'), plan['invocations'][1]]
OUT = ROOT / 'graph-control-environment-completion'
OUT.mkdir(exist_ok=False)
rows = []
for row in commands:
    start = time.perf_counter()
    done = subprocess.run(row['argv'], cwd=WT, env=env, capture_output=True, timeout=240)
    (OUT / (row['python'] + '.stdout.txt')).write_bytes(done.stdout)
    (OUT / (row['python'] + '.stderr.txt')).write_bytes(done.stderr)
    rows.append(dict(python=row['python'], scope=row['scope'], argv=row['argv'], returncode=done.returncode,
                     wall_seconds=time.perf_counter() - start, child_import_paths=env['PYTHONPATH']))
    (OUT / 'execution.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(python=row['python'], returncode=done.returncode, scope=row['scope'])), flush=True)
    assert done.returncode == 0
assert hashlib.sha256((WT / 'src/research_workbench/adapters/models/provider_source_closure.py').read_bytes()).hexdigest() == 'c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3'
