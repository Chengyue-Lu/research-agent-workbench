# Provider source-facts optimization

2026-10-04. Human owner: 路诚钺; Provider cross-owner review: 黄毅.
User authorization: attempt to resolve the two graph post-call budget failures using
the inspected repeated-derivation optimization. Work continues on Draft PR139.

Base c80ec014925f0cbbbaef5486bce8422a5b4f73fb; starting candidate
d7c13791b8ade226a7448cacac3a05fdfe7f71c2. Main checkout and user config/AGENTS stay unchanged.

Scope: source_closure private per-validation parse/derive reuse, necessary local
regressions, original failing graph cases, R2 documentation/archive and PR139/Issue87
existing-phase progress. No process/disk cache, cached PASS, global policy/threshold,
budget increase, deleted tests, selector/workflow, other-owner branch, Ready or merge.

Inputs: project AGENTS/README/docs navigation/DEVELOPMENT; existing PR139 workstream,
P234 reports and FACT_REUSE_ACCEPTANCE; provider_source_closure.py, its direct
provider_binding.py/configured.py callers; test_provider_source_closure.py,
test_provider_binding_graph.py and necessary existing runner/fixture imports.
Record additional directly relevant inputs before reading.

Delegation is bounded under the user's prior parallel-agent authorization and
current continuation. Skills=[] for all agents. Each agent writes only its declared
assessment directory; root owns product edits. Preserve visible messages/tool
outputs and source hashes; no hidden reasoning or secrets. Capture-gap is explicit.

Validation: own old/new tiny per-validation counts and equivalence; every-use
current refs/bytes/hash/runtime/defaults/aliases/wrapper/captured builtins and
closed sets retained. Cold reader remains fresh. Run existing relevant adversarial
suite and same-source/environment original failing cases without profiling;
only claim paired measured savings. Cross-owner review and fresh complete
checkpoint remain acceptance boundaries, distinct from local/component PASS.

Stop at a tested concrete Draft candidate plus its necessary current CI outcome,
or a diagnosed real blocker. Do not start repeated full hosted runs.
