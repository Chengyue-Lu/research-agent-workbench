"""Read-only union of local evidence identities, never rewrite native outcomes."""
from pathlib import Path
import ast, hashlib, json, subprocess

ROOT = Path(__file__).resolve().parent
WT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
SOURCE = 'c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3'
TEST = '52c10a34efbf80fce3829eec77a950f43e73e9a9f97826d2ff5c7d9e01bce96a'
def load(name): return json.loads((ROOT / name).read_bytes())
def identity(name):
    raw = (ROOT / name).read_bytes()
    return dict(path=name, sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
source_path = 'src/research_workbench/adapters/models/provider_source_closure.py'
test_path = 'tests/test_provider_source_closure.py'
assert hashlib.sha256((WT / source_path).read_bytes()).hexdigest() == SOURCE
assert hashlib.sha256((WT / test_path).read_bytes()).hexdigest() == TEST
normal = load('baseline/PAIR_SUMMARY.json')
covered = load('baseline/COVERED_SUMMARY.json')
assert normal['outcome'] == 'PASS' and normal['pairs'] == 1
assert covered['candidate_original_methods'] == 'PASS' and covered['pairs'] == 1
assert all(covered[k] is True for k in ('measurement_capture_valid', 'source_runtime_unchanged', 'branch_data_metadata_valid'))
for name in ('source-coverage/native/native.json', 'final-source313/native.json',
             'final-strengthened313/native.json', 'remaining-cold311/native.json', 'cold-graph313/native.json'):
    row = load(name)
    assert row['successful'] and not row['failures'] and not row['errors'] and not row['skipped']
    assert row['source_before'] == row['source_after'] and row['source_after'][source_path] == SOURCE
exact311 = load('source-coverage/native/native.json')
assert exact311['tests_run'] == 23 and exact311['source_after'][test_path] == TEST
strengthened313 = load('final-strengthened313/native.json')
assert strengthened313['tests_run'] == 2 and strengthened313['source_after'][test_path] == TEST
first_graph = load('remaining-graph311/native.json')
assert first_graph['tests_run'] == 9 and not first_graph['errors'] and not first_graph['skipped']
assert len(first_graph['failures']) == 1
failed = first_graph['failures'][0]
assert "ModuleNotFoundError: No module named 'research_workbench'" in failed['traceback']
corrected = load('remaining-cold311/native.json')
assert corrected['selected'] == [failed['id']] and corrected['tests_run'] == 1
graph_passed = {row['id'] for row in first_graph['records'] if row['outcome'] == 'passed'}
graph_passed.update(corrected['selected'])
graph_passed.update(case['case'] for case in covered['cases'])
graph_ast = ast.parse((WT / 'tests/test_provider_binding_graph.py').read_bytes())
cls = next(n for n in graph_ast.body if isinstance(n, ast.ClassDef) and n.name == 'ProviderBindingGraphTests')
expected_graph = {'tests.test_provider_binding_graph.ProviderBindingGraphTests.' + n.name
                  for n in cls.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
assert len(expected_graph) == 11 and graph_passed == expected_graph
review = load('independent/summary.json')
assert review['status'] == 'PASS' and not review['blockers']
assert all(row['checks'] == row['passed_checks'] == 45 and row['attack_callbacks'] == 0 for row in review['final_probes'])
result = dict(status='PASS_SCOPED_LOCAL_CANDIDATE', parent='d7c13791b8ade226a7448cacac3a05fdfe7f71c2',
    source_sha256=SOURCE, test_sha256=TEST,
    exact_current_source_suite311=23,
    source_suite313='original23 at prior test hash, two strengthened current methods then PASS; no duplicate-count claim',
    original_graph311_unique_passed=11, genuine_cold_positive313=True,
    historical_local_graph_execution='9 actual executions:8PASS+1 child-import environmentFAIL; only affected method rerun with child PYTHONPATH',
    pair_normal=True, pair_coverage_style=True, local_old_budget_failure_reproduced=False,
    full_repository_proven=False, quality_gate_proven=False,
    independent_checks_per_python=45, independent_attack_callbacks=0,
    evidence=[identity(name) for name in ('baseline/PAIR_SUMMARY.json', 'baseline/COVERED_SUMMARY.json',
        'source-coverage/native/native.json', 'final-source313/native.json', 'final-strengthened313/native.json',
        'remaining-graph311/native.json', 'remaining-cold311/native.json', 'cold-graph313/native.json',
        'independent/summary.json', 'source-coverage/summary.json')])
(ROOT / 'local-final-summary.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'evidence'}))
