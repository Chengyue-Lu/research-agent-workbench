# PR139 source-AST candidate native auditor preparation

状态：`PREPARED_UNBOUND_NOT_EXECUTED`；单次 offline prepare PASS，exit 0。最终 HEAD/run/target/tree/official plan 均未绑定，`final_hosted_binding=null`；d7 仅是起始 parent/history。0 API、download、tests、test-module imports、producer import/execute；没有 terminal 调用、源码修改、commit 或 push。写入仅本 native-preparation，新旧所有工具/证据身份分别保留。

工具：[audit_native.py](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/audit_native.py)，SHA-256 `a90d7577f5ad4b16524af7f51490520cbddb7ee92b9d4293ee579fc54e0bffd1`。
完整适配：[adaptation.diff](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/adaptation.diff)；来源：[SOURCE_BINDINGS.json](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/SOURCE_BINDINGS.json)；原始 prepare 收据：[prepare-receipt.json](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/prepare-receipt.json)。

源码 `c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3` / test `52c10a34efbf80fce3829eec77a950f43e73e9a9f97826d2ff5c7d9e01bce96a`。直接 AST 比较 c80 17→d7 21→candidate 23，旧方法 body AST 全等；两项新方法是 successful_verification_does_not_authorize_later_source_or_runtime 与 successful_read_does_not_authorize_changed_claims_or_compiler。使用已独立静态审查/hash绑定的 accepted 530/d7 536 inventory metadata，未变的 collection files 以 Git metadata 核对；当前 prepare 不再扩读43个源码。未来 terminal 会重新读取 accepted/d7/target 全部 selected source，证明530与536全部 AST保留，source-derived 538 + exact short7 = 545，并核对四片 ordered IDs 和完整唯一不交并集。

完整预期列表：[expected-native-inventory.json](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/expected-native-inventory.json)。预期 canonical digest `77a6366bb2905f54b2c23f87afc77ca81879dec53d8ad9541f956c2271699f7b`；四片数量 [145, 137, 140, 123]。相对 accepted 的八个 exact IDs：

- `test_ci_components.ComponentPlanTests.test_protocol_and_exclusion_policy_changes_select_position_guard`
- `test_coverage_policy.CoveragePolicyCheckerTests.test_checked_in_exclusions_match_static_coverage_analysis`
- `test_provider_source_closure.ProviderSourceClosureTests.test_generated_dataclass_repr_and_explicit_custom_repr_are_supported`
- `test_provider_source_closure.ProviderSourceClosureTests.test_generated_repr_captured_builtins_must_be_canonical`
- `test_provider_source_closure.ProviderSourceClosureTests.test_injected_and_forged_repr_wrappers_remain_rejected`
- `test_provider_source_closure.ProviderSourceClosureTests.test_repr_field_metadata_rejects_custom_objects_without_calling_them`
- `test_provider_source_closure.ProviderSourceClosureTests.test_successful_read_does_not_authorize_changed_claims_or_compiler`
- `test_provider_source_closure.ProviderSourceClosureTests.test_successful_verification_does_not_authorize_later_source_or_runtime`

未来仍要求所有八方法及旧530/d7六项实际 native PASS；每片 native inventory == 完整源码 expected list，ordered rows == 独立源码分片及 accepted producer 分片，四片 sorted received == expected，并保存完整 actual/expected lists。计数/digest不替代逐项等值。direct-TestCase/继承/动态/hook的原 source-shape fail-closed 规则保留。repr原正常递归方法、三hosted labels与无标签inner控制保留，local tiny不冒充hosted checkpoints。

本轮 local independent 只引用当前精确候选字节的最终双Python各45 checks PASS/0 attack callbacks；原 e939/P1各22checks不重新签名，旧 harness failure 和 capture gap 原样保留。工具不自行运行任何 probe。

终态明确校验新的 committed-validation/summary.json 实际 schema：PASS、final head/base/tree、parent d7、21→23/旧方法保留、fresh_controls、selection/flags、archives与source/test hashes、governance_errors=False。A003要求显式 path+SHA，MANIFEST必须等于该HEAD Git blob；四个 files records的 path/bytes/SHA 对应 README/CAPTURE/RAW_INDEX/ZIP，CAPTURE.sources 对应HEAD，raw ZIP index/size/SHA/CRC/safe paths核验，不提取或执行归档内容。A001/A002旧证据保留。

最终身份全部为必填 CLI，见 [future-argv.template.json](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/future-argv.template.json)。必填 run/attempt/head/base/target/tree/plan/plan-home/committed-validation/A003 manifest path+hash/governance run+attempt/independent tool review path+hash/output。工具要求新 head != d7、accepted base精确c80；显式CLI身份保存到新 output/explicit-binding.json。独立review status须PASS、无blockers且tool_sha256匹配此工具；root确认实际SUCCESS后才能执行。此模板带未解析 placeholders，不能直接运行。

五份新 native ZIP仍各至多下载一次，API size/SHA-256/CRC/safe paths；official cached plan不重下，canonical plan/Git parents/tree/current source绑定、四片 native/projection equality、每片八项installed smoke、全部 outcome/checkpoint PASS均保留。新component run和ci-governance.yml run必须同 final head、各自actual attempt/event/path/terminal SUCCESS；治理绑定先于native下载。本工具只证明component profile，coverage not-collected，不能替代完整checkpoint、跨owner接受或merge/release授权。

预算：直接源码/工具输入10项（root额外准许上限12）；只按已验证JSON metadata派生其余inventory，未查看其他owner目录/原始业务日志。一次prepare完成后停止，待root/独立代理审查、final身份绑定后才terminal audit。完整transport/Agent Trace不可得，保留capture-gap；没有隐藏推理或凭据捕获。
