"""Package unbound preparation and provenance; no terminal/API/test invocation."""
import difflib
import hashlib
import json
from pathlib import Path
import sys

here=Path(__file__).resolve().parent
root=here.parent
old=Path("D:/lcy/develop/_assessments/rwb-ci-p234-p1-20261004/native-preparation-v2/audit_native.py")
helper=here/"audit_native.py"
proof=json.loads((here/"preparation.json").read_text(encoding="utf-8-sig"))
receipt=json.loads((here/"prepare-receipt.json").read_text(encoding="utf-8-sig"))
def identity(path):
    path=Path(path)
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with Path(path).open("x",encoding="utf-8") as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
template=[
    sys.executable,"-B","-X","utf8",str(helper),"--terminal-success-confirmed",
    "--repo","D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004",
    "--run-id","FINAL_COMPONENT_RUN_ID","--attempt","FINAL_COMPONENT_ATTEMPT",
    "--head","FINAL_HEAD_SHA","--base","c80ec014925f0cbbbaef5486bce8422a5b4f73fb",
    "--target","FINAL_TESTED_MERGE_SHA","--tree","FINAL_TESTED_TREE_SHA",
    "--plan-sha256","FINAL_OFFICIAL_PLAN_SHA256","--plan-home",str(root/"hosted-plan"),
    "--committed-validation",str(root/"committed-validation/summary.json"),
    "--attempt-manifest","D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/work/AUDIT-FULL-CI-REPAIR-001/A-20261004-003/MANIFEST.json",
    "--attempt-manifest-sha256","FINAL_COMMITTED_A003_MANIFEST_SHA256",
    "--governance-run","FINAL_GOVERNANCE_RUN_ID","--governance-attempt","FINAL_GOVERNANCE_ATTEMPT",
    "--tool-review","FINAL_INDEPENDENT_TOOL_REVIEW_SUMMARY_PATH",
    "--tool-review-sha256","FINAL_INDEPENDENT_TOOL_REVIEW_SUMMARY_SHA256",
    "--output",str(root/"native-complete"),
]
save(here/"future-argv.template.json",dict(
    status="UNBOUND_TEMPLATE_NOT_EXECUTED",final_hosted_binding=None,
    argv=template,helper=identity(helper),
    required_gates=["Root binds actual committed head/tested merge/run/tree/official cached plan.",
                    "Independent reviewer binds tool_sha256 and has PASS/no blockers.",
                    "Root confirms exact component and governance run terminal SUCCESS.",
                    "All evidence paths exist with current hashes and native-complete does not exist."],
))
diff="".join(difflib.unified_diff(old.read_text(encoding="utf-8-sig").splitlines(keepends=True),
                               helper.read_text(encoding="utf-8-sig").splitlines(keepends=True),
                               fromfile=str(old),tofile=str(helper)))
with (here/"adaptation.diff").open("x",encoding="utf-8",newline="\n") as stream:
    stream.write(diff)
inputs=[
    old,old.parent/"ast-method-preservation.json",
    old.parent.parent/"native-tool-review-v2/REPORT.md",
    old.parent.parent/"native-tool-review-v2/summary.json",
    root/"independent/summary.json",root/"committed_validation.py",root/"prepare_commit.py",
    Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/.github/scripts/run_component_ci.py"),
    Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py"),
    Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/tests/test_provider_source_closure.py"),
]
save(here/"SOURCE_BINDINGS.json",dict(
    status="UNBOUND_PREPARATION_SOURCE_BINDINGS",
    input_identities=[identity(path) for path in inputs],
    preserved_prior_helper_sha256="1ffd6f9244887805b415eae1b5c2c08ad5a341c566834fe2f202143f07afec6c",
    new_helper=identity(helper),final_hosted_binding=None,
    source_sha256=proof["source"]["sha256"],test_sha256=proof["direct_test"]["sha256"],
    local_independent=proof["local_independent"],
    accepted_inventory_metadata=proof["prior_ast_metadata"],
    candidate_method_ids_file=identity(here/"expected-native-inventory.json"),
    prepared_unknown_identity="d7 is historical starting/source-parent only; never the new hosted head.",
))
b=chr(96)
new_methods="\n".join("- "+b+item+b for item in proof["added_methods"])
shards=[len(row["ids"]) for row in proof["expected_ordered_shards"]]
report=f"""# PR139 source-AST candidate native auditor preparation

状态：{b}PREPARED_UNBOUND_NOT_EXECUTED{b}；单次 offline prepare PASS，exit 0。最终 HEAD/run/target/tree/official plan 均未绑定，{b}final_hosted_binding=null{b}；d7 仅是起始 parent/history。0 API、download、tests、test-module imports、producer import/execute；没有 terminal 调用、源码修改、commit 或 push。写入仅本 native-preparation，新旧所有工具/证据身份分别保留。

工具：[audit_native.py](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/audit_native.py)，SHA-256 {b}{identity(helper)['sha256']}{b}。
完整适配：[adaptation.diff](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/adaptation.diff)；来源：[SOURCE_BINDINGS.json](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/SOURCE_BINDINGS.json)；原始 prepare 收据：[prepare-receipt.json](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/prepare-receipt.json)。

源码 {b}{proof['source']['sha256']}{b} / test {b}{proof['direct_test']['sha256']}{b}。直接 AST 比较 c80 17→d7 21→candidate 23，旧方法 body AST 全等；两项新方法是 successful_verification_does_not_authorize_later_source_or_runtime 与 successful_read_does_not_authorize_changed_claims_or_compiler。使用已独立静态审查/hash绑定的 accepted 530/d7 536 inventory metadata，未变的 collection files 以 Git metadata 核对；当前 prepare 不再扩读43个源码。未来 terminal 会重新读取 accepted/d7/target 全部 selected source，证明530与536全部 AST保留，source-derived 538 + exact short7 = 545，并核对四片 ordered IDs 和完整唯一不交并集。

完整预期列表：[expected-native-inventory.json](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/expected-native-inventory.json)。预期 canonical digest {b}{proof['expected_inventory_sha256']}{b}；四片数量 {shards}。相对 accepted 的八个 exact IDs：

{new_methods}

未来仍要求所有八方法及旧530/d7六项实际 native PASS；每片 native inventory == 完整源码 expected list，ordered rows == 独立源码分片及 accepted producer 分片，四片 sorted received == expected，并保存完整 actual/expected lists。计数/digest不替代逐项等值。direct-TestCase/继承/动态/hook的原 source-shape fail-closed 规则保留。repr原正常递归方法、三hosted labels与无标签inner控制保留，local tiny不冒充hosted checkpoints。

本轮 local independent 只引用当前精确候选字节的最终双Python各45 checks PASS/0 attack callbacks；原 e939/P1各22checks不重新签名，旧 harness failure 和 capture gap 原样保留。工具不自行运行任何 probe。

终态明确校验新的 committed-validation/summary.json 实际 schema：PASS、final head/base/tree、parent d7、21→23/旧方法保留、fresh_controls、selection/flags、archives与source/test hashes、governance_errors=False。A003要求显式 path+SHA，MANIFEST必须等于该HEAD Git blob；四个 files records的 path/bytes/SHA 对应 README/CAPTURE/RAW_INDEX/ZIP，CAPTURE.sources 对应HEAD，raw ZIP index/size/SHA/CRC/safe paths核验，不提取或执行归档内容。A001/A002旧证据保留。

最终身份全部为必填 CLI，见 [future-argv.template.json](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/native-preparation/future-argv.template.json)。必填 run/attempt/head/base/target/tree/plan/plan-home/committed-validation/A003 manifest path+hash/governance run+attempt/independent tool review path+hash/output。工具要求新 head != d7、accepted base精确c80；显式CLI身份保存到新 output/explicit-binding.json。独立review status须PASS、无blockers且tool_sha256匹配此工具；root确认实际SUCCESS后才能执行。此模板带未解析 placeholders，不能直接运行。

五份新 native ZIP仍各至多下载一次，API size/SHA-256/CRC/safe paths；official cached plan不重下，canonical plan/Git parents/tree/current source绑定、四片 native/projection equality、每片八项installed smoke、全部 outcome/checkpoint PASS均保留。新component run和ci-governance.yml run必须同 final head、各自actual attempt/event/path/terminal SUCCESS；治理绑定先于native下载。本工具只证明component profile，coverage not-collected，不能替代完整checkpoint、跨owner接受或merge/release授权。

预算：直接源码/工具输入10项（root额外准许上限12）；只按已验证JSON metadata派生其余inventory，未查看其他owner目录/原始业务日志。一次prepare完成后停止，待root/独立代理审查、final身份绑定后才terminal audit。完整transport/Agent Trace不可得，保留capture-gap；没有隐藏推理或凭据捕获。
"""
with (here/"PREPARATION.md").open("x",encoding="utf-8",newline="\n") as stream:
    stream.write(report)
save(here/"manifest.json",dict(status="PREPARED_UNBOUND_NOT_EXECUTED",
    helper=identity(helper),final_hosted_binding=None,
    files=[identity(path) for path in sorted(here.iterdir()) if path.is_file() and path.name!="manifest.json"]))
print(json.dumps(dict(helper=identity(helper),preparation=identity(here/"PREPARATION.md"),
                     manifest=identity(here/"manifest.json"),expected_inventory_sha256=proof["expected_inventory_sha256"],
                     expected_ordered_shard_counts=shards),ensure_ascii=False))
