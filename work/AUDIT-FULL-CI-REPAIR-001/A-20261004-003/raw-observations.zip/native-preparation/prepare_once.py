"""Single offline preparation invocation, preserving raw output without retry."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

here=Path(__file__).resolve().parent
helper=here/"audit_native.py"
assert not (here/"prepare-receipt.json").exists()
command=[sys.executable,"-B","-X","utf8",str(helper),"--prepare-only"]
environment=dict(os.environ)
environment["PYTHONPATH"]="D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src;D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004"
started=datetime.now(timezone.utc).isoformat()
result=subprocess.run(command,capture_output=True,env=environment,timeout=90)
for filename,payload in (("prepare.stdout.txt",result.stdout),("prepare.stderr.txt",result.stderr)):
    with (here/filename).open("xb") as stream:
        stream.write(payload)
receipt=dict(status="PASS_UNBOUND_OFFLINE_PREPARATION" if result.returncode==0 else "FAIL_KEEP_RAW_NO_RETRY",
    prepare_invocations=1,started_at=started,completed_at=datetime.now(timezone.utc).isoformat(),
    helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),argv=command,exit_code=result.returncode,
    stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),
    final_hosted_binding=None,api_reads=0,downloads=0,tests=0,test_module_imports=0,producer_imports_or_execution=0)
with (here/"prepare-receipt.json").open("x",encoding="utf-8") as stream:
    json.dump(receipt,stream,ensure_ascii=False,indent=2)
print(json.dumps(receipt,ensure_ascii=False))
if result.stdout: print(result.stdout.decode("utf-8","replace"))
if result.stderr: print(result.stderr.decode("utf-8","replace"))
raise SystemExit(result.returncode)
