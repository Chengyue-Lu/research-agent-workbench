"""Create unbound native auditor from preserved reviewed v2; file operations only."""
from pathlib import Path

here = Path(__file__).resolve().parent
old = Path("D:/lcy/develop/_assessments/rwb-ci-p234-p1-20261004/native-preparation-v2/audit_native.py")
text = old.read_text(encoding="utf-8-sig")
text = text.replace("EXPECTED_BASE_METHODS, EXPECTED_TARGET_METHODS, EXPECTED_NATIVE_UNIQUE = 530, 536, 543",
                    "EXPECTED_BASE_METHODS, EXPECTED_TARGET_METHODS, EXPECTED_NATIVE_UNIQUE = 530, 538, 545")
anchor = "REQUIRED_NEW_METHODS = (\n"
text = text.replace(anchor, anchor +
    "    'test_provider_source_closure.ProviderSourceClosureTests.test_successful_verification_does_not_authorize_later_source_or_runtime',\n"
    "    'test_provider_source_closure.ProviderSourceClosureTests.test_successful_read_does_not_authorize_changed_claims_or_compiler',\n")
start = text.index("PR, RUN, ATTEMPT = ")
end = text.index("WORKFLOW = ", start)
text = text[:start] + """PR = 139
RUN = ATTEMPT = HEAD = TARGET = TREE = PLAN_DIGEST = None
BASE = 'c80ec014925f0cbbbaef5486bce8422a5b4f73fb'
STARTING_HEAD = 'd7c13791b8ade226a7448cacac3a05fdfe7f71c2'
SOURCE_SHA256 = 'c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3'
TEST_SHA256 = '52c10a34efbf80fce3829eec77a950f43e73e9a9f97826d2ff5c7d9e01bce96a'
PRIOR_HOME = Path('D:/lcy/develop/_assessments/rwb-ci-p234-p1-20261004')
COMM_VALIDATION = ATTEMPT_MANIFEST = ATTEMPT_MANIFEST_SHA256 = None
GOVERNANCE_RUN = GOVERNANCE_ATTEMPT = TOOL_REVIEW = TOOL_REVIEW_SHA256 = None
ARC = 'work/AUDIT-FULL-CI-REPAIR-001/A-20261004-003'
""" + text[end:]
start = text.index("def local_independent_reference():")
end = text.index("\ndef cache_and_sources():", start)
text = text[:start] + r'''def local_independent_reference():
    path = HOSTED / 'independent/summary.json'
    local = load(path)
    assert local['status'] == 'PASS' and not local['blockers']
    probes = local['final_probes']
    assert len(probes) == 2 and all(row['status'] == 'PASS' and row['checks'] == row['passed_checks'] == 45
                                  and row['attack_callbacks'] == 0 for row in probes)
    assert {row['python'].split()[0] for row in probes} == {'3.11.16', '3.13.15'}
    rows = []
    for source in local['sources']:
        raw = (WT / source['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == source['sha256']
        if TARGET is not None:
            target = git('show', TARGET + ':' + source['path'])
            assert hashlib.sha256(target).hexdigest() == source['sha256']
        rows.append(dict(path=source['path'], independent_sha256=source['sha256'],
                         current=identity(WT / source['path']), current_source_bound=True))
    assert all(row['source_hash_before'] == row['source_hash_after'] == SOURCE_SHA256 for row in probes)
    return dict(summary=identity(path), sources=rows,
                probe_state='This candidate exact bytes, initially uncommitted on starting d7; not old P1 22-check re-signing.',
                python_checks=[dict(version=row['python'], check_count=45, callback_count=0, status='PASS')
                               for row in probes], independent_local_only=True, hosted_extra_subtests=0)

def attempt_archive_binding():
    path = ATTEMPT_MANIFEST.resolve()
    assert path == (WT / ARC / 'MANIFEST.json').resolve() and path.is_file()
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == ATTEMPT_MANIFEST_SHA256
    assert raw == git('show', HEAD + ':' + ARC + '/MANIFEST.json')
    manifest = json.loads(raw)
    assert manifest['kind'] == 'compact_evidence_index'
    entries = manifest['files']
    assert {row['path'] for row in entries} == {'README.md','CAPTURE.json','RAW_INDEX.json','raw-observations.zip'}
    assert len(entries) == 4
    for row in entries:
        assert set(row) == {'path','bytes','sha256'} and row['path'] == PurePosixPath(row['path']).name
        payload = git('show', HEAD + ':' + ARC + '/' + row['path'])
        assert len(payload) == row['bytes'] and hashlib.sha256(payload).hexdigest() == row['sha256']
        assert (WT / ARC / row['path']).read_bytes() == payload
    capture = load(WT / ARC / 'CAPTURE.json')
    assert capture['kind'] == 'compact_delegated_followup_record'
    assert (capture['base'], capture['parent']) == (BASE, STARTING_HEAD)
    assert capture['complete_agent_trace'] is False and capture['global_cache'] is False and capture['cached_acceptance'] is False
    assert capture['ready'] is False and capture['merged'] is False
    assert capture['test_budget_seconds'] == 120
    source_rows = capture['source']
    assert source_rows and len({row['path'] for row in source_rows}) == len(source_rows)
    for row in source_rows:
        relative = PurePosixPath(row['path'])
        assert not relative.is_absolute() and '..' not in relative.parts and ':' not in row['path'] and '\\' not in row['path']
        assert hashlib.sha256(git('show', HEAD + ':' + row['path'])).hexdigest() == row['sha256']
    source_map = {row['path']:row['sha256'] for row in source_rows}
    assert source_map['src/research_workbench/adapters/models/provider_source_closure.py'] == SOURCE_SHA256
    assert source_map['tests/test_provider_source_closure.py'] == TEST_SHA256
    index = load(WT / ARC / 'RAW_INDEX.json')
    assert index['kind'] == 'source_parse_scoped_evidence'
    indexed = index['files']
    archive_path = WT / ARC / 'raw-observations.zip'
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) == len(indexed)
        assert sorted(names) == sorted(row['path'] for row in indexed)
        assert sum(member.file_size for member in archive.infolist()) <= 256000000
        for member in archive.infolist():
            relative = PurePosixPath(member.filename)
            assert not relative.is_absolute() and '..' not in relative.parts and ':' not in member.filename and '\\' not in member.filename
            assert not stat.S_ISLNK(member.external_attr >> 16)
        assert archive.testzip() is None
        for row in indexed:
            payload = archive.read(row['path'])
            assert len(payload) == row['bytes'] and hashlib.sha256(payload).hexdigest() == row['sha256']
    return dict(manifest=identity(path), capture=identity(WT / ARC / 'CAPTURE.json'),
                raw_index=identity(WT / ARC / 'RAW_INDEX.json'), raw_zip=identity(archive_path),
                committed_manifest_files_equal=True, capture_sources_equal=True,
                zip_index_sha_size_crc_safepath_equal=True, capture_gap_retained=True)

def offline_prepare():
    """Reuse reviewed immutable metadata plus direct changed-test AST; no broad source reads."""
    review_path = PRIOR_HOME / 'native-tool-review-v2/summary.json'
    review = load(review_path)
    assert review['status'] == 'PASS_STATIC_NATIVE_AUDITOR_V2' and not review['blockers']
    original = PRIOR_HOME / 'native-preparation-v2/audit_native.py'
    assert hashlib.sha256(original.read_bytes()).hexdigest() == review['tool_sha256']
    proof_path = PRIOR_HOME / 'native-preparation-v2/ast-method-preservation.json'
    proof = load(proof_path)
    expected_prior_sha = next(row['sha256'] for row in review['sources'] if row['path'].endswith('ast-method-preservation.json'))
    assert hashlib.sha256(proof_path.read_bytes()).hexdigest() == expected_prior_sha
    assert (proof['baseline_declared_method_count'],proof['target_declared_method_count']) == (530,536)
    old_selected = proof['source_derived_inventory']['selected_declared_method_ids']
    module = 'test_provider_source_closure'
    relative = 'tests/' + module + '.py'
    previous_raw, base_raw = git('show', STARTING_HEAD + ':' + relative), git('show', BASE + ':' + relative)
    candidate_raw = (WT / relative).read_bytes()
    previous, accepted, candidate = methods(previous_raw,module), methods(base_raw,module), methods(candidate_raw,module)
    assert len(previous) == 21 and len(candidate) == 23 and len(accepted) == 17
    assert all(previous[key] == candidate.get(key) for key in previous)
    assert all(accepted[key] == candidate.get(key) for key in accepted)
    candidate_added = sorted(set(candidate)-set(previous))
    assert candidate_added == sorted(REQUIRED_NEW_METHODS[:2])
    assert hashlib.sha256(candidate_raw).hexdigest() == TEST_SHA256
    source_path = WT / 'src/research_workbench/adapters/models/provider_source_closure.py'
    assert hashlib.sha256(source_path.read_bytes()).hexdigest() == SOURCE_SHA256
    metadata_rows = []
    for row in proof['source_derived_inventory']['source_bindings']:
        if row['path'] == relative:
            continue
        assert git('diff','--name-only',STARTING_HEAD,'--',row['path']) == b'', 'unreviewed collection source change: ' + row['path']
        metadata_rows.append(dict(path=row['path'], retained_reviewed_target_sha256=row['target_blob_sha256'],
                                  unchanged_from_starting_git_metadata=True))
    selected = sorted(set(old_selected) | set(candidate_added))
    assert len(selected) == 538 and set(proof['baseline_declared_method_ids']) <= set(selected)
    added = sorted(set(selected)-set(proof['baseline_declared_method_ids']))
    assert added == sorted(REQUIRED_NEW_METHODS)
    runner_path = WT / '.github/scripts/run_component_ci.py'
    runner_raw = runner_path.read_bytes()
    previous_runner = git('show', BASE + ':.github/scripts/run_component_ci.py')
    assert runner_raw.replace(b'\r\n',b'\n') == previous_runner.replace(b'\r\n',b'\n')
    runner_tree = ast.parse(runner_raw)
    short_node = next(node for node in runner_tree.body if isinstance(node,ast.Assign)
                      and any(isinstance(target,ast.Name) and target.id == 'SHORT_REGRESSIONS' for target in node.targets))
    short = ast.literal_eval(short_node.value)
    assert short == EXPECTED_SHORT_REGRESSIONS == tuple(proof['source_derived_inventory']['short_regression_ids'])
    inventory = sorted(set(selected) | set(short))
    assert len(inventory) == 545 and not set(selected) & set(short)
    local = local_independent_reference()
    return dict(status='PREPARED_UNBOUND_NOT_EXECUTED', final_hosted_binding=None,
                prior_review=identity(review_path), prior_ast_metadata=identity(proof_path),
                starting_head_historical_only=STARTING_HEAD, accepted_base=BASE,
                source=identity(source_path), direct_test=identity(WT / relative),
                unchanged_collection_metadata=metadata_rows, accepted_method_ids=proof['baseline_declared_method_ids'],
                d7_method_ids=old_selected, candidate_method_ids=selected, added_methods=added,
                newly_added_to_d7=candidate_added, old_530_ast_preserved_by_review_and_direct_ast=True,
                old_d7_536_preserved_by_unchanged_metadata_and_direct_ast=True,
                short_exact_ids=list(short), expected_native_inventory=inventory,
                expected_inventory_sha256=hashlib.sha256(canonical(inventory)).hexdigest(),
                expected_ordered_shards=[dict(shard_index=index,ids=expected_shard_inventory(inventory,index)) for index in range(4)],
                expected_native_unique=545, candidate_method_count=538, selected_modules=36,
                source_controls=source_controls(candidate_raw), local_independent=local,
                future_committed_validation=HOSTED.as_posix()+'/committed-validation/summary.json',
                future_attempt_manifest=(WT / ARC / 'MANIFEST.json').as_posix(),
                terminal_identity_fields_required=['run_id','attempt','head','base','target','tree','plan_sha256',
                                                  'plan_home','committed_validation','attempt_manifest','attempt_manifest_sha256',
                                                  'governance_run','governance_attempt','tool_review','tool_review_sha256'],
                api_reads=0, downloads=0, tests=0, test_module_imports=0, producer_imports_or_execution=0,
                complete_agent_trace=False, capture_gap='Bounded preparation artifacts and visible tool history; no complete transport trace.')
''' + text[end:]
text = text.replace("committed = load(HOSTED / 'committed-validation/summary.json')", "committed = load(COMM_VALIDATION)")
text = text.replace("assert committed['selection_and_flags_unchanged'] is True and committed['old_archive_preserved'] is True",
                    "assert committed['selection_and_flags_unchanged'] is True and committed['old_archives_preserved'] is True\n"
                    "    assert committed['parent'] == STARTING_HEAD and committed['tree'] == TREE\n"
                    "    assert committed['committed_archive_bytes'] is True and committed['old_methods_preserved'] is True\n"
                    "    assert (committed['old_test_methods'],committed['current_test_methods']) == (21,23)\n"
                    "    assert (committed['source_sha256'],committed['test_sha256']) == (SOURCE_SHA256,TEST_SHA256)\n"
                    "    assert committed['governance_errors'] is False\n"
                    "    archive_binding = attempt_archive_binding()")
text = text.replace("committed_validation=identity(HOSTED / 'committed-validation/summary.json'),",
                    "committed_validation=identity(COMM_VALIDATION), attempt_archive=archive_binding,")
text = text.replace("    baseline, current, module_rows = {}, {}, []",
                    "    baseline, current, module_rows, starting_methods = {}, {}, [], {}")
text = text.replace("        old_methods, new_methods = methods(old_raw, module), methods(new_raw, module)",
                    "        old_methods, new_methods = methods(old_raw, module), methods(new_raw, module)\n"
                    "        starting_raw = git('show', STARTING_HEAD + ':' + rel)\n"
                    "        starting_module_methods = methods(starting_raw,module)\n"
                    "        assert set(starting_module_methods) <= set(new_methods)\n"
                    "        assert all(starting_module_methods[key] == new_methods[key] for key in starting_module_methods), 'modified d7 test method AST: '+module\n"
                    "        starting_methods.update(starting_module_methods)")
text = text.replace("    assert len(baseline) == EXPECTED_BASE_METHODS and len(current) == EXPECTED_TARGET_METHODS",
                    "    assert len(baseline) == EXPECTED_BASE_METHODS and len(current) == EXPECTED_TARGET_METHODS\n"
                    "    assert len(starting_methods) == 536")
text = text.replace("target_declared_method_count=len(current), baseline_declared_method_ids=sorted(baseline),",
                    "target_declared_method_count=len(current), starting_d7_declared_method_count=len(starting_methods),\n"
                    "                     starting_d7_declared_method_ids=sorted(starting_methods), starting_d7_method_ast_preserved=True,\n"
                    "                     baseline_declared_method_ids=sorted(baseline),")
text = text.replace("    matrix = producer.execution_matrix(plan)",
                    "    assert tuple(plan['selected_tests']) == tuple(sorted(row['module'] for row in load(PRIOR_HOME / 'native-preparation-v2/ast-method-preservation.json')['modules']))\n"
                    "    matrix = producer.execution_matrix(plan)")
needle = "    with ThreadPoolExecutor(max_workers=2) as pool:\n"
text = text.replace(needle,
    "    governance = api(f'actions/runs/{GOVERNANCE_RUN}',out,'governance-run')\n"
    "    assert governance['id'] == GOVERNANCE_RUN and governance['head_sha'] == HEAD and governance['run_attempt'] == GOVERNANCE_ATTEMPT\n"
    "    assert governance['event'] == 'pull_request' and governance['path'] == '.github/workflows/ci-governance.yml'\n"
    "    assert governance['status'] == 'completed' and governance['conclusion'] == 'success', 'Governance is not this head terminal SUCCESS'\n"
    + needle)
text = text.replace("baseline_ast_methods_preserved=True, ast_preservation=ast_proof,",
                    "baseline_ast_methods_preserved=True, old_d7_methods_preserved=True, governance_run_id=GOVERNANCE_RUN, governance_same_head_terminal_success=True, ast_preservation=ast_proof,")
start = text.index("def main():")
text = text[:start] + r'''def main():
    global WT, RUN, ATTEMPT, HEAD, BASE, TARGET, TREE, PLAN_DIGEST, PLAN_HOME
    global COMM_VALIDATION, ATTEMPT_MANIFEST, ATTEMPT_MANIFEST_SHA256
    global GOVERNANCE_RUN, GOVERNANCE_ATTEMPT, TOOL_REVIEW, TOOL_REVIEW_SHA256
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare-only',action='store_true')
    parser.add_argument('--terminal-success-confirmed',action='store_true')
    parser.add_argument('--repo',type=Path,default=WT)
    parser.add_argument('--output',type=Path)
    for name in ('run-id','attempt','governance-run','governance-attempt'):
        parser.add_argument('--'+name,type=int)
    for name in ('head','base','target','tree','plan-sha256','attempt-manifest-sha256','tool-review-sha256'):
        parser.add_argument('--'+name)
    for name in ('plan-home','committed-validation','attempt-manifest','tool-review'):
        parser.add_argument('--'+name,type=Path)
    args = parser.parse_args()
    WT = args.repo.resolve()
    ast.parse(Path(__file__).read_text(encoding='utf-8-sig'))
    if args.prepare_only:
        assert not args.terminal_success_confirmed and args.output is None
        assert all(getattr(args,name) is None for name in (
            'run_id','attempt','head','base','target','tree','plan_sha256','plan_home','committed_validation',
            'attempt_manifest','attempt_manifest_sha256','governance_run','governance_attempt','tool_review','tool_review_sha256'))
        proof = offline_prepare()
        save(HERE / 'preparation.json',proof)
        save(HERE / 'expected-native-inventory.json',dict(
            selected_declared_method_ids=proof['candidate_method_ids'],short_regression_ids=proof['short_exact_ids'],
            expected_native_inventory=proof['expected_native_inventory'],expected_ordered_shards=proof['expected_ordered_shards']))
        print(json.dumps(dict(status=proof['status'],final_hosted_binding=None,expected_native_unique=545,
                              candidate_methods=538,new_relative_to_accepted=8,api_reads=0,tests=0,producer_imports=0)))
        return
    required = ('run_id','attempt','head','base','target','tree','plan_sha256','plan_home','committed_validation',
                'attempt_manifest','attempt_manifest_sha256','governance_run','governance_attempt','tool_review','tool_review_sha256','output')
    parser.error('Explicit terminal flag and all final identity/evidence fields are required') if (
        not args.terminal_success_confirmed or any(getattr(args,name) is None for name in required)) else None
    assert all(getattr(args,name)>0 for name in ('run_id','attempt','governance_run','governance_attempt'))
    assert args.base == BASE and args.head != STARTING_HEAD
    def hexadecimal(value,length):
        return len(value)==length and all(character in '0123456789abcdef' for character in value)
    assert all(hexadecimal(getattr(args,name),40) for name in ('head','base','target','tree'))
    assert all(hexadecimal(getattr(args,name),64) for name in ('plan_sha256','attempt_manifest_sha256','tool_review_sha256'))
    RUN,ATTEMPT,HEAD,TARGET,TREE,PLAN_DIGEST = args.run_id,args.attempt,args.head,args.target,args.tree,args.plan_sha256
    PLAN_HOME,COMM_VALIDATION,ATTEMPT_MANIFEST = args.plan_home.resolve(),args.committed_validation.resolve(),args.attempt_manifest.resolve()
    ATTEMPT_MANIFEST_SHA256 = args.attempt_manifest_sha256
    GOVERNANCE_RUN,GOVERNANCE_ATTEMPT = args.governance_run,args.governance_attempt
    TOOL_REVIEW,TOOL_REVIEW_SHA256 = args.tool_review.resolve(),args.tool_review_sha256
    assert COMM_VALIDATION == (HOSTED / 'committed-validation/summary.json').resolve()
    assert PLAN_HOME == (HOSTED / 'hosted-plan').resolve()
    assert hashlib.sha256(TOOL_REVIEW.read_bytes()).hexdigest() == TOOL_REVIEW_SHA256
    tool_review = load(TOOL_REVIEW)
    assert tool_review['status'].startswith('PASS') and not tool_review.get('blockers',[])
    assert tool_review['tool_sha256'] == identity(Path(__file__))['sha256']
    out = args.output.resolve()
    assert out.is_relative_to(HOSTED.resolve()) and out != HOSTED.resolve() and not out.exists()
    out.mkdir(parents=True,exist_ok=False)
    save(out / 'explicit-binding.json',dict(
        run=RUN,attempt=ATTEMPT,head=HEAD,base=BASE,target=TARGET,tree=TREE,plan_sha256=PLAN_DIGEST,
        plan_home=str(PLAN_HOME),committed_validation=str(COMM_VALIDATION),attempt_manifest=str(ATTEMPT_MANIFEST),
        attempt_manifest_sha256=ATTEMPT_MANIFEST_SHA256,governance_run=GOVERNANCE_RUN,governance_attempt=GOVERNANCE_ATTEMPT,
        tool_review=identity(TOOL_REVIEW),helper=identity(Path(__file__)),terminal_success_confirmation_supplied=True))
    try:
        summary = audit(out)
    except Exception as error:
        summary = dict(status='AUDIT_BLOCKED_KEEP_RAW_NO_RETRY',run_id=RUN,head=HEAD,
                       error=f'{type(error).__name__}: {error}',traceback=traceback.format_exc(),tests_executed_by_auditor=0)
    save(out / 'summary.json',summary)
    with (out / 'REPORT.md').open('x',encoding='utf-8') as handle:
        handle.write('# PR139 component native audit\n\n'+json.dumps(
            {key:summary[key] for key in summary if key not in ('installed_smokes','ast_preservation','module_ranking','artifact_checks','shards')},
            ensure_ascii=False,indent=2)+'\n')
    save(out / 'manifest.json',dict(run_id=RUN,head=HEAD,helper=identity(Path(__file__)),
         files=[identity(path) for path in sorted(out.rglob('*')) if path.is_file() and path.name!='manifest.json']))
    print(json.dumps({key:summary.get(key) for key in ('status','run_id','head','actual_unique_records','expected_inventory_count',
          'source_derived_inventory_exact_equal','governance_same_head_terminal_success','native_coverage','error')},ensure_ascii=False))
if __name__ == '__main__':
    main()
'''
with (here / "audit_native.py").open("x",encoding="utf-8",newline="\n") as stream:
    stream.write(text)
print(here / "audit_native.py")
