"""PR139 native audit. Offline preparation or explicitly authorized terminal audit only."""
from __future__ import annotations
import argparse
import ast
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import traceback
import zipfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
HOSTED = HERE.parent
PLAN_HOME = HOSTED / 'hosted-plan'
EXPECTED_BASE_METHODS, EXPECTED_TARGET_METHODS, EXPECTED_NATIVE_UNIQUE = 530, 538, 545
CAPTURED_BUILTINS_LABELS = ('replaced captured id', 'dict subclass', 'custom mapping')
REQUIRED_NEW_METHODS = (
    'test_provider_source_closure.ProviderSourceClosureTests.test_successful_verification_does_not_authorize_later_source_or_runtime',
    'test_provider_source_closure.ProviderSourceClosureTests.test_successful_read_does_not_authorize_changed_claims_or_compiler',
    'test_ci_components.ComponentPlanTests.test_protocol_and_exclusion_policy_changes_select_position_guard',
    'test_coverage_policy.CoveragePolicyCheckerTests.test_checked_in_exclusions_match_static_coverage_analysis',
    'test_provider_source_closure.ProviderSourceClosureTests.test_generated_dataclass_repr_and_explicit_custom_repr_are_supported',
    'test_provider_source_closure.ProviderSourceClosureTests.test_injected_and_forged_repr_wrappers_remain_rejected',
    'test_provider_source_closure.ProviderSourceClosureTests.test_repr_field_metadata_rejects_custom_objects_without_calling_them',
    'test_provider_source_closure.ProviderSourceClosureTests.test_generated_repr_captured_builtins_must_be_canonical',
)

WT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
REPO = 'Chengyue-Lu/research-agent-workbench'
PR = 139
RUN = ATTEMPT = HEAD = TARGET = TREE = PLAN_DIGEST = None
BASE = 'c80ec014925f0cbbbaef5486bce8422a5b4f73fb'
STARTING_HEAD = 'd7c13791b8ade226a7448cacac3a05fdfe7f71c2'
SOURCE_SHA256 = 'c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3'
TEST_SHA256 = '52c10a34efbf80fce3829eec77a950f43e73e9a9f97826d2ff5c7d9e01bce96a'
PRIOR_HOME = Path('D:/lcy/develop/_assessments/rwb-ci-p234-p1-20261004')
COMM_VALIDATION = ATTEMPT_MANIFEST = ATTEMPT_MANIFEST_SHA256 = None
GOVERNANCE_RUN = GOVERNANCE_ATTEMPT = TOOL_REVIEW = TOOL_REVIEW_SHA256 = None
ARC = 'work/AUDIT-FULL-CI-REPAIR-001/A-20261004-003'
WORKFLOW = '.github/workflows/ci_components.yml'
ENV = {key: value for key, value in os.environ.items() if key.lower() not in {'http_proxy', 'https_proxy', 'all_proxy'}}
ENV.update(GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0')
SOURCES = ('run_component_ci.py', 'ci_component_result.py', 'ci_component_smoke.py', 'ci_components.py')
SMOKE_STEPS = ('installed-import-and-schema', 'runtime-resources', 'schema-cli', 'research-state-command', 'offline-project-init', 'offline-project-check', 'offline-task-validate', 'invalid-timestamp-cli')
def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path, value):
    with Path(path).open('x', encoding='utf-8') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def git(*args):
    return subprocess.run(['git', '-C', str(WT), *args], check=True, capture_output=True, env=ENV).stdout
def methods(raw, module):
    result = {}
    def walk(nodes, prefix=''):
        for node in nodes:
            if isinstance(node, ast.ClassDef):
                owner = prefix + node.name
                for member in node.body:
                    if isinstance(member, (ast.FunctionDef, ast.AsyncFunctionDef)) and member.name.startswith('test_'):
                        result[module + '.' + owner + '.' + member.name] = ast.dump(member, include_attributes=False)
                walk([member for member in node.body if isinstance(member, ast.ClassDef)], owner + '.')
    walk(ast.parse(raw).body)
    return result

EXPECTED_SHORT_REGRESSIONS = (
    'test_integrity.IntegrityTests.test_directory_hash_uses_host_independent_posix_order',
    'test_critical_contract_branches.CriticalIntegrityBranchTests.test_reference_statuses_and_hash_guards_are_closed',
    'test_cli.CliTests.test_provider_conformance_execute_rejects_disabled_template_before_environment',
    'test_pr_governance.ReleaseTrustTopologyTests.test_branch_name_alone_cannot_supply_trusted_expectations',
    'test_research_state_candidate.FixtureContractTest.test_two_bounded_cases_pass_schema_and_closure',
    'test_research_state_candidate.RepositoryIntegrationTest.test_cli_consumes_only_explicit_closure',
    'test_research_state_candidate.RepositoryIntegrationTest.test_validate_documents_reports_state_closure_failure',
)

def expected_shard_inventory(inventory, index, count=4):
    """Static implementation of accepted owner order; independent of producer imports."""
    assert inventory == sorted(set(inventory)) and 0 <= index < count
    owners = sorted({item.split('.', 1)[0] for item in inventory})
    owner_indices = {owner: ordinal % count for ordinal, owner in enumerate(owners)}
    return [item for item in inventory if owner_indices[item.split('.', 1)[0]] == index]

def source_derived_inventory(plan, declared):
    """Derive exact portable IDs without importing any test or running TestLoader.

    This snapshot supports top-level, direct unittest.TestCase classes and direct
    test* methods. Other test-class inheritance, collection hooks, aliases or
    generated test classes must receive a new named static proof, never a count
    allowance. Native inventory equality below independently rejects extra or
    missing runtime IDs, including any effect not implied by this static profile.
    """
    runner_raw = git('show', TARGET + ':.github/scripts/run_component_ci.py')
    runner_tree = ast.parse(runner_raw)
    assignments = [node for node in runner_tree.body if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Name) and target.id == 'SHORT_REGRESSIONS'
                           for target in node.targets)]
    assert len(assignments) == 1
    short = ast.literal_eval(assignments[0].value)
    assert isinstance(short, tuple) and short == EXPECTED_SHORT_REGRESSIONS
    assert len(short) == len(set(short)) == 7
    target_trees, source_rows = {}, []

    def source(module):
        if module not in target_trees:
            relative = 'tests/' + module + '.py'
            raw = git('show', TARGET + ':' + relative)
            current_raw = (WT / relative).read_bytes()
            assert raw.replace(b'\r\n', b'\n') == current_raw.replace(b'\r\n', b'\n'), relative
            target_trees[module] = ast.parse(raw)
            source_rows.append(dict(module=module, path=relative, current=identity(WT / relative),
                                    target_blob_sha256=hashlib.sha256(raw).hexdigest(),
                                    current_target_newline_normalized_equal=True))
        return target_trees[module]

    def direct_symbol(module, name):
        matches = [node for node in source(module).body
                   if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                   and node.name == name]
        assert len(matches) == 1, 'unresolved imported test helper: ' + module + '.' + name
        return matches[0]

    def helper_class(module, name, trail=()):
        """Resolve only test-helper class inheritance; not product execution."""
        assert (module, name) not in trail, 'cyclic helper inheritance'
        owner = direct_symbol(module, name)
        assert isinstance(owner, ast.ClassDef) and not owner.keywords and not owner.decorator_list
        evidence = []
        for base in owner.bases:
            assert isinstance(base, ast.Name), 'unresolved helper base: ' + module + '.' + name
            if base.id == 'object':
                continue
            local = [node for node in source(module).body if isinstance(node, ast.ClassDef)
                     and node.name == base.id]
            if local:
                evidence.extend(helper_class(module, base.id, trail + ((module, name),)))
                continue
            imports = [node for node in source(module).body if isinstance(node, ast.ImportFrom)
                       and node.module and node.module.startswith('tests.')
                       for alias in node.names if (alias.asname or alias.name) == base.id]
            assert len(imports) == 1, 'unresolved helper inheritance: ' + module + '.' + name
            entry = imports[0]
            alias = next(alias for alias in entry.names if (alias.asname or alias.name) == base.id)
            evidence.extend(helper_class(entry.module[6:], alias.name, trail + ((module, name),)))
        assert not any(isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                       and node.name.startswith('test') for node in owner.body)
        evidence.append(dict(id=module + '.' + name, line=owner.lineno,
                             bases=[ast.unparse(base) for base in owner.bases],
                             testcase_ancestry=False, declared_test_methods=[]))
        return evidence

    selected_ids, module_proofs, import_proofs = [], [], []
    modules = sorted(set(plan['selected_tests']) | {item.split('.', 1)[0] for item in short})
    for module in modules:
        tree = source(module)
        assert any(isinstance(node, ast.Import) and any(alias.name == 'unittest' and alias.asname is None
                       for alias in node.names) for node in tree.body), module + ': unittest binding'
        named = [node.name for node in tree.body
                 if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))]
        assert len(named) == len(set(named)), module + ': duplicate top-level definition'
        assert not set(named) & {'load_tests', '__getattr__', '__dir__'}, module + ': collection hook'
        owners = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
        cases, declared_ids, statement_rows = [], [], []
        for owner in owners.values():
            direct_test_nodes = [node for node in owner.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                                 and node.name.startswith('test')]
            is_case = [ast.unparse(base) for base in owner.bases] == ['unittest.TestCase']
            if not is_case:
                assert not direct_test_nodes, module + '.' + owner.name + ': unsupported test inheritance'
                assert not any(isinstance(node, ast.ClassDef) for node in owner.body), 'nested class shape requires proof'
                continue
            assert not owner.keywords and not owner.decorator_list, 'test metaclass/decorator requires proof'
            members = [node for node in owner.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
            assert len(members) == len({node.name for node in members}), 'duplicate test-class member'
            assert not {node.name for node in members} & {
                'id', '__init__', '__new__', '__getattribute__', '__getattr__', '__dir__'}
            assert direct_test_nodes, 'runTest fallback requires proof'
            for node in owner.body:
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                    continue
                assert isinstance(node, (ast.Assign, ast.AnnAssign)), 'dynamic test-class member requires proof'
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                assert all(isinstance(target, ast.Name) and not target.id.startswith('test')
                           and target.id not in {'__module__', '__qualname__', '_testMethodName'}
                           for target in targets), 'test attribute assignment requires proof'
            names = []
            for node in direct_test_nodes:
                assert isinstance(node, ast.FunctionDef) and node.name.startswith('test_'), 'loader prefix differs from declared method profile'
                assert not node.decorator_list or all(
                    isinstance(decorator, ast.Call) and ast.unparse(decorator.func) in {
                        'unittest.skipIf', 'mock.patch.object'} for decorator in node.decorator_list
                ), 'test decorator requires named callable proof'
                names.append(node.name)
                declared_ids.append(module + '.' + owner.name + '.' + node.name)
            cases.append(dict(class_id=module + '.' + owner.name, line=owner.lineno,
                              bases=['unittest.TestCase'], direct_methods=sorted(names),
                              inherited_test_methods=[], dynamic_test_methods=[],
                              metaclass_or_class_decorator=False, id_override=False))
        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                if isinstance(node, ast.ImportFrom):
                    assert all(alias.name != '*' for alias in node.names), 'star import requires proof'
                    if node.module and node.module.startswith('tests.'):
                        for alias in node.names:
                            symbol = direct_symbol(node.module[6:], alias.name) if alias.name not in {'A1','AT','ROOT'} else None
                            if isinstance(symbol, ast.ClassDef):
                                proof = helper_class(node.module[6:], alias.name)
                                import_proofs.append(dict(importer=module, imported=node.module + '.' + alias.name,
                                                          shape='non-TestCase helper class', ancestry=proof))
                            elif symbol is not None:
                                import_proofs.append(dict(importer=module, imported=node.module + '.' + alias.name,
                                                          shape='function; not a global TestCase class'))
                    elif node.module == 'tests':
                        import_proofs.extend(dict(importer=module, imported='tests.' + alias.name,
                                                  shape='module object; TestLoader does not recursively collect its classes')
                                             for alias in node.names)
                continue
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                continue
            if isinstance(node, ast.If):
                assert ast.unparse(node.test) == "__name__ == '__main__'" and not node.orelse
                assert all(isinstance(item, ast.Expr) and isinstance(item.value, ast.Call)
                           and ast.unparse(item.value.func) == 'unittest.main' for item in node.body)
                statement_rows.append(dict(line=node.lineno, kind='guarded unittest.main; false during module import'))
                continue
            assert isinstance(node, (ast.Assign, ast.AnnAssign, ast.Expr, ast.Assert)), 'dynamic module collection requires proof'
            stores = {item.id for item in ast.walk(node) if isinstance(item, ast.Name) and isinstance(item.ctx, ast.Store)}
            assert not stores & (set(owners) | {'unittest', 'load_tests', '__getattr__', '__dir__'})
            assert not any(isinstance(item, ast.Name) and item.id in set(owners) | {'TestCase'}
                           for item in ast.walk(node)), 'test class mutation/alias requires proof'
            assert not any(isinstance(item, ast.Call) and isinstance(item.func, ast.Name)
                           and item.func.id in {'type','exec','eval','setattr','globals','locals','vars','compile'}
                           for item in ast.walk(node)), 'dynamic namespace generation requires proof'
            statement_rows.append(dict(line=node.lineno, kind=type(node).__name__,
                                      ast_sha256=hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()))
        if module in plan['selected_tests']:
            assert sorted(declared_ids) == sorted(methods(git('show', TARGET + ':tests/' + module + '.py'), module))
            selected_ids.extend(declared_ids)
        module_proofs.append(dict(module=module, full_module_selected=module in plan['selected_tests'],
                                  test_classes=cases, declared_test_ids=sorted(declared_ids),
                                  collection_hook=False, runtime_generated_tests_declared=False,
                                  module_execution_statements=statement_rows))
    assert sorted(selected_ids) == sorted(declared) and len(selected_ids) == len(set(selected_ids))
    short_proofs = []
    for item in short:
        module, classname, method = item.split('.')
        owner = direct_symbol(module, classname)
        assert isinstance(owner, ast.ClassDef) and [ast.unparse(base) for base in owner.bases] == ['unittest.TestCase']
        nodes = [node for node in owner.body if isinstance(node, ast.FunctionDef) and node.name == method]
        assert len(nodes) == 1 and not nodes[0].decorator_list
        short_proofs.append(dict(id=item, class_line=owner.lineno, method_line=nodes[0].lineno,
                                 method_ast_sha256=hashlib.sha256(ast.dump(nodes[0], include_attributes=False).encode()).hexdigest(),
                                 direct_testcase_method=True))
    assert not set(short) & set(selected_ids), 'short selection overlaps full module collection'
    expected = sorted(set(selected_ids) | set(short))
    assert len(expected) == EXPECTED_NATIVE_UNIQUE
    helper_path = WT / 'tests/run_unittest_suite.py'
    helper_raw, helper_base = git('show', TARGET + ':tests/run_unittest_suite.py'), git('show', BASE + ':tests/run_unittest_suite.py')
    assert helper_raw.replace(b'\r\n', b'\n') == helper_base.replace(b'\r\n', b'\n') == helper_path.read_bytes().replace(b'\r\n', b'\n')
    helper_tree = ast.parse(helper_raw)
    functions = {node.name: node for node in helper_tree.body if isinstance(node, ast.FunctionDef)}
    runner_functions = {node.name: node for node in runner_tree.body if isinstance(node, ast.FunctionDef)}
    function_proof = [dict(name=name, source='tests/run_unittest_suite.py' if name in functions else '.github/scripts/run_component_ci.py',
                           line=(functions.get(name) or runner_functions[name]).lineno,
                           ast_sha256=hashlib.sha256(ast.dump(functions.get(name) or runner_functions[name], include_attributes=False).encode()).hexdigest())
                      for name in ('_canonical_test_id', '_iter_tests', 'execution_names', 'execute_modules', 'canonical_record_id', 'shard_inventory')]
    reference_root = Path('D:/lcy/develop/research-agent-workbench/.rwb/m14-003/pythons/cpython-3.11.16-windows-x86_64-none/Lib/unittest')
    case_tree = ast.parse((reference_root / 'case.py').read_bytes())
    testcase = next(node for node in case_tree.body if isinstance(node, ast.ClassDef) and node.name == 'TestCase')
    assert not any(isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('test')
                   for node in testcase.body)
    package = WT / 'tests/__init__.py'
    package_raw = git('show', TARGET + ':tests/__init__.py')
    assert package_raw.replace(b'\r\n', b'\n') == package.read_bytes().replace(b'\r\n', b'\n')
    assert all(isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)
               for node in ast.parse(package_raw).body)
    return dict(selected_declared_method_ids=sorted(selected_ids), short_regression_ids=list(short),
                expected_native_inventory=expected,
                expected_inventory_sha256=hashlib.sha256(canonical(expected)).hexdigest(),
                expected_ordered_shards=[dict(shard_index=index, ids=expected_shard_inventory(expected, index))
                                        for index in range(4)],
                full_module_declared_count=len(selected_ids), short_exact_method_count=len(short),
                module_proofs=module_proofs, imported_test_helper_proofs=import_proofs,
                source_bindings=source_rows, accepted_runner_functions=function_proof,
                accepted_runner_helper=dict(current=identity(helper_path),
                                            base_blob_sha256=hashlib.sha256(helper_base).hexdigest(),
                                            target_blob_sha256=hashlib.sha256(helper_raw).hexdigest()),
                tests_package=identity(package),
                local_stdlib_rule_reference=[identity(reference_root / filename) for filename in ('loader.py','case.py')],
                collection_rules='Default TestLoader: module global TestCase classes; callable test-prefix methods including inheritance; no recursive module-object collection; explicit short method loading. Runner dedups source/qualname/method then strips tests. and sorts portable IDs; shard owns sorted module ordinal modulo four.',
                inheritance_and_dynamic_boundary='This bound snapshot has only direct TestCase test classes, no declared inherited/generated test methods or load_tests hook. Non-TestCase BaselineFixture -> SystemEvaluationFixture is resolved by source. Unhandled shapes fail closed; no generic runtime or import-side-effect equivalence is claimed. Future native exact-list equality is mandatory.',
                stdlib_reference_scope='Local 3.11.16 source explains default loader rules; not a claim of hosted stdlib byte identity.',
                no_runtime_collection_or_import=True)

def source_controls(raw):
    tree = ast.parse(raw)
    owner = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'ProviderSourceClosureTests')
    nodes = {node.name: node for node in owner.body if isinstance(node, ast.FunctionDef)}
    positive = nodes['test_generated_dataclass_repr_and_explicit_custom_repr_are_supported']
    clone = nodes['test_generated_repr_captured_builtins_must_be_canonical']
    recursive_assert = any(
        isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'assertEqual'
        and len(node.args) == 2 and isinstance(node.args[0], ast.Constant) and node.args[0].value == 'Record(value=...)'
        and isinstance(node.args[1], ast.Call) and isinstance(node.args[1].func, ast.Name) and node.args[1].func.id == 'repr'
        and len(node.args[1].args) == 1 and isinstance(node.args[1].args[0], ast.Name) and node.args[1].args[0].id == 'recursive'
        for node in ast.walk(positive))
    assert recursive_assert, 'Normal recursive repr assertion is absent'
    loop = next(node for node in clone.body if isinstance(node, ast.For) and isinstance(node.target, ast.Tuple)
                and any(isinstance(item, ast.Name) and item.id == 'label' for item in node.target.elts))
    source_labels = tuple(item.elts[0].value for item in loop.iter.elts)
    assert source_labels == CAPTURED_BUILTINS_LABELS
    subtests = [node for node in ast.walk(clone) if isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute) and node.func.attr == 'subTest']
    assert len(subtests) == 1 and any(keyword.arg == 'label' and isinstance(keyword.value, ast.Name)
                                     and keyword.value.id == 'label' for keyword in subtests[0].keywords)
    inner = any(isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'inner' for target in node.targets)
                and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name)
                and node.value.func.id == 'clone_with_builtins' and isinstance(node.value.args[0], ast.Attribute)
                and node.value.args[0].attr == '__wrapped__' for node in clone.body)
    inner_blocks = [node for node in clone.body if isinstance(node, ast.With) and node.lineno > loop.end_lineno]
    assert inner and inner_blocks
    assert not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'subTest'
                   for block in inner_blocks for node in ast.walk(block))
    assert any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'verify_loaded_source_closure'
               for block in inner_blocks for node in ast.walk(block))
    return dict(normal_recursive_repr_assertion_declared=True, clone_hosted_subtest_labels=list(source_labels),
                clone_hosted_label_count=3, unlabelled_inner_control_declared=True,
                unlabelled_inner_control_proof='Whole original method native PASS; no fourth subTest label exists.',
                canonical_values_copy_hosted_label=False,
                canonical_values_copy_scope='Local independent probe only; never counted as hosted subTest.')

def local_independent_reference():
    path = HOSTED / 'independent/summary.json'
    local = load(path)
    assert local['status'] == 'PASS' and not local['blockers']
    probes = local['final_probes']
    assert len(probes) == 2 and all(row['status'] == 'PASS' and row['checks'] == row['passed_checks'] == 45
                                  and row['attack_callbacks'] == 0 for row in probes)
    assert {row['python'].split()[0] for row in probes} == {'3.11.16', '3.13.15'}
    rows = []
    for source in local['sources']:
        raw = (WT / source['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == source['sha256']
        if TARGET is not None:
            target = git('show', TARGET + ':' + source['path'])
            assert hashlib.sha256(target).hexdigest() == source['sha256']
        rows.append(dict(path=source['path'], independent_sha256=source['sha256'],
                         current=identity(WT / source['path']), current_source_bound=True))
    assert all(row['source_hash_before'] == row['source_hash_after'] == SOURCE_SHA256 for row in probes)
    return dict(summary=identity(path), sources=rows,
                probe_state='This candidate exact bytes, initially uncommitted on starting d7; not old P1 22-check re-signing.',
                python_checks=[dict(version=row['python'], check_count=45, callback_count=0, status='PASS')
                               for row in probes], independent_local_only=True, hosted_extra_subtests=0)

def attempt_archive_binding():
    path = ATTEMPT_MANIFEST.resolve()
    assert path == (WT / ARC / 'MANIFEST.json').resolve() and path.is_file()
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == ATTEMPT_MANIFEST_SHA256
    assert raw == git('show', HEAD + ':' + ARC + '/MANIFEST.json')
    manifest = json.loads(raw)
    assert manifest['kind'] == 'compact_evidence_index'
    entries = manifest['files']
    assert {row['path'] for row in entries} == {'README.md','CAPTURE.json','RAW_INDEX.json','raw-observations.zip'}
    assert len(entries) == 4
    for row in entries:
        assert set(row) == {'path','bytes','sha256'} and row['path'] == PurePosixPath(row['path']).name
        payload = git('show', HEAD + ':' + ARC + '/' + row['path'])
        assert len(payload) == row['bytes'] and hashlib.sha256(payload).hexdigest() == row['sha256']
        assert (WT / ARC / row['path']).read_bytes() == payload
    capture = load(WT / ARC / 'CAPTURE.json')
    assert capture['kind'] == 'compact_delegated_followup_record'
    assert (capture['base'], capture['parent']) == (BASE, STARTING_HEAD)
    assert capture['complete_agent_trace'] is False and capture['global_cache'] is False and capture['cached_acceptance'] is False
    assert capture['ready'] is False and capture['merged'] is False
    assert capture['test_budget_seconds'] == 120
    source_rows = capture['source']
    assert source_rows and len({row['path'] for row in source_rows}) == len(source_rows)
    for row in source_rows:
        relative = PurePosixPath(row['path'])
        assert not relative.is_absolute() and '..' not in relative.parts and ':' not in row['path'] and '\\' not in row['path']
        assert hashlib.sha256(git('show', HEAD + ':' + row['path'])).hexdigest() == row['sha256']
    source_map = {row['path']:row['sha256'] for row in source_rows}
    assert source_map['src/research_workbench/adapters/models/provider_source_closure.py'] == SOURCE_SHA256
    assert source_map['tests/test_provider_source_closure.py'] == TEST_SHA256
    index = load(WT / ARC / 'RAW_INDEX.json')
    assert index['kind'] == 'source_parse_scoped_evidence'
    indexed = index['files']
    archive_path = WT / ARC / 'raw-observations.zip'
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) == len(indexed)
        assert sorted(names) == sorted(row['path'] for row in indexed)
        assert sum(member.file_size for member in archive.infolist()) <= 256000000
        for member in archive.infolist():
            relative = PurePosixPath(member.filename)
            assert not relative.is_absolute() and '..' not in relative.parts and ':' not in member.filename and '\\' not in member.filename
            assert not stat.S_ISLNK(member.external_attr >> 16)
        assert archive.testzip() is None
        for row in indexed:
            payload = archive.read(row['path'])
            assert len(payload) == row['bytes'] and hashlib.sha256(payload).hexdigest() == row['sha256']
    return dict(manifest=identity(path), capture=identity(WT / ARC / 'CAPTURE.json'),
                raw_index=identity(WT / ARC / 'RAW_INDEX.json'), raw_zip=identity(archive_path),
                committed_manifest_files_equal=True, capture_sources_equal=True,
                zip_index_sha_size_crc_safepath_equal=True, capture_gap_retained=True)

def offline_prepare():
    """Reuse reviewed immutable metadata plus direct changed-test AST; no broad source reads."""
    review_path = PRIOR_HOME / 'native-tool-review-v2/summary.json'
    review = load(review_path)
    assert review['status'] == 'PASS_STATIC_NATIVE_AUDITOR_V2' and not review['blockers']
    original = PRIOR_HOME / 'native-preparation-v2/audit_native.py'
    assert hashlib.sha256(original.read_bytes()).hexdigest() == review['tool_sha256']
    proof_path = PRIOR_HOME / 'native-preparation-v2/ast-method-preservation.json'
    proof = load(proof_path)
    expected_prior_sha = next(row['sha256'] for row in review['sources'] if row['path'].endswith('ast-method-preservation.json'))
    assert hashlib.sha256(proof_path.read_bytes()).hexdigest() == expected_prior_sha
    assert (proof['baseline_declared_method_count'],proof['target_declared_method_count']) == (530,536)
    old_selected = proof['source_derived_inventory']['selected_declared_method_ids']
    module = 'test_provider_source_closure'
    relative = 'tests/' + module + '.py'
    previous_raw, base_raw = git('show', STARTING_HEAD + ':' + relative), git('show', BASE + ':' + relative)
    candidate_raw = (WT / relative).read_bytes()
    previous, accepted, candidate = methods(previous_raw,module), methods(base_raw,module), methods(candidate_raw,module)
    assert len(previous) == 21 and len(candidate) == 23 and len(accepted) == 17
    assert all(previous[key] == candidate.get(key) for key in previous)
    assert all(accepted[key] == candidate.get(key) for key in accepted)
    candidate_added = sorted(set(candidate)-set(previous))
    assert candidate_added == sorted(REQUIRED_NEW_METHODS[:2])
    assert hashlib.sha256(candidate_raw).hexdigest() == TEST_SHA256
    source_path = WT / 'src/research_workbench/adapters/models/provider_source_closure.py'
    assert hashlib.sha256(source_path.read_bytes()).hexdigest() == SOURCE_SHA256
    metadata_rows = []
    for row in proof['source_derived_inventory']['source_bindings']:
        if row['path'] == relative:
            continue
        assert git('diff','--name-only',STARTING_HEAD,'--',row['path']) == b'', 'unreviewed collection source change: ' + row['path']
        metadata_rows.append(dict(path=row['path'], retained_reviewed_target_sha256=row['target_blob_sha256'],
                                  unchanged_from_starting_git_metadata=True))
    selected = sorted(set(old_selected) | set(candidate_added))
    assert len(selected) == 538 and set(proof['baseline_declared_method_ids']) <= set(selected)
    added = sorted(set(selected)-set(proof['baseline_declared_method_ids']))
    assert added == sorted(REQUIRED_NEW_METHODS)
    runner_path = WT / '.github/scripts/run_component_ci.py'
    runner_raw = runner_path.read_bytes()
    previous_runner = git('show', BASE + ':.github/scripts/run_component_ci.py')
    assert runner_raw.replace(b'\r\n',b'\n') == previous_runner.replace(b'\r\n',b'\n')
    runner_tree = ast.parse(runner_raw)
    short_node = next(node for node in runner_tree.body if isinstance(node,ast.Assign)
                      and any(isinstance(target,ast.Name) and target.id == 'SHORT_REGRESSIONS' for target in node.targets))
    short = ast.literal_eval(short_node.value)
    assert short == EXPECTED_SHORT_REGRESSIONS == tuple(proof['source_derived_inventory']['short_regression_ids'])
    inventory = sorted(set(selected) | set(short))
    assert len(inventory) == 545 and not set(selected) & set(short)
    local = local_independent_reference()
    return dict(status='PREPARED_UNBOUND_NOT_EXECUTED', final_hosted_binding=None,
                prior_review=identity(review_path), prior_ast_metadata=identity(proof_path),
                starting_head_historical_only=STARTING_HEAD, accepted_base=BASE,
                source=identity(source_path), direct_test=identity(WT / relative),
                unchanged_collection_metadata=metadata_rows, accepted_method_ids=proof['baseline_declared_method_ids'],
                d7_method_ids=old_selected, candidate_method_ids=selected, added_methods=added,
                newly_added_to_d7=candidate_added, old_530_ast_preserved_by_review_and_direct_ast=True,
                old_d7_536_preserved_by_unchanged_metadata_and_direct_ast=True,
                short_exact_ids=list(short), expected_native_inventory=inventory,
                expected_inventory_sha256=hashlib.sha256(canonical(inventory)).hexdigest(),
                expected_ordered_shards=[dict(shard_index=index,ids=expected_shard_inventory(inventory,index)) for index in range(4)],
                expected_native_unique=545, candidate_method_count=538, selected_modules=36,
                source_controls=source_controls(candidate_raw), local_independent=local,
                future_committed_validation=HOSTED.as_posix()+'/committed-validation/summary.json',
                future_attempt_manifest=(WT / ARC / 'MANIFEST.json').as_posix(),
                terminal_identity_fields_required=['run_id','attempt','head','base','target','tree','plan_sha256',
                                                  'plan_home','committed_validation','attempt_manifest','attempt_manifest_sha256',
                                                  'governance_run','governance_attempt','tool_review','tool_review_sha256'],
                api_reads=0, downloads=0, tests=0, test_module_imports=0, producer_imports_or_execution=0,
                complete_agent_trace=False, capture_gap='Bounded preparation artifacts and visible tool history; no complete transport trace.')

def cache_and_sources():
    plan = load(PLAN_HOME / 'official-plan.json')
    artifact = load(PLAN_HOME / 'artifact.json')
    binding = load(PLAN_HOME / 'summary.json')
    committed = load(COMM_VALIDATION)
    assert binding['status'] == 'PASS_OFFICIAL_COMPONENT_PLAN_GIT_BINDING'
    assert binding['git_parents_tree_and_canonical_plan'] is True and binding['zip_api_sha_size_crc_safepath'] is True
    assert binding['run'] == RUN and (binding['head'], binding['base'], binding['target'], binding['tree']) == (HEAD, BASE, TARGET, TREE)
    assert committed['status'] == 'PASS' and (committed['head'], committed['base']) == (HEAD, BASE)
    assert committed['selection_and_flags_unchanged'] is True and committed['old_archives_preserved'] is True
    assert committed['parent'] == STARTING_HEAD and committed['tree'] == TREE
    assert committed['committed_archive_bytes'] is True and committed['old_methods_preserved'] is True
    assert (committed['old_test_methods'],committed['current_test_methods']) == (21,23)
    assert (committed['source_sha256'],committed['test_sha256']) == (SOURCE_SHA256,TEST_SHA256)
    assert committed['governance_errors'] is False
    archive_binding = attempt_archive_binding()
    assert plan['head_sha'] == TARGET and plan['base_sha'] == plan['merge_base_sha'] == BASE
    assert plan['plan_sha256'] == PLAN_DIGEST == binding['plan_sha256']
    assert plan['profile'] == 'component' and plan['python_versions'] == ['3.11'] and len(plan['selected_tests']) == 36
    assert hashlib.sha256(canonical({key: value for key, value in plan.items() if key != 'plan_sha256'})).hexdigest() == PLAN_DIGEST
    assert artifact['id'] == binding['artifact'] and artifact['name'] == 'component-plan' and not artifact['expired']
    assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD
    archive_path = PLAN_HOME / 'official-plan.zip'
    assert 'sha256:' + hashlib.sha256(archive_path.read_bytes()).hexdigest() == artifact['digest']
    assert archive_path.stat().st_size == artifact['size_in_bytes']
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.namelist() == ['plan.json'] and archive.testzip() is None
        assert canonical(json.loads(archive.read('plan.json'))) == canonical(plan)
    assert git('rev-parse', 'HEAD').decode().strip() == HEAD
    assert git('rev-list', '--parents', '-n', '1', TARGET).decode().strip().split() == [TARGET, BASE, HEAD]
    assert git('rev-parse', TARGET + '^{tree}').decode().strip() == TREE == git('rev-parse', HEAD + '^{tree}').decode().strip()
    sources = []
    for name in SOURCES:
        path = WT / '.github/scripts' / name
        current = path.read_bytes().replace(b'\r\n', b'\n')
        original = git('show', BASE + ':.github/scripts/' + name)
        target = git('show', TARGET + ':.github/scripts/' + name)
        assert current == original.replace(b'\r\n', b'\n') == target.replace(b'\r\n', b'\n')
        sources.append(dict(name=name, current=identity(path), base_blob_sha256=hashlib.sha256(original).hexdigest(), target_blob_sha256=hashlib.sha256(target).hexdigest(), newline_normalized_equal=True))
    baseline, current, module_rows, starting_methods = {}, {}, [], {}
    controls = None
    for module in plan['selected_tests']:
        rel = 'tests/' + module + '.py'
        old_raw, new_raw = git('show', BASE + ':' + rel), git('show', TARGET + ':' + rel)
        old_methods, new_methods = methods(old_raw, module), methods(new_raw, module)
        starting_raw = git('show', STARTING_HEAD + ':' + rel)
        starting_module_methods = methods(starting_raw,module)
        assert set(starting_module_methods) <= set(new_methods)
        assert all(starting_module_methods[key] == new_methods[key] for key in starting_module_methods), 'modified d7 test method AST: '+module
        starting_methods.update(starting_module_methods)
        assert set(old_methods) <= set(new_methods), 'deleted baseline test method: ' + module
        assert all(old_methods[key] == new_methods[key] for key in old_methods), 'modified baseline method AST: ' + module
        baseline.update(old_methods); current.update(new_methods)
        module_rows.append(dict(module=module, base_methods=len(old_methods), target_methods=len(new_methods), old_methods_preserved=True, old_method_ast_equal=True, base_blob_sha256=hashlib.sha256(old_raw).hexdigest(), target_blob_sha256=hashlib.sha256(new_raw).hexdigest()))
        if module == 'test_provider_source_closure':
            controls = source_controls(new_raw)
    added = sorted(set(current) - set(baseline))
    assert len(baseline) == EXPECTED_BASE_METHODS and len(current) == EXPECTED_TARGET_METHODS
    assert len(starting_methods) == 536
    assert added == sorted(REQUIRED_NEW_METHODS), 'new method identities differ'
    assert controls is not None
    source_inventory = source_derived_inventory(plan, current)
    assert all(name not in sys.modules and 'tests.' + name not in sys.modules for name in plan['selected_tests'])
    assert 'run_component_ci' not in sys.modules and 'ci_component_result' not in sys.modules
    return plan, dict(sources=sources, modules=module_rows, baseline_declared_method_count=len(baseline),
                     target_declared_method_count=len(current), starting_d7_declared_method_count=len(starting_methods),
                     starting_d7_declared_method_ids=sorted(starting_methods), starting_d7_method_ast_preserved=True,
                     baseline_declared_method_ids=sorted(baseline),
                     target_declared_method_ids=sorted(current), source_derived_inventory=source_inventory,
                     added_methods=added, source_controls=controls,
                     cached_plan_inputs=[identity(PLAN_HOME / name) for name in ('summary.json', 'artifact.json', 'official-plan.json', 'official-plan.zip')],
                     committed_validation=identity(COMM_VALIDATION), attempt_archive=archive_binding,
                     committed_head_plan_sha256=committed['plan_sha256'], official_tested_merge_plan_sha256=PLAN_DIGEST,
                     local_independent_reference=local_independent_reference(),
                     no_test_loader_or_test_import=True, no_producer_import_or_execution=True,
                     ast_limit='Exact source-derived expected IDs with named loader-shape proof; no independent runtime collection or test execution.')

def elapsed(start, end):
    return (datetime.fromisoformat(end.replace('Z', '+00:00')) - datetime.fromisoformat(start.replace('Z', '+00:00'))).total_seconds()
def api(endpoint, out, name):
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(['gh', 'api', 'repos/' + REPO + '/' + endpoint], capture_output=True, env=ENV, timeout=60)
    save(out / (name + '-request.json'), dict(endpoint=endpoint, started_at=started, completed_at=datetime.now(timezone.utc).isoformat(), exit_code=result.returncode, stderr=result.stderr.decode('utf-8', 'replace')))
    assert result.returncode == 0, 'Read-only API failed: ' + endpoint
    with (out / (name + '.json')).open('xb') as handle:
        handle.write(result.stdout)
    return json.loads(result.stdout)
def download(artifact, out, expected):
    assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD and not artifact['expired']
    path = out / (artifact['name'] + '.zip')
    assert not list(HOSTED.rglob(artifact['name'] + '.zip')), 'Never repeat or overwrite this run native artifact download'
    response = subprocess.run(['gh', 'api', f"repos/{REPO}/actions/artifacts/{artifact['id']}/zip"], capture_output=True, env=ENV, timeout=90)
    save(out / (artifact['name'] + '-download.json'), dict(artifact_id=artifact['id'], download_attempts=1, exit_code=response.returncode, stderr=response.stderr.decode('utf-8', 'replace')))
    assert response.returncode == 0
    payload = response.stdout
    with path.open('xb') as handle:
        handle.write(payload)
    digest = hashlib.sha256(payload).hexdigest()
    assert len(payload) == artifact['size_in_bytes'] and 'sha256:' + digest == artifact['digest']
    archive = zipfile.ZipFile(io.BytesIO(payload))
    names = archive.namelist()
    assert len(names) == len(set(names)) and set(names) == set(expected)
    assert sum(member.file_size for member in archive.infolist()) <= 50000000
    for member in archive.infolist():
        rel = PurePosixPath(member.filename)
        assert not rel.is_absolute() and '..' not in rel.parts and ':' not in member.filename and '\\' not in member.filename
        assert not stat.S_ISLNK(member.external_attr >> 16) and member.file_size <= 20000000
    assert archive.testzip() is None
    directory = out / 'native' / artifact['name']
    directory.mkdir(parents=True, exist_ok=False)
    for name in names:
        destination = directory.joinpath(*PurePosixPath(name).parts)
        assert destination.resolve().is_relative_to(directory.resolve())
        with destination.open('xb') as handle:
            handle.write(archive.read(name))
    check = dict(id=artifact['id'], name=artifact['name'], download_attempts=1, api_size=artifact['size_in_bytes'], actual_size=len(payload), api_digest=artifact['digest'], actual_sha256=digest, size_sha_crc_safe_inventory_pass=True, members=names)
    save(out / (artifact['name'] + '-check.json'), check)
    return check
def audit(out):
    plan, ast_proof = cache_and_sources()
    save(out / 'source-and-ast-preservation.json', ast_proof)
    expected_source = ast_proof['source_derived_inventory']
    expected_inventory = expected_source['expected_native_inventory']
    sys.path.insert(0, str(WT / '.github/scripts'))
    import run_component_ci as producer
    import ci_component_result as validator
    assert tuple(producer.SHORT_REGRESSIONS) == tuple(expected_source['short_regression_ids'])
    assert canonical(producer.make_plan(WT, BASE, TARGET, 'component')) == canonical(plan)
    assert tuple(plan['selected_tests']) == tuple(sorted(row['module'] for row in load(PRIOR_HOME / 'native-preparation-v2/ast-method-preservation.json')['modules']))
    matrix = producer.execution_matrix(plan)
    assert len(matrix) == 4 and all(row['python'] == '3.11' and row['shard_count'] == 4 for row in matrix)
    run = api(f'actions/runs/{RUN}', out, 'run')
    assert run['id'] == RUN and run['head_sha'] == HEAD and run['run_attempt'] == ATTEMPT and run['event'] == 'pull_request' and run['path'] == WORKFLOW
    if run['status'] != 'completed' or run['conclusion'] != 'success':
        return dict(status='NOT_TERMINAL_SUCCESS_STOP_NO_ARTIFACTS', run_id=RUN, head=HEAD, run_status=run['status'], run_conclusion=run['conclusion'], native_downloads=0)
    governance = api(f'actions/runs/{GOVERNANCE_RUN}',out,'governance-run')
    assert governance['id'] == GOVERNANCE_RUN and governance['head_sha'] == HEAD and governance['run_attempt'] == GOVERNANCE_ATTEMPT
    assert governance['event'] == 'pull_request' and governance['path'] == '.github/workflows/ci-governance.yml'
    assert governance['status'] == 'completed' and governance['conclusion'] == 'success', 'Governance is not this head terminal SUCCESS'
    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs_future = pool.submit(api, f'actions/runs/{RUN}/attempts/{ATTEMPT}/jobs?per_page=100', out, 'jobs')
        artifacts_future = pool.submit(api, f'actions/runs/{RUN}/artifacts?per_page=100', out, 'artifacts')
        jobs, artifacts = jobs_future.result()['jobs'], artifacts_future.result()['artifacts']
    assert len(jobs) == 6 and all(job['status'] == 'completed' and job['conclusion'] == 'success' for job in jobs)
    checks = []
    names = [row['artifact_name'] for row in matrix] + ['ci-result']
    assert len(names) == 5
    for name in names:
        found = [artifact for artifact in artifacts if artifact['name'] == name]
        assert len(found) == 1, 'Missing/duplicate native artifact: ' + name
        checks.append(download(found[0], out, ['ci-result.json'] if name == 'ci-result' else ['plan.json', 'result.json', 'smoke.json']))
    native = out / 'native'
    official = load(native / 'ci-result/ci-result.json')
    context = dict(repository=REPO, event='pull_request', ref='refs/pull/139/merge', run_id=RUN, run_attempt=ATTEMPT, workflow_path=WORKFLOW)
    statuses = dict(plan='success', execute='success')
    assert official['context'] == context and official['producers'] == statuses
    projection = validator.summarize(plan, native, statuses, context)
    assert canonical(projection) == canonical(official)
    save(out / 'accepted-validator-projection.json', projection)
    inventory, records, shards, smokes = None, [], [], []
    for row in matrix:
        directory = native / row['artifact_name']
        result, smoke = load(directory / 'result.json'), load(directory / 'smoke.json')
        assert canonical(load(directory / 'plan.json')) == canonical(plan)
        assert result['schema_version'] == '0.2.0' and result['authority'] == 'profile-result-only' and result['coverage'] == 'not-collected'
        assert result['head_sha'] == TARGET and result['plan_sha256'] == PLAN_DIGEST and result['selections'] == producer.execution_names(plan, '3.11')
        behavior = result['behavior']; rows = behavior['records']; current = behavior['inventory']
        assert behavior['success'] is True and behavior['failures'] == behavior['errors'] == 0 and len(rows) == behavior['tests_run']
        assert current == expected_inventory, 'native inventory differs from exact source-derived expected IDs'
        assert inventory is None or inventory == current
        inventory = current
        assert hashlib.sha256(canonical(current)).hexdigest() == behavior['inventory_sha256']
        ordered_ids = [producer.canonical_record_id(record['id']) for record in rows]
        expected_ids = expected_source['expected_ordered_shards'][row['shard_index']]['ids']
        assert ordered_ids == expected_ids, 'ordered native shard IDs differ from source-derived ownership'
        assert ordered_ids == producer.shard_inventory(current, row['shard_index'], 4)
        assert all(record['outcome'] in ('passed', 'passed_with_skips', 'skipped', 'expected_failure') and math.isfinite(record['duration_seconds']) and record['duration_seconds'] >= 0 for record in rows)
        for record in rows:
            portable = producer.canonical_record_id(record['id'])
            module, qualified = portable.split('.', 1)
            assert record['module'] in (module, 'tests.' + module)
            assert record['canonical_id'] == 'tests/' + module + '.py::' + qualified
        assert all(point['outcome'] in ('passed', 'skipped') for record in rows for point in record.get('checkpoints', []))
        assert smoke['profile'] == 'installed-component-smoke-v1' and smoke['status'] == 'success'
        assert [step['name'] for step in smoke['steps']] == list(SMOKE_STEPS)
        for step in smoke['steps']:
            expected = 1 if step['name'] == 'invalid-timestamp-cli' else 0
            assert step['status'] == 'success' and step['expected_exit'] == expected and step['exit_code'] == expected
            if expected == 1:
                assert 'timestamp' in step['stdout']
        positive = json.loads(smoke['steps'][0]['stdout'].strip())
        assert positive['positive_schema'] is True and positive['invalid_timestamp_rejected'] is True
        smokes.append(dict(shard=row['shard_index'], **smoke))
        summed = math.fsum(record['duration_seconds'] for record in rows)
        job = next(job for job in jobs if job['name'] == f"Component (3.11, shard {row['shard_index']})")
        shards.append(dict(shard=row['shard_index'], records=len(rows), outcomes=dict(Counter(record['outcome'] for record in rows)), runner_seconds=behavior['elapsed_seconds'], measured_record_seconds_sum=summed, runner_minus_records_seconds=behavior['elapsed_seconds']-summed, job_id=job['id'], job_elapsed_seconds=elapsed(job['started_at'], job['completed_at']), steps=[dict(name=step['name'], conclusion=step.get('conclusion'), seconds=elapsed(step['started_at'], step['completed_at']) if step.get('started_at') and step.get('completed_at') else None) for step in job['steps']]))
        records.extend(dict(record, shard=row['shard_index']) for record in rows)
    received = [producer.canonical_record_id(record['id']) for record in records]
    assert len(received) == len(set(received)) == len(inventory) and sorted(received) == inventory
    assert sorted(received) == expected_inventory, 'native disjoint union differs from exact source-derived IDs'
    save(out / 'source-native-identity-closure.json', dict(
         source_expected_inventory=expected_inventory, native_inventory=inventory,
         native_received_sorted=sorted(received), expected_ordered_shards=expected_source['expected_ordered_shards'],
         native_inventory_equal_source_expected=True, native_ordered_shards_equal_source_expected=True,
         native_complete_disjoint_union_equal_source_expected=True, source_missing_ids=[], native_unexpected_ids=[]))
    assert len(inventory) == EXPECTED_NATIVE_UNIQUE == EXPECTED_TARGET_METHODS + len(producer.SHORT_REGRESSIONS)
    assert sum(item.split('.', 1)[0] in set(plan['selected_tests']) for item in inventory) == EXPECTED_TARGET_METHODS
    assert all(record['outcome'] == 'passed' and all(point['outcome'] == 'passed' for point in record.get('checkpoints', [])) for record in records)
    selected, short = set(plan['selected_tests']), set(producer.SHORT_REGRESSIONS)
    assert short <= set(inventory)
    assert all(item.split('.', 1)[0] in selected or item in short for item in inventory)
    assert selected <= {item.split('.', 1)[0] for item in inventory}
    by_id = {producer.canonical_record_id(record['id']): record for record in records}
    added = [by_id[name] for name in ast_proof['added_methods']]
    assert all(record['outcome'] == 'passed' and all(point['outcome'] == 'passed' for point in record.get('checkpoints', [])) for record in added)
    labels = {'test_injected_and_forged_repr_wrappers_remain_rejected': ('plain injected', 'reprlib wrapped ordinary callable', 'canonical wrapper with forged generated filename'), 'test_repr_field_metadata_rejects_custom_objects_without_calling_them': ('kw_only custom truth', 'field name string subclass', 'Field subclass', 'parameter subclass'), 'test_generated_repr_captured_builtins_must_be_canonical': CAPTURED_BUILTINS_LABELS}
    for suffix, expected_labels in labels.items():
        record = next(record for record in added if producer.canonical_record_id(record['id']).endswith('.' + suffix))
        points = record.get('checkpoints', [])
        assert all(any(label in point['id'] and point['outcome'] == 'passed' for point in points) for label in expected_labels)
    clone_record = by_id['test_provider_source_closure.ProviderSourceClosureTests.test_generated_repr_captured_builtins_must_be_canonical']
    assert len(clone_record.get('checkpoints', [])) == 3, 'Do not invent a fourth hosted subTest label'
    recursive_record = by_id['test_provider_source_closure.ProviderSourceClosureTests.test_generated_dataclass_repr_and_explicit_custom_repr_are_supported']
    assert recursive_record['outcome'] == 'passed' and ast_proof['source_controls']['normal_recursive_repr_assertion_declared']
    assert all(name not in sys.modules and 'tests.' + name not in sys.modules for name in plan['selected_tests'])
    save(out / 'source-control-native-claims.json', dict(source=ast_proof['source_controls'],
         normal_recursive_original_method_native_passed=True, captured_builtins_original_method_native_passed=True,
         captured_builtins_hosted_label_count=3, unlabelled_inner_control='Proven through original method native PASS; not a fourth checkpoint.',
         local_independent=ast_proof['local_independent_reference'], local_probe_hosted_extra_subtests=0))
    save(out / 'all-native-records.json', records)
    save(out / 'new-method-native-records.json', added)
    groups = defaultdict(list)
    for record in records:
        groups[producer.canonical_record_id(record['id']).split('.')[0]].append(record)
    ranking = [dict(module=module, cases=len(rows), selected_full_module=module in selected, measured_record_seconds_sum=math.fsum(record['duration_seconds'] for record in rows), outcomes=dict(Counter(record['outcome'] for record in rows))) for module, rows in sorted(groups.items(), key=lambda pair: math.fsum(record['duration_seconds'] for record in pair[1]), reverse=True)]
    return dict(status='PASS_NATIVE_PR139_COMPONENT_EVIDENCE', observed_at=datetime.now(timezone.utc).isoformat(), run_id=RUN, attempt=ATTEMPT, pr=PR, head=HEAD, base=BASE, tested_merge=TARGET, tested_tree=TREE, plan_sha256=PLAN_DIGEST, selected_full_modules=len(selected), actual_inventory_count=len(inventory), actual_unique_records=len(received), inventory_sha256=hashlib.sha256(canonical(inventory)).hexdigest(), native_inventory_digest_present=True, source_derived_inventory_exact_equal=True, expected_inventory_count=len(expected_inventory), source_derived_exact_ordered_shards_equal=True, ordered_shard_records_and_complete_disjoint_union=True, outcomes=dict(Counter(record['outcome'] for record in records)), subtest_outcomes=dict(Counter(point['outcome'] for record in records for point in record.get('checkpoints', []))), added_methods=ast_proof['added_methods'], added_methods_native_passed=True, captured_builtins_hosted_subtest_labels=list(CAPTURED_BUILTINS_LABELS), unlabelled_inner_control_in_native_method=True, normal_recursive_original_method_native_passed=True, local_independent_source_reference=ast_proof['local_independent_reference'], local_probe_hosted_extra_subtests=0, baseline_ast_methods_preserved=True, old_d7_methods_preserved=True, governance_run_id=GOVERNANCE_RUN, governance_same_head_terminal_success=True, ast_preservation=ast_proof, selected_full_module_cases=sum(row['cases'] for row in ranking if row['selected_full_module']), extra_short_cases=sum(row['cases'] for row in ranking if not row['selected_full_module']), accepted_validator_projection_equal=True, aggregate_context=context, installed_smoke_step_count=sum(len(smoke['steps']) for smoke in smokes), installed_smokes=smokes, shards=shards, module_ranking=ranking, workflow_elapsed_created_to_updated_seconds=elapsed(run['created_at'], run['updated_at']), runner_seconds_sum=math.fsum(row['runner_seconds'] for row in shards), measured_record_seconds_sum=math.fsum(record['duration_seconds'] for record in records), native_coverage='not-collected', aggregate_coverage=official['coverage'], coverage_gate_proven=False, full_repository_proven=False, merge_eligible=official['merge_eligible'], native_artifact_downloads=5, cached_plan_downloads=0, artifact_checks=checks, tests_executed_by_auditor=0, timing_boundary='Runner begins after imports, collection/deduplication and assignment. Record startTest to stopTest includes per-case setup/body/cleanup, excludes class/module setup. Residual is unallocated; parallel runner sum is not workflow wall.', limits=['Component profile only; not full/checkpoint/coverage/release approval.', 'AST derives exact expected IDs for the bound direct-TestCase source shape; native inventory and ordered records must equal those IDs. No independent test imports/collection are run by auditor.', 'Subtest PASS means expected rejection assertions succeeded, not that invalid inputs were accepted.', 'No whole-CI speedup claim; no tests, Provider, archive execution or remote/ref/source mutations.'])
def main():
    global WT, RUN, ATTEMPT, HEAD, BASE, TARGET, TREE, PLAN_DIGEST, PLAN_HOME
    global COMM_VALIDATION, ATTEMPT_MANIFEST, ATTEMPT_MANIFEST_SHA256
    global GOVERNANCE_RUN, GOVERNANCE_ATTEMPT, TOOL_REVIEW, TOOL_REVIEW_SHA256
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare-only',action='store_true')
    parser.add_argument('--terminal-success-confirmed',action='store_true')
    parser.add_argument('--repo',type=Path,default=WT)
    parser.add_argument('--output',type=Path)
    for name in ('run-id','attempt','governance-run','governance-attempt'):
        parser.add_argument('--'+name,type=int)
    for name in ('head','base','target','tree','plan-sha256','attempt-manifest-sha256','tool-review-sha256'):
        parser.add_argument('--'+name)
    for name in ('plan-home','committed-validation','attempt-manifest','tool-review'):
        parser.add_argument('--'+name,type=Path)
    args = parser.parse_args()
    WT = args.repo.resolve()
    ast.parse(Path(__file__).read_text(encoding='utf-8-sig'))
    if args.prepare_only:
        assert not args.terminal_success_confirmed and args.output is None
        assert all(getattr(args,name) is None for name in (
            'run_id','attempt','head','base','target','tree','plan_sha256','plan_home','committed_validation',
            'attempt_manifest','attempt_manifest_sha256','governance_run','governance_attempt','tool_review','tool_review_sha256'))
        proof = offline_prepare()
        save(HERE / 'preparation.json',proof)
        save(HERE / 'expected-native-inventory.json',dict(
            selected_declared_method_ids=proof['candidate_method_ids'],short_regression_ids=proof['short_exact_ids'],
            expected_native_inventory=proof['expected_native_inventory'],expected_ordered_shards=proof['expected_ordered_shards']))
        print(json.dumps(dict(status=proof['status'],final_hosted_binding=None,expected_native_unique=545,
                              candidate_methods=538,new_relative_to_accepted=8,api_reads=0,tests=0,producer_imports=0)))
        return
    required = ('run_id','attempt','head','base','target','tree','plan_sha256','plan_home','committed_validation',
                'attempt_manifest','attempt_manifest_sha256','governance_run','governance_attempt','tool_review','tool_review_sha256','output')
    parser.error('Explicit terminal flag and all final identity/evidence fields are required') if (
        not args.terminal_success_confirmed or any(getattr(args,name) is None for name in required)) else None
    assert all(getattr(args,name)>0 for name in ('run_id','attempt','governance_run','governance_attempt'))
    assert args.base == BASE and args.head != STARTING_HEAD
    def hexadecimal(value,length):
        return len(value)==length and all(character in '0123456789abcdef' for character in value)
    assert all(hexadecimal(getattr(args,name),40) for name in ('head','base','target','tree'))
    assert all(hexadecimal(getattr(args,name),64) for name in ('plan_sha256','attempt_manifest_sha256','tool_review_sha256'))
    RUN,ATTEMPT,HEAD,TARGET,TREE,PLAN_DIGEST = args.run_id,args.attempt,args.head,args.target,args.tree,args.plan_sha256
    PLAN_HOME,COMM_VALIDATION,ATTEMPT_MANIFEST = args.plan_home.resolve(),args.committed_validation.resolve(),args.attempt_manifest.resolve()
    ATTEMPT_MANIFEST_SHA256 = args.attempt_manifest_sha256
    GOVERNANCE_RUN,GOVERNANCE_ATTEMPT = args.governance_run,args.governance_attempt
    TOOL_REVIEW,TOOL_REVIEW_SHA256 = args.tool_review.resolve(),args.tool_review_sha256
    assert COMM_VALIDATION == (HOSTED / 'committed-validation/summary.json').resolve()
    assert PLAN_HOME == (HOSTED / 'hosted-plan').resolve()
    assert hashlib.sha256(TOOL_REVIEW.read_bytes()).hexdigest() == TOOL_REVIEW_SHA256
    tool_review = load(TOOL_REVIEW)
    assert tool_review['status'].startswith('PASS') and not tool_review.get('blockers',[])
    assert tool_review['tool_sha256'] == identity(Path(__file__))['sha256']
    out = args.output.resolve()
    assert out.is_relative_to(HOSTED.resolve()) and out != HOSTED.resolve() and not out.exists()
    out.mkdir(parents=True,exist_ok=False)
    save(out / 'explicit-binding.json',dict(
        run=RUN,attempt=ATTEMPT,head=HEAD,base=BASE,target=TARGET,tree=TREE,plan_sha256=PLAN_DIGEST,
        plan_home=str(PLAN_HOME),committed_validation=str(COMM_VALIDATION),attempt_manifest=str(ATTEMPT_MANIFEST),
        attempt_manifest_sha256=ATTEMPT_MANIFEST_SHA256,governance_run=GOVERNANCE_RUN,governance_attempt=GOVERNANCE_ATTEMPT,
        tool_review=identity(TOOL_REVIEW),helper=identity(Path(__file__)),terminal_success_confirmation_supplied=True))
    try:
        summary = audit(out)
    except Exception as error:
        summary = dict(status='AUDIT_BLOCKED_KEEP_RAW_NO_RETRY',run_id=RUN,head=HEAD,
                       error=f'{type(error).__name__}: {error}',traceback=traceback.format_exc(),tests_executed_by_auditor=0)
    save(out / 'summary.json',summary)
    with (out / 'REPORT.md').open('x',encoding='utf-8') as handle:
        handle.write('# PR139 component native audit\n\n'+json.dumps(
            {key:summary[key] for key in summary if key not in ('installed_smokes','ast_preservation','module_ranking','artifact_checks','shards')},
            ensure_ascii=False,indent=2)+'\n')
    save(out / 'manifest.json',dict(run_id=RUN,head=HEAD,helper=identity(Path(__file__)),
         files=[identity(path) for path in sorted(out.rglob('*')) if path.is_file() and path.name!='manifest.json']))
    print(json.dumps({key:summary.get(key) for key in ('status','run_id','head','actual_unique_records','expected_inventory_count',
          'source_derived_inventory_exact_equal','governance_same_head_terminal_success','native_coverage','error')},ensure_ascii=False))
if __name__ == '__main__':
    main()
