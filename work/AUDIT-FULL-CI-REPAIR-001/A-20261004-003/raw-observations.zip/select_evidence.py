"""Select bounded precommit evidence; exclude repo clone and ephemeral fixtures."""
from pathlib import Path
import hashlib, json

ROOT = Path(__file__).resolve().parent
WT = Path('D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004')
def identity(relative):
    raw = (ROOT / relative).read_bytes()
    return dict(path=relative, sha256=hashlib.sha256(raw).hexdigest())
bindings = ['local-final-summary.json', 'baseline/PAIR_SUMMARY.json', 'baseline/COVERED_SUMMARY.json',
            'independent/summary.json', 'independent/coverage-runner-review/summary.json',
            'independent/committed-validation-review/summary.json', 'independent/native-tool-review/summary.json']
for relative in bindings:
    row = json.loads((ROOT / relative).read_bytes())
    if relative.endswith('PAIR_SUMMARY.json'):
        assert row['outcome'] == 'PASS'
    elif relative.endswith('COVERED_SUMMARY.json'):
        assert row['candidate_original_methods'] == 'PASS'
        assert row['measurement_capture_valid'] and row['source_runtime_unchanged'] and row['branch_data_metadata_valid']
    else:
        assert row['status'].startswith('PASS') and not row.get('blockers', [])
files = {p.relative_to(ROOT).as_posix() for p in ROOT.iterdir() if p.is_file() and p.name != 'evidence-selection.json'}
for directory in ('baseline', 'source-review', 'independent', 'derivation-counts', 'source-coverage',
                  'local311', 'final-source311', 'final-source313', 'final-strengthened311',
                  'final-strengthened313', 'remaining-graph311', 'remaining-cold311', 'cold-graph313',
                  'graph-control-execution', 'graph-control-environment-completion', 'native-preparation'):
    for p in (ROOT / directory).rglob('*'):
        relative = p.relative_to(ROOT)
        if not p.is_file() or any(part in ('snapshot-d7', 'temp', '__pycache__', '.git') for part in relative.parts):
            continue
        files.add(relative.as_posix())
owned = ['src/research_workbench/adapters/models/provider_source_closure.py', 'tests/test_provider_source_closure.py',
         'docs/workstreams/chengyue-lu/FULL-CI-REPAIR-001/README.md',
         'docs/workstreams/chengyue-lu/FULL-CI-REPAIR-001/RISK_LEDGER.md']
value = dict(ready_to_freeze=True, bindings=[identity(p) for p in bindings],
    source=[dict(path=p, sha256=hashlib.sha256((WT / p).read_bytes()).hexdigest()) for p in owned],
    files=sorted(files), boundaries='Precommit local evidence; no future committed/hosted outcome is signed here',
    excluded='Original git snapshot recoverable at d7; ephemeral per-test temp trees omitted; source/runtime/test/helper identities retained')
with (ROOT / 'evidence-selection.json').open('x', encoding='utf-8') as h:
    json.dump(value, h, ensure_ascii=False, indent=2)
print(json.dumps(dict(files=len(files), total_bytes=sum((ROOT / p).stat().st_size for p in files))))
