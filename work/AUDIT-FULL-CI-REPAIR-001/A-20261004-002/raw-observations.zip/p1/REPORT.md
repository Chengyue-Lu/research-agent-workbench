# PR139 P1 captured builtins repair

The supplied independent review describes a real bypass in both tested Python versions. A clone of a generated dataclass repr wrapper can retain the canonical code object, globals, closure and `__wrapped__`, yet capture a different builtins namespace when `FunctionType` is created. Restoring the module's `__builtins__` entry afterward does not change the function's captured namespace. The old checker accepted this clone; invoking its repr then executed the injected `id` callback.

This assessment uses the isolated worktree `D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004` at committed HEAD `e9397d074a61a582bf57a430f9070af7713c3909`, based on c80. The current repair is an uncommitted change to exactly `provider_source_closure.py` and `test_provider_source_closure.py`. It has not been published or reviewed independently yet.

## Evidence and version difference

The original-source SHA-256 is `f0f63804d0b80625f57cd25e6805958ac44e3c3f044fdd2b38d5858184b9490e`. `original311.json` and `original313.json` preserve the accepted bypass under that source. Both receipts confirm identical code/globals/closure/`__wrapped__`, restored module builtins, a changed captured namespace, acceptance by the layout checker, and one injected callback on repr invocation. Python 3.11.16 uses the `dataclasses` recursive repr wrapper; Python 3.13.15 uses the `reprlib` wrapper. The same captured namespace bypass affects both.

The minimal reproduction uses `object.__new__` and `object.__setattr__` for synthetic repr demonstration. It does not run the Provider constructor, a default factory, archived source, external provider operation, or a full test suite. Its short execution is reproduction feasibility evidence, not a CI job cost measurement.

## Repair policy

The generated repr path now requires both outer wrapper and generated inner function to have `function.__builtins__ is vars(builtins)`. This is canonical captured namespace identity, not merely checking the module's restored `__builtins__` entry and not comparing only the actual `id` reference. A copied dictionary is conservatively rejected even when some values match. Dict subclasses and custom mappings are rejected without inspecting their entries or invoking getters. The inner function must also be an exact `FunctionType`, avoiding a custom `__class__` callback during this check.

The existing declared-source requirement, canonical wrapper code/global/closure checks, dataclass and Field exact primitive guards, source-module identity, and generated inner code comparison remain in force. Normal source-declared custom repr remains supported. No broader stdlib file, new runtime callable, or Provider-specific exemption is trusted.

This guard assumes the process's canonical builtins dictionary is trusted; it does not independently certify every value inside that global dictionary. Existing `code_state` comparison retains its explicit field policy: `co_names`, `co_varnames`, `co_freevars`, `co_cellvars`, argument counts, locals/stack/flags, names/qualname, first line number, bytecode, recursively represented constants, line table and exception table. Generated repr comparison normalizes first line number as before. It does not compare every `CodeType` field; `co_filename` is excluded.

## Focused validation

`fixed311.json` and `fixed313.json` replay the original clone with the repaired source and record rejection as `undeclared runtime class callable: ProviderAdapterConfig.__repr__`, with no callback during verification. The module's builtins entry is restored before verification in both cases.

Each interpreter then ran the same five selected methods exactly once. Python 3.11.16: 5 PASS, zero failure/error/skip, 15.997842 seconds. Python 3.13.15: 5 PASS, zero failure/error/skip, 16.135417 seconds. Native test IDs, per-method duration, interpreter identity and before/after hashes are in `focused311/native.json` and `focused313/native.json`; raw unittest output is alongside them.

- New captured namespace regression rejects replaced `id`, a dict subclass, a custom mapping and a generated inner clone, with zero malicious callback/getter execution.
- Normal generated and explicit custom repr passes; the generated recursive object renders `Record(value=...)` on both interpreters.
- Existing injected/forged wrappers remain rejected.
- Existing malicious Field/params metadata controls remain rejected with zero callback.
- The actual provider closure graph passes on both interpreters. Its selected method took 15.858119 seconds on 3.11 and 16.018102 seconds on 3.13.

`git diff --check` for the two owned files passed. No full suite, hosted CI, repository policy/configuration change, stage, commit, push, Ready transition or merge was performed.

## Frozen handoff

Final source SHA-256: `441bb66b2ab2f69cb721950e54e15690ce6aafd8bcfbbe2dd4162bbe2786ee96`.

Final test SHA-256: `9fb534bd81ad467e923d895f18a53d4d2e85907d521a29c52411cc73aac45a98`.

Both focused receipts show these same hashes before and after execution. `final.patch` is the scoped diff against e939. All original bypass receipts are preserved under their original identity. Root coordination owns independent review, combined validation, archive/publication, metadata and merge decisions. This local handoff does not claim the candidate's full CI passed or that any measured optimization was implemented.
