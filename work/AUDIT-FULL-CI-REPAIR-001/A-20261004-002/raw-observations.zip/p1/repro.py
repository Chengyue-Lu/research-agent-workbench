from pathlib import Path
import builtins
import hashlib
import json
import sys
from types import FunctionType
from unittest.mock import patch

root = Path(sys.argv[1])
output = Path(sys.argv[2])
sys.path[:0] = [str(root / "src"), str(root)]
from research_workbench.adapters.models import configuration
from research_workbench.adapters.models import provider_source_closure as closure

cls = configuration.ProviderAdapterConfig
original = cls.__repr__
namespace = closure._recursive_repr_namespace(original)
calls = []
def injected_id(value):
    calls.append("captured id called")
    return builtins.id(value)

globals_ = original.__globals__
previous = globals_["__builtins__"]
try:
    globals_["__builtins__"] = {**vars(builtins), "id": injected_id}
    clone = FunctionType(original.__code__, globals_, original.__name__, original.__defaults__, original.__closure__)
finally:
    globals_["__builtins__"] = previous
clone.__dict__.update(original.__dict__)
clone.__module__ = original.__module__
clone.__qualname__ = original.__qualname__
raw = Path(configuration.__file__).read_bytes()
_, aliases = closure._imports(configuration.__name__, raw, is_package=False, namespace={"research_workbench"})
item = {"raw": raw, "aliases": aliases}
source = Path(closure.__file__)
result = {"python": sys.version, "executable": sys.executable,
          "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
          "wrapper_namespace": namespace.__name__,
          "same_code": clone.__code__ is original.__code__, "same_globals": clone.__globals__ is original.__globals__,
          "same_closure": clone.__closure__ is original.__closure__, "same_wrapped": clone.__wrapped__ is original.__wrapped__,
          "namespace_builtins_restored": globals_["__builtins__"] is previous,
          "captured_builtins_identity_changed": clone.__builtins__ is not original.__builtins__}
with patch.object(cls, "__repr__", clone):
    try:
        closure._verify_class_layout(configuration, cls.__qualname__, cls, item)
    except closure.SourceClosureError as error:
        result["layout"] = "rejected"
        result["error"] = str(error)
    else:
        result["layout"] = "accepted"
    result["callbacks_during_verification"] = list(calls)
    if result["layout"] == "accepted":
        value = object.__new__(cls)
        for field in cls.__dataclass_fields__.values():
            object.__setattr__(value, field.name, "synthetic")
        result["repr_demonstration"] = repr(value)
        result["callbacks_after_repr"] = list(calls)
result["source_sha256_after"] = hashlib.sha256(source.read_bytes()).hexdigest()
assert result["source_sha256"] == result["source_sha256_after"]
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result))
