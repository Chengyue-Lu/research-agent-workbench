from pathlib import Path
import hashlib
import importlib
import io
import json
import sys
import time
import unittest

root = Path(sys.argv[1])
output = Path(sys.argv[2])
output.mkdir(parents=True, exist_ok=False)
sys.path[:0] = [str(root / "src"), str(root), str(root / "tests")]
paths = ("src/research_workbench/adapters/models/provider_source_closure.py", "tests/test_provider_source_closure.py")
def hashes():
    return {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths}

class Result(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []
    def startTest(self, test):
        super().startTest(test)
        self.started = time.perf_counter()
    def stopTest(self, test):
        self.records.append({"id": test.id(), "elapsed_seconds": time.perf_counter() - self.started})
        super().stopTest(test)

before = hashes()
importlib.import_module("test_provider_source_closure")
selected = ["test_provider_source_closure.ProviderSourceClosureTests." + name for name in (
    "test_generated_repr_captured_builtins_must_be_canonical",
    "test_generated_dataclass_repr_and_explicit_custom_repr_are_supported",
    "test_injected_and_forged_repr_wrappers_remain_rejected",
    "test_repr_field_metadata_rejects_custom_objects_without_calling_them",
    "test_actual_provider_graph_named_closed_registries_and_outside_seven_helper",
)]
suite = unittest.defaultTestLoader.loadTestsFromNames(selected)
stream = io.StringIO()
started = time.perf_counter()
result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=Result).run(suite)
summary = {"python": sys.version, "executable": sys.executable, "root": str(root),
           "selected": selected, "test_count": result.testsRun, "successful": result.wasSuccessful(),
           "elapsed_seconds": time.perf_counter() - started, "records": result.records,
           "failures": [{"id": test.id(), "traceback": detail} for test, detail in result.failures],
           "errors": [{"id": test.id(), "traceback": detail} for test, detail in result.errors],
           "skipped": [{"id": test.id(), "reason": reason} for test, reason in result.skipped],
           "source_hashes_before": before, "source_hashes_after": hashes()}
(output / "native.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
(output / "unittest.txt").write_text(stream.getvalue(), encoding="utf-8")
print(json.dumps({key: summary[key] for key in ("python", "test_count", "successful", "elapsed_seconds", "source_hashes_after")}))
assert before == summary["source_hashes_after"]
raise SystemExit(not result.wasSuccessful())
