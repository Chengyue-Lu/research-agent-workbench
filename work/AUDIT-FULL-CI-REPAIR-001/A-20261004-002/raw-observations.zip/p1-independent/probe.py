"""One bounded independent repr-layout probe; no provider graph or poisoned repr."""
import ast
import builtins
import dataclasses
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import reprlib
import sys
import time
from types import FunctionType, ModuleType

WT = Path(r"D:\lcy\develop\_worktrees\RWB\full-ci-repair-20261004")
OUT = Path(r"D:\lcy\develop\_assessments\rwb-ci-p234-p1-20261004\p1-independent")
PINS = {
    "src/research_workbench/adapters/models/provider_source_closure.py": "441bb66b2ab2f69cb721950e54e15690ce6aafd8bcfbbe2dd4162bbe2786ee96",
    "tests/test_provider_source_closure.py": "9fb534bd81ad467e923d895f18a53d4d2e85907d521a29c52411cc73aac45a98",
}

def sources():
    return [{"path": p, "sha256": hashlib.sha256((WT / p).read_bytes()).hexdigest()} for p in PINS]

started = time.monotonic()
before = sources()
checks = []
callbacks = []
clones = []
stdlib = []
receipt = {
    "interpreter": {"executable": sys.executable, "version": sys.version, "flags": str(sys.flags)},
    "sources_before": before,
    "scope": "direct source-module import plus independent trusted synthetic dataclass; no graph, tests, archive execution, or poisoned repr",
}

def record(name, passed, **details):
    checks.append({"name": name, "passed": bool(passed), **details})

def check_layout(label, cls, module, item, should_accept):
    count = len(callbacks)
    try:
        closure._verify_class_layout(module, cls.__qualname__, cls, item)
    except closure.SourceClosureError as exc:
        accepted = False
        error = str(exc)
    else:
        accepted = True
        error = None
    record(label, accepted is should_accept and len(callbacks) == count,
           accepted=accepted, expected_accept=should_accept, error=error,
           callback_delta=len(callbacks) - count)

def make_cell(value):
    return (lambda: value).__closure__[0]

def replace_inner(wrapper, inner):
    cells = tuple(make_cell(inner) if name == "user_function" else cell
                  for name, cell in zip(wrapper.__code__.co_freevars, wrapper.__closure__))
    replacement = FunctionType(wrapper.__code__, wrapper.__globals__, wrapper.__name__,
                               wrapper.__defaults__, cells)
    replacement.__dict__.update(wrapper.__dict__)
    replacement.__wrapped__ = inner
    replacement.__qualname__ = wrapper.__qualname__
    replacement.__module__ = wrapper.__module__
    return replacement

def clone_captured(function, namespace, label):
    environment = function.__globals__
    saved = environment["__builtins__"]
    try:
        environment["__builtins__"] = namespace
        replacement = FunctionType(function.__code__, environment, function.__name__,
                                   function.__defaults__, function.__closure__)
    finally:
        environment["__builtins__"] = saved
    replacement.__dict__.update(function.__dict__)
    replacement.__qualname__ = function.__qualname__
    replacement.__module__ = function.__module__
    identity = {
        "label": label, "same_code": replacement.__code__ is function.__code__,
        "same_globals": replacement.__globals__ is function.__globals__,
        "same_closure": replacement.__closure__ is function.__closure__,
        "same_wrapped": replacement.__dict__.get("__wrapped__") is function.__dict__.get("__wrapped__"),
        "module_builtins_restored": environment["__builtins__"] is saved,
        "captured_namespace_preserved": replacement.__builtins__ is namespace,
        "captured_namespace_noncanonical": replacement.__builtins__ is not vars(builtins),
    }
    clones.append(identity)
    record(label + ":clone-identities", all(v for k, v in identity.items() if k != "label"))
    return replacement

try:
    record("frozen-input-hashes", all(row["sha256"] == PINS[row["path"]] for row in before))
    spec = importlib.util.spec_from_file_location("_bounded_independent_closure", WT / next(iter(PINS)))
    closure = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = closure
    spec.loader.exec_module(closure)

    raw = ("from dataclasses import dataclass, field\n"
           "@dataclass\n"
           "class Tiny:\n"
           "    payload: object\n"
           "    quiet: int = field(default=11, repr=False)\n"
           "@dataclass\n"
           "class Written:\n"
           "    payload: object\n"
           "    def __repr__(self):\n"
           "        return 'written'\n")
    module = ModuleType("_independent_trusted_repr_input")
    sys.modules[module.__name__] = module
    module.__dict__["__builtins__"] = vars(builtins)
    exec(compile(raw, "<trusted-independent-probe>", "exec"), vars(module))
    item = {"raw": raw.encode(), "aliases": {"dataclass": ("dataclasses", "dataclass"), "field": ("dataclasses", "field")}}
    cls = module.Tiny
    original = vars(cls)["__repr__"]
    original_inner = original.__wrapped__
    namespace = closure._recursive_repr_namespace(original)
    record("canonical-captured-namespaces", original.__builtins__ is vars(builtins)
           and original_inner.__builtins__ is vars(builtins))
    check_layout("normal-generated-repr-accepted", cls, module, item, True)
    check_layout("explicit-source-repr-accepted", module.Written, module, item, True)
    ordinary = cls(payload=7)
    record("normal-repr-render", repr(ordinary) == "Tiny(payload=7)")
    ordinary.payload = ordinary
    record("recursive-repr-render", repr(ordinary) == "Tiny(payload=...)")

    for mod, function in ((reprlib, reprlib.recursive_repr), (dataclasses, dataclasses.fields)):
        lines, first = inspect.getsourcelines(function)
        path = Path(inspect.getsourcefile(function)).resolve()
        stdlib.append({"module": mod.__name__, "function": function.__qualname__, "path": str(path),
                       "file_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                       "first_line": first, "line_count": len(lines), "direct_source": "".join(lines)})
    legacy = vars(dataclasses).get("_recursive_repr")
    if type(legacy) is FunctionType:
        lines, first = inspect.getsourcelines(legacy)
        path = Path(inspect.getsourcefile(legacy)).resolve()
        stdlib.append({"module": "dataclasses", "function": legacy.__qualname__, "path": str(path),
                       "file_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                       "first_line": first, "line_count": len(lines), "direct_source": "".join(lines)})
    receipt["active_wrapper"] = {"namespace": namespace.__name__, "freevars": list(original.__code__.co_freevars)}

    def trap_id(value):
        callbacks.append("poisoned-id")
        raise AssertionError("poisoned repr must never execute")

    class TrapDict(dict):
        def __getitem__(self, key):
            callbacks.append("dict-getitem")
            raise AssertionError("dict getter must not execute")
        def get(self, *args):
            callbacks.append("dict-get")
            raise AssertionError("dict get must not execute")

    class TrapMapping:
        def __getitem__(self, key):
            callbacks.append("mapping-getitem")
            raise AssertionError("mapping getter must not execute")
        def get(self, *args):
            callbacks.append("mapping-get")
            raise AssertionError("mapping get must not execute")

    attacks = [
        ("outer-poisoned-id", {**vars(builtins), "id": trap_id}),
        ("outer-copied-canonical-values", dict(vars(builtins))),
        ("outer-dict-subclass", TrapDict(vars(builtins))),
        ("outer-custom-mapping", TrapMapping()),
    ]
    for label, alternate in attacks:
        replacement = clone_captured(original, alternate, label)
        cls.__repr__ = replacement
        try:
            check_layout(label + ":rejected-without-invocation", cls, module, item, False)
        finally:
            cls.__repr__ = original

    changed_inner = clone_captured(original_inner, {**vars(builtins), "id": trap_id}, "inner-poisoned-dict")
    cls.__repr__ = replace_inner(original, changed_inner)
    try:
        check_layout("inner-poisoned-dict:rejected-without-invocation", cls, module, item, False)
    finally:
        cls.__repr__ = original

    class TrapInner:
        @property
        def __class__(self):
            callbacks.append("inner-class-metadata")
            return FunctionType

    cls.__repr__ = replace_inner(original, TrapInner())
    try:
        check_layout("nonfunction-inner-rejected-without-class-getter", cls, module, item, False)
    finally:
        cls.__repr__ = original

    class TrapField(dataclasses.Field):
        __slots__ = ()
        def __getattribute__(self, name):
            callbacks.append("field-metadata-getter")
            raise AssertionError("Field getter must not execute")

    saved_fields = cls.__dataclass_fields__
    cls.__dataclass_fields__ = {**saved_fields, "payload": object.__new__(TrapField)}
    try:
        check_layout("Field-subclass-rejected-before-getter", cls, module, item, False)
    finally:
        cls.__dataclass_fields__ = saved_fields
    record("all-callbacks-zero", callbacks == [], callbacks=list(callbacks))
    record("normal-layout-after-attack-restoration", vars(cls)["__repr__"] is original)
    check_layout("normal-repr-still-accepted-after-restoration", cls, module, item, True)
except BaseException as exc:
    receipt["unexpected_error"] = {"type": type(exc).__name__, "message": str(exc)}
    record("probe-completed-without-unexpected-error", False)

after = sources()
record("source-and-test-hashes-unchanged", before == after)
receipt.update({"checks": checks, "clones": clones, "callbacks": callbacks,
                "stdlib_direct_sources": stdlib, "sources_after": after,
                "status": "PASS" if all(row["passed"] for row in checks) else "FAIL",
                "probe_elapsed_seconds": time.monotonic() - started,
                "capture_gap": "No complete platform transport or Agent Trace capture; this receipt contains this probe's observable results only."})
destination = OUT / sys.argv[1]
assert destination.resolve().parent == OUT.resolve()
destination.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": receipt["status"], "output": str(destination), "checks": len(checks),
                  "failed_checks": [row for row in checks if not row["passed"]], "callbacks": callbacks,
                  "source_hashes_unchanged": before == after, "active_wrapper": receipt.get("active_wrapper"),
                  "probe_elapsed_seconds": receipt["probe_elapsed_seconds"]}, ensure_ascii=False))
sys.exit(0 if receipt["status"] == "PASS" else 1)
