# PR139 captured-builtins P1 独立复核

2026-10-04。Profile：有界安全独立复核；Skills：[]。结论为 **PASS，限定于冻结修复及本报告具名边界；未发现阻断项**。

审查来源为 PLAN 的 P1 契约、作者 `p1/REPORT.md`、原始用户截图和当前两份冻结文件。源码 `provider_source_closure.py` SHA-256 为 `441bb66b2ab2f69cb721950e54e15690ce6aafd8bcfbbe2dd4162bbe2786ee96`；测试 `test_provider_source_closure.py` 为 `9fb534bd81ad467e923d895f18a53d4d2e85907d521a29c52411cc73aac45a98`。两版解释器执行前后均保持此身份。

**源码审查结果。** `provider_source_closure.py:688–693` 在读取 dataclass 细节之前要求外层 wrapper 的 `__builtins__ is vars(builtins)`；`714–721` 要求 exact `FunctionType` 内层、源模块 globals、canonical captured builtins、精确 `__wrapped__` 及无 defaults/closure。captured namespace 来自函数本身，恢复 stdlib module 的 `__builtins__` 条目不会使新克隆重新获得可信身份。该修复未对 mapping 作 `.get()`、`__getitem__` 或内容相等比较；FunctionType 的本地属性访问与 `is` 检查不会调用被捕获 mapping 的 getter。

检查 e939 对两文件的 scoped diff：产品变更仅外/内两处 builtins identity guard 及内层 `isinstance` → exact `type`。旧控制保持：exact dataclass params/Field/dict 早检 (`444–451,690–692`)、source-declared decorator (`696–705`)、canonical wrapper code/global 和 exact closure 名称 (`672–678,688,707–718`)、字段 name/repr/kw_only 的 primitive 类型和 stdlib 生成代码比较 (`724–735`)、repr slot 与类布局归属 (`738–765`)。`code_state` 原有字段策略未变 (`106–131`)；没有扩大 stdlib 信任文件集或 Provider-specific exemption。

**独立执行证据。** 未调用作者 unittest method、closure producer、完整 loaded-source graph 或 Provider 构造器。独立 [probe.py](probe.py) 直接载入目标源模块，对自己生成的可信小型 dataclass 调用有界 class-layout checker。Python 3.11.16 和 3.13.15 各仅执行一次 `-B -X utf8` probe；3.11 使用 dataclasses wrapper，3.13 使用 reprlib wrapper。每份原生 receipt 含 22 个具名检查（不是 22 个 unittest 方法），全部 PASS，callback/getter 次数均为 0：

- 正常生成 repr、显式 source-declared repr 接受；正常与 self-recursive repr 分别输出 `Tiny(payload=7)`、`Tiny(payload=...)`。
- 外层 FunctionType 克隆保持原 code/globals/closure/`__wrapped__`，模块 builtins 恢复后仍携带非 canonical captured namespace；替换 `id` 的 dict 被拒绝。
- 内容与 canonical builtins 相同的独立 dict、dict subclass、custom mapping 均被拒绝；没有读取其恶意 getter。
- 生成内层捕获替代 dict、伪装 FunctionType 的内层 `__class__` getter、Field subclass metadata getter 均在不调用其回调的情况下被拒绝。
- 恢复原 wrapper 后合法 layout 再次接受；两份源码/测试 hash 前后全等。所有 poisoned repr 从未执行。

原始观察、clone identities、具体拒绝信息、解释器版本与源码前后 hash 保存在 [probe311.raw.json](probe311.raw.json) 和 [probe313.raw.json](probe313.raw.json)。两份 receipt 还保存所用 stdlib `recursive_repr` / `fields` 的直接函数源、行号和所在文件 SHA-256，以说明两版 wrapper 差异。

**证明边界。** `vars(builtins)` 代表被信任的进程 canonical builtins 字典；这次修复不证明该全局字典的每个值未被外部改写。此边界与既有 Python compiler/runtime/native 信任边界一致。未运行实际 graph、整 module、新 CI 或性能对照；probe 时间只说明小探针可执行，不代表 CI 提速或完整产品安全认证。平台完整 transport / Agent Trace 不可得，保留 capture gap；这里只声明已保存的可见 probe 结果与 static diff。

写入仅本 `p1-independent/`，产品/config/test 源码未修改，未 stage/commit/push。下一步交 root 对冻结修复作集成和发布判断；本代理至此停止。
