# 重复派生/重fixture/早检核查与P1修复

Human授权：先检查前一盘点2、3、4项，子代理并行确认并修复图中P1。暂不推进checkpoint/source-CI第一项，不做前端/封装、release/main或merge。已有PR139 Draft e939/basec80；保持主11c3b57、用户config/AGENTS及所有旧失败/证据。

分工与边界：

- P1 agent：Profile=有界SourceClosure安全修复，Skills=[]；输入为图示review、PR139源码/直接test、历史P1审查和原hash；允许写PR139 worktree内 provider_source_closure.py、test_provider_source_closure.py，另本assessment/p1/。先双Python最小注入复现，再修wrapper捕获builtins身份，保留code/globals/closure/wrapped及历史primitive guard。回归须正常递归repr接受、篡改builtins/id拒绝且不调用恶意对象。最多两实现/测试文件+stdlib直接wrapper；不改其他边界、push、stage或merge。保存分阶段hash/raw，独立复核由root另派。
- P2 performance agent：Profile=只读重复源码派生分段测量，Skills=[]；使用隔离的固定e939 performance worktree（与P1编辑隔离），此前账证/repeated-work报告、provider_binding及直接closures/helpers，最多6源码文件。写仅本assessment/derivation/及临时fixture，禁止改源码/测试/CI。挑一项具名真实正例，可做一次有界observer执行；保留原assertions。observer不得替换产品函数/code/global身份，只记录具名函数聚合计时/次数、不存参数。没有未插桩基线配对则不能称提速。最多一次真实case、一次tiny计时校准，不跑整module/full，工具失败先报告不自动重跑。
- P3 performance agent：Profile=重fixture与反例编排测量，Skills=[]；同固定performance worktree、具名graph v1.2 helper/fixture及cost账证，最多6源码文件。写仅本assessment/fixture/和独立temp fixture。挑一项包含合法baseline和反例的真实case，一次有界observer执行，分清class/producer/attack/cold，保留所有断言。不得缓存运行输出/授权/凭据账本，不修改产品函数以逃过source身份检查；不重复P2所选case，双方先报告选择。最多一次真实case，不跑整suite；如数据支持输入seed/编排优化，提交候选设计与需保留边界，先不擅改源。
- Root：Profile=CI早期小检查与集成，Skills=[]；第4项检查当前跨版本早检路线与已有短guard，准备最小局部3.13 probe方案；先完成P1独立review、必要相关回归、文档/archive/plan/gov及PR139快进发布。性能修改不混入P1；测量若有可证的低影响优化则在独立候选分支/PR推进，而非降低质量或删必要反例。检查最新base/run身份，0手动重复full。共享memory fresh-read仅本任务条目、Issue87现有阶段更新，不增流水comment。

Artifact provenance：新目录/新hash对应新观察；旧e939与所有失败不重签，保留capture-gap。如无法完整捕获transport trace，明确报告而不声称完整Agent Trace。停止点为P1修复可审与2/3/4实际检查结果；不擅自Ready或merge。
