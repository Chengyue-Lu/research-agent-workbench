# Local repository diagnostic for failed full

LOCAL_REPOSITORY_REPLAY_PASS_NOT_HOSTED_GATE. This is one local read-only checker replay, not hosted Gate PASS.

Run 37189042708 / attempt 1 / head 84ded7c5aba5872bbb273d429289aba288c9a8aa; all current source/policy/checker bytes equal git84. Authenticated artifact inputs and unchanged post-read hashes are recorded in inputs.json.

Enforce calls impact_coverage first (ci_checks.py line [188]). Its actual uncovered-changed-lines exception prevented the repository checker subprocess (line [59, 191]).

Repository checker return code: 0; global line=94.38% threshold=90.00%. Original argv/stdout/stderr hashes are preserved in checker-command.json.

The original checker checks all critical 95/90 thresholds, branch collection, positive/negative mappings and exact exclusions, as well as global source line 90. This replay does not re-execute impact checking or tests.

| Physical lane | Native wall s | Method sum s | Native unallocated s | API execution step s | API job s |
|---|---:|---:|---:|---:|---:|
| 3.11_coverage_producer | 4542.140703 | 3515.219896 | 1026.920807 | 4550 | 4572 |
| 3.13_full | 2490.442436 | 1932.548263 | 557.894173 | 2491 | 2507 |

Authorized budget methods (recorded seconds only):

- 3.11_coverage_producer: tests/test_provider_binding_graph.py::ProviderBindingGraphTests.test_v12_cold_replay_rejects_helper_source_drift_without_provider_reuse = 69.780038s; actual execution index 1479.
- 3.11_coverage_producer: tests/test_provider_binding_graph.py::ProviderBindingGraphTests.test_v12_rehashed_use_facts_require_exact_source_closure_per_invocation = 71.693390s; actual execution index 1480.
- 3.13_full: tests/test_provider_binding_graph.py::ProviderBindingGraphTests.test_v12_cold_replay_rejects_helper_source_drift_without_provider_reuse = 38.679543s; actual execution index 1479.
- 3.13_full: tests/test_provider_binding_graph.py::ProviderBindingGraphTests.test_v12_rehashed_use_facts_require_exact_source_closure_per_invocation = 39.273607s; actual execution index 1480.

Limits:

- Local replay diagnoses the old failed run; it does not turn the hosted Enforce or aggregate failures into PASS.
- Each Python lane is a separate recorded observation; no matched old/new performance pair or speedup is claimed.
- Method records are duration sorted; execution_index uses only execution_order.
- Native wall, API execution-step elapsed and whole-job elapsed differ; every subtraction residual remains unallocated.
- API timestamps have second resolution; no setup attribution, budget clock or budget margin is inferred.
- Current source/policy/checkers equal git84; locally added tests are not inputs to this replay.
