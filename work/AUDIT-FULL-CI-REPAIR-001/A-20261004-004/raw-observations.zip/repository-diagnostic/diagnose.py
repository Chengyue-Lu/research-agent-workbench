"""One authorized local repository-policy replay plus authenticated-run arithmetic."""
from __future__ import annotations

import ast
from datetime import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys


OUT = Path(__file__).resolve().parent
ASSESSMENT = OUT.parent
NATIVE = ASSESSMENT / "full-failure-native"
WT = Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004")
HEAD = "84ded7c5aba5872bbb273d429289aba288c9a8aa"
IDENTITY = {
    "run": 37189042708, "attempt": 1, "head": HEAD,
    "base": "c80ec014925f0cbbbaef5486bce8422a5b4f73fb",
    "target": "787aea3e2adca8bc671d8cca3d23ec08ba4bad35",
    "plan_id": "70faacdbe652b3498f6567bb31085fb7d3539d9001d2dbf26a0731a778ed50b1",
}
SUMMARY_SHA = "d89f9c5c099d309e7dc06fd8b60e6b1e8c95f440bf2bae50502060ce627d102c"
JOBS_SHA = "3ec7935b220ab7178fa87ffee5802ab0b5a321ce2cc35d5dea080901fbc28766"
SOURCES = {
    "src/research_workbench/adapters/models/provider_source_closure.py": "c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3",
    "tests/coverage_policy.yaml": "05a47de90603c30db301232a8828971cbaeb003b7381dd293d3a464260c8f6fc",
    ".github/scripts/check_coverage_policy.py": "f67b7abae68812260733ba1694a737c6d745a0194a17026f5147686239a5264a",
    ".github/scripts/ci_checks.py": "d1ef2da6a92be90b9d91e3c31a02198dba41b3e52e493703be0dfa4e3fb3cba6",
}
BUDGET_CASES = (
    "tests/test_provider_binding_graph.py::ProviderBindingGraphTests.test_v12_cold_replay_rejects_helper_source_drift_without_provider_reuse",
    "tests/test_provider_binding_graph.py::ProviderBindingGraphTests.test_v12_rehashed_use_facts_require_exact_source_closure_per_invocation",
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def bound(path, expected, watched):
    raw = path.read_bytes()
    require(sha(raw) == expected, "Input hash differs: " + str(path))
    watched.append((path, expected))
    return raw, {"path": str(path), "sha256": expected, "bytes": len(raw)}


def elapsed(start, end):
    return (datetime.fromisoformat(end.replace("Z", "+00:00")) - datetime.fromisoformat(start.replace("Z", "+00:00"))).total_seconds()


def lane(data, job, step_name, binding):
    order = data["execution_order"]
    rows = data["tests"]
    by_id = {row["canonical_id"]: row for row in rows}
    require(len(order) == len(set(order)) == len(rows) == len(by_id) == data["test_count"] and set(order) == set(by_id), "Native inventory differs")
    require(data["schema_version"] == "1.2.0" and data["successful"] is True and data["target"] == IDENTITY["target"] and data["plan_id"] == IDENTITY["plan_id"], "Native identity differs")
    durations = []
    for row in rows:
        value = row["duration_seconds"]
        require(row["outcome"] == "passed" and type(value) in (int, float) and math.isfinite(value) and value >= 0, "Invalid recorded interval")
        durations.append(value)
    total = math.fsum(durations)
    wall = data["wall_seconds"]
    require(type(wall) in (int, float) and math.isfinite(wall) and wall >= 0, "Invalid native wall")
    matching_steps = [step for step in job["steps"] if step["name"] == step_name]
    require(len(matching_steps) == 1 and matching_steps[0]["conclusion"] == "success", "Actual execution step unavailable")
    step = matching_steps[0]
    step_seconds = elapsed(step["started_at"], step["completed_at"])
    job_seconds = elapsed(job["started_at"], job["completed_at"])
    selected = []
    for identity in BUDGET_CASES:
        require(identity in by_id, "Budget method absent; absence is not zero: " + identity)
        row = by_id[identity]
        selected.append({"canonical_id": identity, "observed_id": row["id"], "recorded_seconds": row["duration_seconds"], "outcome": row["outcome"], "execution_index": order.index(identity) + 1})
    return {
        "source": binding, "schema_version": data["schema_version"], "suite": data["suite"], "python_version": data["python_version"],
        "test_count": data["test_count"], "execution_order_sha256": sha(json.dumps(order, ensure_ascii=False, separators=(",", ":")).encode("utf-8")),
        "native_wall_seconds": wall, "sum_recorded_method_seconds": total,
        "native_wall_minus_method_sum_unallocated_seconds": wall - total,
        "API_execution_step": {"name": step_name, "number": step["number"], "started_at": step["started_at"], "completed_at": step["completed_at"], "elapsed_seconds": step_seconds},
        "execution_step_minus_method_sum_unallocated_seconds": step_seconds - total,
        "API_job": {"id": job["id"], "name": job["name"], "conclusion": job["conclusion"], "elapsed_seconds": job_seconds},
        "job_elapsed_minus_method_sum_unallocated_seconds": job_seconds - total,
        "budget_methods": selected, "budget_clock_or_margin_inferred": False,
    }


def main():
    require(not (OUT / "checker-command.json").exists(), "One-shot replay already recorded; do not rerun")
    watched = []
    raw, summary_binding = bound(NATIVE / "summary.json", SUMMARY_SHA, watched)
    summary = json.loads(raw)
    require(summary["status"] == "PARTIAL_NATIVE_EXECUTION_PASS_QUALITY_GATE_FAIL" and all(summary[key] == value for key, value in IDENTITY.items()), "Failed-run identity differs")
    source_bindings = []
    for relative, expected in SOURCES.items():
        raw, binding = bound(WT / relative, expected, watched)
        git_argv = ["git", "show", HEAD + ":" + relative]
        result = subprocess.run(git_argv, cwd=WT, capture_output=True)
        require(result.returncode == 0 and result.stdout == raw, "Current input is not byte equal to git84: " + relative)
        binding.update({"git84_sha256": sha(result.stdout), "byte_equal_to_git84": True, "identity_read_argv": git_argv})
        source_bindings.append(binding)
    native_bindings = {}
    native_data = {}
    for record in summary["native_member_bindings"]:
        raw, binding = bound(NATIVE / record["path"], record["sha256"], watched)
        require(len(raw) == record["bytes"], "Native member size differs")
        native_bindings[record["path"]] = binding
        native_data[record["path"]] = json.loads(raw)
    raw, jobs_binding = bound(NATIVE / "jobs.json", JOBS_SHA, watched)
    jobs = json.loads(raw)["jobs"]
    coverage_relative = "artifact-11299741295/coverage.json"
    c_relative = "artifact-11299741295/coverage-test-results.json"
    producer_relative = "artifact-11299741295/execution-test-results.json"
    full313_relative = "artifact-11298867864/full-test-results-3.13.json"
    require(native_data[c_relative]["suite"] == "coverage-quality" and native_data[c_relative]["successful"] is True, "C projection is not successful coverage-quality evidence")
    checker = WT / ".github/scripts/check_coverage_policy.py"
    argv = [sys.executable, "-B", "-X", "utf8", str(checker), "--policy", str(WT / "tests/coverage_policy.yaml"), "--coverage", str(NATIVE / coverage_relative), "--test-results", str(NATIVE / c_relative)]
    write("inputs.json", {"identity": IDENTITY, "failed_native_summary": summary_binding, "sources": source_bindings, "native_members": list(native_bindings.values()), "jobs": jobs_binding})
    environment = dict(os.environ)
    environment.pop("PYTHONPATH", None)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(argv, cwd=WT, env=environment, capture_output=True)
    (OUT / "checker.stdout.raw").write_bytes(result.stdout)
    (OUT / "checker.stderr.raw").write_bytes(result.stderr)
    command = {"argv": argv, "cwd": str(WT), "returncode": result.returncode, "invocations": 1,
               "stdout": {"path": "checker.stdout.raw", "sha256": sha(result.stdout), "bytes": len(result.stdout)},
               "stderr": {"path": "checker.stderr.raw", "sha256": sha(result.stderr), "bytes": len(result.stderr)},
               "interpreter_version": sys.version, "environment_parameters_or_credentials_recorded": False}
    write("checker-command.json", command)
    stdout = result.stdout.decode("utf-8", errors="replace")
    repository_pass = result.returncode == 0 and "coverage-policy: PASS" in stdout
    cost = {}
    for label, relative, job_name, step_name in (
        ("3.11_coverage_producer", producer_relative, "coverage-quality (3.11)", "Run ordered behavior and coverage-only cases once"),
        ("3.13_full", full313_relative, "compatibility (3.13)", "Run selected compatibility suite"),
    ):
        matching_jobs = [job for job in jobs if job["name"] == job_name]
        require(len(matching_jobs) == 1, "Actual execution job unavailable")
        cost[label] = lane(native_data[relative], matching_jobs[0], step_name, native_bindings[relative])
    tree = ast.parse((WT / ".github/scripts/ci_checks.py").read_bytes())
    impact_lines = [node.lineno for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "impact_coverage"]
    repository_lines = [node.lineno for node in ast.walk(tree) if isinstance(node, ast.Constant) and node.value == ".github/scripts/check_coverage_policy.py"]
    for path, expected in watched:
        require(sha(path.read_bytes()) == expected, "Input changed during diagnosis: " + str(path))
    payload = {
        "status": "LOCAL_REPOSITORY_REPLAY_PASS_NOT_HOSTED_GATE" if repository_pass else "LOCAL_REPOSITORY_REPLAY_FAIL_NOT_HOSTED_GATE",
        "identity": IDENTITY, "repository_checker_local_pass": repository_pass, "hosted_quality_gate_pass": False, "overall_run_conclusion": "failure",
        "checker": command, "input_receipt": "inputs.json", "current_inputs_byte_equal_git84": True,
        "actual_hosted_first_failure": "impact uncovered changed lines; impact_coverage raises before repository subprocess",
        "ci_checks_source_lines": {"impact_call": impact_lines, "repository_checker_path": repository_lines},
        "checker_scope": ["branch collection enabled", "global source line >=90", "every declared critical line >=95 / branch >=90", "exact declared-vs-actual exclusions", "coverage-quality successful", "all declared positive/negative passing IDs", "critical acceptance mapping"],
        "stdout_global_summary": [line for line in stdout.splitlines() if line.startswith("global line=")],
        "stdout_failure_lines": [line for line in stdout.splitlines() if line.startswith("- ")],
        "cost_observations": cost, "API": 0, "downloads": 0, "tests": 0, "producer_execution": 0, "repository_checker_invocations": 1,
        "success_only_cost_extractor_called": False,
        "limits": ["Local replay diagnoses the old failed run; it does not turn the hosted Enforce or aggregate failures into PASS.", "Each Python lane is a separate recorded observation; no matched old/new performance pair or speedup is claimed.", "Method records are duration sorted; execution_index uses only execution_order.", "Native wall, API execution-step elapsed and whole-job elapsed differ; every subtraction residual remains unallocated.", "API timestamps have second resolution; no setup attribution, budget clock or budget margin is inferred.", "Current source/policy/checkers equal git84; locally added tests are not inputs to this replay."],
    }
    write("summary.json", payload)
    lines = ["# Local repository diagnostic for failed full", "", payload["status"] + ". This is one local read-only checker replay, not hosted Gate PASS.", "",
             "Run 37189042708 / attempt 1 / head " + HEAD + "; all current source/policy/checker bytes equal git84. Authenticated artifact inputs and unchanged post-read hashes are recorded in inputs.json.", "",
             "Enforce calls impact_coverage first (ci_checks.py line " + str(impact_lines) + "). Its actual uncovered-changed-lines exception prevented the repository checker subprocess (line " + str(repository_lines) + ").", "",
             "Repository checker return code: " + str(result.returncode) + "; " + "; ".join(payload["stdout_global_summary"]) + ". Original argv/stdout/stderr hashes are preserved in checker-command.json.", "",
             "The original checker checks all critical 95/90 thresholds, branch collection, positive/negative mappings and exact exclusions, as well as global source line 90. This replay does not re-execute impact checking or tests.", "",
             "| Physical lane | Native wall s | Method sum s | Native unallocated s | API execution step s | API job s |", "|---|---:|---:|---:|---:|---:|"]
    for label, values in cost.items():
        lines.append(f"| {label} | {values['native_wall_seconds']:.6f} | {values['sum_recorded_method_seconds']:.6f} | {values['native_wall_minus_method_sum_unallocated_seconds']:.6f} | {values['API_execution_step']['elapsed_seconds']:.0f} | {values['API_job']['elapsed_seconds']:.0f} |")
    lines.extend(["", "Authorized budget methods (recorded seconds only):", ""])
    for label, values in cost.items():
        for method in values["budget_methods"]:
            lines.append(f"- {label}: {method['canonical_id']} = {method['recorded_seconds']:.6f}s; actual execution index {method['execution_index']}.")
    lines.extend(["", "Limits:", ""] + ["- " + item for item in payload["limits"]])
    if payload["stdout_failure_lines"]:
        lines.extend(["", "Actual local checker failures:", ""] + payload["stdout_failure_lines"])
    (OUT / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"status": payload["status"], "checker_returncode": result.returncode, "global": payload["stdout_global_summary"], "failures": payload["stdout_failure_lines"], "cost": cost, "summary_sha256": sha((OUT / "summary.json").read_bytes())}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
