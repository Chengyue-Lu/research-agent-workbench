"""Prepare hashes/immutable snapshots only; never creates the WT A004 archive."""
from pathlib import Path
from datetime import datetime, timezone
import importlib.util
import json

PREP = Path(__file__).resolve().parent
ROOT = PREP.parent
helper_path = PREP / "prepare_commit.py"
compile(helper_path.read_bytes(), str(helper_path), "exec")
spec = importlib.util.spec_from_file_location("a004_static_preparation", helper_path)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
assert helper.git("rev-parse", "HEAD").decode().strip() == helper.HEAD
assert helper.sha((helper.WT / helper.SOURCE).read_bytes()) == helper.SOURCE_SHA
assert helper.sha((helper.WT / helper.TEST).read_bytes()) == helper.TEST_SHA
assert not (helper.WT / helper.ARCHIVE_REL).exists()
diff = helper.git("diff", "--", *helper.OWNED)
(PREP / "candidate.diff").write_bytes(diff)
doc_snapshots = []
for name in helper.OWNED[1:]:
    snapshot = PREP / (("README" if name.endswith("/README.md") else "RISK_LEDGER") + ".workstream-snapshot.md")
    snapshot.write_bytes((helper.WT / name).read_bytes())
    doc_snapshots.append(snapshot.relative_to(ROOT).as_posix())
review = json.loads((ROOT / "coverage-tests-review/summary.json").read_bytes())
assert review["old_methods"]["count"] == 23 and not review["old_methods"]["body_differences"]
inspection = {
    "schema": "a004-test-only-static-preparation-v1", "at": datetime.now(timezone.utc).isoformat(),
    "parent": helper.HEAD, "source_sha256": helper.SOURCE_SHA, "test_sha256": helper.TEST_SHA,
    "source_byte_equal_parent": helper.sha(helper.git("show", "HEAD:" + helper.SOURCE)) == helper.SOURCE_SHA,
    "owned_commit_paths": list(helper.OWNED) + [helper.ARCHIVE_REL + "/"],
    "old23_retained": "independent static review exact body comparison, no new test execution",
    "new_methods": 6, "git_diff_sha256": helper.sha(diff),
    "userfiles_unmodified_by_packager": True,
    "source_input_reads": "Only delegated assessment evidence, two owned workdocs/current test diff, old A003 format; additional data bytes hashed only",
    "tests": 0, "producer": 0, "API": 0, "downloads": 0, "stage_commit_push": 0,
    "freeze_executed": False,
}
helper.save(PREP / "STATIC_INSPECTION.json", inspection)
groups = {
    "full-failure-native": "original frozen failed full; 33 authenticated entries plus original manifest",
    "full-plan": "cached official plan authentication and binding",
    "source-review": "scoped product source static review",
    "checkpoint-review": "scoped checkpoint contract static review",
    "coverage-gap-review": "initial coverage design static review; its old test snapshot not final74 authority",
    "local-gap311": "initial311 c9 snapshot:29 selected/27PASS/2fixture errors",
    "local-gap311-repair": "repaired311 final74 snapshot:only two failed fixture methods rerun PASS",
    "local-gap313": "final313 final74 snapshot:29 methods once PASS",
    "coverage-tests-review": "independent final74 static review:old23 preserved/no new execution",
    "repository-diagnostic": "one original artifact repository checker replay, not hosted Gate",
}
rows = []
for directory, role in groups.items():
    folder = ROOT / directory
    assert folder.is_dir()
    for path in sorted(folder.rglob("*")):
        if path.is_file():
            relative = path.relative_to(ROOT).as_posix()
            helper.evidence_path(relative)
            raw = path.read_bytes()
            rows.append({"path": relative, "bytes": len(raw), "sha256": helper.sha(raw), "role": role})
extra = ["local-gap-summary.json", "local-gap311-coverage.json", "local-gap311.coverage",
         "archive-preparation/prepare_commit.py", "archive-preparation/prepare_selection.py",
         "archive-preparation/candidate.diff", "archive-preparation/STATIC_INSPECTION.json",
         "archive-preparation/README.template.md", "archive-preparation/CAPTURE.template.json", *doc_snapshots]
for relative in extra:
    raw = helper.evidence_path(relative).read_bytes()
    rows.append({"path": relative, "bytes": len(raw), "sha256": helper.sha(raw),
                 "role": "immutable preparation snapshot" if relative.startswith("archive-preparation/") else "local coverage-gap evidence, not hosted Gate"})
history = []
for name in ("A-20261004-001", "A-20261004-002", "A-20261004-003"):
    folder = helper.WT / "work/AUDIT-FULL-CI-REPAIR-001" / name
    assert folder.is_dir()
    for path in sorted(folder.rglob("*")):
        if path.is_file():
            raw = path.read_bytes()
            history.append({"path": path.relative_to(helper.WT).as_posix(), "bytes": len(raw), "sha256": helper.sha(raw)})
source = [{"path": path, "sha256": helper.sha((helper.WT / path).read_bytes())}
          for path in (helper.SOURCE, *helper.OWNED)]
selection = {
    "schema": "a004-immutable-evidence-selection-v1", "parent": helper.HEAD, "base": helper.BASE,
    "archive": helper.ARCHIVE_REL, "source": source, "script_sha256": helper.sha(helper_path.read_bytes()),
    "files": rows, "historical_archive_files": history,
    "ready_to_freeze": False,
    "root_review": {"independent_test_review_checked": False, "repository_diagnostic_checked": False,
        "independent_test_review_summary_sha256": helper.sha((ROOT / "coverage-tests-review/summary.json").read_bytes()),
        "repository_diagnostic_summary_sha256": helper.sha((ROOT / "repository-diagnostic/summary.json").read_bytes())},
    "excluded": ["all active followup root PLAN/REPORT/publication/live/full-watch files", "future hosted results",
        "success-only native-tools/cost-tools execution evidence (not run)", "other-owner content", "secrets and hidden reasoning"],
    "freeze_boundary": "Root must inspect review/diagnostic, mark these three booleans true, and pass exact resulting selection SHA with explicit --freeze --root-approved; no git stage/commit/push is performed",
}
helper.save(PREP / "evidence-selection.json", selection)
helper.save(PREP / "RAW_INDEX.preview.json", {"kind": "A004 necessary immutable evidence preview, not an archive", "files": rows,
    "raw_files": len(rows), "raw_bytes": sum(row["bytes"] for row in rows),
    "future_selection_member": "Final root-approved evidence-selection.json is added only at future freeze", "freeze_executed": False})
print(json.dumps({"selection_sha256": helper.sha((PREP / "evidence-selection.json").read_bytes()),
    "script_sha256": helper.sha(helper_path.read_bytes()), "raw_files": len(rows), "raw_bytes": sum(row["bytes"] for row in rows),
    "historical_files_unchanged_bound": len(history), "ready_to_freeze": False, "WT_archive_exists": False,
    "tests": 0, "API": 0, "producer": 0}, ensure_ascii=False))
