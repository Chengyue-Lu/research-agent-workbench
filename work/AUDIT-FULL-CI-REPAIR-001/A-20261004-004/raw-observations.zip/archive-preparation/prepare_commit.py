"""Freeze only selected immutable A004 evidence after root's explicit approval.

Static checks/importing this script never executes tests, producers, API or ZIP
freeze. The future --freeze path writes only the new requested WT A004 archive.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import re
import subprocess
import zipfile

ASSESSMENT = Path(__file__).resolve().parents[1]
PREPARATION = Path(__file__).resolve().parent
WT = Path("D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004")
HEAD = "84ded7c5aba5872bbb273d429289aba288c9a8aa"
BASE = "c80ec014925f0cbbbaef5486bce8422a5b4f73fb"
SOURCE = "src/research_workbench/adapters/models/provider_source_closure.py"
TEST = "tests/test_provider_source_closure.py"
SOURCE_SHA = "c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3"
TEST_SHA = "74b882411f9fdb72d37734e3503cb6ccb13b708f3c2e400532dce61c8f26d94f"
OWNED = (TEST, "docs/workstreams/chengyue-lu/FULL-CI-REPAIR-001/README.md",
         "docs/workstreams/chengyue-lu/FULL-CI-REPAIR-001/RISK_LEDGER.md")
ARCHIVE_REL = "work/AUDIT-FULL-CI-REPAIR-001/A-20261004-004"
ALLOWED_DIRS = {"full-failure-native", "full-plan", "source-review", "checkpoint-review",
                "coverage-gap-review", "local-gap311", "local-gap311-repair", "local-gap313",
                "coverage-tests-review", "repository-diagnostic", "archive-preparation"}
ALLOWED_ROOT_FILES = {"local-gap-summary.json", "local-gap311-coverage.json", "local-gap311.coverage"}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

def git(*args):
    return subprocess.check_output(["git", "-C", str(WT), *args])

def git_normalized_bytes_equal(path):
    relative = path.relative_to(WT).as_posix()
    attribute = git("check-attr", "filter", "--", relative).decode().strip()
    assert attribute.endswith(": unspecified") or attribute.endswith(": unset"), "archive clean filter not authorized"
    raw = path.read_bytes()
    plain = subprocess.check_output(["git", "-C", str(WT), "hash-object", "--no-filters", "--stdin"], input=raw)
    normalized = subprocess.check_output(["git", "-C", str(WT), "hash-object", "--path=" + relative, "--stdin"], input=raw)
    assert plain == normalized, "Git normalization would change archive bytes: " + relative
    if path.suffix in {".json", ".md"}:
        raw.decode("utf-8")
        assert not raw.startswith(b"\xef\xbb\xbf") and b"\r" not in raw

def evidence_path(relative):
    p = Path(relative)
    assert not p.is_absolute() and p.parts and ".." not in p.parts
    assert p.parts[0] in ALLOWED_DIRS or relative in ALLOWED_ROOT_FILES
    path = (ASSESSMENT / p).resolve()
    assert path.is_relative_to(ASSESSMENT) and path.is_file() and not path.is_symlink()
    return path

def json_evidence(relative):
    return json.loads(evidence_path(relative).read_bytes())

def high_confidence_secret_types(raw):
    # Only recognisable credential forms, never emit matched values. Fixtures,
    # variable names and masked GitHub logs are not broad keyword warnings.
    patterns = {"github_classic_token": rb"gh[pousr]_[A-Za-z0-9]{36,}",
                "github_fine_grained_token": rb"github_pat_[A-Za-z0-9_]{60,}",
                "private_key_block": rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"}
    return [name for name, pattern in patterns.items() if re.search(pattern, raw)]

def check(selection):
    assert git("rev-parse", "HEAD").decode().strip() == HEAD
    assert sha((WT / SOURCE).read_bytes()) == SOURCE_SHA
    assert sha(git("show", "HEAD:" + SOURCE)) == SOURCE_SHA
    assert not git("diff", "--", SOURCE).strip()
    assert sha((WT / TEST).read_bytes()) == TEST_SHA
    assert selection["parent"] == HEAD and selection["base"] == BASE
    assert selection["script_sha256"] == sha(Path(__file__).read_bytes())
    for name in ("README.template.md", "CAPTURE.template.json"):
        raw = (PREPARATION / name).read_bytes()
        raw.decode("utf-8")
        assert not raw.startswith(b"\xef\xbb\xbf") and b"\r" not in raw
    paths = [row["path"] for row in selection["files"]]
    assert len(paths) == len(set(paths))
    total_bytes = 0
    for row in selection["files"]:
        raw = evidence_path(row["path"]).read_bytes()
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"], row["path"]
        assert not high_confidence_secret_types(raw), "credential-form marker in " + row["path"]
        total_bytes += len(raw)
    for row in selection["source"]:
        assert sha((WT / row["path"]).read_bytes()) == row["sha256"], row["path"]
    assert git("diff", "--", *OWNED) == evidence_path("archive-preparation/candidate.diff").read_bytes()
    changed = set(git("diff", "--name-only").decode().splitlines())
    assert changed <= set(OWNED) | {"AGENTS.md", ".codex/config.toml"}
    for row in selection["historical_archive_files"]:
        assert sha((WT / row["path"]).read_bytes()) == row["sha256"], row["path"]

    native_manifest = json_evidence("full-failure-native/MANIFEST.json")
    assert native_manifest["file_count"] == len(native_manifest["files"]) == 33
    assert native_manifest["self_included"] is False
    for row in native_manifest["files"]:
        raw = evidence_path("full-failure-native/" + row["path"]).read_bytes()
        assert sha(raw) == row["sha256"] and len(raw) == row["bytes"]
    failed = json_evidence("full-failure-native/summary.json")
    assert failed["run"] == 37189042708 and failed["attempt"] == 1 and failed["head"] == HEAD
    assert failed["overall_run_conclusion"] == "failure" and failed["quality_gate_pass"] is False
    assert failed["native_outcomes"]["3.13_full"]["test_count"] == 2042
    assert failed["native_outcomes"]["3.11_producer"]["test_count"] == 2042
    assert all(lane["outcomes"]["passed"] == 2042 for lane in failed["native_outcomes"].values())
    assert failed["official_3_11_B_projection"].startswith("ABSENT_")
    full_plan = json_evidence("full-plan/summary.json")
    assert full_plan["run"] == failed["run"] and full_plan["plan_id"] == failed["plan_id"]

    initial = json_evidence("local-gap311/native.json")
    repaired = json_evidence("local-gap311-repair/native.json")
    final313 = json_evidence("local-gap313/native.json")
    assert initial["tests_run"] == 29 and initial["successful"] is False
    assert sum(row["outcome"] == "passed" for row in initial["records"]) == 27
    assert len(initial["errors"]) == 2 and not initial["failures"] and not initial["skipped"]
    assert repaired["tests_run"] == 2 and repaired["successful"] is True
    assert {row["id"] for row in initial["errors"]} == set(repaired["selected"])
    assert all(row["outcome"] == "passed" for row in repaired["records"])
    assert final313["tests_run"] == 29 and final313["successful"] is True
    assert all(row["outcome"] == "passed" for row in final313["records"])
    for data in (initial, repaired, final313):
        assert data["source_before"] == data["source_after"]
        assert data["source_before"][SOURCE] == SOURCE_SHA
    assert repaired["source_before"][TEST] == final313["source_before"][TEST] == TEST_SHA
    gap = json_evidence("local-gap-summary.json")
    assert gap["source_sha256"] == SOURCE_SHA and gap["current_test_sha256"] == TEST_SHA
    assert len(gap["required_lines"]) == 7 and len(gap["required_arcs"]) == 9
    assert not gap["remaining_lines"] and not gap["remaining_arcs"]
    assert gap["new_hosted_gate_pass"] is False
    assert sha(evidence_path("local-gap311-coverage.json").read_bytes()) == gap["local_coverage_sha256"]
    review = json_evidence("coverage-tests-review/summary.json")
    assert review["status"] == "PASS_STATIC_COVERAGE_TEST_REVIEW_NO_NEW_EXECUTION" and review["blockers"] == []
    assert TEST_SHA in json.dumps(review) and SOURCE_SHA in json.dumps(review)
    assert review["old_methods"]["count"] == 23 and review["old_methods"]["body_differences"] == []
    assert review["old_methods"]["all_prior_helper_bodies_except_repr_fixture_unchanged"] is True
    diagnostic = json_evidence("repository-diagnostic/summary.json")
    assert diagnostic["status"] == "LOCAL_REPOSITORY_REPLAY_PASS_NOT_HOSTED_GATE"
    assert diagnostic["repository_checker_local_pass"] is True and diagnostic["hosted_quality_gate_pass"] is False
    assert diagnostic["success_only_cost_extractor_called"] is False
    return {"static_check": "PASS", "files": len(paths), "raw_bytes": total_bytes,
            "native_frozen_entries": 33, "native_manifest_separately_included": True,
            "initial311": {"selected": 29, "passed": 27, "fixture_errors": 2, "test_sha256": initial["source_before"][TEST]},
            "repair311": {"selected": 2, "passed": 2, "test_sha256": TEST_SHA},
            "final313": {"selected": 29, "passed": 29, "test_sha256": TEST_SHA},
            "local_required_gap": {"lines": 7, "arcs": 9, "remaining": 0, "hosted_gate": False},
            "repository_diagnostic": "one cached-artifact local replay PASS, not hosted Gate", "tests": 0, "API": 0,
            "producer": 0, "downloads": 0, "freeze_executed": False}

def freeze(selection, selection_path, expected_selection_sha256):
    assert sha(selection_path.read_bytes()) == expected_selection_sha256
    assert selection["ready_to_freeze"] is True
    assert selection["root_review"]["independent_test_review_checked"] is True
    assert selection["root_review"]["repository_diagnostic_checked"] is True
    assert selection["root_review"]["independent_test_review_summary_sha256"] == sha(evidence_path("coverage-tests-review/summary.json").read_bytes())
    assert selection["root_review"]["repository_diagnostic_summary_sha256"] == sha(evidence_path("repository-diagnostic/summary.json").read_bytes())
    checks = check(selection)
    archive = (WT / ARCHIVE_REL).resolve()
    assert archive.is_relative_to(WT / "work/AUDIT-FULL-CI-REPAIR-001")
    assert not archive.exists()
    archive.mkdir(parents=True, exist_ok=False)
    index = []
    with zipfile.ZipFile(archive / "raw-observations.zip", "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        rows = list(selection["files"]) + [{"path": selection_path.relative_to(ASSESSMENT).as_posix(),
                                           "bytes": selection_path.stat().st_size, "sha256": expected_selection_sha256,
                                           "role": "root-approved frozen evidence selection"}]
        for row in rows:
            raw = evidence_path(row["path"]).read_bytes()
            assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
            bundle.writestr(row["path"], raw)
            index.append(row)
    save(archive / "RAW_INDEX.json", {"kind": "test_only_coverage_gap_followup_scoped_evidence", "files": index,
          "failed_full_run": 37189042708, "failed_full_head": HEAD, "selection_sha256": expected_selection_sha256})
    capture = json.loads((PREPARATION / "CAPTURE.template.json").read_bytes())
    capture.update({"at": datetime.now(timezone.utc).isoformat(), "source": selection["source"],
                    "selection_sha256": expected_selection_sha256, "prepare_script_sha256": selection["script_sha256"],
                    "root_review": selection["root_review"], "static_checks": checks})
    save(archive / "CAPTURE.json", capture)
    (archive / "README.md").write_bytes((PREPARATION / "README.template.md").read_bytes())
    with zipfile.ZipFile(archive / "raw-observations.zip") as bundle:
        assert bundle.testzip() is None
        assert set(bundle.namelist()) == {row["path"] for row in index}
        for row in index:
            raw = bundle.read(row["path"])
            assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
    save(archive / "MANIFEST.json", {"kind": "compact_evidence_index", "self_included": False,
        "files": [{"path": path.name, "bytes": path.stat().st_size, "sha256": sha(path.read_bytes())}
                  for path in sorted(archive.iterdir())]})
    assert {path.name for path in archive.iterdir()} == {"README.md", "CAPTURE.json", "RAW_INDEX.json", "MANIFEST.json", "raw-observations.zip"}
    for path in archive.iterdir():
        git_normalized_bytes_equal(path)
    for row in selection["historical_archive_files"]:
        assert sha((WT / row["path"]).read_bytes()) == row["sha256"]
    assert sha((WT / SOURCE).read_bytes()) == SOURCE_SHA and sha((WT / TEST).read_bytes()) == TEST_SHA
    print(json.dumps({"archive": archive.as_posix(), "raw_members": len(index), "zip_bytes": (archive / "raw-observations.zip").stat().st_size,
                      "manifest_sha256": sha((archive / "MANIFEST.json").read_bytes()), "tests": 0, "API": 0, "producer": 0,
                      "stage_commit_push": 0, "old_archives_unchanged": True}))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--selection", type=Path, default=PREPARATION / "evidence-selection.json")
    parser.add_argument("--static-check", action="store_true")
    parser.add_argument("--receipt", type=Path)
    parser.add_argument("--freeze", action="store_true")
    parser.add_argument("--root-approved", action="store_true")
    parser.add_argument("--expected-selection-sha256")
    args = parser.parse_args()
    selection_path = args.selection.resolve()
    assert selection_path.is_relative_to(PREPARATION) and selection_path.is_file()
    selection = json.loads(selection_path.read_bytes())
    assert args.static_check != args.freeze, "choose static-check or explicit root-approved freeze"
    if args.freeze:
        assert args.root_approved and args.expected_selection_sha256, "explicit root approval and exact selection SHA required"
        freeze(selection, selection_path, args.expected_selection_sha256)
    else:
        result = check(selection)
        result.update({"selection_sha256": sha(selection_path.read_bytes()), "script_sha256": sha(Path(__file__).read_bytes()),
                       "ready_to_freeze": selection["ready_to_freeze"]})
        if args.receipt:
            receipt = args.receipt.resolve()
            assert receipt.is_relative_to(PREPARATION)
            save(receipt, result)
        print(json.dumps(result, ensure_ascii=False))

if __name__ == "__main__":
    main()
