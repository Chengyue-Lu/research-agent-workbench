# 必要测试缺口静态复核

结论：`PASS_STATIC_GAP_DESIGN_NOT_EXECUTED`，`blockers=[]`。这里确认必要测试设计与当前真实契约相符；没有实现或运行测试，没有宣称缺口已覆盖或质量 Gate 已修复。

认证输入：run `37189042708` / head `84ded7c5aba5872bbb273d429289aba288c9a8aa` / base `c80ec014925f0cbbbaef5486bce8422a5b4f73fb` / target `787aea3e2adca8bc671d8cca3d23ec08ba4bad35` / plan `70faacdbe652b3498f6567bb31085fb7d3539d9001d2dbf26a0731a778ed50b1`。源码 `src/research_workbench/adapters/models/provider_source_closure.py` 冻结 SHA-256 `c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3`，复核前后不变；现有测试复核快照为 `52c10a34efbf80fce3829eec77a950f43e73e9a9f97826d2ff5c7d9e01bce96a`，封存时当前测试 SHA 为 `c9da9959e1f8269bc7e8d12c905f77a73cf391006bfd277a9d3f8afa9227c77f`。

认证原生 coverage JSON SHA `83afca5d4138b2bdce35460d470eea4d84053b5aebb3dd7886d85f30505a666b`，gap 元数据 SHA `ade5ed51843cb215462249c39689c91087c0bb06e708596597e49594e86d4475`。只使用此源字段中正式 plan 必需缺口：行 `76,99,701,707,710,712,719`；arcs `75→76,98→99,561→560,700→701,705→707,707→703,707→710,711→712,718→719`。先前 reprlib 猜测只能解释其中一部分；其他缺口没有扩大到全部 52 个 missing 行。

| 真实行为夹具 | 必须断言 | 预计必要行/arc |
|---|---|---|
| 过级相对导入，source 首行 raise sentinel，公共 produce，不预先 import | SourceClosureError relative import leaves declared package；sentinel 未执行 | 76 / 75→76 |
| 星号导入，同样 source sentinel 和公共 produce | SourceClosureError star imports are outside closed alias policy；sentinel 未执行 | 99 / 98→99 |
| lower_one=lower_two=1 与 POLICY=2 的真实 source 正例 | claims.globals 只含 POLICY；公共 document/read/source verify/loaded verify 保留原结构和真实 FileRef | 561→560 |
| import dataclasses 与 @dataclasses.dataclass，真实 generated inner + reprlib factory | public verify actual_verified；普通 Record(value=1)、自引用 Record(value=...) 行为正确；最终恢复原方法 | 707,710 / 705→707,707→710 |
| 真实 _DataclassParams.repr 暂时为 plain False，原 generated repr 保持 | public verify 必拒 undeclared runtime class callable；不调用负例 repr；恢复参数 | 701 / 700→701 |
| source-defined fake(cls) 调用 dataclasses.dataclass，@fake 的真实类 | 公共 produce 因 generated repr 未获 canonical source decorator 授权而拒绝 | 707,712 / 705→707,707→703,711→712 |
| 真实 reprlib factory 的 fillvalue=不同纯字符串，以及带 __eq__ counter 的 str subclass | 各 labeled subTest public verify 必拒；不调用负例 repr；counter=[] | 719 / 718→719 |

这些是 source-based 预计路径，必须以随后实际覆盖与双 Python 行为验证确认。导入负例由 `_imports` 在公共 produce 的900行处理，而913行才进入 loaded verification；SourceClosureError 而不是 sentinel RuntimeError 是“未导入危险 source”的行为断言。class decorator 检查不执行 AST decorator；source 的 canonical dataclass 声明与现实 generated repr 才能共同获得许可。`from dataclasses import dataclass as fake` 仍是合法 canonical alias，不能用来制造 undeclared 负例。

标准库静态兼容证据：Python3.11.16 reprlib.py:9-34（SHA `264433cc232332db871666b3bb6e4c2cb97b092cb8d5056a45ec2e53daea2b1c`）不设置 `__wrapped__`；其 dataclasses.py:228-244/588-596 使用 legacy wrapper。Python3.13.15 reprlib.py:33（SHA `76003eea30d186a99d125decc9def6ae32c7b389d3db00f91aaf02229bf2714f`）设置 `__wrapped__=user_function`；dataclasses.py:1098-1106 对真实生成 repr 使用 reprlib decorator。因此跨版本 positive 由真实工厂生成 wrapper，只有其 vars 中没有 `__wrapped__` 时补上真实 generated inner 引用；不修改 code/globals/cells/__builtins__，不 mock Python 版本。所有 stdlib/venv 确切路径、哈希和读取段见 summary.json。

现有 tests:198-208 是 native dataclasses wrapper 正例；3.11 不强制进入 reprlib。tests:286-296 的 ordinary/forged negative 可提前拒绝，不证明718分支。tests:210-270 和303-345 原 captured-builtins/metadata 零 callback 保护应完整保留。只补必要行为反例，不改 source、门槛、exclusions、workflow 或固定 Gates。

0 API/下载/测试/collect/coverage采集/产品运行/候选 import/工具入口执行/源码写入。仅写本目录报告与 summary。Root 负责 test-only 实施和真实新验证；本失败 run 不能被重签为新 commit 的 PASS。
