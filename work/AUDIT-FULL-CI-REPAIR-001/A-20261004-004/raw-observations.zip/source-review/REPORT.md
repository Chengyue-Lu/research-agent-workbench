# PR139 每归档 AST 复用：限定正确性复核

结论：PASS_SCOPED_STATIC_NO_NEW_BLOCKER。本轮对 84ded7c5aba5872bbb273d429289aba288c9a8aa 的 c309/52 源码与测试复核，未发现每归档 AST 复用新增的具体语义或信任缺口；无修复建议。本结论限于下述直接实现及声明边界，不认证新 hosted/full/quality gate，也不重签旧测试结果。

Profile=bounded source-closure correctness reviewer；Skills=[]。产品文件未改动，0 tests / test imports / API / producer。当前 HEAD 在开始与结束核对一致；AGENTS/config 的既有用户修改保留。原输入中的 source 简写路径经 filename discovery 定位为 adapters/models 下的真实文件，没有尝试读取不存在的简写路径，也没有读取其他 owner 文件内容。

## 本轮新增核对

| 关注点 | 当前实现的证据与结论 |
|---|---|
| fresh source 与 runtime | [_read_ref](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:575) 每次重新读 bytes、检查大小和 SHA；[_document_archive](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:586) 每次核 compiler/runtime、完整闭图和 source-derived claims，[_claims](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:549) 仍从 raw 独立 compile。[_verify_loaded](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:774) 继续读当前 loaded 文件并核当前 callable/descriptor/builtins/code/closure/defaults、globals、aliases 与 class policies，未将这些状态放入 AST 复用资格。 |
| 两遍独立性 | [loaded 入口](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:857) 先调用 verify_source_closure，随后直接再调用 _document_archive；[归档局部 archive/tree/ClosedSource](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:596) 在每次调用中重建，两个 pass 没有共享 archive、tree、values、claims 或 compiled hashes。[claims equality](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:622) 在每个 pass 独立执行；原 receipt 和异常归一化路径仍存在。 |
| 可执行 metadata 的读取顺序 | [runtime_functions](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:457) 在 class member 扫描前调用精确类型 guard；[_check_dataclass_metadata](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:447) 使用 class-local params/dict/Field 精确类型检查。[_generated_dataclass_repr](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:687) 先核 wrapper/inner 的 canonical builtins 与 metadata 类型，再在 make_dataclass 前核 field name/repr/kw_only 精确原始类型。AST 复用没有缓存这些 runtime metadata，也没有把此局部 guard 扩大宣称为 Python 反射的普遍安全证明。 |
| mutable AST 外泄与语义 | [tree](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:608) 仅进入当前 private archive；lookup/class/annotation/declaration/policy 扫描只读节点并保持 body 次序，未见 AST 写操作或节点进入 public document/receipt。[公共 declarations(raw)](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:443) 仍独立 parse 后返回新节点，其节点不连接内部归档树；[_declarations(tree)](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:433) 只供内部 claims 使用。运行结束后没有全局 AST 或 PASS 缓存。 |

两个新增测试的实际断言与这些边界吻合：[成功后再改源码/运行时](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/tests/test_provider_source_closure.py:103) 先获成功，再改同路径、同字节长度且恢复 mtime 的源内容，以及当前 global/alias，要求 fresh 拒绝；[成功 read 后改 claims/compiler](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/tests/test_provider_source_closure.py:128) 对重新外层重签的 false claim 与 runtime/optimization 变化要求重派生拒绝。这是本轮对测试源码的静态核对，不是新执行结果。[metadata 零 callback 测试](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/tests/test_provider_source_closure.py:303) 和 [captured builtins 控制](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/tests/test_provider_source_closure.py:210) 的拒绝断言仍存在。

## 范围与证据边界

[RISK_LEDGER 第 15–16 行](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/docs/workstreams/chengyue-lu/FULL-CI-REPAIR-001/RISK_LEDGER.md:15) 对每 pass fresh、独立 claims/compile、局部只读树及未外推内存的声明与本次直接实现一致。此前报告已记录 public declarations 保留、私有 raw-only archive 调用契约与全仓私有消费者的覆盖范围；本轮不扩读 caller 或重复泛化设计。直接 verify_source_closure 调用方仍须自行绑定 document authority，见 [docstring](D:/lcy/develop/_worktrees/RWB/full-ci-repair-20261004/src/research_workbench/adapters/models/provider_source_closure.py:628)。

[local-final-summary](D:/lcy/develop/_assessments/rwb-ci-source-facts-20261004/local-final-summary.json:2) 是既有局部候选验收记录，明示 full_repository_proven=false、quality_gate_proven=false；本次只核其来源绑定及限制。未加载其引用的业务原始日志，未把其 45/23 等数字当成本轮重新执行。没有新的 blocker，不要求额外测试或产品修改；由 root 按当前 PR139 的独立 hosted/full 门禁继续。

## 哈希与读取预算

- source：c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3（52836 bytes）。
- test：52c10a34efbf80fce3829eec77a950f43e73e9a9f97826d2ff5c7d9e01bce96a（23593 bytes）。
- RISK_LEDGER：e557c96685d7ed77f4f0ed07db9c75ab356c7a550879dcb0ab6ce04abcf1e922。
- prior REPORT：4fe64f4bd2b1afcb8016dc3f84e4780e14571f6a9eb7ae60f46cbf8269db13a2。
- local-final-summary：dccf84ec0724fd052e7424a2a1c22e2ed653a3092a59389c368f41f55c7252a1。

共 7 个唯一内容文件、10 次 scoped 内容读取（原 8 次，root 显式允许同两文件各一次窄行补齐），另做既定输入 SHA 元数据核对。源码/测试总输出截断已补齐源码 614–655 与测试 1–137；未扩大文件或 owner 范围。可见工具输出与消息在当前 Codex 任务历史；本报告不是完整 transport transcript/Agent Trace，不捕获隐藏推理、参数或凭据。共享 PROJECT_MEMORY 未写；root 可将本结论与报告链接写入项目摘要。

