"""Verify captured JSON/log relationships; no API or candidate/quality execution."""
import hashlib
import json
import math
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
RUN = 37189042708
HEAD = "84ded7c5aba5872bbb273d429289aba288c9a8aa"
BASE = "c80ec014925f0cbbbaef5486bce8422a5b4f73fb"
TARGET = "787aea3e2adca8bc671d8cca3d23ec08ba4bad35"
PLAN = "70faacdbe652b3498f6567bb31085fb7d3539d9001d2dbf26a0731a778ed50b1"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(name):
    return json.loads((OUT / name).read_bytes())


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    require(not (OUT / "summary.json").exists(), "analysis is one-shot; preserve prior output")
    artifacts = read("authenticated-artifacts.json")
    commands = read("commands.json")
    for command in commands:
        raw = (OUT / command["path"]).read_bytes()
        require(command["returncode"] == 0 and sha(raw) == command["sha256"] and len(raw) == command["bytes"], "raw API capture changed")
    members = {}
    bindings = []
    for artifact in artifacts:
        require(sha((OUT / f"artifact-{artifact['id']}.zip").read_bytes()) == artifact["sha256"], "authenticated ZIP changed")
        for member in artifact["members"]:
            path = OUT / f"artifact-{artifact['id']}" / member["path"]
            raw = path.read_bytes()
            require(sha(raw) == member["sha256"] and len(raw) == member["bytes"], "authenticated member changed")
            members[artifact["name"], member["path"]] = path
            bindings.append({"path": path.relative_to(OUT).as_posix(), "sha256": sha(raw), "bytes": len(raw)})
    def native(name, file, suite, python, projection=False):
        path = members[name, file]
        data = json.loads(path.read_bytes())
        require(data["schema_version"] == "1.2.0" and data["suite"] == suite and data["successful"] is True, "native execution header differs")
        require(data["plan_id"] == PLAN and data["target"] == TARGET and data["coverage_obligations"] == ["impact", "repository"]
                and data["python_version"].startswith(python + "."), "native identity/Python differs")
        rows, order = data["tests"], data["execution_order"]
        ids = [row["canonical_id"] for row in rows]
        require(len(ids) == len(set(ids)) == len(order) == len(set(order)) == data["test_count"] and set(ids) == set(order), "native inventory is incomplete/duplicate")
        require(all(row["outcome"] == "passed" and type(row["duration_seconds"]) in (int, float)
                    and math.isfinite(row["duration_seconds"]) and row["duration_seconds"] >= 0
                    and all(point["outcome"] == "passed" for point in row["checkpoints"]) for row in rows), "native case/checkpoint failure")
        if not projection:
            require(data["events"] == {"errors": 0, "failures": 0, "skips": 0} and not data["problems"], "native lifecycle failure")
            require(data["outcomes"]["passed"] == len(ids) and all(value == 0 for key, value in data["outcomes"].items() if key != "passed"), "native outcome totals differ")
        return data
    producer = native("coverage-quality-evidence", "execution-test-results.json", "coverage-execution", "3.11")
    full313 = native("compatibility-3.13-evidence", "full-test-results-3.13.json", "full", "3.13")
    c_receipt = native("coverage-quality-evidence", "coverage-test-results.json", "coverage-quality", "3.11", True)
    b, c = producer["execution"]["behavioral_order"], producer["execution"]["coverage_order"]
    require(producer["execution"]["contract"] == "ordered-behavioral-v1" and len(b) == len(set(b)) and len(c) == len(set(c)), "producer contract/inventory differs")
    expected = b + [identity for identity in c if identity not in set(b)]
    require(producer["execution_order"] == expected and full313["execution_order"] == b, "B then C-minus-B/cross-Python B order differs")
    source_digest = sha(json.dumps(producer, sort_keys=True, separators=(",", ":")).encode())
    require(c_receipt["execution_order"] == c and c_receipt["execution"]["source_receipt_sha256"] == source_digest
            and c_receipt["python_version"] == producer["python_version"], "official C projection order/digest/Python differs")
    original = {row["canonical_id"]: row for row in producer["tests"]}
    for row in c_receipt["tests"]:
        actual = original[row["canonical_id"]]
        require(row["execution_id"] == actual["id"] and {key: value for key, value in row.items() if key not in ("id", "execution_id")}
                == {key: value for key, value in actual.items() if key != "id"}, "official C projection row differs")
    require(not any(a["name"] == "compatibility-3.11-evidence" for a in read("artifacts.json")["artifacts"]), "unexpected B projection needs explicit review")
    jobs = read("jobs.json")["jobs"]
    require(all(job["run_id"] == RUN and job["run_attempt"] == 1 and job["status"] == "completed" for job in jobs), "job identity/state differs")
    def job(name, conclusion):
        found = [row for row in jobs if row["name"] == name]
        require(len(found) == 1 and found[0]["conclusion"] == conclusion, "actual job status differs: " + name)
        return found[0]
    cov_job = job("coverage-quality (3.11)", "failure")
    steps = {step["name"]: step["conclusion"] for step in cov_job["steps"]}
    require(steps["Run ordered behavior and coverage-only cases once"] == steps["Export coverage evidence"] == "success"
            and steps["Enforce coverage obligations"] == "failure", "coverage execution/Enforce step states differ")
    job("compatibility (3.13)", "success")
    b_job = job("compatibility (3.11)", "failure")
    require(any(step["name"] == "Require the planned coverage producer" and step["conclusion"] == "failure" for step in b_job["steps"]), "3.11 compatibility failure cause differs")
    logs = []
    for name in ("coverage-quality (3.11)", "test (3.11)", "test (3.13)"):
        item = job(name, "failure")
        path = OUT / f"job-{item['id']}-raw.log"
        raw = path.read_bytes()
        text = raw.decode("utf-8-sig")
        errors = [line for line in text.splitlines() if "##[error]" in line or "ValueError:" in line]
        require(errors, "failure log contains no raw error")
        if name == "coverage-quality (3.11)":
            require("uncovered changed lines: src/research_workbench/adapters/models/provider_source_closure.py" in text, "actual Enforce coverage error differs")
        else:
            require("required job did not succeed:" in text, "aggregate dependency failure differs")
        logs.append({"job": name, "job_id": item["id"], "path": path.name, "sha256": sha(raw), "bytes": len(raw), "actual_error_lines": errors})
    counts = {"B": len(b), "C": len(c), "intersection": len(set(b) & set(c)), "C_minus_B": len(set(c) - set(b)), "union": len(set(b) | set(c))}
    save("inventories.json", {"B_order_actual_3_13_and_3_11_producer": b, "C_order_actual_3_11_producer_and_official_projection": c,
                              "producer_execution_order_actual": producer["execution_order"], "counts": counts})
    result = {"status": "PARTIAL_NATIVE_EXECUTION_PASS_QUALITY_GATE_FAIL", "run": RUN, "attempt": 1, "event": "workflow_dispatch", "head": HEAD, "base": BASE,
              "target": TARGET, "plan_id": PLAN, "overall_run_conclusion": "failure", "full_pipeline_pass": False, "quality_gate_pass": False,
              "authenticated_artifacts": artifacts, "native_member_bindings": bindings, "execution": counts,
              "verified_items": {"actual_3_13_full_native": "PASS", "actual_3_11_coverage_producer_native": "PASS", "B_order_cross_Python": "PASS",
                                 "B_then_C_minus_B_order_unique_union": "PASS", "official_3_11_C_projection_exact_rows_source_digest": "PASS"},
              "native_outcomes": {"3.13_full": {"python": full313["python_version"], "test_count": full313["test_count"], "outcomes": full313["outcomes"], "events": full313["events"]},
                                  "3.11_producer": {"python": producer["python_version"], "test_count": producer["test_count"], "outcomes": producer["outcomes"], "events": producer["events"]}},
              "official_3_11_B_projection": "ABSENT_NOT_EXECUTED_COMPATIBILITY_DEPENDENCY_GUARD_FAILED", "official_C_projection_case_count": c_receipt["test_count"],
              "coverage_gap": read("coverage-gap.json"), "raw_failure_logs": logs,
              "job_states": [{"name": row["name"], "id": row["id"], "conclusion": row["conclusion"]} for row in jobs],
              "repository_policy_gate": "NOT_PROVEN_IMPACT_CHECK_RAISED_FIRST", "coverage_policy_tool_executed_locally": False,
              "local_tests": 0, "local_producer_execution": 0, "success_only_auditor_or_cost_extractor_called": False,
              "native_full_success_directory_created": False, "native_inventory_limit": "Actual authenticated native inventories; no independent source-derived full TestLoader collection", "speedup_proved": False}
    save("summary.json", result)
    gap = result["coverage_gap"]
    report = f"""# Failed full: authenticated partial native evidence

PARTIAL_NATIVE_EXECUTION_PASS_QUALITY_GATE_FAIL. Run {RUN}/attempt1/head{HEAD}/base{BASE}/target{TARGET}/plan{PLAN}. Overall run remains failure; no full/quality PASS.

Actual 3.13 full native and 3.11 coverage producer passed their cases/checkpoints with zero failure/error/skip events. B={counts['B']}, C={counts['C']}, intersection={counts['intersection']}, C-minus-B={counts['C_minus_B']}, physical union={counts['union']}. Actual cross-Python B order and producer B then C-minus-B are equal/unique. Existing official C projection has exact source receipt digest, order and complete row equality. Full ordered arrays are preserved in inventories.json.

Official 3.11 B projection is absent: compatibility job {b_job['id']} failed its producer dependency guard; proof/download/upload steps were skipped. 3.11 actual B is observed within the producer, not a fabricated standalone projection or a passed compatibility job.

Coverage file: {gap['coverage_path']}; SHA256 {gap['coverage_sha256']}. Actual uncovered required lines: {gap['uncovered_required_lines']}; actual missing outgoing arcs from required lines: {gap['uncovered_required_outgoing_branches']}. Full source missing arrays and the official required set are in coverage-gap.json. These are impact gaps, not a proof of repository quality. Actual Enforce failed before repository policy could be proved; no local quality checker ran.

Original API run/artifact/target/job responses, two newly downloaded native ZIPs and cached official-plan ZIP are retained. All captured ZIPs passed API SHA/size, CRC and safe/canonical paths; each extracted member is SHA/size bound. Cached plan was not redownloaded. Exact target tree/ordered parents and canonical plan match. Three original API logs retain Enforce and both aggregate dependency failures; the root console copy was never substituted.

This directory records failed-run evidence only. No candidate/tests/producer/quality tool ran locally; no old evidence/worktree/success directory changed. Actual inventory is not an independent source-derived collection, no setup attribution or CI speedup is claimed. See summary.json for exact member/raw log hashes and only verified item PASS labels.
"""
    (OUT / "REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps({"status": result["status"], "execution": counts, "native_outcomes": result["native_outcomes"], "official_3_11_B_projection": result["official_3_11_B_projection"]}))


if __name__ == "__main__":
    main()
