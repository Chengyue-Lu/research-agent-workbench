"""One-shot failed-run raw capture; never runs candidate or quality code."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import subprocess
import traceback
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = "Chengyue-Lu/research-agent-workbench"
RUN = 37189042708
HEAD = "84ded7c5aba5872bbb273d429289aba288c9a8aa"
BASE = "c80ec014925f0cbbbaef5486bce8422a5b4f73fb"
TARGET = "787aea3e2adca8bc671d8cca3d23ec08ba4bad35"
PLAN = "70faacdbe652b3498f6567bb31085fb7d3539d9001d2dbf26a0731a778ed50b1"
TREE = "ac9ba2b532d5c6eb1413b5efb6784c2d7b659ed0"
SOURCE = "src/research_workbench/adapters/models/provider_source_closure.py"
commands = []
captured = []
members = {}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def api(label, endpoint, binary=False, suffix=None):
    path = OUT / (label + (suffix or (".zip" if binary else ".json")))
    require(not path.exists(), "no repeated API capture: " + label)
    argv = ["gh", "api", f"repos/{REPO}/" + endpoint]
    result = subprocess.run(argv, capture_output=True, timeout=90)
    path.write_bytes(result.stdout)
    (OUT / (label + ".stderr.log")).write_bytes(result.stderr)
    commands.append({"argv": argv, "returncode": result.returncode, "path": path.name, "sha256": sha(result.stdout), "bytes": len(result.stdout)})
    save("commands.json", commands)
    require(result.returncode == 0, "API failed; raw preserved: " + label)
    return result.stdout if binary else json.loads(result.stdout)


def artifact(item, cached=None):
    require(not item["expired"] and item["workflow_run"]["id"] == RUN and item["workflow_run"]["head_sha"] == HEAD, "artifact identity differs")
    label = f"artifact-{item['id']}"
    if cached:
        raw = cached.read_bytes()
        (OUT / (label + ".zip")).write_bytes(raw)
    else:
        raw = api(label, f"actions/artifacts/{item['id']}/zip", True)
    require(len(raw) == item["size_in_bytes"] and item["digest"] == "sha256:" + sha(raw), "artifact API SHA/size differs")
    folder = OUT / label
    folder.mkdir(exist_ok=False)
    manifest = []
    with zipfile.ZipFile(OUT / (label + ".zip")) as z:
        require(z.testzip() is None, "artifact CRC differs")
        require(len(z.namelist()) == len({n.casefold() for n in z.namelist()}), "ZIP duplicate/case collision")
        for info in z.infolist():
            pure = PurePosixPath(info.filename)
            require(info.filename and pure.as_posix() == info.filename.rstrip("/") and not pure.is_absolute() and ".." not in pure.parts and "\\" not in info.filename and ":" not in info.filename
                    and not stat.S_ISLNK(info.external_attr >> 16), "unsafe ZIP path")
            path = folder.joinpath(*pure.parts)
            require(path.resolve().is_relative_to(folder), "ZIP escapes output")
            if info.is_dir():
                path.mkdir(parents=True, exist_ok=True)
                continue
            data = z.read(info.filename)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            manifest.append({"path": info.filename, "sha256": sha(data), "bytes": len(data)})
            members[item["name"], info.filename] = path
    captured.append({"name": item["name"], "id": item["id"], "sha256": sha(raw), "bytes": len(raw), "cached_plan": bool(cached), "CRC": "PASS", "safe_paths": "PASS", "members": manifest})
    save("authenticated-artifacts.json", captured)


def capture():
    run = api("run", f"actions/runs/{RUN}")
    require((run["id"], run["head_sha"], run["event"], run["run_attempt"], run["status"], run["conclusion"])
            == (RUN, HEAD, "workflow_dispatch", 1, "completed", "failure"), "exact terminal failed run required")
    require(run["path"].split("@")[0] == ".github/workflows/ci.yml", "workflow differs")
    listing = api("artifacts", f"actions/runs/{RUN}/artifacts?per_page=100")
    require(listing["total_count"] <= 100, "artifact pagination unsupported")
    def selected(name, required=True):
        items = [item for item in listing["artifacts"] if item["name"] == name]
        require(len(items) == 1 if required else len(items) <= 1, "artifact missing/ambiguous: " + name)
        return items[0] if items else None
    artifact(selected("ci-plan"), ROOT / "full-plan/official-plan.zip")
    plan = json.loads(members["ci-plan", "ci-plan.json"].read_bytes())
    unsigned = dict(plan)
    pid = unsigned.pop("plan_id")
    require(pid == PLAN == sha((json.dumps(unsigned, sort_keys=True, ensure_ascii=True, separators=(",", ":")) + "\n").encode()), "canonical plan identity differs")
    require(plan["binding"] == {"base": BASE, "head": HEAD, "merge_base": BASE, "repository": REPO, "target": TARGET}, "exact plan source binding differs")
    require(plan["version"] == 4 and plan["behavioral_scope"] == "full" and plan["coverage_obligations"] == ["impact", "repository"]
            and plan["coverage_scope"] == "impact+repository" and not plan["blocked_reasons"], "full plan obligations differ")
    target = api("target-commit", f"git/commits/{TARGET}")
    require(target["sha"] == TARGET and target["tree"]["sha"] == TREE and [p["sha"] for p in target["parents"]] == [BASE, HEAD], "tested merge SHA/tree/parents differ")
    artifact(selected("coverage-quality-evidence"))
    coverage_path = members["coverage-quality-evidence", "coverage.json"]
    coverage = json.loads(coverage_path.read_bytes())
    require(coverage["meta"]["branch_coverage"] is True, "actual branch coverage absent")
    files = {key.replace("\\", "/").removeprefix("./"): value for key, value in coverage["files"].items()}
    require(len(files) == len(coverage["files"]) and SOURCE in files, "coverage source/path alias differs")
    row = files[SOURCE]
    required = set(plan["coverage_lines"][SOURCE])
    gap = {"status": "AUTHENTICATED_ACTUAL_COVERAGE_GAP_NOT_QUALITY_PASS", "run": RUN, "attempt": 1, "head": HEAD,
           "base": BASE, "target": TARGET, "tree": TREE, "plan_id": PLAN, "source": SOURCE,
           "source_sha256_from_committed_binding": "c309208fe89f09cb29f64470d1036693fb84fd97f300e8bf01fa05702ef759f3",
           "coverage_path": str(coverage_path), "coverage_sha256": sha(coverage_path.read_bytes()), "source_summary": row["summary"],
           "all_missing_lines": row["missing_lines"], "all_missing_branches": row["missing_branches"],
           "required_coverage_lines": sorted(required), "uncovered_required_lines": sorted(required & set(row["missing_lines"])),
           "uncovered_required_outgoing_branches": [arc for arc in row["missing_branches"] if arc[0] in required],
           "quality_gate_passed": False, "tests_executed_locally": 0}
    save("coverage-gap.json", gap)
    print(json.dumps(gap, ensure_ascii=False), flush=True)
    for name in ("compatibility-3.13-evidence", "compatibility-3.11-evidence"):
        item = selected(name, name.endswith("3.13-evidence"))
        if item:
            artifact(item)
    jobs = api("jobs", f"actions/runs/{RUN}/attempts/1/jobs?per_page=100")
    require(jobs["total_count"] <= 100, "job pagination unsupported")
    for job in jobs["jobs"]:
        if job["name"] in ("coverage-quality (3.11)", "test (3.11)", "test (3.13)"):
            api(f"job-{job['id']}-raw", f"actions/jobs/{job['id']}/logs", True, ".log")
    save("capture-state.json", {"status": "RAW_FAILED_RUN_CAPTURE_COMPLETE_NOT_NATIVE_PASS", "run": RUN, "head": HEAD, "base": BASE, "target": TARGET,
                               "plan_id": PLAN, "attempt": 1, "artifacts": captured, "tests": 0, "producer_execution": 0, "quality_tool_execution": 0})


if __name__ == "__main__":
    require(not (OUT / "run.json").exists(), "capture is one-shot; no overwrite/retry")
    try:
        capture()
    except Exception as exc:
        (OUT / "capture-failure.txt").write_text(traceback.format_exc(), encoding="utf-8")
        save("capture-state.json", {"status": "FAIL_CAPTURE_PARTIAL_RAW_PRESERVED", "reason": str(exc), "run": RUN, "head": HEAD, "native_or_quality_pass": False})
        raise
