# Failed full: authenticated partial native evidence

PARTIAL_NATIVE_EXECUTION_PASS_QUALITY_GATE_FAIL. Run 37189042708/attempt1/head84ded7c5aba5872bbb273d429289aba288c9a8aa/basec80ec014925f0cbbbaef5486bce8422a5b4f73fb/target787aea3e2adca8bc671d8cca3d23ec08ba4bad35/plan70faacdbe652b3498f6567bb31085fb7d3539d9001d2dbf26a0731a778ed50b1. Overall run remains failure; no full/quality PASS.

Actual 3.13 full native and 3.11 coverage producer passed their cases/checkpoints with zero failure/error/skip events. B=2042, C=2016, intersection=2016, C-minus-B=0, physical union=2042. Actual cross-Python B order and producer B then C-minus-B are equal/unique. Existing official C projection has exact source receipt digest, order and complete row equality. Full ordered arrays are preserved in inventories.json.

Official 3.11 B projection is absent: compatibility job 111409409350 failed its producer dependency guard; proof/download/upload steps were skipped. 3.11 actual B is observed within the producer, not a fabricated standalone projection or a passed compatibility job.

Coverage file: D:\lcy\develop\_assessments\rwb-ci-pr139-followup-20261004\full-failure-native\artifact-11299741295\coverage.json; SHA256 83afca5d4138b2bdce35460d470eea4d84053b5aebb3dd7886d85f30505a666b. Actual uncovered required lines: [76, 99, 701, 707, 710, 712, 719]; actual missing outgoing arcs from required lines: [[75, 76], [98, 99], [561, 560], [700, 701], [705, 707], [707, 703], [707, 710], [711, 712], [718, 719]]. Full source missing arrays and the official required set are in coverage-gap.json. These are impact gaps, not a proof of repository quality. Actual Enforce failed before repository policy could be proved; no local quality checker ran.

Original API run/artifact/target/job responses, two newly downloaded native ZIPs and cached official-plan ZIP are retained. All captured ZIPs passed API SHA/size, CRC and safe/canonical paths; each extracted member is SHA/size bound. Cached plan was not redownloaded. Exact target tree/ordered parents and canonical plan match. Three original API logs retain Enforce and both aggregate dependency failures; the root console copy was never substituted.

This directory records failed-run evidence only. No candidate/tests/producer/quality tool ran locally; no old evidence/worktree/success directory changed. Actual inventory is not an independent source-derived collection, no setup attribution or CI speedup is claimed. See summary.json for exact member/raw log hashes and only verified item PASS labels.
