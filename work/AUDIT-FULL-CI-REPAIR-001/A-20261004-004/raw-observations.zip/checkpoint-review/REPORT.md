# 候选84 fresh双Python full/repository checkpoint入口审查

PASS_STATIC_CHECKPOINT_PATH_REVIEW，blockers=[]。建议正常使用一次CI(ci.yml) workflow_dispatch，ref为回读确认的当前PR139 head分支，inputs.pr=139；预期head84ded7c5aba5872bbb273d429289aba288c9a8aa/basec80ec014925f0cbbbaef5486bce8422a5b4f73fb。未执行CI、API、测试、planner或候选import。10份文件读取及两critical文件再次hash、两missing路径确认，共14 scoped read attempts。ci.yml及plan_ci.py前后bytes SHA一致。

初始scripts/plan_ci.py和scripts/ci_profile.py不存在，仅filename discovery发现.github/scripts/plan_ci.py与ci_checkpoint.py及ci_checkpoint.yml；root明确扩读这些实际路径、run_component_ci profile段、make_plan/event_plan窄段和coverage_policy。未广扫/扩读其他owner。

ci_checkpoint.yml:61–64限定release-checkpoint仅develop；run_component_ci.py:87–98规定普通checkpoint只3.11，release-profile才双Py，但两者仍profile-result-only/diagnostic-only，实际结果:239 coverage=not-collected。因此候选不能调用release-checkpoint，也不能以普通checkpoint代替双Py/coverage gate。ci_checkpoint.py:63–66仅scheduled有旧fingerprint抑制，手动checkpoint不重签旧结果；这仍不补足其profile义务。

ci.yml:4–9已有PR手动入口，:66各job checkout refs/pull/139/merge。plan_ci.py:727–747精确PR编号、读取当前PR元数据、GITHUB_SHA必须等于当前PRhead，force_full=True；若checkout不是head，必须双亲顺序[base,head]。make_plan:429–438建立exact repository/base/head/merge_base/target绑定；:461–464显式complete-evidence request同时扩大behavioral和repository coverage；:695/707–709 full、双Py、package/repository smoke为true。真实新plan必须blocked_reasons=[]，coverage保留impact+repository及相应正负/critical义务。plan_id由:723对该计划生成，不能代用组件plan_sha256或旧c80 plan。当前component37187377157虽545绿，native summary仍full_repository=false、coverage_gate=false、merge_eligible=false。

本次读取当前coverage_policy v2.3.7 SHA05a47de90603c30db301232a8828971cbaeb003b7381dd293d3a464260c8f6fc，:152–160为impact line/branch100/100、global line90、critical line/branch95/90。planner:468–469读base和candidate策略，:605起保留base critical mappings并只允许安全增加义务；本审查未额外读取base policy blob，不能把当前WT policy hash误说成已独立核过base bytes。实际quality checker须按真实plan和冻结policy执行，不减阈值、exclusion或原预算。

执行及取证应覆盖：

- ci-plan artifact中的官方ci-plan.json，真实run/attempt/workflow_dispatch/GITHUB_SHA、PR base/head、当前merge双亲/tree、plan_id及policy/producer source身份。
- coverage-quality-evidence中的coverage.json、coverage-test-results.json、execution-test-results.json。ci.yml:233–251将ordered behavioral+coverage-only一次放在3.11 coverage-execution下，再运行ci_checks coverage强制真实impact/repository/critical质量门禁；missing projection/失败不能合成PASS。
- compatibility-3.11-evidence/full-test-results-3.11.json：:129–173消费同一次coverage producer的actual execution projection，避免重复跑3.11同一行为套件。compatibility-3.13-evidence/full-test-results-3.13.json：:175–205真实full独立执行。
- package-smoke3.11和3.13的实际producer/logs，以及repository_smoke的examples/registry验证success；workflow未声明独立package/repository artifact上传，不能虚构此类工件。
- test(3.11)/test(3.13):308–350各自ci_checks aggregate以同run实际CI_NEEDS验证全部义务；诊断ci-contract-shadow不替代这些gate。下载证据还应核API SHA/size/CRC、安全路径、官方plan绑定及原生完整/有序inventory，保留终态failure和缺失证据，不重签旧component/c80。

只dispatch ci.yml，不再触发ci_components或普通checkpoint。完整运行必然与旧组件方法有重合，但新增缺失的3.13 full和repository/coverage/package验收，并非用同scope green重复作证明。ci.yml:18–20 group=ci-content-139可取消同组in-progress非push；执行前root应确认没有进行中的旧full。它与ci-components-139 group不同。permissions contents/pull-requests read，所有checkout/步骤不推送、合并或改protected develop；source_governance仅push-develop激活，本次dispatch不伪作merged-source治理。DEVELOPMENT:58–65禁止直推main/develop，:191–198明确日常组件与完整checkpoint分工。

本报告给出可执行有界建议，不是fresh完整PASS、原hosted covered budget已修复或cross-owner接受。root后续已告知正常一次dispatch37189042708启动；此静态审查没有发起它，实际新plan/terminal证据将在后续独立步骤绑定。停止本审查。
